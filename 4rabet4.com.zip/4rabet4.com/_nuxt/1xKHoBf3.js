(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "691e0ca4-9b17-40da-beb4-83cd4f95eb4f", e._sentryDebugIdIdentifier = "sentry-dbid-691e0ca4-9b17-40da-beb4-83cd4f95eb4f")
    } catch {}
})();
const t = 1200,
    o = 359,
    r = 1140,
    f = 768;

function d(e, n) {
    if (typeof window < "u") return window.matchMedia(`(${n}-width: ${e}px)`)
}

function i(e) {
    return d(t, e)
}
export {
    t as D, r as L, o as M, f as T, i as c
};