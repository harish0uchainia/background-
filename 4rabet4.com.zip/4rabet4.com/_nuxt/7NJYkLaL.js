import {
    _ as q,
    bA as R,
    z as j,
    bB as z,
    h as G,
    bC as d
} from "./BbvgifQp.js";
import {
    _ as V,
    V as U,
    a0 as r,
    a7 as $,
    b as o
} from "./BBZLTf3A.js";
(function() {
    try {
        var s = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            w = new s.Error().stack;
        w && (s._sentryDebugIds = s._sentryDebugIds || {}, s._sentryDebugIds[w] = "d704ba4f-4d93-476a-8704-f0f97504d4f9", s._sentryDebugIdIdentifier = "sentry-dbid-d704ba4f-4d93-476a-8704-f0f97504d4f9")
    } catch {}
})();
const J = {
        __name: "Loader",
        props: {
            inButton: {
                type: Boolean,
                default: !1
            },
            isGlobal: {
                type: Boolean,
                default: !1
            }
        },
        setup(s) {
            return (w, l) => (U(), V("div", {
                class: $(["loader text-center", {
                    "loader_in-button": s.inButton,
                    loader_global: s.isGlobal
                }])
            }, l[0] || (l[0] = [r("div", {
                class: "lds-spinner"
            }, [r("div"), r("div"), r("div"), r("div"), r("div"), r("div"), r("div"), r("div"), r("div"), r("div"), r("div"), r("div")], -1)]), 2))
        }
    },
    X = q(J, [
        ["__scopeId", "data-v-994e387f"]
    ]),
    Y = R("withdrawal-store", () => {
        const {
            $API: s
        } = j(), {
            showNotification: w
        } = z(), {
            t: l
        } = G(), v = o(!1), y = o(null), p = o([]), W = o(null), m = o(null), D = o(null), _ = o([]), A = o(null), P = o(null), I = o(null), S = o(0), c = o(null);
        async function x(e) {
            try {
                const t = await s.ApiPayments.fetchWithdrawMethodsList(e),
                    a = t.data;
                return p.value = a.methods, W.value = a.translates, t.data
            } catch (t) {
                throw p.value = [], d(t), t
            }
        }
        async function C(e = 0) {
            try {
                return (await s.ApiPayments.fetchCalcCommission({
                    amount: e
                })).data
            } catch (t) {
                throw d(t), t
            }
        }
        async function O(e) {
            try {
                const t = await s.ApiPayments.fetchWithdrawMethodFields(e);
                return m.value = t.data, t.data
            } catch (t) {
                throw m.value = null, d(t), t
            }
        }
        async function M(e) {
            var t, a, n, f;
            try {
                const u = ["fail", "invalid", "limit", "notConfirmedAccount"],
                    i = await s.ApiPayments.createOrderToWithdraw(e),
                    {
                        status: h,
                        limit_count: g
                    } = i.data;
                if (u.includes(h)) {
                    let {
                        message: b
                    } = i.data;
                    return h === "limit" && g && (b = g === "1" ? l("dialogs.withdrawOnceDay.text") : l("withdraw.withdrawLimits", {
                        limit: g
                    })), y.value = "fail", w({
                        code: 400,
                        message: b
                    }), d(b), null
                }
                return y.value = "success", i.data
            } catch (u) {
                y.value = "fail";
                const i = u,
                    h = ((a = (t = i.response) == null ? void 0 : t.data) == null ? void 0 : a.message) === "Submitting a withdrawal request is available only once every 24 hours" ? l("dialogs.withdrawOnceDay.text") : (f = (n = i.response) == null ? void 0 : n.data) == null ? void 0 : f.message;
                throw w({
                    code: 400,
                    message: h
                }), d(u), u
            } finally {
                v.value = !1
            }
        }
        async function B(e) {
            try {
                const t = await s.ApiPayments.fetchDataForCrypto(e);
                return D.value = t.data, t.data
            } catch (t) {
                throw d(t), t
            }
        }
        async function T(e) {
            if (_.value.length) return _.value;
            try {
                const t = await s.ApiPayments.fetchPaymentMethodsImages(e);
                return _.value = t.data, t.data
            } catch (t) {
                throw d(t), t
            }
        }
        async function L(e) {
            try {
                const a = (await s.ApiPayments.fetchWithdrawOrderStatus(e)).data,
                    n = a.transaction_info;
                return a && a.status === "success" && (y.value = n.status === "processing" ? "in_queue" : n.status), a.data
            } catch (t) {
                throw d(t), t
            }
        }
        async function N(e) {
            try {
                const a = (await s.ApiPayments.fetchDepositStatus(e)).data,
                    n = a.transaction_info;
                return a && a.status === "success" && (I.value = n.status === "processing" ? "in_queue" : n.status, A.value = n.title, P.value = n.text), a.data
            } catch (t) {
                throw d(t), t
            }
        }
        async function E(e) {
            try {
                const a = (await s.ApiPayments.getWithdrawalList({ ...e && {
                        cursor: e
                    }
                })).data;
                return a && (c.value = { ...a,
                    data: e && c.value ? [...c.value.data, ...a.data] : a.data
                }), a
            } catch (t) {
                d(t)
            }
        }
        async function F(e) {
            var t, a, n;
            try {
                const f = await s.ApiPayments.rejectWithdrawOrder(e),
                    u = (a = (t = c.value) == null ? void 0 : t.data) == null ? void 0 : a.findIndex(i => {
                        var h;
                        return i.payout_id === ((h = f.data) == null ? void 0 : h.id)
                    });
                if (typeof u == "number" && u !== -1 && c.value) {
                    const i = [...c.value.data];
                    i[u] = { ...i[u],
                        status: (n = f.data) == null ? void 0 : n.status
                    }, c.value = { ...c.value,
                        data: i
                    }
                }
            } catch (f) {
                d(f)
            }
        }

        function H(e) {
            v.value = e
        }

        function k() {
            c.value = null
        }
        return {
            newWithdraw: v,
            setNewWithdraw: H,
            resetWithdrawHistory: k,
            withdrawOrderCreatingStatus: y,
            withdrawMethods: p,
            withdrawDialogTitles: W,
            withdrawMethodFields: m,
            fetchWithdrawMethodsList: x,
            fetchCalcCommission: C,
            fetchWithdrawMethodFields: O,
            createOrderToWithdraw: M,
            fetchDataForCrypto: B,
            fetchPaymentMethodsImages: T,
            fetchWithdrawOrderStatus: L,
            fetchWithdrawStatus: N,
            fetchWithdrawHistory: E,
            withdrawResultTitle: A,
            withdrawResultText: P,
            withdrawProcessStep: S,
            withdrawHistory: c,
            rejectWithdrawOrder: F
        }
    });
export {
    X as _, Y as u
};