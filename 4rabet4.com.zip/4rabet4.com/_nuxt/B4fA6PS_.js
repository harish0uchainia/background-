/* empty css        */
import {
    U as o,
    W as r,
    a2 as d,
    a3 as i,
    a4 as l,
    X as f,
    a5 as u,
    Y as c
} from "./BbvgifQp.js";
import {
    D as m
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            a = new e.Error().stack;
        a && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[a] = "08db7d79-afda-4ffe-877c-893119bab9ad", e._sentryDebugIdIdentifier = "sentry-dbid-08db7d79-afda-4ffe-877c-893119bab9ad")
    } catch {}
})();
const y = r({
        fluid: {
            type: Boolean,
            default: !1
        },
        ...c(),
        ...u(),
        ...f()
    }, "VContainer"),
    C = o()({
        name: "VContainer",
        props: y(),
        setup(e, a) {
            let {
                slots: n
            } = a;
            const {
                rtlClasses: s
            } = d(), {
                dimensionStyles: t
            } = i(e);
            return l(() => m(e.tag, {
                class: ["v-container", {
                    "v-container--fluid": e.fluid
                }, s.value, e.class],
                style: [t.value, e.style]
            }, n)), {}
        }
    });
export {
    C as V
};