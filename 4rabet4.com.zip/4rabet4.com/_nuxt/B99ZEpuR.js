(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            o = new e.Error().stack;
        o && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[o] = "668be723-4896-4029-9c6b-f1e3c7e67f86", e._sentryDebugIdIdentifier = "sentry-dbid-668be723-4896-4029-9c6b-f1e3c7e67f86")
    } catch {}
})();

function r() {
    return {
        scrollToTop: () => window == null ? void 0 : window.scrollTo(0, 0)
    }
}
export {
    r as u
};