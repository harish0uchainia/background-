import {
    c as d,
    m as P
} from "./D9sqA5Xl.js";
import {
    f as w
} from "./CbxP4vag.js";
import {
    U as I,
    W as h,
    a7 as S,
    a8 as D,
    a4 as O,
    aa as x
} from "./BbvgifQp.js";
import {
    u as T
} from "./B9YIqgoQ.js";
import {
    d as o,
    b as k,
    J as f,
    D as U
} from "./BBZLTf3A.js";
(function() {
    try {
        var t = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            a = new t.Error().stack;
        a && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[a] = "f050bb00-576a-4cd0-890f-25cec011b4d3", t._sentryDebugIdIdentifier = "sentry-dbid-f050bb00-576a-4cd0-890f-25cec011b4d3")
    } catch {}
})();
const A = h({
        id: String,
        text: String,
        ...x(P({
            closeOnBack: !1,
            location: "end",
            locationStrategy: "connected",
            eager: !0,
            minWidth: 0,
            offset: 10,
            openOnClick: !1,
            openOnHover: !0,
            origin: "auto",
            scrim: !1,
            scrollStrategy: "reposition",
            transition: !1
        }), ["absolute", "persistent"])
    }, "VTooltip"),
    F = I()({
        name: "VTooltip",
        props: A(),
        emits: {
            "update:modelValue": t => !0
        },
        setup(t, a) {
            let {
                slots: e
            } = a;
            const r = S(t, "modelValue"),
                {
                    scopeId: g
                } = T(),
                m = D(),
                l = o(() => t.id || `v-tooltip-${m}`),
                s = k(),
                v = o(() => t.location.split(" ").length > 1 ? t.location : t.location + " center"),
                b = o(() => t.origin === "auto" || t.origin === "overlap" || t.origin.split(" ").length > 1 || t.location.split(" ").length > 1 ? t.origin : t.origin + " center"),
                y = o(() => t.transition ? t.transition : r.value ? "scale-transition" : "fade-transition"),
                V = o(() => f({
                    "aria-describedby": l.value
                }, t.activatorProps));
            return O(() => {
                const p = d.filterProps(t);
                return U(d, f({
                    ref: s,
                    class: ["v-tooltip", t.class],
                    style: t.style,
                    id: l.value
                }, p, {
                    modelValue: r.value,
                    "onUpdate:modelValue": i => r.value = i,
                    transition: y.value,
                    absolute: !0,
                    location: v.value,
                    origin: b.value,
                    persistent: !0,
                    role: "tooltip",
                    activatorProps: V.value,
                    _disableGlobalStack: !0
                }, g), {
                    activator: e.activator,
                    default: function() {
                        var u;
                        for (var i = arguments.length, c = new Array(i), n = 0; n < i; n++) c[n] = arguments[n];
                        return ((u = e.default) == null ? void 0 : u.call(e, ...c)) ? ? t.text
                    }
                })
            }), w({}, s)
        }
    });
export {
    F as V
};