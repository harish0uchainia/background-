import {
    u as m,
    z as b,
    bD as I
} from "./BbvgifQp.js";
import {
    d as S,
    b as y,
    B as k
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "d5f88ec6-e992-408e-af37-3307670b56c3", e._sentryDebugIdIdentifier = "sentry-dbid-d5f88ec6-e992-408e-af37-3307670b56c3")
    } catch {}
})();

function _() {
    const {
        config: e
    } = m(), {
        $privateLog: t
    } = b(), {
        getUUID: s
    } = I(), a = S(() => s.value), o = y(null), d = e.value.APP_WITH_OPTIMOVE_SDK, c = {
        src: "https://sdk.optimove.net/websdk/?tenant_id=904",
        id: "optimoveSdk",
        async: !0
    }, i = () => {
        o.value || (o.value = (window == null ? void 0 : window.optimoveSDK) || null)
    }, f = {
        DEPOSIT_ATTEMPTS: (v, l = {}) => {
            var r, u;
            if (d) try {
                i(), (u = (r = o.value) == null ? void 0 : r.API) == null || u.setUserId(a.value, () => {
                    var n, p;
                    return (p = (n = o.value) == null ? void 0 : n.API) == null ? void 0 : p.reportEvent(v, l)
                })
            } catch (n) {
                t(n, "[optimoveSdkEvents] - depositAttempts")
            }
        }
    };
    return k(() => {
        i()
    }), {
        optimoveSdkScriptObj: c,
        appWithOptimoveSdk: d,
        optimoveSdkEvents: f
    }
}
export {
    _ as u
};