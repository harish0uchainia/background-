import {
    aE as d
} from "./BbvgifQp.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "73fe5488-c0f0-4910-be4b-303e1a57ca40", e._sentryDebugIdIdentifier = "sentry-dbid-73fe5488-c0f0-4910-be4b-303e1a57ca40")
    } catch {}
})();

function s() {
    const n = d("useScopeId").vnode.scopeId;
    return {
        scopeId: n ? {
            [n]: ""
        } : void 0
    }
}
export {
    s as u
};