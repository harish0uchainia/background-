/**
 * @vue/shared v3.5.13
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
/*! #__NO_SIDE_EFFECTS__ */
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "68aae913-b194-405e-8320-4efbba9a65e3", e._sentryDebugIdIdentifier = "sentry-dbid-68aae913-b194-405e-8320-4efbba9a65e3")
    } catch {}
})();

function us(e) {
    const t = Object.create(null);
    for (const n of e.split(",")) t[n] = 1;
    return n => n in t
}
const ee = {},
    Nt = [],
    He = () => {},
    _o = () => !1,
    Sn = e => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97),
    ds = e => e.startsWith("onUpdate:"),
    ae = Object.assign,
    ps = (e, t) => {
        const n = e.indexOf(t);
        n > -1 && e.splice(n, 1)
    },
    Mo = Object.prototype.hasOwnProperty,
    te = (e, t) => Mo.call(e, t),
    W = Array.isArray,
    $t = e => Xt(e) === "[object Map]",
    Yt = e => Xt(e) === "[object Set]",
    Vs = e => Xt(e) === "[object Date]",
    Po = e => Xt(e) === "[object RegExp]",
    q = e => typeof e == "function",
    le = e => typeof e == "string",
    je = e => typeof e == "symbol",
    ie = e => e !== null && typeof e == "object",
    hs = e => (ie(e) || q(e)) && q(e.then) && q(e.catch),
    Lr = Object.prototype.toString,
    Xt = e => Lr.call(e),
    Ao = e => Xt(e).slice(8, -1),
    Br = e => Xt(e) === "[object Object]",
    gs = e => le(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e,
    zt = us(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),
    ai = e => {
        const t = Object.create(null);
        return n => t[n] || (t[n] = e(n))
    },
    Io = /-(\w)/g,
    Le = ai(e => e.replace(Io, (t, n) => n ? n.toUpperCase() : "")),
    Oo = /\B([A-Z])/g,
    st = ai(e => e.replace(Oo, "-$1").toLowerCase()),
    fi = ai(e => e.charAt(0).toUpperCase() + e.slice(1)),
    zn = ai(e => e ? `on${fi(e)}` : ""),
    xe = (e, t) => !Object.is(e, t),
    Vt = (e, ...t) => {
        for (let n = 0; n < e.length; n++) e[n](...t)
    },
    Dr = (e, t, n, i = !1) => {
        Object.defineProperty(e, t, {
            configurable: !0,
            enumerable: !1,
            writable: i,
            value: n
        })
    },
    Wn = e => {
        const t = parseFloat(e);
        return isNaN(t) ? e : t
    },
    Fr = e => {
        const t = le(e) ? Number(e) : NaN;
        return isNaN(t) ? e : t
    };
let Hs;
const ci = () => Hs || (Hs = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});

function ui(e) {
    if (W(e)) {
        const t = {};
        for (let n = 0; n < e.length; n++) {
            const i = e[n],
                s = le(i) ? Fo(i) : ui(i);
            if (s)
                for (const r in s) t[r] = s[r]
        }
        return t
    } else if (le(e) || ie(e)) return e
}
const Lo = /;(?![^(]*\))/g,
    Bo = /:([^]+)/,
    Do = /\/\*[^]*?\*\//g;

function Fo(e) {
    const t = {};
    return e.replace(Do, "").split(Lo).forEach(n => {
        if (n) {
            const i = n.split(Bo);
            i.length > 1 && (t[i[0].trim()] = i[1].trim())
        }
    }), t
}

function di(e) {
    let t = "";
    if (le(e)) t = e;
    else if (W(e))
        for (let n = 0; n < e.length; n++) {
            const i = di(e[n]);
            i && (t += i + " ")
        } else if (ie(e))
            for (const n in e) e[n] && (t += n + " ");
    return t.trim()
}

function Ru(e) {
    if (!e) return null;
    let {
        class: t,
        style: n
    } = e;
    return t && !le(t) && (e.class = di(t)), n && (e.style = ui(n)), e
}
const Ro = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",
    No = us(Ro);

function Rr(e) {
    return !!e || e === ""
}

function $o(e, t) {
    if (e.length !== t.length) return !1;
    let n = !0;
    for (let i = 0; n && i < e.length; i++) n = Mt(e[i], t[i]);
    return n
}

function Mt(e, t) {
    if (e === t) return !0;
    let n = Vs(e),
        i = Vs(t);
    if (n || i) return n && i ? e.getTime() === t.getTime() : !1;
    if (n = je(e), i = je(t), n || i) return e === t;
    if (n = W(e), i = W(t), n || i) return n && i ? $o(e, t) : !1;
    if (n = ie(e), i = ie(t), n || i) {
        if (!n || !i) return !1;
        const s = Object.keys(e).length,
            r = Object.keys(t).length;
        if (s !== r) return !1;
        for (const l in e) {
            const a = e.hasOwnProperty(l),
                o = t.hasOwnProperty(l);
            if (a && !o || !a && o || !Mt(e[l], t[l])) return !1
        }
    }
    return String(e) === String(t)
}

function ms(e, t) {
    return e.findIndex(n => Mt(n, t))
}
const Nr = e => !!(e && e.__v_isRef === !0),
    zo = e => le(e) ? e : e == null ? "" : W(e) || ie(e) && (e.toString === Lr || !q(e.toString)) ? Nr(e) ? zo(e.value) : JSON.stringify(e, $r, 2) : String(e),
    $r = (e, t) => Nr(t) ? $r(e, t.value) : $t(t) ? {
        [`Map(${t.size})`]: [...t.entries()].reduce((n, [i, s], r) => (n[xi(i, r) + " =>"] = s, n), {})
    } : Yt(t) ? {
        [`Set(${t.size})`]: [...t.values()].map(n => xi(n))
    } : je(t) ? xi(t) : ie(t) && !W(t) && !Br(t) ? String(t) : t,
    xi = (e, t = "") => {
        var n;
        return je(e) ? `Symbol(${(n=e.description)!=null?n:t})` : e
    };
/**
 * @vue/reactivity v3.5.13
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
let we;
class zr {
    constructor(t = !1) {
        this.detached = t, this._active = !0, this.effects = [], this.cleanups = [], this._isPaused = !1, this.parent = we, !t && we && (this.index = (we.scopes || (we.scopes = [])).push(this) - 1)
    }
    get active() {
        return this._active
    }
    pause() {
        if (this._active) {
            this._isPaused = !0;
            let t, n;
            if (this.scopes)
                for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].pause();
            for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].pause()
        }
    }
    resume() {
        if (this._active && this._isPaused) {
            this._isPaused = !1;
            let t, n;
            if (this.scopes)
                for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].resume();
            for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].resume()
        }
    }
    run(t) {
        if (this._active) {
            const n = we;
            try {
                return we = this, t()
            } finally {
                we = n
            }
        }
    }
    on() {
        we = this
    }
    off() {
        we = this.parent
    }
    stop(t) {
        if (this._active) {
            this._active = !1;
            let n, i;
            for (n = 0, i = this.effects.length; n < i; n++) this.effects[n].stop();
            for (this.effects.length = 0, n = 0, i = this.cleanups.length; n < i; n++) this.cleanups[n]();
            if (this.cleanups.length = 0, this.scopes) {
                for (n = 0, i = this.scopes.length; n < i; n++) this.scopes[n].stop(!0);
                this.scopes.length = 0
            }
            if (!this.detached && this.parent && !t) {
                const s = this.parent.scopes.pop();
                s && s !== this && (this.parent.scopes[this.index] = s, s.index = this.index)
            }
            this.parent = void 0
        }
    }
}

function Nu(e) {
    return new zr(e)
}

function Vo() {
    return we
}

function $u(e, t = !1) {
    we && we.cleanups.push(e)
}
let re;
const Ei = new WeakSet;
class Vr {
    constructor(t) {
        this.fn = t, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, we && we.active && we.effects.push(this)
    }
    pause() {
        this.flags |= 64
    }
    resume() {
        this.flags & 64 && (this.flags &= -65, Ei.has(this) && (Ei.delete(this), this.trigger()))
    }
    notify() {
        this.flags & 2 && !(this.flags & 32) || this.flags & 8 || kr(this)
    }
    run() {
        if (!(this.flags & 1)) return this.fn();
        this.flags |= 2, ks(this), jr(this);
        const t = re,
            n = ke;
        re = this, ke = !0;
        try {
            return this.fn()
        } finally {
            Gr(this), re = t, ke = n, this.flags &= -3
        }
    }
    stop() {
        if (this.flags & 1) {
            for (let t = this.deps; t; t = t.nextDep) bs(t);
            this.deps = this.depsTail = void 0, ks(this), this.onStop && this.onStop(), this.flags &= -2
        }
    }
    trigger() {
        this.flags & 64 ? Ei.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty()
    }
    runIfDirty() {
        Gi(this) && this.run()
    }
    get dirty() {
        return Gi(this)
    }
}
let Hr = 0,
    an, fn;

function kr(e, t = !1) {
    if (e.flags |= 8, t) {
        e.next = fn, fn = e;
        return
    }
    e.next = an, an = e
}

function vs() {
    Hr++
}

function ys() {
    if (--Hr > 0) return;
    if (fn) {
        let t = fn;
        for (fn = void 0; t;) {
            const n = t.next;
            t.next = void 0, t.flags &= -9, t = n
        }
    }
    let e;
    for (; an;) {
        let t = an;
        for (an = void 0; t;) {
            const n = t.next;
            if (t.next = void 0, t.flags &= -9, t.flags & 1) try {
                t.trigger()
            } catch (i) {
                e || (e = i)
            }
            t = n
        }
    }
    if (e) throw e
}

function jr(e) {
    for (let t = e.deps; t; t = t.nextDep) t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t
}

function Gr(e) {
    let t, n = e.depsTail,
        i = n;
    for (; i;) {
        const s = i.prevDep;
        i.version === -1 ? (i === n && (n = s), bs(i), Ho(i)) : t = i, i.dep.activeLink = i.prevActiveLink, i.prevActiveLink = void 0, i = s
    }
    e.deps = t, e.depsTail = n
}

function Gi(e) {
    for (let t = e.deps; t; t = t.nextDep)
        if (t.dep.version !== t.version || t.dep.computed && (Wr(t.dep.computed) || t.dep.version !== t.version)) return !0;
    return !!e._dirty
}

function Wr(e) {
    if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === hn)) return;
    e.globalVersion = hn;
    const t = e.dep;
    if (e.flags |= 2, t.version > 0 && !e.isSSR && e.deps && !Gi(e)) {
        e.flags &= -3;
        return
    }
    const n = re,
        i = ke;
    re = e, ke = !0;
    try {
        jr(e);
        const s = e.fn(e._value);
        (t.version === 0 || xe(s, e._value)) && (e._value = s, t.version++)
    } catch (s) {
        throw t.version++, s
    } finally {
        re = n, ke = i, Gr(e), e.flags &= -3
    }
}

function bs(e, t = !1) {
    const {
        dep: n,
        prevSub: i,
        nextSub: s
    } = e;
    if (i && (i.nextSub = s, e.prevSub = void 0), s && (s.prevSub = i, e.nextSub = void 0), n.subs === e && (n.subs = i, !i && n.computed)) {
        n.computed.flags &= -5;
        for (let r = n.computed.deps; r; r = r.nextDep) bs(r, !0)
    }!t && !--n.sc && n.map && n.map.delete(n.key)
}

function Ho(e) {
    const {
        prevDep: t,
        nextDep: n
    } = e;
    t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0)
}
let ke = !0;
const Ur = [];

function vt() {
    Ur.push(ke), ke = !1
}

function yt() {
    const e = Ur.pop();
    ke = e === void 0 ? !0 : e
}

function ks(e) {
    const {
        cleanup: t
    } = e;
    if (e.cleanup = void 0, t) {
        const n = re;
        re = void 0;
        try {
            t()
        } finally {
            re = n
        }
    }
}
let hn = 0;
class ko {
    constructor(t, n) {
        this.sub = t, this.dep = n, this.version = n.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0
    }
}
class pi {
    constructor(t) {
        this.computed = t, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0
    }
    track(t) {
        if (!re || !ke || re === this.computed) return;
        let n = this.activeLink;
        if (n === void 0 || n.sub !== re) n = this.activeLink = new ko(re, this), re.deps ? (n.prevDep = re.depsTail, re.depsTail.nextDep = n, re.depsTail = n) : re.deps = re.depsTail = n, Kr(n);
        else if (n.version === -1 && (n.version = this.version, n.nextDep)) {
            const i = n.nextDep;
            i.prevDep = n.prevDep, n.prevDep && (n.prevDep.nextDep = i), n.prevDep = re.depsTail, n.nextDep = void 0, re.depsTail.nextDep = n, re.depsTail = n, re.deps === n && (re.deps = i)
        }
        return n
    }
    trigger(t) {
        this.version++, hn++, this.notify(t)
    }
    notify(t) {
        vs();
        try {
            for (let n = this.subs; n; n = n.prevSub) n.sub.notify() && n.sub.dep.notify()
        } finally {
            ys()
        }
    }
}

function Kr(e) {
    if (e.dep.sc++, e.sub.flags & 4) {
        const t = e.dep.computed;
        if (t && !e.dep.subs) {
            t.flags |= 20;
            for (let i = t.deps; i; i = i.nextDep) Kr(i)
        }
        const n = e.dep.subs;
        n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subs = e
    }
}
const Un = new WeakMap,
    Tt = Symbol(""),
    Wi = Symbol(""),
    gn = Symbol("");

function ve(e, t, n) {
    if (ke && re) {
        let i = Un.get(e);
        i || Un.set(e, i = new Map);
        let s = i.get(n);
        s || (i.set(n, s = new pi), s.map = i, s.key = n), s.track()
    }
}

function et(e, t, n, i, s, r) {
    const l = Un.get(e);
    if (!l) {
        hn++;
        return
    }
    const a = o => {
        o && o.trigger()
    };
    if (vs(), t === "clear") l.forEach(a);
    else {
        const o = W(e),
            d = o && gs(n);
        if (o && n === "length") {
            const f = Number(i);
            l.forEach((u, m) => {
                (m === "length" || m === gn || !je(m) && m >= f) && a(u)
            })
        } else switch ((n !== void 0 || l.has(void 0)) && a(l.get(n)), d && a(l.get(gn)), t) {
            case "add":
                o ? d && a(l.get("length")) : (a(l.get(Tt)), $t(e) && a(l.get(Wi)));
                break;
            case "delete":
                o || (a(l.get(Tt)), $t(e) && a(l.get(Wi)));
                break;
            case "set":
                $t(e) && a(l.get(Tt));
                break
        }
    }
    ys()
}

function jo(e, t) {
    const n = Un.get(e);
    return n && n.get(t)
}

function Bt(e) {
    const t = Q(e);
    return t === e ? t : (ve(t, "iterate", gn), Ne(e) ? t : t.map(ye))
}

function hi(e) {
    return ve(e = Q(e), "iterate", gn), e
}
const Go = {
    __proto__: null,
    [Symbol.iterator]() {
        return Ci(this, Symbol.iterator, ye)
    },
    concat(...e) {
        return Bt(this).concat(...e.map(t => W(t) ? Bt(t) : t))
    },
    entries() {
        return Ci(this, "entries", e => (e[1] = ye(e[1]), e))
    },
    every(e, t) {
        return Je(this, "every", e, t, void 0, arguments)
    },
    filter(e, t) {
        return Je(this, "filter", e, t, n => n.map(ye), arguments)
    },
    find(e, t) {
        return Je(this, "find", e, t, ye, arguments)
    },
    findIndex(e, t) {
        return Je(this, "findIndex", e, t, void 0, arguments)
    },
    findLast(e, t) {
        return Je(this, "findLast", e, t, ye, arguments)
    },
    findLastIndex(e, t) {
        return Je(this, "findLastIndex", e, t, void 0, arguments)
    },
    forEach(e, t) {
        return Je(this, "forEach", e, t, void 0, arguments)
    },
    includes(...e) {
        return _i(this, "includes", e)
    },
    indexOf(...e) {
        return _i(this, "indexOf", e)
    },
    join(e) {
        return Bt(this).join(e)
    },
    lastIndexOf(...e) {
        return _i(this, "lastIndexOf", e)
    },
    map(e, t) {
        return Je(this, "map", e, t, void 0, arguments)
    },
    pop() {
        return tn(this, "pop")
    },
    push(...e) {
        return tn(this, "push", e)
    },
    reduce(e, ...t) {
        return js(this, "reduce", e, t)
    },
    reduceRight(e, ...t) {
        return js(this, "reduceRight", e, t)
    },
    shift() {
        return tn(this, "shift")
    },
    some(e, t) {
        return Je(this, "some", e, t, void 0, arguments)
    },
    splice(...e) {
        return tn(this, "splice", e)
    },
    toReversed() {
        return Bt(this).toReversed()
    },
    toSorted(e) {
        return Bt(this).toSorted(e)
    },
    toSpliced(...e) {
        return Bt(this).toSpliced(...e)
    },
    unshift(...e) {
        return tn(this, "unshift", e)
    },
    values() {
        return Ci(this, "values", ye)
    }
};

function Ci(e, t, n) {
    const i = hi(e),
        s = i[t]();
    return i !== e && !Ne(e) && (s._next = s.next, s.next = () => {
        const r = s._next();
        return r.value && (r.value = n(r.value)), r
    }), s
}
const Wo = Array.prototype;

function Je(e, t, n, i, s, r) {
    const l = hi(e),
        a = l !== e && !Ne(e),
        o = l[t];
    if (o !== Wo[t]) {
        const u = o.apply(e, r);
        return a ? ye(u) : u
    }
    let d = n;
    l !== e && (a ? d = function(u, m) {
        return n.call(this, ye(u), m, e)
    } : n.length > 2 && (d = function(u, m) {
        return n.call(this, u, m, e)
    }));
    const f = o.call(l, d, i);
    return a && s ? s(f) : f
}

function js(e, t, n, i) {
    const s = hi(e);
    let r = n;
    return s !== e && (Ne(e) ? n.length > 3 && (r = function(l, a, o) {
        return n.call(this, l, a, o, e)
    }) : r = function(l, a, o) {
        return n.call(this, l, ye(a), o, e)
    }), s[t](r, ...i)
}

function _i(e, t, n) {
    const i = Q(e);
    ve(i, "iterate", gn);
    const s = i[t](...n);
    return (s === -1 || s === !1) && xs(n[0]) ? (n[0] = Q(n[0]), i[t](...n)) : s
}

function tn(e, t, n = []) {
    vt(), vs();
    const i = Q(e)[t].apply(e, n);
    return ys(), yt(), i
}
const Uo = us("__proto__,__v_isRef,__isVue"),
    qr = new Set(Object.getOwnPropertyNames(Symbol).filter(e => e !== "arguments" && e !== "caller").map(e => Symbol[e]).filter(je));

function Ko(e) {
    je(e) || (e = String(e));
    const t = Q(this);
    return ve(t, "has", e), t.hasOwnProperty(e)
}
class Yr {
    constructor(t = !1, n = !1) {
        this._isReadonly = t, this._isShallow = n
    }
    get(t, n, i) {
        if (n === "__v_skip") return t.__v_skip;
        const s = this._isReadonly,
            r = this._isShallow;
        if (n === "__v_isReactive") return !s;
        if (n === "__v_isReadonly") return s;
        if (n === "__v_isShallow") return r;
        if (n === "__v_raw") return i === (s ? r ? ia : Qr : r ? Zr : Jr).get(t) || Object.getPrototypeOf(t) === Object.getPrototypeOf(i) ? t : void 0;
        const l = W(t);
        if (!s) {
            let o;
            if (l && (o = Go[n])) return o;
            if (n === "hasOwnProperty") return Ko
        }
        const a = Reflect.get(t, n, he(t) ? t : i);
        return (je(n) ? qr.has(n) : Uo(n)) || (s || ve(t, "get", n), r) ? a : he(a) ? l && gs(n) ? a : a.value : ie(a) ? s ? el(a) : Ss(a) : a
    }
}
class Xr extends Yr {
    constructor(t = !1) {
        super(!1, t)
    }
    set(t, n, i, s) {
        let r = t[n];
        if (!this._isShallow) {
            const o = Pt(r);
            if (!Ne(i) && !Pt(i) && (r = Q(r), i = Q(i)), !W(t) && he(r) && !he(i)) return o ? !1 : (r.value = i, !0)
        }
        const l = W(t) && gs(n) ? Number(n) < t.length : te(t, n),
            a = Reflect.set(t, n, i, he(t) ? t : s);
        return t === Q(s) && (l ? xe(i, r) && et(t, "set", n, i) : et(t, "add", n, i)), a
    }
    deleteProperty(t, n) {
        const i = te(t, n);
        t[n];
        const s = Reflect.deleteProperty(t, n);
        return s && i && et(t, "delete", n, void 0), s
    }
    has(t, n) {
        const i = Reflect.has(t, n);
        return (!je(n) || !qr.has(n)) && ve(t, "has", n), i
    }
    ownKeys(t) {
        return ve(t, "iterate", W(t) ? "length" : Tt), Reflect.ownKeys(t)
    }
}
class qo extends Yr {
    constructor(t = !1) {
        super(!0, t)
    }
    set(t, n) {
        return !0
    }
    deleteProperty(t, n) {
        return !0
    }
}
const Yo = new Xr,
    Xo = new qo,
    Jo = new Xr(!0);
const Ui = e => e,
    Pn = e => Reflect.getPrototypeOf(e);

function Zo(e, t, n) {
    return function(...i) {
        const s = this.__v_raw,
            r = Q(s),
            l = $t(r),
            a = e === "entries" || e === Symbol.iterator && l,
            o = e === "keys" && l,
            d = s[e](...i),
            f = n ? Ui : t ? Ki : ye;
        return !t && ve(r, "iterate", o ? Wi : Tt), {
            next() {
                const {
                    value: u,
                    done: m
                } = d.next();
                return m ? {
                    value: u,
                    done: m
                } : {
                    value: a ? [f(u[0]), f(u[1])] : f(u),
                    done: m
                }
            },
            [Symbol.iterator]() {
                return this
            }
        }
    }
}

function An(e) {
    return function(...t) {
        return e === "delete" ? !1 : e === "clear" ? void 0 : this
    }
}

function Qo(e, t) {
    const n = {
        get(s) {
            const r = this.__v_raw,
                l = Q(r),
                a = Q(s);
            e || (xe(s, a) && ve(l, "get", s), ve(l, "get", a));
            const {
                has: o
            } = Pn(l), d = t ? Ui : e ? Ki : ye;
            if (o.call(l, s)) return d(r.get(s));
            if (o.call(l, a)) return d(r.get(a));
            r !== l && r.get(s)
        },
        get size() {
            const s = this.__v_raw;
            return !e && ve(Q(s), "iterate", Tt), Reflect.get(s, "size", s)
        },
        has(s) {
            const r = this.__v_raw,
                l = Q(r),
                a = Q(s);
            return e || (xe(s, a) && ve(l, "has", s), ve(l, "has", a)), s === a ? r.has(s) : r.has(s) || r.has(a)
        },
        forEach(s, r) {
            const l = this,
                a = l.__v_raw,
                o = Q(a),
                d = t ? Ui : e ? Ki : ye;
            return !e && ve(o, "iterate", Tt), a.forEach((f, u) => s.call(r, d(f), d(u), l))
        }
    };
    return ae(n, e ? {
        add: An("add"),
        set: An("set"),
        delete: An("delete"),
        clear: An("clear")
    } : {
        add(s) {
            !t && !Ne(s) && !Pt(s) && (s = Q(s));
            const r = Q(this);
            return Pn(r).has.call(r, s) || (r.add(s), et(r, "add", s, s)), this
        },
        set(s, r) {
            !t && !Ne(r) && !Pt(r) && (r = Q(r));
            const l = Q(this),
                {
                    has: a,
                    get: o
                } = Pn(l);
            let d = a.call(l, s);
            d || (s = Q(s), d = a.call(l, s));
            const f = o.call(l, s);
            return l.set(s, r), d ? xe(r, f) && et(l, "set", s, r) : et(l, "add", s, r), this
        },
        delete(s) {
            const r = Q(this),
                {
                    has: l,
                    get: a
                } = Pn(r);
            let o = l.call(r, s);
            o || (s = Q(s), o = l.call(r, s)), a && a.call(r, s);
            const d = r.delete(s);
            return o && et(r, "delete", s, void 0), d
        },
        clear() {
            const s = Q(this),
                r = s.size !== 0,
                l = s.clear();
            return r && et(s, "clear", void 0, void 0), l
        }
    }), ["keys", "values", "entries", Symbol.iterator].forEach(s => {
        n[s] = Zo(s, e, t)
    }), n
}

function ws(e, t) {
    const n = Qo(e, t);
    return (i, s, r) => s === "__v_isReactive" ? !e : s === "__v_isReadonly" ? e : s === "__v_raw" ? i : Reflect.get(te(n, s) && s in i ? n : i, s, r)
}
const ea = {
        get: ws(!1, !1)
    },
    ta = {
        get: ws(!1, !0)
    },
    na = {
        get: ws(!0, !1)
    };
const Jr = new WeakMap,
    Zr = new WeakMap,
    Qr = new WeakMap,
    ia = new WeakMap;

function sa(e) {
    switch (e) {
        case "Object":
        case "Array":
            return 1;
        case "Map":
        case "Set":
        case "WeakMap":
        case "WeakSet":
            return 2;
        default:
            return 0
    }
}

function ra(e) {
    return e.__v_skip || !Object.isExtensible(e) ? 0 : sa(Ao(e))
}

function Ss(e) {
    return Pt(e) ? e : Ts(e, !1, Yo, ea, Jr)
}

function la(e) {
    return Ts(e, !1, Jo, ta, Zr)
}

function el(e) {
    return Ts(e, !0, Xo, na, Qr)
}

function Ts(e, t, n, i, s) {
    if (!ie(e) || e.__v_raw && !(t && e.__v_isReactive)) return e;
    const r = s.get(e);
    if (r) return r;
    const l = ra(e);
    if (l === 0) return e;
    const a = new Proxy(e, l === 2 ? i : n);
    return s.set(e, a), a
}

function xt(e) {
    return Pt(e) ? xt(e.__v_raw) : !!(e && e.__v_isReactive)
}

function Pt(e) {
    return !!(e && e.__v_isReadonly)
}

function Ne(e) {
    return !!(e && e.__v_isShallow)
}

function xs(e) {
    return e ? !!e.__v_raw : !1
}

function Q(e) {
    const t = e && e.__v_raw;
    return t ? Q(t) : e
}

function oa(e) {
    return !te(e, "__v_skip") && Object.isExtensible(e) && Dr(e, "__v_skip", !0), e
}
const ye = e => ie(e) ? Ss(e) : e,
    Ki = e => ie(e) ? el(e) : e;

function he(e) {
    return e ? e.__v_isRef === !0 : !1
}

function pe(e) {
    return tl(e, !1)
}

function aa(e) {
    return tl(e, !0)
}

function tl(e, t) {
    return he(e) ? e : new fa(e, t)
}
class fa {
    constructor(t, n) {
        this.dep = new pi, this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = n ? t : Q(t), this._value = n ? t : ye(t), this.__v_isShallow = n
    }
    get value() {
        return this.dep.track(), this._value
    }
    set value(t) {
        const n = this._rawValue,
            i = this.__v_isShallow || Ne(t) || Pt(t);
        t = i ? t : Q(t), xe(t, n) && (this._rawValue = t, this._value = i ? t : ye(t), this.dep.trigger())
    }
}

function nl(e) {
    return he(e) ? e.value : e
}

function zu(e) {
    return q(e) ? e() : nl(e)
}
const ca = {
    get: (e, t, n) => t === "__v_raw" ? e : nl(Reflect.get(e, t, n)),
    set: (e, t, n, i) => {
        const s = e[t];
        return he(s) && !he(n) ? (s.value = n, !0) : Reflect.set(e, t, n, i)
    }
};

function il(e) {
    return xt(e) ? e : new Proxy(e, ca)
}
class ua {
    constructor(t) {
        this.__v_isRef = !0, this._value = void 0;
        const n = this.dep = new pi,
            {
                get: i,
                set: s
            } = t(n.track.bind(n), n.trigger.bind(n));
        this._get = i, this._set = s
    }
    get value() {
        return this._value = this._get()
    }
    set value(t) {
        this._set(t)
    }
}

function da(e) {
    return new ua(e)
}

function Vu(e) {
    const t = W(e) ? new Array(e.length) : {};
    for (const n in e) t[n] = sl(e, n);
    return t
}
class pa {
    constructor(t, n, i) {
        this._object = t, this._key = n, this._defaultValue = i, this.__v_isRef = !0, this._value = void 0
    }
    get value() {
        const t = this._object[this._key];
        return this._value = t === void 0 ? this._defaultValue : t
    }
    set value(t) {
        this._object[this._key] = t
    }
    get dep() {
        return jo(Q(this._object), this._key)
    }
}
class ha {
    constructor(t) {
        this._getter = t, this.__v_isRef = !0, this.__v_isReadonly = !0, this._value = void 0
    }
    get value() {
        return this._value = this._getter()
    }
}

function Hu(e, t, n) {
    return he(e) ? e : q(e) ? new ha(e) : ie(e) && arguments.length > 1 ? sl(e, t, n) : pe(e)
}

function sl(e, t, n) {
    const i = e[t];
    return he(i) ? i : new pa(e, t, n)
}
class ga {
    constructor(t, n, i) {
        this.fn = t, this.setter = n, this._value = void 0, this.dep = new pi(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = hn - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !n, this.isSSR = i
    }
    notify() {
        if (this.flags |= 16, !(this.flags & 8) && re !== this) return kr(this, !0), !0
    }
    get value() {
        const t = this.dep.track();
        return Wr(this), t && (t.version = this.dep.version), this._value
    }
    set value(t) {
        this.setter && this.setter(t)
    }
}

function ma(e, t, n = !1) {
    let i, s;
    return q(e) ? i = e : (i = e.get, s = e.set), new ga(i, s, n)
}
const In = {},
    Kn = new WeakMap;
let St;

function va(e, t = !1, n = St) {
    if (n) {
        let i = Kn.get(n);
        i || Kn.set(n, i = []), i.push(e)
    }
}

function ya(e, t, n = ee) {
    const {
        immediate: i,
        deep: s,
        once: r,
        scheduler: l,
        augmentJob: a,
        call: o
    } = n, d = p => s ? p : Ne(p) || s === !1 || s === 0 ? tt(p, 1) : tt(p);
    let f, u, m, g, S = !1,
        v = !1;
    if (he(e) ? (u = () => e.value, S = Ne(e)) : xt(e) ? (u = () => d(e), S = !0) : W(e) ? (v = !0, S = e.some(p => xt(p) || Ne(p)), u = () => e.map(p => {
            if (he(p)) return p.value;
            if (xt(p)) return d(p);
            if (q(p)) return o ? o(p, 2) : p()
        })) : q(e) ? t ? u = o ? () => o(e, 2) : e : u = () => {
            if (m) {
                vt();
                try {
                    m()
                } finally {
                    yt()
                }
            }
            const p = St;
            St = f;
            try {
                return o ? o(e, 3, [g]) : e(g)
            } finally {
                St = p
            }
        } : u = He, t && s) {
        const p = u,
            w = s === !0 ? 1 / 0 : s;
        u = () => tt(p(), w)
    }
    const E = Vo(),
        x = () => {
            f.stop(), E && E.active && ps(E.effects, f)
        };
    if (r && t) {
        const p = t;
        t = (...w) => {
            p(...w), x()
        }
    }
    let h = v ? new Array(e.length).fill(In) : In;
    const c = p => {
        if (!(!(f.flags & 1) || !f.dirty && !p))
            if (t) {
                const w = f.run();
                if (s || S || (v ? w.some((C, P) => xe(C, h[P])) : xe(w, h))) {
                    m && m();
                    const C = St;
                    St = f;
                    try {
                        const P = [w, h === In ? void 0 : v && h[0] === In ? [] : h, g];
                        o ? o(t, 3, P) : t(...P), h = w
                    } finally {
                        St = C
                    }
                }
            } else f.run()
    };
    return a && a(c), f = new Vr(u), f.scheduler = l ? () => l(c, !1) : c, g = p => va(p, !1, f), m = f.onStop = () => {
        const p = Kn.get(f);
        if (p) {
            if (o) o(p, 4);
            else
                for (const w of p) w();
            Kn.delete(f)
        }
    }, t ? i ? c(!0) : h = f.run() : l ? l(c.bind(null, !0), !0) : f.run(), x.pause = f.pause.bind(f), x.resume = f.resume.bind(f), x.stop = x, x
}

function tt(e, t = 1 / 0, n) {
    if (t <= 0 || !ie(e) || e.__v_skip || (n = n || new Set, n.has(e))) return e;
    if (n.add(e), t--, he(e)) tt(e.value, t, n);
    else if (W(e))
        for (let i = 0; i < e.length; i++) tt(e[i], t, n);
    else if (Yt(e) || $t(e)) e.forEach(i => {
        tt(i, t, n)
    });
    else if (Br(e)) {
        for (const i in e) tt(e[i], t, n);
        for (const i of Object.getOwnPropertySymbols(e)) Object.prototype.propertyIsEnumerable.call(e, i) && tt(e[i], t, n)
    }
    return e
}
/**
 * @vue/runtime-core v3.5.13
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
function Tn(e, t, n, i) {
    try {
        return i ? e(...i) : e()
    } catch (s) {
        Jt(s, t, n)
    }
}

function Ge(e, t, n, i) {
    if (q(e)) {
        const s = Tn(e, t, n, i);
        return s && hs(s) && s.catch(r => {
            Jt(r, t, n)
        }), s
    }
    if (W(e)) {
        const s = [];
        for (let r = 0; r < e.length; r++) s.push(Ge(e[r], t, n, i));
        return s
    }
}

function Jt(e, t, n, i = !0) {
    const s = t ? t.vnode : null,
        {
            errorHandler: r,
            throwUnhandledErrorInProduction: l
        } = t && t.appContext.config || ee;
    if (t) {
        let a = t.parent;
        const o = t.proxy,
            d = `https://vuejs.org/error-reference/#runtime-${n}`;
        for (; a;) {
            const f = a.ec;
            if (f) {
                for (let u = 0; u < f.length; u++)
                    if (f[u](e, o, d) === !1) return
            }
            a = a.parent
        }
        if (r) {
            vt(), Tn(r, null, 10, [e, o, d]), yt();
            return
        }
    }
    ba(e, n, s, i, l)
}

function ba(e, t, n, i = !0, s = !1) {
    if (s) throw e;
    console.error(e)
}
const Se = [];
let Ke = -1;
const Ht = [];
let ft = null,
    Ft = 0;
const rl = Promise.resolve();
let qn = null;

function Es(e) {
    const t = qn || rl;
    return e ? t.then(this ? e.bind(this) : e) : t
}

function wa(e) {
    let t = Ke + 1,
        n = Se.length;
    for (; t < n;) {
        const i = t + n >>> 1,
            s = Se[i],
            r = mn(s);
        r < e || r === e && s.flags & 2 ? t = i + 1 : n = i
    }
    return t
}

function Cs(e) {
    if (!(e.flags & 1)) {
        const t = mn(e),
            n = Se[Se.length - 1];
        !n || !(e.flags & 2) && t >= mn(n) ? Se.push(e) : Se.splice(wa(t), 0, e), e.flags |= 1, ll()
    }
}

function ll() {
    qn || (qn = rl.then(ol))
}

function Yn(e) {
    W(e) ? Ht.push(...e) : ft && e.id === -1 ? ft.splice(Ft + 1, 0, e) : e.flags & 1 || (Ht.push(e), e.flags |= 1), ll()
}

function Gs(e, t, n = Ke + 1) {
    for (; n < Se.length; n++) {
        const i = Se[n];
        if (i && i.flags & 2) {
            if (e && i.id !== e.uid) continue;
            Se.splice(n, 1), n--, i.flags & 4 && (i.flags &= -2), i(), i.flags & 4 || (i.flags &= -2)
        }
    }
}

function Xn(e) {
    if (Ht.length) {
        const t = [...new Set(Ht)].sort((n, i) => mn(n) - mn(i));
        if (Ht.length = 0, ft) {
            ft.push(...t);
            return
        }
        for (ft = t, Ft = 0; Ft < ft.length; Ft++) {
            const n = ft[Ft];
            n.flags & 4 && (n.flags &= -2), n.flags & 8 || n(), n.flags &= -2
        }
        ft = null, Ft = 0
    }
}
const mn = e => e.id == null ? e.flags & 2 ? -1 : 1 / 0 : e.id;

function ol(e) {
    try {
        for (Ke = 0; Ke < Se.length; Ke++) {
            const t = Se[Ke];
            t && !(t.flags & 8) && (t.flags & 4 && (t.flags &= -2), Tn(t, t.i, t.i ? 15 : 14), t.flags & 4 || (t.flags &= -2))
        }
    } finally {
        for (; Ke < Se.length; Ke++) {
            const t = Se[Ke];
            t && (t.flags &= -2)
        }
        Ke = -1, Se.length = 0, Xn(), qn = null, (Se.length || Ht.length) && ol()
    }
}
let de = null,
    al = null;

function Jn(e) {
    const t = de;
    return de = e, al = e && e.type.__scopeId || null, t
}

function Sa(e, t = de, n) {
    if (!t || e._n) return e;
    const i = (...s) => {
        i._d && sr(-1);
        const r = Jn(t);
        let l;
        try {
            l = e(...s)
        } finally {
            Jn(r), i._d && sr(1)
        }
        return l
    };
    return i._n = !0, i._c = !0, i._d = !0, i
}

function ku(e, t) {
    if (de === null) return e;
    const n = bi(de),
        i = e.dirs || (e.dirs = []);
    for (let s = 0; s < t.length; s++) {
        let [r, l, a, o = ee] = t[s];
        r && (q(r) && (r = {
            mounted: r,
            updated: r
        }), r.deep && tt(l), i.push({
            dir: r,
            instance: n,
            value: l,
            oldValue: void 0,
            arg: a,
            modifiers: o
        }))
    }
    return e
}

function qe(e, t, n, i) {
    const s = e.dirs,
        r = t && t.dirs;
    for (let l = 0; l < s.length; l++) {
        const a = s[l];
        r && (a.oldValue = r[l].value);
        let o = a.dir[i];
        o && (vt(), Ge(o, n, 8, [e.el, a, e, t]), yt())
    }
}
const fl = Symbol("_vte"),
    cl = e => e.__isTeleport,
    cn = e => e && (e.disabled || e.disabled === ""),
    Ws = e => e && (e.defer || e.defer === ""),
    Us = e => typeof SVGElement < "u" && e instanceof SVGElement,
    Ks = e => typeof MathMLElement == "function" && e instanceof MathMLElement,
    qi = (e, t) => {
        const n = e && e.to;
        return le(n) ? t ? t(n) : null : n
    },
    ul = {
        name: "Teleport",
        __isTeleport: !0,
        process(e, t, n, i, s, r, l, a, o, d) {
            const {
                mc: f,
                pc: u,
                pbc: m,
                o: {
                    insert: g,
                    querySelector: S,
                    createText: v,
                    createComment: E
                }
            } = d, x = cn(t.props);
            let {
                shapeFlag: h,
                children: c,
                dynamicChildren: p
            } = t;
            if (e == null) {
                const w = t.el = v(""),
                    C = t.anchor = v("");
                g(w, n, i), g(C, n, i);
                const P = (b, I) => {
                        h & 16 && (s && s.isCE && (s.ce._teleportTarget = b), f(c, b, I, s, r, l, a, o))
                    },
                    O = () => {
                        const b = t.target = qi(t.props, S),
                            I = dl(b, t, v, g);
                        b && (l !== "svg" && Us(b) ? l = "svg" : l !== "mathml" && Ks(b) && (l = "mathml"), x || (P(b, I), Vn(t, !1)))
                    };
                x && (P(n, C), Vn(t, !0)), Ws(t.props) ? fe(() => {
                    O(), t.el.__isMounted = !0
                }, r) : O()
            } else {
                if (Ws(t.props) && !e.el.__isMounted) {
                    fe(() => {
                        ul.process(e, t, n, i, s, r, l, a, o, d), delete e.el.__isMounted
                    }, r);
                    return
                }
                t.el = e.el, t.targetStart = e.targetStart;
                const w = t.anchor = e.anchor,
                    C = t.target = e.target,
                    P = t.targetAnchor = e.targetAnchor,
                    O = cn(e.props),
                    b = O ? n : C,
                    I = O ? w : P;
                if (l === "svg" || Us(C) ? l = "svg" : (l === "mathml" || Ks(C)) && (l = "mathml"), p ? (m(e.dynamicChildren, p, b, s, r, l, a), Ds(e, t, !0)) : o || u(e, t, b, I, s, r, l, a, !1), x) O ? t.props && e.props && t.props.to !== e.props.to && (t.props.to = e.props.to) : On(t, n, w, d, 1);
                else if ((t.props && t.props.to) !== (e.props && e.props.to)) {
                    const M = t.target = qi(t.props, S);
                    M && On(t, M, null, d, 0)
                } else O && On(t, C, P, d, 1);
                Vn(t, x)
            }
        },
        remove(e, t, n, {
            um: i,
            o: {
                remove: s
            }
        }, r) {
            const {
                shapeFlag: l,
                children: a,
                anchor: o,
                targetStart: d,
                targetAnchor: f,
                target: u,
                props: m
            } = e;
            if (u && (s(d), s(f)), r && s(o), l & 16) {
                const g = r || !cn(m);
                for (let S = 0; S < a.length; S++) {
                    const v = a[S];
                    i(v, t, n, g, !!v.dynamicChildren)
                }
            }
        },
        move: On,
        hydrate: Ta
    };

function On(e, t, n, {
    o: {
        insert: i
    },
    m: s
}, r = 2) {
    r === 0 && i(e.targetAnchor, t, n);
    const {
        el: l,
        anchor: a,
        shapeFlag: o,
        children: d,
        props: f
    } = e, u = r === 2;
    if (u && i(l, t, n), (!u || cn(f)) && o & 16)
        for (let m = 0; m < d.length; m++) s(d[m], t, n, 2);
    u && i(a, t, n)
}

function Ta(e, t, n, i, s, r, {
    o: {
        nextSibling: l,
        parentNode: a,
        querySelector: o,
        insert: d,
        createText: f
    }
}, u) {
    const m = t.target = qi(t.props, o);
    if (m) {
        const g = cn(t.props),
            S = m._lpa || m.firstChild;
        if (t.shapeFlag & 16)
            if (g) t.anchor = u(l(e), t, a(e), n, i, s, r), t.targetStart = S, t.targetAnchor = S && l(S);
            else {
                t.anchor = l(e);
                let v = S;
                for (; v;) {
                    if (v && v.nodeType === 8) {
                        if (v.data === "teleport start anchor") t.targetStart = v;
                        else if (v.data === "teleport anchor") {
                            t.targetAnchor = v, m._lpa = t.targetAnchor && l(t.targetAnchor);
                            break
                        }
                    }
                    v = l(v)
                }
                t.targetAnchor || dl(m, t, f, d), u(S && l(S), t, m, n, i, s, r)
            }
        Vn(t, g)
    }
    return t.anchor && l(t.anchor)
}
const ju = ul;

function Vn(e, t) {
    const n = e.ctx;
    if (n && n.ut) {
        let i, s;
        for (t ? (i = e.el, s = e.anchor) : (i = e.targetStart, s = e.targetAnchor); i && i !== s;) i.nodeType === 1 && i.setAttribute("data-v-owner", n.uid), i = i.nextSibling;
        n.ut()
    }
}

function dl(e, t, n, i) {
    const s = t.targetStart = n(""),
        r = t.targetAnchor = n("");
    return s[fl] = r, e && (i(s, e), i(r, e)), r
}
const ct = Symbol("_leaveCb"),
    Ln = Symbol("_enterCb");

function pl() {
    const e = {
        isMounted: !1,
        isLeaving: !1,
        isUnmounting: !1,
        leavingVNodes: new Map
    };
    return Zt(() => {
        e.isMounted = !0
    }), Cn(() => {
        e.isUnmounting = !0
    }), e
}
const Fe = [Function, Array],
    hl = {
        mode: String,
        appear: Boolean,
        persisted: Boolean,
        onBeforeEnter: Fe,
        onEnter: Fe,
        onAfterEnter: Fe,
        onEnterCancelled: Fe,
        onBeforeLeave: Fe,
        onLeave: Fe,
        onAfterLeave: Fe,
        onLeaveCancelled: Fe,
        onBeforeAppear: Fe,
        onAppear: Fe,
        onAfterAppear: Fe,
        onAppearCancelled: Fe
    },
    gl = e => {
        const t = e.subTree;
        return t.component ? gl(t.component) : t
    },
    xa = {
        name: "BaseTransition",
        props: hl,
        setup(e, {
            slots: t
        }) {
            const n = lt(),
                i = pl();
            return () => {
                const s = t.default && _s(t.default(), !0);
                if (!s || !s.length) return;
                const r = ml(s),
                    l = Q(e),
                    {
                        mode: a
                    } = l;
                if (i.isLeaving) return Mi(r);
                const o = qs(r);
                if (!o) return Mi(r);
                let d = vn(o, l, i, n, u => d = u);
                o.type !== ce && gt(o, d);
                let f = n.subTree && qs(n.subTree);
                if (f && f.type !== ce && !Ve(o, f) && gl(n).type !== ce) {
                    let u = vn(f, l, i, n);
                    if (gt(f, u), a === "out-in" && o.type !== ce) return i.isLeaving = !0, u.afterLeave = () => {
                        i.isLeaving = !1, n.job.flags & 8 || n.update(), delete u.afterLeave, f = void 0
                    }, Mi(r);
                    a === "in-out" && o.type !== ce ? u.delayLeave = (m, g, S) => {
                        const v = vl(i, f);
                        v[String(f.key)] = f, m[ct] = () => {
                            g(), m[ct] = void 0, delete d.delayedLeave, f = void 0
                        }, d.delayedLeave = () => {
                            S(), delete d.delayedLeave, f = void 0
                        }
                    } : f = void 0
                } else f && (f = void 0);
                return r
            }
        }
    };

function ml(e) {
    let t = e[0];
    if (e.length > 1) {
        for (const n of e)
            if (n.type !== ce) {
                t = n;
                break
            }
    }
    return t
}
const Ea = xa;

function vl(e, t) {
    const {
        leavingVNodes: n
    } = e;
    let i = n.get(t.type);
    return i || (i = Object.create(null), n.set(t.type, i)), i
}

function vn(e, t, n, i, s) {
    const {
        appear: r,
        mode: l,
        persisted: a = !1,
        onBeforeEnter: o,
        onEnter: d,
        onAfterEnter: f,
        onEnterCancelled: u,
        onBeforeLeave: m,
        onLeave: g,
        onAfterLeave: S,
        onLeaveCancelled: v,
        onBeforeAppear: E,
        onAppear: x,
        onAfterAppear: h,
        onAppearCancelled: c
    } = t, p = String(e.key), w = vl(n, e), C = (b, I) => {
        b && Ge(b, i, 9, I)
    }, P = (b, I) => {
        const M = I[1];
        C(b, I), W(b) ? b.every(_ => _.length <= 1) && M() : b.length <= 1 && M()
    }, O = {
        mode: l,
        persisted: a,
        beforeEnter(b) {
            let I = o;
            if (!n.isMounted)
                if (r) I = E || o;
                else return;
            b[ct] && b[ct](!0);
            const M = w[p];
            M && Ve(e, M) && M.el[ct] && M.el[ct](), C(I, [b])
        },
        enter(b) {
            let I = d,
                M = f,
                _ = u;
            if (!n.isMounted)
                if (r) I = x || d, M = h || f, _ = c || u;
                else return;
            let L = !1;
            const G = b[Ln] = Y => {
                L || (L = !0, Y ? C(_, [b]) : C(M, [b]), O.delayedLeave && O.delayedLeave(), b[Ln] = void 0)
            };
            I ? P(I, [b, G]) : G()
        },
        leave(b, I) {
            const M = String(e.key);
            if (b[Ln] && b[Ln](!0), n.isUnmounting) return I();
            C(m, [b]);
            let _ = !1;
            const L = b[ct] = G => {
                _ || (_ = !0, I(), G ? C(v, [b]) : C(S, [b]), b[ct] = void 0, w[M] === e && delete w[M])
            };
            w[M] = e, g ? P(g, [b, L]) : L()
        },
        clone(b) {
            const I = vn(b, t, n, i, s);
            return s && s(I), I
        }
    };
    return O
}

function Mi(e) {
    if (xn(e)) return e = it(e), e.children = null, e
}

function qs(e) {
    if (!xn(e)) return cl(e.type) && e.children ? ml(e.children) : e;
    const {
        shapeFlag: t,
        children: n
    } = e;
    if (n) {
        if (t & 16) return n[0];
        if (t & 32 && q(n.default)) return n.default()
    }
}

function gt(e, t) {
    e.shapeFlag & 6 && e.component ? (e.transition = t, gt(e.component.subTree, t)) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t
}

function _s(e, t = !1, n) {
    let i = [],
        s = 0;
    for (let r = 0; r < e.length; r++) {
        let l = e[r];
        const a = n == null ? l.key : String(n) + String(l.key != null ? l.key : r);
        l.type === ge ? (l.patchFlag & 128 && s++, i = i.concat(_s(l.children, t, a))) : (t || l.type !== ce) && i.push(a != null ? it(l, {
            key: a
        }) : l)
    }
    if (s > 1)
        for (let r = 0; r < i.length; r++) i[r].patchFlag = -2;
    return i
} /*! #__NO_SIDE_EFFECTS__ */
function Ca(e, t) {
    return q(e) ? ae({
        name: e.name
    }, t, {
        setup: e
    }) : e
}

function Gu() {
    const e = lt();
    return e ? (e.appContext.config.idPrefix || "v") + "-" + e.ids[0] + e.ids[1]++ : ""
}

function Ms(e) {
    e.ids = [e.ids[0] + e.ids[2]++ + "-", 0, 0]
}

function Wu(e) {
    const t = lt(),
        n = aa(null);
    if (t) {
        const s = t.refs === ee ? t.refs = {} : t.refs;
        Object.defineProperty(s, e, {
            enumerable: !0,
            get: () => n.value,
            set: r => n.value = r
        })
    }
    return n
}

function yn(e, t, n, i, s = !1) {
    if (W(e)) {
        e.forEach((S, v) => yn(S, t && (W(t) ? t[v] : t), n, i, s));
        return
    }
    if (ht(i) && !s) {
        i.shapeFlag & 512 && i.type.__asyncResolved && i.component.subTree.component && yn(e, t, n, i.component.subTree);
        return
    }
    const r = i.shapeFlag & 4 ? bi(i.component) : i.el,
        l = s ? null : r,
        {
            i: a,
            r: o
        } = e,
        d = t && t.r,
        f = a.refs === ee ? a.refs = {} : a.refs,
        u = a.setupState,
        m = Q(u),
        g = u === ee ? () => !1 : S => te(m, S);
    if (d != null && d !== o && (le(d) ? (f[d] = null, g(d) && (u[d] = null)) : he(d) && (d.value = null)), q(o)) Tn(o, a, 12, [l, f]);
    else {
        const S = le(o),
            v = he(o);
        if (S || v) {
            const E = () => {
                if (e.f) {
                    const x = S ? g(o) ? u[o] : f[o] : o.value;
                    s ? W(x) && ps(x, r) : W(x) ? x.includes(r) || x.push(r) : S ? (f[o] = [r], g(o) && (u[o] = f[o])) : (o.value = [r], e.k && (f[e.k] = o.value))
                } else S ? (f[o] = l, g(o) && (u[o] = l)) : v && (o.value = l, e.k && (f[e.k] = l))
            };
            l ? (E.id = -1, fe(E, n)) : E()
        }
    }
}
let Ys = !1;
const Dt = () => {
        Ys || (console.error("Hydration completed but contains mismatches."), Ys = !0)
    },
    _a = e => e.namespaceURI.includes("svg") && e.tagName !== "foreignObject",
    Ma = e => e.namespaceURI.includes("MathML"),
    Bn = e => {
        if (e.nodeType === 1) {
            if (_a(e)) return "svg";
            if (Ma(e)) return "mathml"
        }
    },
    Rt = e => e.nodeType === 8;

function Pa(e) {
    const {
        mt: t,
        p: n,
        o: {
            patchProp: i,
            createText: s,
            nextSibling: r,
            parentNode: l,
            remove: a,
            insert: o,
            createComment: d
        }
    } = e, f = (c, p) => {
        if (!p.hasChildNodes()) {
            n(null, c, p), Xn(), p._vnode = c;
            return
        }
        u(p.firstChild, c, null, null, null), Xn(), p._vnode = c
    }, u = (c, p, w, C, P, O = !1) => {
        O = O || !!p.dynamicChildren;
        const b = Rt(c) && c.data === "[",
            I = () => v(c, p, w, C, P, b),
            {
                type: M,
                ref: _,
                shapeFlag: L,
                patchFlag: G
            } = p;
        let Y = c.nodeType;
        p.el = c, G === -2 && (O = !1, p.dynamicChildren = null);
        let V = null;
        switch (M) {
            case Ct:
                Y !== 3 ? p.children === "" ? (o(p.el = s(""), l(c), c), V = c) : V = I() : (c.data !== p.children && (Dt(), c.data = p.children), V = r(c));
                break;
            case ce:
                h(c) ? (V = r(c), x(p.el = c.content.firstChild, c, w)) : Y !== 8 || b ? V = I() : V = r(c);
                break;
            case Gt:
                if (b && (c = r(c), Y = c.nodeType), Y === 1 || Y === 3) {
                    V = c;
                    const k = !p.children.length;
                    for (let j = 0; j < p.staticCount; j++) k && (p.children += V.nodeType === 1 ? V.outerHTML : V.data), j === p.staticCount - 1 && (p.anchor = V), V = r(V);
                    return b ? r(V) : V
                } else I();
                break;
            case ge:
                b ? V = S(c, p, w, C, P, O) : V = I();
                break;
            default:
                if (L & 1)(Y !== 1 || p.type.toLowerCase() !== c.tagName.toLowerCase()) && !h(c) ? V = I() : V = m(c, p, w, C, P, O);
                else if (L & 6) {
                    p.slotScopeIds = P;
                    const k = l(c);
                    if (b ? V = E(c) : Rt(c) && c.data === "teleport start" ? V = E(c, c.data, "teleport end") : V = r(c), t(p, k, null, w, C, Bn(k), O), ht(p) && !p.type.__asyncResolved) {
                        let j;
                        b ? (j = oe(ge), j.anchor = V ? V.previousSibling : k.lastChild) : j = c.nodeType === 3 ? Ul("") : oe("div"), j.el = c, p.component.subTree = j
                    }
                } else L & 64 ? Y !== 8 ? V = I() : V = p.type.hydrate(c, p, w, C, P, O, e, g) : L & 128 && (V = p.type.hydrate(c, p, w, C, Bn(l(c)), P, O, e, u))
        }
        return _ != null && yn(_, null, C, p), V
    }, m = (c, p, w, C, P, O) => {
        O = O || !!p.dynamicChildren;
        const {
            type: b,
            props: I,
            patchFlag: M,
            shapeFlag: _,
            dirs: L,
            transition: G
        } = p, Y = b === "input" || b === "option";
        if (Y || M !== -1) {
            L && qe(p, null, w, "created");
            let V = !1;
            if (h(c)) {
                V = Fl(null, G) && w && w.vnode.props && w.vnode.props.appear;
                const j = c.content.firstChild;
                V && G.beforeEnter(j), x(j, c, w), p.el = c = j
            }
            if (_ & 16 && !(I && (I.innerHTML || I.textContent))) {
                let j = g(c.firstChild, p, c, w, C, P, O);
                for (; j;) {
                    Dn(c, 1) || Dt();
                    const Z = j;
                    j = j.nextSibling, a(Z)
                }
            } else if (_ & 8) {
                let j = p.children;
                j[0] === `
` && (c.tagName === "PRE" || c.tagName === "TEXTAREA") && (j = j.slice(1)), c.textContent !== j && (Dn(c, 0) || Dt(), c.textContent = p.children)
            }
            if (I) {
                if (Y || !O || M & 48) {
                    const j = c.tagName.includes("-");
                    for (const Z in I)(Y && (Z.endsWith("value") || Z === "indeterminate") || Sn(Z) && !zt(Z) || Z[0] === "." || j) && i(c, Z, null, I[Z], void 0, w)
                } else if (I.onClick) i(c, "onClick", null, I.onClick, void 0, w);
                else if (M & 4 && xt(I.style))
                    for (const j in I.style) I.style[j]
            }
            let k;
            (k = I && I.onVnodeBeforeMount) && Te(k, w, p), L && qe(p, null, w, "beforeMount"), ((k = I && I.onVnodeMounted) || L || V) && Hl(() => {
                k && Te(k, w, p), V && G.enter(c), L && qe(p, null, w, "mounted")
            }, C)
        }
        return c.nextSibling
    }, g = (c, p, w, C, P, O, b) => {
        b = b || !!p.dynamicChildren;
        const I = p.children,
            M = I.length;
        for (let _ = 0; _ < M; _++) {
            const L = b ? I[_] : I[_] = Oe(I[_]),
                G = L.type === Ct;
            c ? (G && !b && _ + 1 < M && Oe(I[_ + 1]).type === Ct && (o(s(c.data.slice(L.children.length)), w, r(c)), c.data = L.children), c = u(c, L, C, P, O, b)) : G && !L.children ? o(L.el = s(""), w) : (Dn(w, 1) || Dt(), n(null, L, w, null, C, P, Bn(w), O))
        }
        return c
    }, S = (c, p, w, C, P, O) => {
        const {
            slotScopeIds: b
        } = p;
        b && (P = P ? P.concat(b) : b);
        const I = l(c),
            M = g(r(c), p, I, w, C, P, O);
        return M && Rt(M) && M.data === "]" ? r(p.anchor = M) : (Dt(), o(p.anchor = d("]"), I, M), M)
    }, v = (c, p, w, C, P, O) => {
        if (Dn(c.parentElement, 1) || Dt(), p.el = null, O) {
            const M = E(c);
            for (;;) {
                const _ = r(c);
                if (_ && _ !== M) a(_);
                else break
            }
        }
        const b = r(c),
            I = l(c);
        return a(c), n(null, p, I, b, w, C, Bn(I), P), w && (w.vnode.el = p.el, yi(w, p.el)), b
    }, E = (c, p = "[", w = "]") => {
        let C = 0;
        for (; c;)
            if (c = r(c), c && Rt(c) && (c.data === p && C++, c.data === w)) {
                if (C === 0) return r(c);
                C--
            }
        return c
    }, x = (c, p, w) => {
        const C = p.parentNode;
        C && C.replaceChild(c, p);
        let P = w;
        for (; P;) P.vnode.el === p && (P.vnode.el = P.subTree.el = c), P = P.parent
    }, h = c => c.nodeType === 1 && c.tagName === "TEMPLATE";
    return [f, u]
}
const Xs = "data-allow-mismatch",
    Aa = {
        0: "text",
        1: "children",
        2: "class",
        3: "style",
        4: "attribute"
    };

function Dn(e, t) {
    if (t === 0 || t === 1)
        for (; e && !e.hasAttribute(Xs);) e = e.parentElement;
    const n = e && e.getAttribute(Xs);
    if (n == null) return !1;
    if (n === "") return !0; {
        const i = n.split(",");
        return t === 0 && i.includes("children") ? !0 : n.split(",").includes(Aa[t])
    }
}
ci().requestIdleCallback;
ci().cancelIdleCallback;

function Ia(e, t) {
    if (Rt(e) && e.data === "[") {
        let n = 1,
            i = e.nextSibling;
        for (; i;) {
            if (i.nodeType === 1) {
                if (t(i) === !1) break
            } else if (Rt(i))
                if (i.data === "]") {
                    if (--n === 0) break
                } else i.data === "[" && n++;
            i = i.nextSibling
        }
    } else t(e)
}
const ht = e => !!e.type.__asyncLoader; /*! #__NO_SIDE_EFFECTS__ */
function Uu(e) {
    q(e) && (e = {
        loader: e
    });
    const {
        loader: t,
        loadingComponent: n,
        errorComponent: i,
        delay: s = 200,
        hydrate: r,
        timeout: l,
        suspensible: a = !0,
        onError: o
    } = e;
    let d = null,
        f, u = 0;
    const m = () => (u++, d = null, g()),
        g = () => {
            let S;
            return d || (S = d = t().catch(v => {
                if (v = v instanceof Error ? v : new Error(String(v)), o) return new Promise((E, x) => {
                    o(v, () => E(m()), () => x(v), u + 1)
                });
                throw v
            }).then(v => S !== d && d ? d : (v && (v.__esModule || v[Symbol.toStringTag] === "Module") && (v = v.default), f = v, v)))
        };
    return Ca({
        name: "AsyncComponentWrapper",
        __asyncLoader: g,
        __asyncHydrate(S, v, E) {
            const x = r ? () => {
                const h = r(E, c => Ia(S, c));
                h && (v.bum || (v.bum = [])).push(h)
            } : E;
            f ? x() : g().then(() => !v.isUnmounted && x())
        },
        get __asyncResolved() {
            return f
        },
        setup() {
            const S = ue;
            if (Ms(S), f) return () => Pi(f, S);
            const v = c => {
                d = null, Jt(c, S, 13, !i)
            };
            if (a && S.suspense || Ut) return g().then(c => () => Pi(c, S)).catch(c => (v(c), () => i ? oe(i, {
                error: c
            }) : null));
            const E = pe(!1),
                x = pe(),
                h = pe(!!s);
            return s && setTimeout(() => {
                h.value = !1
            }, s), l != null && setTimeout(() => {
                if (!E.value && !x.value) {
                    const c = new Error(`Async component timed out after ${l}ms.`);
                    v(c), x.value = c
                }
            }, l), g().then(() => {
                E.value = !0, S.parent && xn(S.parent.vnode) && S.parent.update()
            }).catch(c => {
                v(c), x.value = c
            }), () => {
                if (E.value && f) return Pi(f, S);
                if (x.value && i) return oe(i, {
                    error: x.value
                });
                if (n && !h.value) return oe(n)
            }
        }
    })
}

function Pi(e, t) {
    const {
        ref: n,
        props: i,
        children: s,
        ce: r
    } = t.vnode, l = oe(e, i, s);
    return l.ref = n, l.ce = r, delete t.vnode.ce, l
}
const xn = e => e.type.__isKeepAlive,
    Oa = {
        name: "KeepAlive",
        __isKeepAlive: !0,
        props: {
            include: [String, RegExp, Array],
            exclude: [String, RegExp, Array],
            max: [String, Number]
        },
        setup(e, {
            slots: t
        }) {
            const n = lt(),
                i = n.ctx;
            if (!i.renderer) return () => {
                const h = t.default && t.default();
                return h && h.length === 1 ? h[0] : h
            };
            const s = new Map,
                r = new Set;
            let l = null;
            const a = n.suspense,
                {
                    renderer: {
                        p: o,
                        m: d,
                        um: f,
                        o: {
                            createElement: u
                        }
                    }
                } = i,
                m = u("div");
            i.activate = (h, c, p, w, C) => {
                const P = h.component;
                d(h, c, p, 0, a), o(P.vnode, h, c, p, P, a, w, h.slotScopeIds, C), fe(() => {
                    P.isDeactivated = !1, P.a && Vt(P.a);
                    const O = h.props && h.props.onVnodeMounted;
                    O && Te(O, P.parent, h)
                }, a)
            }, i.deactivate = h => {
                const c = h.component;
                ei(c.m), ei(c.a), d(h, m, null, 1, a), fe(() => {
                    c.da && Vt(c.da);
                    const p = h.props && h.props.onVnodeUnmounted;
                    p && Te(p, c.parent, h), c.isDeactivated = !0
                }, a)
            };

            function g(h) {
                Ai(h), f(h, n, a, !0)
            }

            function S(h) {
                s.forEach((c, p) => {
                    const w = ss(c.type);
                    w && !h(w) && v(p)
                })
            }

            function v(h) {
                const c = s.get(h);
                c && (!l || !Ve(c, l)) ? g(c) : l && Ai(l), s.delete(h), r.delete(h)
            }
            kt(() => [e.include, e.exclude], ([h, c]) => {
                h && S(p => ln(h, p)), c && S(p => !ln(c, p))
            }, {
                flush: "post",
                deep: !0
            });
            let E = null;
            const x = () => {
                E != null && (ti(n.subTree.type) ? fe(() => {
                    s.set(E, Fn(n.subTree))
                }, n.subTree.suspense) : s.set(E, Fn(n.subTree)))
            };
            return Zt(x), En(x), Cn(() => {
                s.forEach(h => {
                    const {
                        subTree: c,
                        suspense: p
                    } = n, w = Fn(c);
                    if (h.type === w.type && h.key === w.key) {
                        Ai(w);
                        const C = w.component.da;
                        C && fe(C, p);
                        return
                    }
                    g(h)
                })
            }), () => {
                if (E = null, !t.default) return l = null;
                const h = t.default(),
                    c = h[0];
                if (h.length > 1) return l = null, h;
                if (!At(c) || !(c.shapeFlag & 4) && !(c.shapeFlag & 128)) return l = null, c;
                let p = Fn(c);
                if (p.type === ce) return l = null, p;
                const w = p.type,
                    C = ss(ht(p) ? p.type.__asyncResolved || {} : w),
                    {
                        include: P,
                        exclude: O,
                        max: b
                    } = e;
                if (P && (!C || !ln(P, C)) || O && C && ln(O, C)) return p.shapeFlag &= -257, l = p, c;
                const I = p.key == null ? w : p.key,
                    M = s.get(I);
                return p.el && (p = it(p), c.shapeFlag & 128 && (c.ssContent = p)), E = I, M ? (p.el = M.el, p.component = M.component, p.transition && gt(p, p.transition), p.shapeFlag |= 512, r.delete(I), r.add(I)) : (r.add(I), b && r.size > parseInt(b, 10) && v(r.values().next().value)), p.shapeFlag |= 256, l = p, ti(c.type) ? c : p
            }
        }
    },
    Ku = Oa;

function ln(e, t) {
    return W(e) ? e.some(n => ln(n, t)) : le(e) ? e.split(",").includes(t) : Po(e) ? (e.lastIndex = 0, e.test(t)) : !1
}

function La(e, t) {
    yl(e, "a", t)
}

function Ba(e, t) {
    yl(e, "da", t)
}

function yl(e, t, n = ue) {
    const i = e.__wdc || (e.__wdc = () => {
        let s = n;
        for (; s;) {
            if (s.isDeactivated) return;
            s = s.parent
        }
        return e()
    });
    if (gi(t, i, n), n) {
        let s = n.parent;
        for (; s && s.parent;) xn(s.parent.vnode) && Da(i, t, n, s), s = s.parent
    }
}

function Da(e, t, n, i) {
    const s = gi(t, e, i, !0);
    As(() => {
        ps(i[t], s)
    }, n)
}

function Ai(e) {
    e.shapeFlag &= -257, e.shapeFlag &= -513
}

function Fn(e) {
    return e.shapeFlag & 128 ? e.ssContent : e
}

function gi(e, t, n = ue, i = !1) {
    if (n) {
        const s = n[e] || (n[e] = []),
            r = t.__weh || (t.__weh = (...l) => {
                vt();
                const a = It(n),
                    o = Ge(t, n, e, l);
                return a(), yt(), o
            });
        return i ? s.unshift(r) : s.push(r), r
    }
}
const rt = e => (t, n = ue) => {
        (!Ut || e === "sp") && gi(e, (...i) => t(...i), n)
    },
    Fa = rt("bm"),
    Zt = rt("m"),
    Ps = rt("bu"),
    En = rt("u"),
    Cn = rt("bum"),
    As = rt("um"),
    Ra = rt("sp"),
    Na = rt("rtg"),
    $a = rt("rtc");

function za(e, t = ue) {
    gi("ec", e, t)
}
const Is = "components",
    Va = "directives";

function qu(e, t) {
    return Os(Is, e, !0, t) || e
}
const bl = Symbol.for("v-ndc");

function Yu(e) {
    return le(e) ? Os(Is, e, !1) || e : e || bl
}

function Xu(e) {
    return Os(Va, e)
}

function Os(e, t, n = !0, i = !1) {
    const s = de || ue;
    if (s) {
        const r = s.type;
        if (e === Is) {
            const a = ss(r, !1);
            if (a && (a === t || a === Le(t) || a === fi(Le(t)))) return r
        }
        const l = Js(s[e] || r[e], t) || Js(s.appContext[e], t);
        return !l && i ? r : l
    }
}

function Js(e, t) {
    return e && (e[t] || e[Le(t)] || e[fi(Le(t))])
}

function Ju(e, t, n, i) {
    let s;
    const r = n,
        l = W(e);
    if (l || le(e)) {
        const a = l && xt(e);
        let o = !1;
        a && (o = !Ne(e), e = hi(e)), s = new Array(e.length);
        for (let d = 0, f = e.length; d < f; d++) s[d] = t(o ? ye(e[d]) : e[d], d, void 0, r)
    } else if (typeof e == "number") {
        s = new Array(e);
        for (let a = 0; a < e; a++) s[a] = t(a + 1, a, void 0, r)
    } else if (ie(e))
        if (e[Symbol.iterator]) s = Array.from(e, (a, o) => t(a, o, void 0, r));
        else {
            const a = Object.keys(e);
            s = new Array(a.length);
            for (let o = 0, d = a.length; o < d; o++) {
                const f = a[o];
                s[o] = t(e[f], f, o, r)
            }
        }
    else s = [];
    return s
}

function Zu(e, t) {
    for (let n = 0; n < t.length; n++) {
        const i = t[n];
        if (W(i))
            for (let s = 0; s < i.length; s++) e[i[s].name] = i[s].fn;
        else i && (e[i.name] = i.key ? (...s) => {
            const r = i.fn(...s);
            return r && (r.key = i.key), r
        } : i.fn)
    }
    return e
}

function Qu(e, t, n = {}, i, s) {
    if (de.ce || de.parent && ht(de.parent) && de.parent.ce) return t !== "default" && (n.name = t), ni(), es(ge, null, [oe("slot", n, i && i())], 64);
    let r = e[t];
    r && r._c && (r._d = !1), ni();
    const l = r && wl(r(n)),
        a = n.key || l && l.key,
        o = es(ge, {
            key: (a && !je(a) ? a : `_${t}`) + (!l && i ? "_fb" : "")
        }, l || (i ? i() : []), l && e._ === 1 ? 64 : -2);
    return !s && o.scopeId && (o.slotScopeIds = [o.scopeId + "-s"]), r && r._c && (r._d = !0), o
}

function wl(e) {
    return e.some(t => At(t) ? !(t.type === ce || t.type === ge && !wl(t.children)) : !0) ? e : null
}

function ed(e, t) {
    const n = {};
    for (const i in e) n[t && /[A-Z]/.test(i) ? `on:${i}` : zn(i)] = e[i];
    return n
}
const Yi = e => e ? Kl(e) ? bi(e) : Yi(e.parent) : null,
    un = ae(Object.create(null), {
        $: e => e,
        $el: e => e.vnode.el,
        $data: e => e.data,
        $props: e => e.props,
        $attrs: e => e.attrs,
        $slots: e => e.slots,
        $refs: e => e.refs,
        $parent: e => Yi(e.parent),
        $root: e => Yi(e.root),
        $host: e => e.ce,
        $emit: e => e.emit,
        $options: e => xl(e),
        $forceUpdate: e => e.f || (e.f = () => {
            Cs(e.update)
        }),
        $nextTick: e => e.n || (e.n = Es.bind(e.proxy)),
        $watch: e => af.bind(e)
    }),
    Ii = (e, t) => e !== ee && !e.__isScriptSetup && te(e, t),
    Ha = {
        get({
            _: e
        }, t) {
            if (t === "__v_skip") return !0;
            const {
                ctx: n,
                setupState: i,
                data: s,
                props: r,
                accessCache: l,
                type: a,
                appContext: o
            } = e;
            let d;
            if (t[0] !== "$") {
                const g = l[t];
                if (g !== void 0) switch (g) {
                    case 1:
                        return i[t];
                    case 2:
                        return s[t];
                    case 4:
                        return n[t];
                    case 3:
                        return r[t]
                } else {
                    if (Ii(i, t)) return l[t] = 1, i[t];
                    if (s !== ee && te(s, t)) return l[t] = 2, s[t];
                    if ((d = e.propsOptions[0]) && te(d, t)) return l[t] = 3, r[t];
                    if (n !== ee && te(n, t)) return l[t] = 4, n[t];
                    Xi && (l[t] = 0)
                }
            }
            const f = un[t];
            let u, m;
            if (f) return t === "$attrs" && ve(e.attrs, "get", ""), f(e);
            if ((u = a.__cssModules) && (u = u[t])) return u;
            if (n !== ee && te(n, t)) return l[t] = 4, n[t];
            if (m = o.config.globalProperties, te(m, t)) return m[t]
        },
        set({
            _: e
        }, t, n) {
            const {
                data: i,
                setupState: s,
                ctx: r
            } = e;
            return Ii(s, t) ? (s[t] = n, !0) : i !== ee && te(i, t) ? (i[t] = n, !0) : te(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (r[t] = n, !0)
        },
        has({
            _: {
                data: e,
                setupState: t,
                accessCache: n,
                ctx: i,
                appContext: s,
                propsOptions: r
            }
        }, l) {
            let a;
            return !!n[l] || e !== ee && te(e, l) || Ii(t, l) || (a = r[0]) && te(a, l) || te(i, l) || te(un, l) || te(s.config.globalProperties, l)
        },
        defineProperty(e, t, n) {
            return n.get != null ? e._.accessCache[t] = 0 : te(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n)
        }
    };

function td() {
    return Sl().slots
}

function nd() {
    return Sl().attrs
}

function Sl() {
    const e = lt();
    return e.setupContext || (e.setupContext = Yl(e))
}

function Zn(e) {
    return W(e) ? e.reduce((t, n) => (t[n] = null, t), {}) : e
}

function id(e, t) {
    return !e || !t ? e || t : W(e) && W(t) ? e.concat(t) : ae({}, Zn(e), Zn(t))
}

function sd(e, t) {
    const n = {};
    for (const i in e) t.includes(i) || Object.defineProperty(n, i, {
        enumerable: !0,
        get: () => e[i]
    });
    return n
}

function rd(e) {
    const t = lt();
    let n = e();
    return ns(), hs(n) && (n = n.catch(i => {
        throw It(t), i
    })), [n, () => It(t)]
}
let Xi = !0;

function ka(e) {
    const t = xl(e),
        n = e.proxy,
        i = e.ctx;
    Xi = !1, t.beforeCreate && Zs(t.beforeCreate, e, "bc");
    const {
        data: s,
        computed: r,
        methods: l,
        watch: a,
        provide: o,
        inject: d,
        created: f,
        beforeMount: u,
        mounted: m,
        beforeUpdate: g,
        updated: S,
        activated: v,
        deactivated: E,
        beforeDestroy: x,
        beforeUnmount: h,
        destroyed: c,
        unmounted: p,
        render: w,
        renderTracked: C,
        renderTriggered: P,
        errorCaptured: O,
        serverPrefetch: b,
        expose: I,
        inheritAttrs: M,
        components: _,
        directives: L,
        filters: G
    } = t;
    if (d && ja(d, i, null), l)
        for (const k in l) {
            const j = l[k];
            q(j) && (i[k] = j.bind(n))
        }
    if (s) {
        const k = s.call(n, n);
        ie(k) && (e.data = Ss(k))
    }
    if (Xi = !0, r)
        for (const k in r) {
            const j = r[k],
                Z = q(j) ? j.bind(n, n) : q(j.get) ? j.get.bind(n, n) : He,
                Ce = !q(j) && q(j.set) ? j.set.bind(n) : He,
                _e = Xl({
                    get: Z,
                    set: Ce
                });
            Object.defineProperty(i, k, {
                enumerable: !0,
                configurable: !0,
                get: () => _e.value,
                set: De => _e.value = De
            })
        }
    if (a)
        for (const k in a) Tl(a[k], i, n, k);
    if (o) {
        const k = q(o) ? o.call(n) : o;
        Reflect.ownKeys(k).forEach(j => {
            Ls(j, k[j])
        })
    }
    f && Zs(f, e, "c");

    function V(k, j) {
        W(j) ? j.forEach(Z => k(Z.bind(n))) : j && k(j.bind(n))
    }
    if (V(Fa, u), V(Zt, m), V(Ps, g), V(En, S), V(La, v), V(Ba, E), V(za, O), V($a, C), V(Na, P), V(Cn, h), V(As, p), V(Ra, b), W(I))
        if (I.length) {
            const k = e.exposed || (e.exposed = {});
            I.forEach(j => {
                Object.defineProperty(k, j, {
                    get: () => n[j],
                    set: Z => n[j] = Z
                })
            })
        } else e.exposed || (e.exposed = {});
    w && e.render === He && (e.render = w), M != null && (e.inheritAttrs = M), _ && (e.components = _), L && (e.directives = L), b && Ms(e)
}

function ja(e, t, n = He) {
    W(e) && (e = Ji(e));
    for (const i in e) {
        const s = e[i];
        let r;
        ie(s) ? "default" in s ? r = Hn(s.from || i, s.default, !0) : r = Hn(s.from || i) : r = Hn(s), he(r) ? Object.defineProperty(t, i, {
            enumerable: !0,
            configurable: !0,
            get: () => r.value,
            set: l => r.value = l
        }) : t[i] = r
    }
}

function Zs(e, t, n) {
    Ge(W(e) ? e.map(i => i.bind(t.proxy)) : e.bind(t.proxy), t, n)
}

function Tl(e, t, n, i) {
    let s = i.includes(".") ? Nl(n, i) : () => n[i];
    if (le(e)) {
        const r = t[e];
        q(r) && kt(s, r)
    } else if (q(e)) kt(s, e.bind(n));
    else if (ie(e))
        if (W(e)) e.forEach(r => Tl(r, t, n, i));
        else {
            const r = q(e.handler) ? e.handler.bind(n) : t[e.handler];
            q(r) && kt(s, r, e)
        }
}

function xl(e) {
    const t = e.type,
        {
            mixins: n,
            extends: i
        } = t,
        {
            mixins: s,
            optionsCache: r,
            config: {
                optionMergeStrategies: l
            }
        } = e.appContext,
        a = r.get(t);
    let o;
    return a ? o = a : !s.length && !n && !i ? o = t : (o = {}, s.length && s.forEach(d => Qn(o, d, l, !0)), Qn(o, t, l)), ie(t) && r.set(t, o), o
}

function Qn(e, t, n, i = !1) {
    const {
        mixins: s,
        extends: r
    } = t;
    r && Qn(e, r, n, !0), s && s.forEach(l => Qn(e, l, n, !0));
    for (const l in t)
        if (!(i && l === "expose")) {
            const a = Ga[l] || n && n[l];
            e[l] = a ? a(e[l], t[l]) : t[l]
        }
    return e
}
const Ga = {
    data: Qs,
    props: er,
    emits: er,
    methods: on,
    computed: on,
    beforeCreate: be,
    created: be,
    beforeMount: be,
    mounted: be,
    beforeUpdate: be,
    updated: be,
    beforeDestroy: be,
    beforeUnmount: be,
    destroyed: be,
    unmounted: be,
    activated: be,
    deactivated: be,
    errorCaptured: be,
    serverPrefetch: be,
    components: on,
    directives: on,
    watch: Ua,
    provide: Qs,
    inject: Wa
};

function Qs(e, t) {
    return t ? e ? function() {
        return ae(q(e) ? e.call(this, this) : e, q(t) ? t.call(this, this) : t)
    } : t : e
}

function Wa(e, t) {
    return on(Ji(e), Ji(t))
}

function Ji(e) {
    if (W(e)) {
        const t = {};
        for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
        return t
    }
    return e
}

function be(e, t) {
    return e ? [...new Set([].concat(e, t))] : t
}

function on(e, t) {
    return e ? ae(Object.create(null), e, t) : t
}

function er(e, t) {
    return e ? W(e) && W(t) ? [...new Set([...e, ...t])] : ae(Object.create(null), Zn(e), Zn(t ? ? {})) : t
}

function Ua(e, t) {
    if (!e) return t;
    if (!t) return e;
    const n = ae(Object.create(null), e);
    for (const i in t) n[i] = be(e[i], t[i]);
    return n
}

function El() {
    return {
        app: null,
        config: {
            isNativeTag: _o,
            performance: !1,
            globalProperties: {},
            optionMergeStrategies: {},
            errorHandler: void 0,
            warnHandler: void 0,
            compilerOptions: {}
        },
        mixins: [],
        components: {},
        directives: {},
        provides: Object.create(null),
        optionsCache: new WeakMap,
        propsCache: new WeakMap,
        emitsCache: new WeakMap
    }
}
let Ka = 0;

function qa(e, t) {
    return function(i, s = null) {
        q(i) || (i = ae({}, i)), s != null && !ie(s) && (s = null);
        const r = El(),
            l = new WeakSet,
            a = [];
        let o = !1;
        const d = r.app = {
            _uid: Ka++,
            _component: i,
            _props: s,
            _container: null,
            _context: r,
            _instance: null,
            version: If,
            get config() {
                return r.config
            },
            set config(f) {},
            use(f, ...u) {
                return l.has(f) || (f && q(f.install) ? (l.add(f), f.install(d, ...u)) : q(f) && (l.add(f), f(d, ...u))), d
            },
            mixin(f) {
                return r.mixins.includes(f) || r.mixins.push(f), d
            },
            component(f, u) {
                return u ? (r.components[f] = u, d) : r.components[f]
            },
            directive(f, u) {
                return u ? (r.directives[f] = u, d) : r.directives[f]
            },
            mount(f, u, m) {
                if (!o) {
                    const g = d._ceVNode || oe(i, s);
                    return g.appContext = r, m === !0 ? m = "svg" : m === !1 && (m = void 0), u && t ? t(g, f) : e(g, f, m), o = !0, d._container = f, f.__vue_app__ = d, bi(g.component)
                }
            },
            onUnmount(f) {
                a.push(f)
            },
            unmount() {
                o && (Ge(a, d._instance, 16), e(null, d._container), delete d._container.__vue_app__)
            },
            provide(f, u) {
                return r.provides[f] = u, d
            },
            runWithContext(f) {
                const u = Et;
                Et = d;
                try {
                    return f()
                } finally {
                    Et = u
                }
            }
        };
        return d
    }
}
let Et = null;

function Ls(e, t) {
    if (ue) {
        let n = ue.provides;
        const i = ue.parent && ue.parent.provides;
        i === n && (n = ue.provides = Object.create(i)), n[e] = t
    }
}

function Hn(e, t, n = !1) {
    const i = ue || de;
    if (i || Et) {
        const s = Et ? Et._context.provides : i ? i.parent == null ? i.vnode.appContext && i.vnode.appContext.provides : i.parent.provides : void 0;
        if (s && e in s) return s[e];
        if (arguments.length > 1) return n && q(t) ? t.call(i && i.proxy) : t
    }
}

function ld() {
    return !!(ue || de || Et)
}
const Cl = {},
    _l = () => Object.create(Cl),
    Ml = e => Object.getPrototypeOf(e) === Cl;

function Ya(e, t, n, i = !1) {
    const s = {},
        r = _l();
    e.propsDefaults = Object.create(null), Pl(e, t, s, r);
    for (const l in e.propsOptions[0]) l in s || (s[l] = void 0);
    n ? e.props = i ? s : la(s) : e.type.props ? e.props = s : e.props = r, e.attrs = r
}

function Xa(e, t, n, i) {
    const {
        props: s,
        attrs: r,
        vnode: {
            patchFlag: l
        }
    } = e, a = Q(s), [o] = e.propsOptions;
    let d = !1;
    if ((i || l > 0) && !(l & 16)) {
        if (l & 8) {
            const f = e.vnode.dynamicProps;
            for (let u = 0; u < f.length; u++) {
                let m = f[u];
                if (vi(e.emitsOptions, m)) continue;
                const g = t[m];
                if (o)
                    if (te(r, m)) g !== r[m] && (r[m] = g, d = !0);
                    else {
                        const S = Le(m);
                        s[S] = Zi(o, a, S, g, e, !1)
                    }
                else g !== r[m] && (r[m] = g, d = !0)
            }
        }
    } else {
        Pl(e, t, s, r) && (d = !0);
        let f;
        for (const u in a)(!t || !te(t, u) && ((f = st(u)) === u || !te(t, f))) && (o ? n && (n[u] !== void 0 || n[f] !== void 0) && (s[u] = Zi(o, a, u, void 0, e, !0)) : delete s[u]);
        if (r !== a)
            for (const u in r)(!t || !te(t, u)) && (delete r[u], d = !0)
    }
    d && et(e.attrs, "set", "")
}

function Pl(e, t, n, i) {
    const [s, r] = e.propsOptions;
    let l = !1,
        a;
    if (t)
        for (let o in t) {
            if (zt(o)) continue;
            const d = t[o];
            let f;
            s && te(s, f = Le(o)) ? !r || !r.includes(f) ? n[f] = d : (a || (a = {}))[f] = d : vi(e.emitsOptions, o) || (!(o in i) || d !== i[o]) && (i[o] = d, l = !0)
        }
    if (r) {
        const o = Q(n),
            d = a || ee;
        for (let f = 0; f < r.length; f++) {
            const u = r[f];
            n[u] = Zi(s, o, u, d[u], e, !te(d, u))
        }
    }
    return l
}

function Zi(e, t, n, i, s, r) {
    const l = e[n];
    if (l != null) {
        const a = te(l, "default");
        if (a && i === void 0) {
            const o = l.default;
            if (l.type !== Function && !l.skipFactory && q(o)) {
                const {
                    propsDefaults: d
                } = s;
                if (n in d) i = d[n];
                else {
                    const f = It(s);
                    i = d[n] = o.call(null, t), f()
                }
            } else i = o;
            s.ce && s.ce._setProp(n, i)
        }
        l[0] && (r && !a ? i = !1 : l[1] && (i === "" || i === st(n)) && (i = !0))
    }
    return i
}
const Ja = new WeakMap;

function Al(e, t, n = !1) {
    const i = n ? Ja : t.propsCache,
        s = i.get(e);
    if (s) return s;
    const r = e.props,
        l = {},
        a = [];
    let o = !1;
    if (!q(e)) {
        const f = u => {
            o = !0;
            const [m, g] = Al(u, t, !0);
            ae(l, m), g && a.push(...g)
        };
        !n && t.mixins.length && t.mixins.forEach(f), e.extends && f(e.extends), e.mixins && e.mixins.forEach(f)
    }
    if (!r && !o) return ie(e) && i.set(e, Nt), Nt;
    if (W(r))
        for (let f = 0; f < r.length; f++) {
            const u = Le(r[f]);
            tr(u) && (l[u] = ee)
        } else if (r)
            for (const f in r) {
                const u = Le(f);
                if (tr(u)) {
                    const m = r[f],
                        g = l[u] = W(m) || q(m) ? {
                            type: m
                        } : ae({}, m),
                        S = g.type;
                    let v = !1,
                        E = !0;
                    if (W(S))
                        for (let x = 0; x < S.length; ++x) {
                            const h = S[x],
                                c = q(h) && h.name;
                            if (c === "Boolean") {
                                v = !0;
                                break
                            } else c === "String" && (E = !1)
                        } else v = q(S) && S.name === "Boolean";
                    g[0] = v, g[1] = E, (v || te(g, "default")) && a.push(u)
                }
            }
    const d = [l, a];
    return ie(e) && i.set(e, d), d
}

function tr(e) {
    return e[0] !== "$" && !zt(e)
}
const Il = e => e[0] === "_" || e === "$stable",
    Bs = e => W(e) ? e.map(Oe) : [Oe(e)],
    Za = (e, t, n) => {
        if (t._n) return t;
        const i = Sa((...s) => Bs(t(...s)), n);
        return i._c = !1, i
    },
    Ol = (e, t, n) => {
        const i = e._ctx;
        for (const s in e) {
            if (Il(s)) continue;
            const r = e[s];
            if (q(r)) t[s] = Za(s, r, i);
            else if (r != null) {
                const l = Bs(r);
                t[s] = () => l
            }
        }
    },
    Ll = (e, t) => {
        const n = Bs(t);
        e.slots.default = () => n
    },
    Bl = (e, t, n) => {
        for (const i in t)(n || i !== "_") && (e[i] = t[i])
    },
    Qa = (e, t, n) => {
        const i = e.slots = _l();
        if (e.vnode.shapeFlag & 32) {
            const s = t._;
            s ? (Bl(i, t, n), n && Dr(i, "_", s, !0)) : Ol(t, i)
        } else t && Ll(e, t)
    },
    ef = (e, t, n) => {
        const {
            vnode: i,
            slots: s
        } = e;
        let r = !0,
            l = ee;
        if (i.shapeFlag & 32) {
            const a = t._;
            a ? n && a === 1 ? r = !1 : Bl(s, t, n) : (r = !t.$stable, Ol(t, s)), l = t
        } else t && (Ll(e, t), l = {
            default: 1
        });
        if (r)
            for (const a in s) !Il(a) && l[a] == null && delete s[a]
    },
    fe = Hl;

function tf(e) {
    return Dl(e)
}

function nf(e) {
    return Dl(e, Pa)
}

function Dl(e, t) {
    const n = ci();
    n.__VUE__ = !0;
    const {
        insert: i,
        remove: s,
        patchProp: r,
        createElement: l,
        createText: a,
        createComment: o,
        setText: d,
        setElementText: f,
        parentNode: u,
        nextSibling: m,
        setScopeId: g = He,
        insertStaticContent: S
    } = e, v = (y, T, A, F = null, B = null, D = null, z = void 0, $ = null, N = !!T.dynamicChildren) => {
        if (y === T) return;
        y && !Ve(y, T) && (F = Mn(y), De(y, B, D, !0), y = null), T.patchFlag === -2 && (N = !1, T.dynamicChildren = null);
        const {
            type: R,
            ref: K,
            shapeFlag: H
        } = T;
        switch (R) {
            case Ct:
                E(y, T, A, F);
                break;
            case ce:
                x(y, T, A, F);
                break;
            case Gt:
                y == null && h(T, A, F, z);
                break;
            case ge:
                _(y, T, A, F, B, D, z, $, N);
                break;
            default:
                H & 1 ? w(y, T, A, F, B, D, z, $, N) : H & 6 ? L(y, T, A, F, B, D, z, $, N) : (H & 64 || H & 128) && R.process(y, T, A, F, B, D, z, $, N, Lt)
        }
        K != null && B && yn(K, y && y.ref, D, T || y, !T)
    }, E = (y, T, A, F) => {
        if (y == null) i(T.el = a(T.children), A, F);
        else {
            const B = T.el = y.el;
            T.children !== y.children && d(B, T.children)
        }
    }, x = (y, T, A, F) => {
        y == null ? i(T.el = o(T.children || ""), A, F) : T.el = y.el
    }, h = (y, T, A, F) => {
        [y.el, y.anchor] = S(y.children, T, A, F, y.el, y.anchor)
    }, c = ({
        el: y,
        anchor: T
    }, A, F) => {
        let B;
        for (; y && y !== T;) B = m(y), i(y, A, F), y = B;
        i(T, A, F)
    }, p = ({
        el: y,
        anchor: T
    }) => {
        let A;
        for (; y && y !== T;) A = m(y), s(y), y = A;
        s(T)
    }, w = (y, T, A, F, B, D, z, $, N) => {
        T.type === "svg" ? z = "svg" : T.type === "math" && (z = "mathml"), y == null ? C(T, A, F, B, D, z, $, N) : b(y, T, B, D, z, $, N)
    }, C = (y, T, A, F, B, D, z, $) => {
        let N, R;
        const {
            props: K,
            shapeFlag: H,
            transition: U,
            dirs: X
        } = y;
        if (N = y.el = l(y.type, D, K && K.is, K), H & 8 ? f(N, y.children) : H & 16 && O(y.children, N, null, F, B, Oi(y, D), z, $), X && qe(y, null, F, "created"), P(N, y, y.scopeId, z, F), K) {
            for (const se in K) se !== "value" && !zt(se) && r(N, se, null, K[se], D, F);
            "value" in K && r(N, "value", null, K.value, D), (R = K.onVnodeBeforeMount) && Te(R, F, y)
        }
        X && qe(y, null, F, "beforeMount");
        const J = Fl(B, U);
        J && U.beforeEnter(N), i(N, T, A), ((R = K && K.onVnodeMounted) || J || X) && fe(() => {
            R && Te(R, F, y), J && U.enter(N), X && qe(y, null, F, "mounted")
        }, B)
    }, P = (y, T, A, F, B) => {
        if (A && g(y, A), F)
            for (let D = 0; D < F.length; D++) g(y, F[D]);
        if (B) {
            let D = B.subTree;
            if (T === D || ti(D.type) && (D.ssContent === T || D.ssFallback === T)) {
                const z = B.vnode;
                P(y, z, z.scopeId, z.slotScopeIds, B.parent)
            }
        }
    }, O = (y, T, A, F, B, D, z, $, N = 0) => {
        for (let R = N; R < y.length; R++) {
            const K = y[R] = $ ? ut(y[R]) : Oe(y[R]);
            v(null, K, T, A, F, B, D, z, $)
        }
    }, b = (y, T, A, F, B, D, z) => {
        const $ = T.el = y.el;
        let {
            patchFlag: N,
            dynamicChildren: R,
            dirs: K
        } = T;
        N |= y.patchFlag & 16;
        const H = y.props || ee,
            U = T.props || ee;
        let X;
        if (A && bt(A, !1), (X = U.onVnodeBeforeUpdate) && Te(X, A, T, y), K && qe(T, y, A, "beforeUpdate"), A && bt(A, !0), (H.innerHTML && U.innerHTML == null || H.textContent && U.textContent == null) && f($, ""), R ? I(y.dynamicChildren, R, $, A, F, Oi(T, B), D) : z || j(y, T, $, null, A, F, Oi(T, B), D, !1), N > 0) {
            if (N & 16) M($, H, U, A, B);
            else if (N & 2 && H.class !== U.class && r($, "class", null, U.class, B), N & 4 && r($, "style", H.style, U.style, B), N & 8) {
                const J = T.dynamicProps;
                for (let se = 0; se < J.length; se++) {
                    const ne = J[se],
                        Me = H[ne],
                        me = U[ne];
                    (me !== Me || ne === "value") && r($, ne, Me, me, B, A)
                }
            }
            N & 1 && y.children !== T.children && f($, T.children)
        } else !z && R == null && M($, H, U, A, B);
        ((X = U.onVnodeUpdated) || K) && fe(() => {
            X && Te(X, A, T, y), K && qe(T, y, A, "updated")
        }, F)
    }, I = (y, T, A, F, B, D, z) => {
        for (let $ = 0; $ < T.length; $++) {
            const N = y[$],
                R = T[$],
                K = N.el && (N.type === ge || !Ve(N, R) || N.shapeFlag & 70) ? u(N.el) : A;
            v(N, R, K, null, F, B, D, z, !0)
        }
    }, M = (y, T, A, F, B) => {
        if (T !== A) {
            if (T !== ee)
                for (const D in T) !zt(D) && !(D in A) && r(y, D, T[D], null, B, F);
            for (const D in A) {
                if (zt(D)) continue;
                const z = A[D],
                    $ = T[D];
                z !== $ && D !== "value" && r(y, D, $, z, B, F)
            }
            "value" in A && r(y, "value", T.value, A.value, B)
        }
    }, _ = (y, T, A, F, B, D, z, $, N) => {
        const R = T.el = y ? y.el : a(""),
            K = T.anchor = y ? y.anchor : a("");
        let {
            patchFlag: H,
            dynamicChildren: U,
            slotScopeIds: X
        } = T;
        X && ($ = $ ? $.concat(X) : X), y == null ? (i(R, A, F), i(K, A, F), O(T.children || [], A, K, B, D, z, $, N)) : H > 0 && H & 64 && U && y.dynamicChildren ? (I(y.dynamicChildren, U, A, B, D, z, $), (T.key != null || B && T === B.subTree) && Ds(y, T, !0)) : j(y, T, A, K, B, D, z, $, N)
    }, L = (y, T, A, F, B, D, z, $, N) => {
        T.slotScopeIds = $, y == null ? T.shapeFlag & 512 ? B.ctx.activate(T, A, F, z, N) : G(T, A, F, B, D, z, N) : Y(y, T, N)
    }, G = (y, T, A, F, B, D, z) => {
        const $ = y.component = Cf(y, F, B);
        if (xn(y) && ($.ctx.renderer = Lt), _f($, !1, z), $.asyncDep) {
            if (B && B.registerDep($, V, z), !y.el) {
                const N = $.subTree = oe(ce);
                x(null, N, T, A)
            }
        } else V($, y, T, A, B, D, z)
    }, Y = (y, T, A) => {
        const F = T.component = y.component;
        if (pf(y, T, A))
            if (F.asyncDep && !F.asyncResolved) {
                k(F, T, A);
                return
            } else F.next = T, F.update();
        else T.el = y.el, F.vnode = T
    }, V = (y, T, A, F, B, D, z) => {
        const $ = () => {
            if (y.isMounted) {
                let {
                    next: H,
                    bu: U,
                    u: X,
                    parent: J,
                    vnode: se
                } = y; {
                    const Pe = Rl(y);
                    if (Pe) {
                        H && (H.el = se.el, k(y, H, z)), Pe.asyncDep.then(() => {
                            y.isUnmounted || $()
                        });
                        return
                    }
                }
                let ne = H,
                    Me;
                bt(y, !1), H ? (H.el = se.el, k(y, H, z)) : H = se, U && Vt(U), (Me = H.props && H.props.onVnodeBeforeUpdate) && Te(Me, J, H, se), bt(y, !0);
                const me = Li(y),
                    ze = y.subTree;
                y.subTree = me, v(ze, me, u(ze.el), Mn(ze), y, B, D), H.el = me.el, ne === null && yi(y, me.el), X && fe(X, B), (Me = H.props && H.props.onVnodeUpdated) && fe(() => Te(Me, J, H, se), B)
            } else {
                let H;
                const {
                    el: U,
                    props: X
                } = T, {
                    bm: J,
                    m: se,
                    parent: ne,
                    root: Me,
                    type: me
                } = y, ze = ht(T);
                if (bt(y, !1), J && Vt(J), !ze && (H = X && X.onVnodeBeforeMount) && Te(H, ne, T), bt(y, !0), U && Ti) {
                    const Pe = () => {
                        y.subTree = Li(y), Ti(U, y.subTree, y, B, null)
                    };
                    ze && me.__asyncHydrate ? me.__asyncHydrate(U, y, Pe) : Pe()
                } else {
                    Me.ce && Me.ce._injectChildStyle(me);
                    const Pe = y.subTree = Li(y);
                    v(null, Pe, A, F, y, B, D), T.el = Pe.el
                }
                if (se && fe(se, B), !ze && (H = X && X.onVnodeMounted)) {
                    const Pe = T;
                    fe(() => Te(H, ne, Pe), B)
                }(T.shapeFlag & 256 || ne && ht(ne.vnode) && ne.vnode.shapeFlag & 256) && y.a && fe(y.a, B), y.isMounted = !0, T = A = F = null
            }
        };
        y.scope.on();
        const N = y.effect = new Vr($);
        y.scope.off();
        const R = y.update = N.run.bind(N),
            K = y.job = N.runIfDirty.bind(N);
        K.i = y, K.id = y.uid, N.scheduler = () => Cs(K), bt(y, !0), R()
    }, k = (y, T, A) => {
        T.component = y;
        const F = y.vnode.props;
        y.vnode = T, y.next = null, Xa(y, T.props, F, A), ef(y, T.children, A), vt(), Gs(y), yt()
    }, j = (y, T, A, F, B, D, z, $, N = !1) => {
        const R = y && y.children,
            K = y ? y.shapeFlag : 0,
            H = T.children,
            {
                patchFlag: U,
                shapeFlag: X
            } = T;
        if (U > 0) {
            if (U & 128) {
                Ce(R, H, A, F, B, D, z, $, N);
                return
            } else if (U & 256) {
                Z(R, H, A, F, B, D, z, $, N);
                return
            }
        }
        X & 8 ? (K & 16 && Qt(R, B, D), H !== R && f(A, H)) : K & 16 ? X & 16 ? Ce(R, H, A, F, B, D, z, $, N) : Qt(R, B, D, !0) : (K & 8 && f(A, ""), X & 16 && O(H, A, F, B, D, z, $, N))
    }, Z = (y, T, A, F, B, D, z, $, N) => {
        y = y || Nt, T = T || Nt;
        const R = y.length,
            K = T.length,
            H = Math.min(R, K);
        let U;
        for (U = 0; U < H; U++) {
            const X = T[U] = N ? ut(T[U]) : Oe(T[U]);
            v(y[U], X, A, null, B, D, z, $, N)
        }
        R > K ? Qt(y, B, D, !0, !1, H) : O(T, A, F, B, D, z, $, N, H)
    }, Ce = (y, T, A, F, B, D, z, $, N) => {
        let R = 0;
        const K = T.length;
        let H = y.length - 1,
            U = K - 1;
        for (; R <= H && R <= U;) {
            const X = y[R],
                J = T[R] = N ? ut(T[R]) : Oe(T[R]);
            if (Ve(X, J)) v(X, J, A, null, B, D, z, $, N);
            else break;
            R++
        }
        for (; R <= H && R <= U;) {
            const X = y[H],
                J = T[U] = N ? ut(T[U]) : Oe(T[U]);
            if (Ve(X, J)) v(X, J, A, null, B, D, z, $, N);
            else break;
            H--, U--
        }
        if (R > H) {
            if (R <= U) {
                const X = U + 1,
                    J = X < K ? T[X].el : F;
                for (; R <= U;) v(null, T[R] = N ? ut(T[R]) : Oe(T[R]), A, J, B, D, z, $, N), R++
            }
        } else if (R > U)
            for (; R <= H;) De(y[R], B, D, !0), R++;
        else {
            const X = R,
                J = R,
                se = new Map;
            for (R = J; R <= U; R++) {
                const Ae = T[R] = N ? ut(T[R]) : Oe(T[R]);
                Ae.key != null && se.set(Ae.key, R)
            }
            let ne, Me = 0;
            const me = U - J + 1;
            let ze = !1,
                Pe = 0;
            const en = new Array(me);
            for (R = 0; R < me; R++) en[R] = 0;
            for (R = X; R <= H; R++) {
                const Ae = y[R];
                if (Me >= me) {
                    De(Ae, B, D, !0);
                    continue
                }
                let We;
                if (Ae.key != null) We = se.get(Ae.key);
                else
                    for (ne = J; ne <= U; ne++)
                        if (en[ne - J] === 0 && Ve(Ae, T[ne])) {
                            We = ne;
                            break
                        }
                We === void 0 ? De(Ae, B, D, !0) : (en[We - J] = R + 1, We >= Pe ? Pe = We : ze = !0, v(Ae, T[We], A, null, B, D, z, $, N), Me++)
            }
            const $s = ze ? sf(en) : Nt;
            for (ne = $s.length - 1, R = me - 1; R >= 0; R--) {
                const Ae = J + R,
                    We = T[Ae],
                    zs = Ae + 1 < K ? T[Ae + 1].el : F;
                en[R] === 0 ? v(null, We, A, zs, B, D, z, $, N) : ze && (ne < 0 || R !== $s[ne] ? _e(We, A, zs, 2) : ne--)
            }
        }
    }, _e = (y, T, A, F, B = null) => {
        const {
            el: D,
            type: z,
            transition: $,
            children: N,
            shapeFlag: R
        } = y;
        if (R & 6) {
            _e(y.component.subTree, T, A, F);
            return
        }
        if (R & 128) {
            y.suspense.move(T, A, F);
            return
        }
        if (R & 64) {
            z.move(y, T, A, Lt);
            return
        }
        if (z === ge) {
            i(D, T, A);
            for (let H = 0; H < N.length; H++) _e(N[H], T, A, F);
            i(y.anchor, T, A);
            return
        }
        if (z === Gt) {
            c(y, T, A);
            return
        }
        if (F !== 2 && R & 1 && $)
            if (F === 0) $.beforeEnter(D), i(D, T, A), fe(() => $.enter(D), B);
            else {
                const {
                    leave: H,
                    delayLeave: U,
                    afterLeave: X
                } = $, J = () => i(D, T, A), se = () => {
                    H(D, () => {
                        J(), X && X()
                    })
                };
                U ? U(D, J, se) : se()
            }
        else i(D, T, A)
    }, De = (y, T, A, F = !1, B = !1) => {
        const {
            type: D,
            props: z,
            ref: $,
            children: N,
            dynamicChildren: R,
            shapeFlag: K,
            patchFlag: H,
            dirs: U,
            cacheIndex: X
        } = y;
        if (H === -2 && (B = !1), $ != null && yn($, null, A, y, !0), X != null && (T.renderCache[X] = void 0), K & 256) {
            T.ctx.deactivate(y);
            return
        }
        const J = K & 1 && U,
            se = !ht(y);
        let ne;
        if (se && (ne = z && z.onVnodeBeforeUnmount) && Te(ne, T, y), K & 6) Co(y.component, A, F);
        else {
            if (K & 128) {
                y.suspense.unmount(A, F);
                return
            }
            J && qe(y, null, T, "beforeUnmount"), K & 64 ? y.type.remove(y, T, A, Lt, F) : R && !R.hasOnce && (D !== ge || H > 0 && H & 64) ? Qt(R, T, A, !1, !0) : (D === ge && H & 384 || !B && K & 16) && Qt(N, T, A), F && _n(y)
        }(se && (ne = z && z.onVnodeUnmounted) || J) && fe(() => {
            ne && Te(ne, T, y), J && qe(y, null, T, "unmounted")
        }, A)
    }, _n = y => {
        const {
            type: T,
            el: A,
            anchor: F,
            transition: B
        } = y;
        if (T === ge) {
            Eo(A, F);
            return
        }
        if (T === Gt) {
            p(y);
            return
        }
        const D = () => {
            s(A), B && !B.persisted && B.afterLeave && B.afterLeave()
        };
        if (y.shapeFlag & 1 && B && !B.persisted) {
            const {
                leave: z,
                delayLeave: $
            } = B, N = () => z(A, D);
            $ ? $(y.el, D, N) : N()
        } else D()
    }, Eo = (y, T) => {
        let A;
        for (; y !== T;) A = m(y), s(y), y = A;
        s(T)
    }, Co = (y, T, A) => {
        const {
            bum: F,
            scope: B,
            job: D,
            subTree: z,
            um: $,
            m: N,
            a: R
        } = y;
        ei(N), ei(R), F && Vt(F), B.stop(), D && (D.flags |= 8, De(z, y, T, A)), $ && fe($, T), fe(() => {
            y.isUnmounted = !0
        }, T), T && T.pendingBranch && !T.isUnmounted && y.asyncDep && !y.asyncResolved && y.suspenseId === T.pendingId && (T.deps--, T.deps === 0 && T.resolve())
    }, Qt = (y, T, A, F = !1, B = !1, D = 0) => {
        for (let z = D; z < y.length; z++) De(y[z], T, A, F, B)
    }, Mn = y => {
        if (y.shapeFlag & 6) return Mn(y.component.subTree);
        if (y.shapeFlag & 128) return y.suspense.next();
        const T = m(y.anchor || y.el),
            A = T && T[fl];
        return A ? m(A) : T
    };
    let wi = !1;
    const Ns = (y, T, A) => {
            y == null ? T._vnode && De(T._vnode, null, null, !0) : v(T._vnode || null, y, T, null, null, null, A), T._vnode = y, wi || (wi = !0, Gs(), Xn(), wi = !1)
        },
        Lt = {
            p: v,
            um: De,
            m: _e,
            r: _n,
            mt: G,
            mc: O,
            pc: j,
            pbc: I,
            n: Mn,
            o: e
        };
    let Si, Ti;
    return t && ([Si, Ti] = t(Lt)), {
        render: Ns,
        hydrate: Si,
        createApp: qa(Ns, Si)
    }
}

function Oi({
    type: e,
    props: t
}, n) {
    return n === "svg" && e === "foreignObject" || n === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : n
}

function bt({
    effect: e,
    job: t
}, n) {
    n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5)
}

function Fl(e, t) {
    return (!e || e && !e.pendingBranch) && t && !t.persisted
}

function Ds(e, t, n = !1) {
    const i = e.children,
        s = t.children;
    if (W(i) && W(s))
        for (let r = 0; r < i.length; r++) {
            const l = i[r];
            let a = s[r];
            a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = s[r] = ut(s[r]), a.el = l.el), !n && a.patchFlag !== -2 && Ds(l, a)), a.type === Ct && (a.el = l.el)
        }
}

function sf(e) {
    const t = e.slice(),
        n = [0];
    let i, s, r, l, a;
    const o = e.length;
    for (i = 0; i < o; i++) {
        const d = e[i];
        if (d !== 0) {
            if (s = n[n.length - 1], e[s] < d) {
                t[i] = s, n.push(i);
                continue
            }
            for (r = 0, l = n.length - 1; r < l;) a = r + l >> 1, e[n[a]] < d ? r = a + 1 : l = a;
            d < e[n[r]] && (r > 0 && (t[i] = n[r - 1]), n[r] = i)
        }
    }
    for (r = n.length, l = n[r - 1]; r-- > 0;) n[r] = l, l = t[l];
    return n
}

function Rl(e) {
    const t = e.subTree.component;
    if (t) return t.asyncDep && !t.asyncResolved ? t : Rl(t)
}

function ei(e) {
    if (e)
        for (let t = 0; t < e.length; t++) e[t].flags |= 8
}
const rf = Symbol.for("v-scx"),
    lf = () => Hn(rf);

function od(e, t) {
    return mi(e, null, t)
}

function of (e, t) {
    return mi(e, null, {
        flush: "sync"
    })
}

function kt(e, t, n) {
    return mi(e, t, n)
}

function mi(e, t, n = ee) {
    const {
        immediate: i,
        deep: s,
        flush: r,
        once: l
    } = n, a = ae({}, n), o = t && i || !t && r !== "post";
    let d;
    if (Ut) {
        if (r === "sync") {
            const g = lf();
            d = g.__watcherHandles || (g.__watcherHandles = [])
        } else if (!o) {
            const g = () => {};
            return g.stop = He, g.resume = He, g.pause = He, g
        }
    }
    const f = ue;
    a.call = (g, S, v) => Ge(g, f, S, v);
    let u = !1;
    r === "post" ? a.scheduler = g => {
        fe(g, f && f.suspense)
    } : r !== "sync" && (u = !0, a.scheduler = (g, S) => {
        S ? g() : Cs(g)
    }), a.augmentJob = g => {
        t && (g.flags |= 4), u && (g.flags |= 2, f && (g.id = f.uid, g.i = f))
    };
    const m = ya(e, t, a);
    return Ut && (d ? d.push(m) : o && m()), m
}

function af(e, t, n) {
    const i = this.proxy,
        s = le(e) ? e.includes(".") ? Nl(i, e) : () => i[e] : e.bind(i, i);
    let r;
    q(t) ? r = t : (r = t.handler, n = t);
    const l = It(this),
        a = mi(s, r.bind(i), n);
    return l(), a
}

function Nl(e, t) {
    const n = t.split(".");
    return () => {
        let i = e;
        for (let s = 0; s < n.length && i; s++) i = i[n[s]];
        return i
    }
}

function ad(e, t, n = ee) {
    const i = lt(),
        s = Le(t),
        r = st(t),
        l = $l(e, s),
        a = da((o, d) => {
            let f, u = ee,
                m;
            return of(() => {
                const g = e[s];
                xe(f, g) && (f = g, d())
            }), {
                get() {
                    return o(), n.get ? n.get(f) : f
                },
                set(g) {
                    const S = n.set ? n.set(g) : g;
                    if (!xe(S, f) && !(u !== ee && xe(g, u))) return;
                    const v = i.vnode.props;
                    v && (t in v || s in v || r in v) && (`onUpdate:${t}` in v || `onUpdate:${s}` in v || `onUpdate:${r}` in v) || (f = g, d()), i.emit(`update:${t}`, S), xe(g, S) && xe(g, u) && !xe(S, m) && d(), u = g, m = S
                }
            }
        });
    return a[Symbol.iterator] = () => {
        let o = 0;
        return {
            next() {
                return o < 2 ? {
                    value: o++ ? l || ee : a,
                    done: !1
                } : {
                    done: !0
                }
            }
        }
    }, a
}
const $l = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${Le(t)}Modifiers`] || e[`${st(t)}Modifiers`];

function ff(e, t, ...n) {
    if (e.isUnmounted) return;
    const i = e.vnode.props || ee;
    let s = n;
    const r = t.startsWith("update:"),
        l = r && $l(i, t.slice(7));
    l && (l.trim && (s = n.map(f => le(f) ? f.trim() : f)), l.number && (s = n.map(Wn)));
    let a, o = i[a = zn(t)] || i[a = zn(Le(t))];
    !o && r && (o = i[a = zn(st(t))]), o && Ge(o, e, 6, s);
    const d = i[a + "Once"];
    if (d) {
        if (!e.emitted) e.emitted = {};
        else if (e.emitted[a]) return;
        e.emitted[a] = !0, Ge(d, e, 6, s)
    }
}

function zl(e, t, n = !1) {
    const i = t.emitsCache,
        s = i.get(e);
    if (s !== void 0) return s;
    const r = e.emits;
    let l = {},
        a = !1;
    if (!q(e)) {
        const o = d => {
            const f = zl(d, t, !0);
            f && (a = !0, ae(l, f))
        };
        !n && t.mixins.length && t.mixins.forEach(o), e.extends && o(e.extends), e.mixins && e.mixins.forEach(o)
    }
    return !r && !a ? (ie(e) && i.set(e, null), null) : (W(r) ? r.forEach(o => l[o] = null) : ae(l, r), ie(e) && i.set(e, l), l)
}

function vi(e, t) {
    return !e || !Sn(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), te(e, t[0].toLowerCase() + t.slice(1)) || te(e, st(t)) || te(e, t))
}

function Li(e) {
    const {
        type: t,
        vnode: n,
        proxy: i,
        withProxy: s,
        propsOptions: [r],
        slots: l,
        attrs: a,
        emit: o,
        render: d,
        renderCache: f,
        props: u,
        data: m,
        setupState: g,
        ctx: S,
        inheritAttrs: v
    } = e, E = Jn(e);
    let x, h;
    try {
        if (n.shapeFlag & 4) {
            const p = s || i,
                w = p;
            x = Oe(d.call(w, p, f, u, g, m, S)), h = a
        } else {
            const p = t;
            x = Oe(p.length > 1 ? p(u, {
                attrs: a,
                slots: l,
                emit: o
            }) : p(u, null)), h = t.props ? a : uf(a)
        }
    } catch (p) {
        dn.length = 0, Jt(p, e, 1), x = oe(ce)
    }
    let c = x;
    if (h && v !== !1) {
        const p = Object.keys(h),
            {
                shapeFlag: w
            } = c;
        p.length && w & 7 && (r && p.some(ds) && (h = df(h, r)), c = it(c, h, !1, !0))
    }
    return n.dirs && (c = it(c, null, !1, !0), c.dirs = c.dirs ? c.dirs.concat(n.dirs) : n.dirs), n.transition && gt(c, n.transition), x = c, Jn(E), x
}

function cf(e, t = !0) {
    let n;
    for (let i = 0; i < e.length; i++) {
        const s = e[i];
        if (At(s)) {
            if (s.type !== ce || s.children === "v-if") {
                if (n) return;
                n = s
            }
        } else return
    }
    return n
}
const uf = e => {
        let t;
        for (const n in e)(n === "class" || n === "style" || Sn(n)) && ((t || (t = {}))[n] = e[n]);
        return t
    },
    df = (e, t) => {
        const n = {};
        for (const i in e)(!ds(i) || !(i.slice(9) in t)) && (n[i] = e[i]);
        return n
    };

function pf(e, t, n) {
    const {
        props: i,
        children: s,
        component: r
    } = e, {
        props: l,
        children: a,
        patchFlag: o
    } = t, d = r.emitsOptions;
    if (t.dirs || t.transition) return !0;
    if (n && o >= 0) {
        if (o & 1024) return !0;
        if (o & 16) return i ? nr(i, l, d) : !!l;
        if (o & 8) {
            const f = t.dynamicProps;
            for (let u = 0; u < f.length; u++) {
                const m = f[u];
                if (l[m] !== i[m] && !vi(d, m)) return !0
            }
        }
    } else return (s || a) && (!a || !a.$stable) ? !0 : i === l ? !1 : i ? l ? nr(i, l, d) : !0 : !!l;
    return !1
}

function nr(e, t, n) {
    const i = Object.keys(t);
    if (i.length !== Object.keys(e).length) return !0;
    for (let s = 0; s < i.length; s++) {
        const r = i[s];
        if (t[r] !== e[r] && !vi(n, r)) return !0
    }
    return !1
}

function yi({
    vnode: e,
    parent: t
}, n) {
    for (; t;) {
        const i = t.subTree;
        if (i.suspense && i.suspense.activeBranch === e && (i.el = e.el), i === e)(e = t.vnode).el = n, t = t.parent;
        else break
    }
}
const ti = e => e.__isSuspense;
let Qi = 0;
const hf = {
        name: "Suspense",
        __isSuspense: !0,
        process(e, t, n, i, s, r, l, a, o, d) {
            if (e == null) gf(t, n, i, s, r, l, a, o, d);
            else {
                if (r && r.deps > 0 && !e.suspense.isInFallback) {
                    t.suspense = e.suspense, t.suspense.vnode = t, t.el = e.el;
                    return
                }
                mf(e, t, n, i, s, l, a, o, d)
            }
        },
        hydrate: vf,
        normalize: yf
    },
    fd = hf;

function bn(e, t) {
    const n = e.props && e.props[t];
    q(n) && n()
}

function gf(e, t, n, i, s, r, l, a, o) {
    const {
        p: d,
        o: {
            createElement: f
        }
    } = o, u = f("div"), m = e.suspense = Vl(e, s, i, t, u, n, r, l, a, o);
    d(null, m.pendingBranch = e.ssContent, u, null, i, m, r, l), m.deps > 0 ? (bn(e, "onPending"), bn(e, "onFallback"), d(null, e.ssFallback, t, n, i, null, r, l), jt(m, e.ssFallback)) : m.resolve(!1, !0)
}

function mf(e, t, n, i, s, r, l, a, {
    p: o,
    um: d,
    o: {
        createElement: f
    }
}) {
    const u = t.suspense = e.suspense;
    u.vnode = t, t.el = e.el;
    const m = t.ssContent,
        g = t.ssFallback,
        {
            activeBranch: S,
            pendingBranch: v,
            isInFallback: E,
            isHydrating: x
        } = u;
    if (v) u.pendingBranch = m, Ve(m, v) ? (o(v, m, u.hiddenContainer, null, s, u, r, l, a), u.deps <= 0 ? u.resolve() : E && (x || (o(S, g, n, i, s, null, r, l, a), jt(u, g)))) : (u.pendingId = Qi++, x ? (u.isHydrating = !1, u.activeBranch = v) : d(v, s, u), u.deps = 0, u.effects.length = 0, u.hiddenContainer = f("div"), E ? (o(null, m, u.hiddenContainer, null, s, u, r, l, a), u.deps <= 0 ? u.resolve() : (o(S, g, n, i, s, null, r, l, a), jt(u, g))) : S && Ve(m, S) ? (o(S, m, n, i, s, u, r, l, a), u.resolve(!0)) : (o(null, m, u.hiddenContainer, null, s, u, r, l, a), u.deps <= 0 && u.resolve()));
    else if (S && Ve(m, S)) o(S, m, n, i, s, u, r, l, a), jt(u, m);
    else if (bn(t, "onPending"), u.pendingBranch = m, m.shapeFlag & 512 ? u.pendingId = m.component.suspenseId : u.pendingId = Qi++, o(null, m, u.hiddenContainer, null, s, u, r, l, a), u.deps <= 0) u.resolve();
    else {
        const {
            timeout: h,
            pendingId: c
        } = u;
        h > 0 ? setTimeout(() => {
            u.pendingId === c && u.fallback(g)
        }, h) : h === 0 && u.fallback(g)
    }
}

function Vl(e, t, n, i, s, r, l, a, o, d, f = !1) {
    const {
        p: u,
        m,
        um: g,
        n: S,
        o: {
            parentNode: v,
            remove: E
        }
    } = d;
    let x;
    const h = bf(e);
    h && t && t.pendingBranch && (x = t.pendingId, t.deps++);
    const c = e.props ? Fr(e.props.timeout) : void 0,
        p = r,
        w = {
            vnode: e,
            parent: t,
            parentComponent: n,
            namespace: l,
            container: i,
            hiddenContainer: s,
            deps: 0,
            pendingId: Qi++,
            timeout: typeof c == "number" ? c : -1,
            activeBranch: null,
            pendingBranch: null,
            isInFallback: !f,
            isHydrating: f,
            isUnmounted: !1,
            effects: [],
            resolve(C = !1, P = !1) {
                const {
                    vnode: O,
                    activeBranch: b,
                    pendingBranch: I,
                    pendingId: M,
                    effects: _,
                    parentComponent: L,
                    container: G
                } = w;
                let Y = !1;
                w.isHydrating ? w.isHydrating = !1 : C || (Y = b && I.transition && I.transition.mode === "out-in", Y && (b.transition.afterLeave = () => {
                    M === w.pendingId && (m(I, G, r === p ? S(b) : r, 0), Yn(_))
                }), b && (v(b.el) === G && (r = S(b)), g(b, L, w, !0)), Y || m(I, G, r, 0)), jt(w, I), w.pendingBranch = null, w.isInFallback = !1;
                let V = w.parent,
                    k = !1;
                for (; V;) {
                    if (V.pendingBranch) {
                        V.effects.push(..._), k = !0;
                        break
                    }
                    V = V.parent
                }!k && !Y && Yn(_), w.effects = [], h && t && t.pendingBranch && x === t.pendingId && (t.deps--, t.deps === 0 && !P && t.resolve()), bn(O, "onResolve")
            },
            fallback(C) {
                if (!w.pendingBranch) return;
                const {
                    vnode: P,
                    activeBranch: O,
                    parentComponent: b,
                    container: I,
                    namespace: M
                } = w;
                bn(P, "onFallback");
                const _ = S(O),
                    L = () => {
                        w.isInFallback && (u(null, C, I, _, b, null, M, a, o), jt(w, C))
                    },
                    G = C.transition && C.transition.mode === "out-in";
                G && (O.transition.afterLeave = L), w.isInFallback = !0, g(O, b, null, !0), G || L()
            },
            move(C, P, O) {
                w.activeBranch && m(w.activeBranch, C, P, O), w.container = C
            },
            next() {
                return w.activeBranch && S(w.activeBranch)
            },
            registerDep(C, P, O) {
                const b = !!w.pendingBranch;
                b && w.deps++;
                const I = C.vnode.el;
                C.asyncDep.catch(M => {
                    Jt(M, C, 0)
                }).then(M => {
                    if (C.isUnmounted || w.isUnmounted || w.pendingId !== C.suspenseId) return;
                    C.asyncResolved = !0;
                    const {
                        vnode: _
                    } = C;
                    is(C, M), I && (_.el = I);
                    const L = !I && C.subTree.el;
                    P(C, _, v(I || C.subTree.el), I ? null : S(C.subTree), w, l, O), L && E(L), yi(C, _.el), b && --w.deps === 0 && w.resolve()
                })
            },
            unmount(C, P) {
                w.isUnmounted = !0, w.activeBranch && g(w.activeBranch, n, C, P), w.pendingBranch && g(w.pendingBranch, n, C, P)
            }
        };
    return w
}

function vf(e, t, n, i, s, r, l, a, o) {
    const d = t.suspense = Vl(t, i, n, e.parentNode, document.createElement("div"), null, s, r, l, a, !0),
        f = o(e, d.pendingBranch = t.ssContent, n, d, r, l);
    return d.deps === 0 && d.resolve(!1, !0), f
}

function yf(e) {
    const {
        shapeFlag: t,
        children: n
    } = e, i = t & 32;
    e.ssContent = ir(i ? n.default : n), e.ssFallback = i ? ir(n.fallback) : oe(ce)
}

function ir(e) {
    let t;
    if (q(e)) {
        const n = Wt && e._c;
        n && (e._d = !1, ni()), e = e(), n && (e._d = !0, t = Ee, kl())
    }
    return W(e) && (e = cf(e)), e = Oe(e), t && !e.dynamicChildren && (e.dynamicChildren = t.filter(n => n !== e)), e
}

function Hl(e, t) {
    t && t.pendingBranch ? W(e) ? t.effects.push(...e) : t.effects.push(e) : Yn(e)
}

function jt(e, t) {
    e.activeBranch = t;
    const {
        vnode: n,
        parentComponent: i
    } = e;
    let s = t.el;
    for (; !s && t.component;) t = t.component.subTree, s = t.el;
    n.el = s, i && i.subTree === n && (i.vnode.el = s, yi(i, s))
}

function bf(e) {
    const t = e.props && e.props.suspensible;
    return t != null && t !== !1
}
const ge = Symbol.for("v-fgt"),
    Ct = Symbol.for("v-txt"),
    ce = Symbol.for("v-cmt"),
    Gt = Symbol.for("v-stc"),
    dn = [];
let Ee = null;

function ni(e = !1) {
    dn.push(Ee = e ? null : [])
}

function kl() {
    dn.pop(), Ee = dn[dn.length - 1] || null
}
let Wt = 1;

function sr(e, t = !1) {
    Wt += e, e < 0 && Ee && t && (Ee.hasOnce = !0)
}

function jl(e) {
    return e.dynamicChildren = Wt > 0 ? Ee || Nt : null, kl(), Wt > 0 && Ee && Ee.push(e), e
}

function cd(e, t, n, i, s, r) {
    return jl(Wl(e, t, n, i, s, r, !0))
}

function es(e, t, n, i, s) {
    return jl(oe(e, t, n, i, s, !0))
}

function At(e) {
    return e ? e.__v_isVNode === !0 : !1
}

function Ve(e, t) {
    return e.type === t.type && e.key === t.key
}
const Gl = ({
        key: e
    }) => e ? ? null,
    kn = ({
        ref: e,
        ref_key: t,
        ref_for: n
    }) => (typeof e == "number" && (e = "" + e), e != null ? le(e) || he(e) || q(e) ? {
        i: de,
        r: e,
        k: t,
        f: !!n
    } : e : null);

function Wl(e, t = null, n = null, i = 0, s = null, r = e === ge ? 0 : 1, l = !1, a = !1) {
    const o = {
        __v_isVNode: !0,
        __v_skip: !0,
        type: e,
        props: t,
        key: t && Gl(t),
        ref: t && kn(t),
        scopeId: al,
        slotScopeIds: null,
        children: n,
        component: null,
        suspense: null,
        ssContent: null,
        ssFallback: null,
        dirs: null,
        transition: null,
        el: null,
        anchor: null,
        target: null,
        targetStart: null,
        targetAnchor: null,
        staticCount: 0,
        shapeFlag: r,
        patchFlag: i,
        dynamicProps: s,
        dynamicChildren: null,
        appContext: null,
        ctx: de
    };
    return a ? (Fs(o, n), r & 128 && e.normalize(o)) : n && (o.shapeFlag |= le(n) ? 8 : 16), Wt > 0 && !l && Ee && (o.patchFlag > 0 || r & 6) && o.patchFlag !== 32 && Ee.push(o), o
}
const oe = wf;

function wf(e, t = null, n = null, i = 0, s = null, r = !1) {
    if ((!e || e === bl) && (e = ce), At(e)) {
        const a = it(e, t, !0);
        return n && Fs(a, n), Wt > 0 && !r && Ee && (a.shapeFlag & 6 ? Ee[Ee.indexOf(e)] = a : Ee.push(a)), a.patchFlag = -2, a
    }
    if (Af(e) && (e = e.__vccOpts), t) {
        t = Sf(t);
        let {
            class: a,
            style: o
        } = t;
        a && !le(a) && (t.class = di(a)), ie(o) && (xs(o) && !W(o) && (o = ae({}, o)), t.style = ui(o))
    }
    const l = le(e) ? 1 : ti(e) ? 128 : cl(e) ? 64 : ie(e) ? 4 : q(e) ? 2 : 0;
    return Wl(e, t, n, i, s, l, r, !0)
}

function Sf(e) {
    return e ? xs(e) || Ml(e) ? ae({}, e) : e : null
}

function it(e, t, n = !1, i = !1) {
    const {
        props: s,
        ref: r,
        patchFlag: l,
        children: a,
        transition: o
    } = e, d = t ? Tf(s || {}, t) : s, f = {
        __v_isVNode: !0,
        __v_skip: !0,
        type: e.type,
        props: d,
        key: d && Gl(d),
        ref: t && t.ref ? n && r ? W(r) ? r.concat(kn(t)) : [r, kn(t)] : kn(t) : r,
        scopeId: e.scopeId,
        slotScopeIds: e.slotScopeIds,
        children: a,
        target: e.target,
        targetStart: e.targetStart,
        targetAnchor: e.targetAnchor,
        staticCount: e.staticCount,
        shapeFlag: e.shapeFlag,
        patchFlag: t && e.type !== ge ? l === -1 ? 16 : l | 16 : l,
        dynamicProps: e.dynamicProps,
        dynamicChildren: e.dynamicChildren,
        appContext: e.appContext,
        dirs: e.dirs,
        transition: o,
        component: e.component,
        suspense: e.suspense,
        ssContent: e.ssContent && it(e.ssContent),
        ssFallback: e.ssFallback && it(e.ssFallback),
        el: e.el,
        anchor: e.anchor,
        ctx: e.ctx,
        ce: e.ce
    };
    return o && i && gt(f, o.clone(f)), f
}

function Ul(e = " ", t = 0) {
    return oe(Ct, null, e, t)
}

function ud(e, t) {
    const n = oe(Gt, null, e);
    return n.staticCount = t, n
}

function dd(e = "", t = !1) {
    return t ? (ni(), es(ce, null, e)) : oe(ce, null, e)
}

function Oe(e) {
    return e == null || typeof e == "boolean" ? oe(ce) : W(e) ? oe(ge, null, e.slice()) : At(e) ? ut(e) : oe(Ct, null, String(e))
}

function ut(e) {
    return e.el === null && e.patchFlag !== -1 || e.memo ? e : it(e)
}

function Fs(e, t) {
    let n = 0;
    const {
        shapeFlag: i
    } = e;
    if (t == null) t = null;
    else if (W(t)) n = 16;
    else if (typeof t == "object")
        if (i & 65) {
            const s = t.default;
            s && (s._c && (s._d = !1), Fs(e, s()), s._c && (s._d = !0));
            return
        } else {
            n = 32;
            const s = t._;
            !s && !Ml(t) ? t._ctx = de : s === 3 && de && (de.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024))
        }
    else q(t) ? (t = {
        default: t,
        _ctx: de
    }, n = 32) : (t = String(t), i & 64 ? (n = 16, t = [Ul(t)]) : n = 8);
    e.children = t, e.shapeFlag |= n
}

function Tf(...e) {
    const t = {};
    for (let n = 0; n < e.length; n++) {
        const i = e[n];
        for (const s in i)
            if (s === "class") t.class !== i.class && (t.class = di([t.class, i.class]));
            else if (s === "style") t.style = ui([t.style, i.style]);
        else if (Sn(s)) {
            const r = t[s],
                l = i[s];
            l && r !== l && !(W(r) && r.includes(l)) && (t[s] = r ? [].concat(r, l) : l)
        } else s !== "" && (t[s] = i[s])
    }
    return t
}

function Te(e, t, n, i = null) {
    Ge(e, t, 7, [n, i])
}
const xf = El();
let Ef = 0;

function Cf(e, t, n) {
    const i = e.type,
        s = (t ? t.appContext : e.appContext) || xf,
        r = {
            uid: Ef++,
            vnode: e,
            type: i,
            parent: t,
            appContext: s,
            root: null,
            next: null,
            subTree: null,
            effect: null,
            update: null,
            job: null,
            scope: new zr(!0),
            render: null,
            proxy: null,
            exposed: null,
            exposeProxy: null,
            withProxy: null,
            provides: t ? t.provides : Object.create(s.provides),
            ids: t ? t.ids : ["", 0, 0],
            accessCache: null,
            renderCache: [],
            components: null,
            directives: null,
            propsOptions: Al(i, s),
            emitsOptions: zl(i, s),
            emit: null,
            emitted: null,
            propsDefaults: ee,
            inheritAttrs: i.inheritAttrs,
            ctx: ee,
            data: ee,
            props: ee,
            attrs: ee,
            slots: ee,
            refs: ee,
            setupState: ee,
            setupContext: null,
            suspense: n,
            suspenseId: n ? n.pendingId : 0,
            asyncDep: null,
            asyncResolved: !1,
            isMounted: !1,
            isUnmounted: !1,
            isDeactivated: !1,
            bc: null,
            c: null,
            bm: null,
            m: null,
            bu: null,
            u: null,
            um: null,
            bum: null,
            da: null,
            a: null,
            rtg: null,
            rtc: null,
            ec: null,
            sp: null
        };
    return r.ctx = {
        _: r
    }, r.root = t ? t.root : r, r.emit = ff.bind(null, r), e.ce && e.ce(r), r
}
let ue = null;
const lt = () => ue || de;
let ii, ts; {
    const e = ci(),
        t = (n, i) => {
            let s;
            return (s = e[n]) || (s = e[n] = []), s.push(i), r => {
                s.length > 1 ? s.forEach(l => l(r)) : s[0](r)
            }
        };
    ii = t("__VUE_INSTANCE_SETTERS__", n => ue = n), ts = t("__VUE_SSR_SETTERS__", n => Ut = n)
}
const It = e => {
        const t = ue;
        return ii(e), e.scope.on(), () => {
            e.scope.off(), ii(t)
        }
    },
    ns = () => {
        ue && ue.scope.off(), ii(null)
    };

function Kl(e) {
    return e.vnode.shapeFlag & 4
}
let Ut = !1;

function _f(e, t = !1, n = !1) {
    t && ts(t);
    const {
        props: i,
        children: s
    } = e.vnode, r = Kl(e);
    Ya(e, i, r, t), Qa(e, s, n);
    const l = r ? Mf(e, t) : void 0;
    return t && ts(!1), l
}

function Mf(e, t) {
    const n = e.type;
    e.accessCache = Object.create(null), e.proxy = new Proxy(e.ctx, Ha);
    const {
        setup: i
    } = n;
    if (i) {
        vt();
        const s = e.setupContext = i.length > 1 ? Yl(e) : null,
            r = It(e),
            l = Tn(i, e, 0, [e.props, s]),
            a = hs(l);
        if (yt(), r(), (a || e.sp) && !ht(e) && Ms(e), a) {
            if (l.then(ns, ns), t) return l.then(o => {
                is(e, o)
            }).catch(o => {
                Jt(o, e, 0)
            });
            e.asyncDep = l
        } else is(e, l)
    } else ql(e)
}

function is(e, t, n) {
    q(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : ie(t) && (e.setupState = il(t)), ql(e)
}

function ql(e, t, n) {
    const i = e.type;
    e.render || (e.render = i.render || He); {
        const s = It(e);
        vt();
        try {
            ka(e)
        } finally {
            yt(), s()
        }
    }
}
const Pf = {
    get(e, t) {
        return ve(e, "get", ""), e[t]
    }
};

function Yl(e) {
    const t = n => {
        e.exposed = n || {}
    };
    return {
        attrs: new Proxy(e.attrs, Pf),
        slots: e.slots,
        emit: e.emit,
        expose: t
    }
}

function bi(e) {
    return e.exposed ? e.exposeProxy || (e.exposeProxy = new Proxy(il(oa(e.exposed)), {
        get(t, n) {
            if (n in t) return t[n];
            if (n in un) return un[n](e)
        },
        has(t, n) {
            return n in t || n in un
        }
    })) : e.proxy
}

function ss(e, t = !0) {
    return q(e) ? e.displayName || e.name : e.name || t && e.__name
}

function Af(e) {
    return q(e) && "__vccOpts" in e
}
const Xl = (e, t) => ma(e, t, Ut);

function Re(e, t, n) {
    const i = arguments.length;
    return i === 2 ? ie(t) && !W(t) ? At(t) ? oe(e, null, [t]) : oe(e, t) : oe(e, null, t) : (i > 3 ? n = Array.prototype.slice.call(arguments, 2) : i === 3 && At(n) && (n = [n]), oe(e, t, n))
}
const If = "3.5.13";
/**
 * @vue/runtime-dom v3.5.13
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
let rs;
const rr = typeof window < "u" && window.trustedTypes;
if (rr) try {
    rs = rr.createPolicy("vue", {
        createHTML: e => e
    })
} catch {}
const Jl = rs ? e => rs.createHTML(e) : e => e,
    Of = "http://www.w3.org/2000/svg",
    Lf = "http://www.w3.org/1998/Math/MathML",
    Qe = typeof document < "u" ? document : null,
    lr = Qe && Qe.createElement("template"),
    Bf = {
        insert: (e, t, n) => {
            t.insertBefore(e, n || null)
        },
        remove: e => {
            const t = e.parentNode;
            t && t.removeChild(e)
        },
        createElement: (e, t, n, i) => {
            const s = t === "svg" ? Qe.createElementNS(Of, e) : t === "mathml" ? Qe.createElementNS(Lf, e) : n ? Qe.createElement(e, {
                is: n
            }) : Qe.createElement(e);
            return e === "select" && i && i.multiple != null && s.setAttribute("multiple", i.multiple), s
        },
        createText: e => Qe.createTextNode(e),
        createComment: e => Qe.createComment(e),
        setText: (e, t) => {
            e.nodeValue = t
        },
        setElementText: (e, t) => {
            e.textContent = t
        },
        parentNode: e => e.parentNode,
        nextSibling: e => e.nextSibling,
        querySelector: e => Qe.querySelector(e),
        setScopeId(e, t) {
            e.setAttribute(t, "")
        },
        insertStaticContent(e, t, n, i, s, r) {
            const l = n ? n.previousSibling : t.lastChild;
            if (s && (s === r || s.nextSibling))
                for (; t.insertBefore(s.cloneNode(!0), n), !(s === r || !(s = s.nextSibling)););
            else {
                lr.innerHTML = Jl(i === "svg" ? `<svg>${e}</svg>` : i === "mathml" ? `<math>${e}</math>` : e);
                const a = lr.content;
                if (i === "svg" || i === "mathml") {
                    const o = a.firstChild;
                    for (; o.firstChild;) a.appendChild(o.firstChild);
                    a.removeChild(o)
                }
                t.insertBefore(a, n)
            }
            return [l ? l.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild]
        }
    },
    ot = "transition",
    nn = "animation",
    Kt = Symbol("_vtc"),
    Zl = {
        name: String,
        type: String,
        css: {
            type: Boolean,
            default: !0
        },
        duration: [String, Number, Object],
        enterFromClass: String,
        enterActiveClass: String,
        enterToClass: String,
        appearFromClass: String,
        appearActiveClass: String,
        appearToClass: String,
        leaveFromClass: String,
        leaveActiveClass: String,
        leaveToClass: String
    },
    Ql = ae({}, hl, Zl),
    Df = e => (e.displayName = "Transition", e.props = Ql, e),
    pd = Df((e, {
        slots: t
    }) => Re(Ea, eo(e), t)),
    wt = (e, t = []) => {
        W(e) ? e.forEach(n => n(...t)) : e && e(...t)
    },
    or = e => e ? W(e) ? e.some(t => t.length > 1) : e.length > 1 : !1;

function eo(e) {
    const t = {};
    for (const _ in e) _ in Zl || (t[_] = e[_]);
    if (e.css === !1) return t;
    const {
        name: n = "v",
        type: i,
        duration: s,
        enterFromClass: r = `${n}-enter-from`,
        enterActiveClass: l = `${n}-enter-active`,
        enterToClass: a = `${n}-enter-to`,
        appearFromClass: o = r,
        appearActiveClass: d = l,
        appearToClass: f = a,
        leaveFromClass: u = `${n}-leave-from`,
        leaveActiveClass: m = `${n}-leave-active`,
        leaveToClass: g = `${n}-leave-to`
    } = e, S = Ff(s), v = S && S[0], E = S && S[1], {
        onBeforeEnter: x,
        onEnter: h,
        onEnterCancelled: c,
        onLeave: p,
        onLeaveCancelled: w,
        onBeforeAppear: C = x,
        onAppear: P = h,
        onAppearCancelled: O = c
    } = t, b = (_, L, G, Y) => {
        _._enterCancelled = Y, at(_, L ? f : a), at(_, L ? d : l), G && G()
    }, I = (_, L) => {
        _._isLeaving = !1, at(_, u), at(_, g), at(_, m), L && L()
    }, M = _ => (L, G) => {
        const Y = _ ? P : h,
            V = () => b(L, _, G);
        wt(Y, [L, V]), ar(() => {
            at(L, _ ? o : r), Ue(L, _ ? f : a), or(Y) || fr(L, i, v, V)
        })
    };
    return ae(t, {
        onBeforeEnter(_) {
            wt(x, [_]), Ue(_, r), Ue(_, l)
        },
        onBeforeAppear(_) {
            wt(C, [_]), Ue(_, o), Ue(_, d)
        },
        onEnter: M(!1),
        onAppear: M(!0),
        onLeave(_, L) {
            _._isLeaving = !0;
            const G = () => I(_, L);
            Ue(_, u), _._enterCancelled ? (Ue(_, m), ls()) : (ls(), Ue(_, m)), ar(() => {
                _._isLeaving && (at(_, u), Ue(_, g), or(p) || fr(_, i, E, G))
            }), wt(p, [_, G])
        },
        onEnterCancelled(_) {
            b(_, !1, void 0, !0), wt(c, [_])
        },
        onAppearCancelled(_) {
            b(_, !0, void 0, !0), wt(O, [_])
        },
        onLeaveCancelled(_) {
            I(_), wt(w, [_])
        }
    })
}

function Ff(e) {
    if (e == null) return null;
    if (ie(e)) return [Bi(e.enter), Bi(e.leave)]; {
        const t = Bi(e);
        return [t, t]
    }
}

function Bi(e) {
    return Fr(e)
}

function Ue(e, t) {
    t.split(/\s+/).forEach(n => n && e.classList.add(n)), (e[Kt] || (e[Kt] = new Set)).add(t)
}

function at(e, t) {
    t.split(/\s+/).forEach(i => i && e.classList.remove(i));
    const n = e[Kt];
    n && (n.delete(t), n.size || (e[Kt] = void 0))
}

function ar(e) {
    requestAnimationFrame(() => {
        requestAnimationFrame(e)
    })
}
let Rf = 0;

function fr(e, t, n, i) {
    const s = e._endId = ++Rf,
        r = () => {
            s === e._endId && i()
        };
    if (n != null) return setTimeout(r, n);
    const {
        type: l,
        timeout: a,
        propCount: o
    } = to(e, t);
    if (!l) return i();
    const d = l + "end";
    let f = 0;
    const u = () => {
            e.removeEventListener(d, m), r()
        },
        m = g => {
            g.target === e && ++f >= o && u()
        };
    setTimeout(() => {
        f < o && u()
    }, a + 1), e.addEventListener(d, m)
}

function to(e, t) {
    const n = window.getComputedStyle(e),
        i = S => (n[S] || "").split(", "),
        s = i(`${ot}Delay`),
        r = i(`${ot}Duration`),
        l = cr(s, r),
        a = i(`${nn}Delay`),
        o = i(`${nn}Duration`),
        d = cr(a, o);
    let f = null,
        u = 0,
        m = 0;
    t === ot ? l > 0 && (f = ot, u = l, m = r.length) : t === nn ? d > 0 && (f = nn, u = d, m = o.length) : (u = Math.max(l, d), f = u > 0 ? l > d ? ot : nn : null, m = f ? f === ot ? r.length : o.length : 0);
    const g = f === ot && /\b(transform|all)(,|$)/.test(i(`${ot}Property`).toString());
    return {
        type: f,
        timeout: u,
        propCount: m,
        hasTransform: g
    }
}

function cr(e, t) {
    for (; e.length < t.length;) e = e.concat(e);
    return Math.max(...t.map((n, i) => ur(n) + ur(e[i])))
}

function ur(e) {
    return e === "auto" ? 0 : Number(e.slice(0, -1).replace(",", ".")) * 1e3
}

function ls() {
    return document.body.offsetHeight
}

function Nf(e, t, n) {
    const i = e[Kt];
    i && (t = (t ? [t, ...i] : [...i]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t
}
const si = Symbol("_vod"),
    no = Symbol("_vsh"),
    hd = {
        beforeMount(e, {
            value: t
        }, {
            transition: n
        }) {
            e[si] = e.style.display === "none" ? "" : e.style.display, n && t ? n.beforeEnter(e) : sn(e, t)
        },
        mounted(e, {
            value: t
        }, {
            transition: n
        }) {
            n && t && n.enter(e)
        },
        updated(e, {
            value: t,
            oldValue: n
        }, {
            transition: i
        }) {
            !t != !n && (i ? t ? (i.beforeEnter(e), sn(e, !0), i.enter(e)) : i.leave(e, () => {
                sn(e, !1)
            }) : sn(e, t))
        },
        beforeUnmount(e, {
            value: t
        }) {
            sn(e, t)
        }
    };

function sn(e, t) {
    e.style.display = t ? e[si] : "none", e[no] = !t
}
const io = Symbol("");

function gd(e) {
    const t = lt();
    if (!t) return;
    const n = t.ut = (s = e(t.proxy)) => {
            Array.from(document.querySelectorAll(`[data-v-owner="${t.uid}"]`)).forEach(r => ri(r, s))
        },
        i = () => {
            const s = e(t.proxy);
            t.ce ? ri(t.ce, s) : os(t.subTree, s), n(s)
        };
    Ps(() => {
        Yn(i)
    }), Zt(() => {
        kt(i, He, {
            flush: "post"
        });
        const s = new MutationObserver(i);
        s.observe(t.subTree.el.parentNode, {
            childList: !0
        }), As(() => s.disconnect())
    })
}

function os(e, t) {
    if (e.shapeFlag & 128) {
        const n = e.suspense;
        e = n.activeBranch, n.pendingBranch && !n.isHydrating && n.effects.push(() => {
            os(n.activeBranch, t)
        })
    }
    for (; e.component;) e = e.component.subTree;
    if (e.shapeFlag & 1 && e.el) ri(e.el, t);
    else if (e.type === ge) e.children.forEach(n => os(n, t));
    else if (e.type === Gt) {
        let {
            el: n,
            anchor: i
        } = e;
        for (; n && (ri(n, t), n !== i);) n = n.nextSibling
    }
}

function ri(e, t) {
    if (e.nodeType === 1) {
        const n = e.style;
        let i = "";
        for (const s in t) n.setProperty(`--${s}`, t[s]), i += `--${s}: ${t[s]};`;
        n[io] = i
    }
}
const $f = /(^|;)\s*display\s*:/;

function zf(e, t, n) {
    const i = e.style,
        s = le(n);
    let r = !1;
    if (n && !s) {
        if (t)
            if (le(t))
                for (const l of t.split(";")) {
                    const a = l.slice(0, l.indexOf(":")).trim();
                    n[a] == null && jn(i, a, "")
                } else
                    for (const l in t) n[l] == null && jn(i, l, "");
        for (const l in n) l === "display" && (r = !0), jn(i, l, n[l])
    } else if (s) {
        if (t !== n) {
            const l = i[io];
            l && (n += ";" + l), i.cssText = n, r = $f.test(n)
        }
    } else t && e.removeAttribute("style");
    si in e && (e[si] = r ? i.display : "", e[no] && (i.display = "none"))
}
const dr = /\s*!important$/;

function jn(e, t, n) {
    if (W(n)) n.forEach(i => jn(e, t, i));
    else if (n == null && (n = ""), t.startsWith("--")) e.setProperty(t, n);
    else {
        const i = Vf(e, t);
        dr.test(n) ? e.setProperty(st(i), n.replace(dr, ""), "important") : e[i] = n
    }
}
const pr = ["Webkit", "Moz", "ms"],
    Di = {};

function Vf(e, t) {
    const n = Di[t];
    if (n) return n;
    let i = Le(t);
    if (i !== "filter" && i in e) return Di[t] = i;
    i = fi(i);
    for (let s = 0; s < pr.length; s++) {
        const r = pr[s] + i;
        if (r in e) return Di[t] = r
    }
    return t
}
const hr = "http://www.w3.org/1999/xlink";

function gr(e, t, n, i, s, r = No(t)) {
    i && t.startsWith("xlink:") ? n == null ? e.removeAttributeNS(hr, t.slice(6, t.length)) : e.setAttributeNS(hr, t, n) : n == null || r && !Rr(n) ? e.removeAttribute(t) : e.setAttribute(t, r ? "" : je(n) ? String(n) : n)
}

function mr(e, t, n, i, s) {
    if (t === "innerHTML" || t === "textContent") {
        n != null && (e[t] = t === "innerHTML" ? Jl(n) : n);
        return
    }
    const r = e.tagName;
    if (t === "value" && r !== "PROGRESS" && !r.includes("-")) {
        const a = r === "OPTION" ? e.getAttribute("value") || "" : e.value,
            o = n == null ? e.type === "checkbox" ? "on" : "" : String(n);
        (a !== o || !("_value" in e)) && (e.value = o), n == null && e.removeAttribute(t), e._value = n;
        return
    }
    let l = !1;
    if (n === "" || n == null) {
        const a = typeof e[t];
        a === "boolean" ? n = Rr(n) : n == null && a === "string" ? (n = "", l = !0) : a === "number" && (n = 0, l = !0)
    }
    try {
        e[t] = n
    } catch {}
    l && e.removeAttribute(s || t)
}

function nt(e, t, n, i) {
    e.addEventListener(t, n, i)
}

function Hf(e, t, n, i) {
    e.removeEventListener(t, n, i)
}
const vr = Symbol("_vei");

function kf(e, t, n, i, s = null) {
    const r = e[vr] || (e[vr] = {}),
        l = r[t];
    if (i && l) l.value = i;
    else {
        const [a, o] = jf(t);
        if (i) {
            const d = r[t] = Uf(i, s);
            nt(e, a, d, o)
        } else l && (Hf(e, a, l, o), r[t] = void 0)
    }
}
const yr = /(?:Once|Passive|Capture)$/;

function jf(e) {
    let t;
    if (yr.test(e)) {
        t = {};
        let i;
        for (; i = e.match(yr);) e = e.slice(0, e.length - i[0].length), t[i[0].toLowerCase()] = !0
    }
    return [e[2] === ":" ? e.slice(3) : st(e.slice(2)), t]
}
let Fi = 0;
const Gf = Promise.resolve(),
    Wf = () => Fi || (Gf.then(() => Fi = 0), Fi = Date.now());

function Uf(e, t) {
    const n = i => {
        if (!i._vts) i._vts = Date.now();
        else if (i._vts <= n.attached) return;
        Ge(Kf(i, n.value), t, 5, [i])
    };
    return n.value = e, n.attached = Wf(), n
}

function Kf(e, t) {
    if (W(t)) {
        const n = e.stopImmediatePropagation;
        return e.stopImmediatePropagation = () => {
            n.call(e), e._stopped = !0
        }, t.map(i => s => !s._stopped && i && i(s))
    } else return t
}
const br = e => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123,
    qf = (e, t, n, i, s, r) => {
        const l = s === "svg";
        t === "class" ? Nf(e, i, l) : t === "style" ? zf(e, n, i) : Sn(t) ? ds(t) || kf(e, t, n, i, r) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : Yf(e, t, i, l)) ? (mr(e, t, i), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && gr(e, t, i, l, r, t !== "value")) : e._isVueCE && (/[A-Z]/.test(t) || !le(i)) ? mr(e, Le(t), i, r, t) : (t === "true-value" ? e._trueValue = i : t === "false-value" && (e._falseValue = i), gr(e, t, i, l))
    };

function Yf(e, t, n, i) {
    if (i) return !!(t === "innerHTML" || t === "textContent" || t in e && br(t) && q(n));
    if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA") return !1;
    if (t === "width" || t === "height") {
        const s = e.tagName;
        if (s === "IMG" || s === "VIDEO" || s === "CANVAS" || s === "SOURCE") return !1
    }
    return br(t) && le(n) ? !1 : t in e
}
const so = new WeakMap,
    ro = new WeakMap,
    li = Symbol("_moveCb"),
    wr = Symbol("_enterCb"),
    Xf = e => (delete e.props.mode, e),
    Jf = Xf({
        name: "TransitionGroup",
        props: ae({}, Ql, {
            tag: String,
            moveClass: String
        }),
        setup(e, {
            slots: t
        }) {
            const n = lt(),
                i = pl();
            let s, r;
            return En(() => {
                if (!s.length) return;
                const l = e.moveClass || `${e.name||"v"}-move`;
                if (!tc(s[0].el, n.vnode.el, l)) return;
                s.forEach(Zf), s.forEach(Qf);
                const a = s.filter(ec);
                ls(), a.forEach(o => {
                    const d = o.el,
                        f = d.style;
                    Ue(d, l), f.transform = f.webkitTransform = f.transitionDuration = "";
                    const u = d[li] = m => {
                        m && m.target !== d || (!m || /transform$/.test(m.propertyName)) && (d.removeEventListener("transitionend", u), d[li] = null, at(d, l))
                    };
                    d.addEventListener("transitionend", u)
                })
            }), () => {
                const l = Q(e),
                    a = eo(l);
                let o = l.tag || ge;
                if (s = [], r)
                    for (let d = 0; d < r.length; d++) {
                        const f = r[d];
                        f.el && f.el instanceof Element && (s.push(f), gt(f, vn(f, a, i, n)), so.set(f, f.el.getBoundingClientRect()))
                    }
                r = t.default ? _s(t.default()) : [];
                for (let d = 0; d < r.length; d++) {
                    const f = r[d];
                    f.key != null && gt(f, vn(f, a, i, n))
                }
                return oe(o, null, r)
            }
        }
    }),
    md = Jf;

function Zf(e) {
    const t = e.el;
    t[li] && t[li](), t[wr] && t[wr]()
}

function Qf(e) {
    ro.set(e, e.el.getBoundingClientRect())
}

function ec(e) {
    const t = so.get(e),
        n = ro.get(e),
        i = t.left - n.left,
        s = t.top - n.top;
    if (i || s) {
        const r = e.el.style;
        return r.transform = r.webkitTransform = `translate(${i}px,${s}px)`, r.transitionDuration = "0s", e
    }
}

function tc(e, t, n) {
    const i = e.cloneNode(),
        s = e[Kt];
    s && s.forEach(a => {
        a.split(/\s+/).forEach(o => o && i.classList.remove(o))
    }), n.split(/\s+/).forEach(a => a && i.classList.add(a)), i.style.display = "none";
    const r = t.nodeType === 1 ? t : t.parentNode;
    r.appendChild(i);
    const {
        hasTransform: l
    } = to(i);
    return r.removeChild(i), l
}
const mt = e => {
    const t = e.props["onUpdate:modelValue"] || !1;
    return W(t) ? n => Vt(t, n) : t
};

function nc(e) {
    e.target.composing = !0
}

function Sr(e) {
    const t = e.target;
    t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")))
}
const $e = Symbol("_assign"),
    Tr = {
        created(e, {
            modifiers: {
                lazy: t,
                trim: n,
                number: i
            }
        }, s) {
            e[$e] = mt(s);
            const r = i || s.props && s.props.type === "number";
            nt(e, t ? "change" : "input", l => {
                if (l.target.composing) return;
                let a = e.value;
                n && (a = a.trim()), r && (a = Wn(a)), e[$e](a)
            }), n && nt(e, "change", () => {
                e.value = e.value.trim()
            }), t || (nt(e, "compositionstart", nc), nt(e, "compositionend", Sr), nt(e, "change", Sr))
        },
        mounted(e, {
            value: t
        }) {
            e.value = t ? ? ""
        },
        beforeUpdate(e, {
            value: t,
            oldValue: n,
            modifiers: {
                lazy: i,
                trim: s,
                number: r
            }
        }, l) {
            if (e[$e] = mt(l), e.composing) return;
            const a = (r || e.type === "number") && !/^0\d/.test(e.value) ? Wn(e.value) : e.value,
                o = t ? ? "";
            a !== o && (document.activeElement === e && e.type !== "range" && (i && t === n || s && e.value.trim() === o) || (e.value = o))
        }
    },
    ic = {
        deep: !0,
        created(e, t, n) {
            e[$e] = mt(n), nt(e, "change", () => {
                const i = e._modelValue,
                    s = qt(e),
                    r = e.checked,
                    l = e[$e];
                if (W(i)) {
                    const a = ms(i, s),
                        o = a !== -1;
                    if (r && !o) l(i.concat(s));
                    else if (!r && o) {
                        const d = [...i];
                        d.splice(a, 1), l(d)
                    }
                } else if (Yt(i)) {
                    const a = new Set(i);
                    r ? a.add(s) : a.delete(s), l(a)
                } else l(lo(e, r))
            })
        },
        mounted: xr,
        beforeUpdate(e, t, n) {
            e[$e] = mt(n), xr(e, t, n)
        }
    };

function xr(e, {
    value: t,
    oldValue: n
}, i) {
    e._modelValue = t;
    let s;
    if (W(t)) s = ms(t, i.props.value) > -1;
    else if (Yt(t)) s = t.has(i.props.value);
    else {
        if (t === n) return;
        s = Mt(t, lo(e, !0))
    }
    e.checked !== s && (e.checked = s)
}
const sc = {
        created(e, {
            value: t
        }, n) {
            e.checked = Mt(t, n.props.value), e[$e] = mt(n), nt(e, "change", () => {
                e[$e](qt(e))
            })
        },
        beforeUpdate(e, {
            value: t,
            oldValue: n
        }, i) {
            e[$e] = mt(i), t !== n && (e.checked = Mt(t, i.props.value))
        }
    },
    rc = {
        deep: !0,
        created(e, {
            value: t,
            modifiers: {
                number: n
            }
        }, i) {
            const s = Yt(t);
            nt(e, "change", () => {
                const r = Array.prototype.filter.call(e.options, l => l.selected).map(l => n ? Wn(qt(l)) : qt(l));
                e[$e](e.multiple ? s ? new Set(r) : r : r[0]), e._assigning = !0, Es(() => {
                    e._assigning = !1
                })
            }), e[$e] = mt(i)
        },
        mounted(e, {
            value: t
        }) {
            Er(e, t)
        },
        beforeUpdate(e, t, n) {
            e[$e] = mt(n)
        },
        updated(e, {
            value: t
        }) {
            e._assigning || Er(e, t)
        }
    };

function Er(e, t) {
    const n = e.multiple,
        i = W(t);
    if (!(n && !i && !Yt(t))) {
        for (let s = 0, r = e.options.length; s < r; s++) {
            const l = e.options[s],
                a = qt(l);
            if (n)
                if (i) {
                    const o = typeof a;
                    o === "string" || o === "number" ? l.selected = t.some(d => String(d) === String(a)) : l.selected = ms(t, a) > -1
                } else l.selected = t.has(a);
            else if (Mt(qt(l), t)) {
                e.selectedIndex !== s && (e.selectedIndex = s);
                return
            }
        }!n && e.selectedIndex !== -1 && (e.selectedIndex = -1)
    }
}

function qt(e) {
    return "_value" in e ? e._value : e.value
}

function lo(e, t) {
    const n = t ? "_trueValue" : "_falseValue";
    return n in e ? e[n] : t
}
const vd = {
    created(e, t, n) {
        Rn(e, t, n, null, "created")
    },
    mounted(e, t, n) {
        Rn(e, t, n, null, "mounted")
    },
    beforeUpdate(e, t, n, i) {
        Rn(e, t, n, i, "beforeUpdate")
    },
    updated(e, t, n, i) {
        Rn(e, t, n, i, "updated")
    }
};

function lc(e, t) {
    switch (e) {
        case "SELECT":
            return rc;
        case "TEXTAREA":
            return Tr;
        default:
            switch (t) {
                case "checkbox":
                    return ic;
                case "radio":
                    return sc;
                default:
                    return Tr
            }
    }
}

function Rn(e, t, n, i, s) {
    const l = lc(e.tagName, n.props && n.props.type)[s];
    l && l(e, t, n, i)
}
const oc = ["ctrl", "shift", "alt", "meta"],
    ac = {
        stop: e => e.stopPropagation(),
        prevent: e => e.preventDefault(),
        self: e => e.target !== e.currentTarget,
        ctrl: e => !e.ctrlKey,
        shift: e => !e.shiftKey,
        alt: e => !e.altKey,
        meta: e => !e.metaKey,
        left: e => "button" in e && e.button !== 0,
        middle: e => "button" in e && e.button !== 1,
        right: e => "button" in e && e.button !== 2,
        exact: (e, t) => oc.some(n => e[`${n}Key`] && !t.includes(n))
    },
    yd = (e, t) => {
        const n = e._withMods || (e._withMods = {}),
            i = t.join(".");
        return n[i] || (n[i] = (s, ...r) => {
            for (let l = 0; l < t.length; l++) {
                const a = ac[t[l]];
                if (a && a(s, t)) return
            }
            return e(s, ...r)
        })
    },
    fc = {
        esc: "escape",
        space: " ",
        up: "arrow-up",
        left: "arrow-left",
        right: "arrow-right",
        down: "arrow-down",
        delete: "backspace"
    },
    bd = (e, t) => {
        const n = e._withKeys || (e._withKeys = {}),
            i = t.join(".");
        return n[i] || (n[i] = s => {
            if (!("key" in s)) return;
            const r = st(s.key);
            if (t.some(l => l === r || fc[l] === r)) return e(s)
        })
    },
    oo = ae({
        patchProp: qf
    }, Bf);
let pn, Cr = !1;

function cc() {
    return pn || (pn = tf(oo))
}

function uc() {
    return pn = Cr ? pn : nf(oo), Cr = !0, pn
}
const wd = (...e) => {
        const t = cc().createApp(...e),
            {
                mount: n
            } = t;
        return t.mount = i => {
            const s = fo(i);
            if (!s) return;
            const r = t._component;
            !q(r) && !r.render && !r.template && (r.template = s.innerHTML), s.nodeType === 1 && (s.textContent = "");
            const l = n(s, !1, ao(s));
            return s instanceof Element && (s.removeAttribute("v-cloak"), s.setAttribute("data-v-app", "")), l
        }, t
    },
    Sd = (...e) => {
        const t = uc().createApp(...e),
            {
                mount: n
            } = t;
        return t.mount = i => {
            const s = fo(i);
            if (s) return n(s, !0, ao(s))
        }, t
    };

function ao(e) {
    if (e instanceof SVGElement) return "svg";
    if (typeof MathMLElement == "function" && e instanceof MathMLElement) return "mathml"
}

function fo(e) {
    return le(e) ? document.querySelector(e) : e
}

function _r(e) {
    return e !== null && typeof e == "object" && "constructor" in e && e.constructor === Object
}

function Rs(e, t) {
    e === void 0 && (e = {}), t === void 0 && (t = {}), Object.keys(t).forEach(n => {
        typeof e[n] > "u" ? e[n] = t[n] : _r(t[n]) && _r(e[n]) && Object.keys(t[n]).length > 0 && Rs(e[n], t[n])
    })
}
const co = {
    body: {},
    addEventListener() {},
    removeEventListener() {},
    activeElement: {
        blur() {},
        nodeName: ""
    },
    querySelector() {
        return null
    },
    querySelectorAll() {
        return []
    },
    getElementById() {
        return null
    },
    createEvent() {
        return {
            initEvent() {}
        }
    },
    createElement() {
        return {
            children: [],
            childNodes: [],
            style: {},
            setAttribute() {},
            getElementsByTagName() {
                return []
            }
        }
    },
    createElementNS() {
        return {}
    },
    importNode() {
        return null
    },
    location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: ""
    }
};

function Xe() {
    const e = typeof document < "u" ? document : {};
    return Rs(e, co), e
}
const dc = {
    document: co,
    navigator: {
        userAgent: ""
    },
    location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: ""
    },
    history: {
        replaceState() {},
        pushState() {},
        go() {},
        back() {}
    },
    CustomEvent: function() {
        return this
    },
    addEventListener() {},
    removeEventListener() {},
    getComputedStyle() {
        return {
            getPropertyValue() {
                return ""
            }
        }
    },
    Image() {},
    Date() {},
    screen: {},
    setTimeout() {},
    clearTimeout() {},
    matchMedia() {
        return {}
    },
    requestAnimationFrame(e) {
        return typeof setTimeout > "u" ? (e(), null) : setTimeout(e, 0)
    },
    cancelAnimationFrame(e) {
        typeof setTimeout > "u" || clearTimeout(e)
    }
};

function Be() {
    const e = typeof window < "u" ? window : {};
    return Rs(e, dc), e
}

function pc(e) {
    const t = e;
    Object.keys(t).forEach(n => {
        try {
            t[n] = null
        } catch {}
        try {
            delete t[n]
        } catch {}
    })
}

function as(e, t) {
    return t === void 0 && (t = 0), setTimeout(e, t)
}

function _t() {
    return Date.now()
}

function hc(e) {
    const t = Be();
    let n;
    return t.getComputedStyle && (n = t.getComputedStyle(e, null)), !n && e.currentStyle && (n = e.currentStyle), n || (n = e.style), n
}

function gc(e, t) {
    t === void 0 && (t = "x");
    const n = Be();
    let i, s, r;
    const l = hc(e);
    return n.WebKitCSSMatrix ? (s = l.transform || l.webkitTransform, s.split(",").length > 6 && (s = s.split(", ").map(a => a.replace(",", ".")).join(", ")), r = new n.WebKitCSSMatrix(s === "none" ? "" : s)) : (r = l.MozTransform || l.OTransform || l.MsTransform || l.msTransform || l.transform || l.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"), i = r.toString().split(",")), t === "x" && (n.WebKitCSSMatrix ? s = r.m41 : i.length === 16 ? s = parseFloat(i[12]) : s = parseFloat(i[4])), t === "y" && (n.WebKitCSSMatrix ? s = r.m42 : i.length === 16 ? s = parseFloat(i[13]) : s = parseFloat(i[5])), s || 0
}

function Nn(e) {
    return typeof e == "object" && e !== null && e.constructor && Object.prototype.toString.call(e).slice(8, -1) === "Object"
}

function mc(e) {
    return typeof window < "u" && typeof window.HTMLElement < "u" ? e instanceof HTMLElement : e && (e.nodeType === 1 || e.nodeType === 11)
}

function Ie() {
    const e = Object(arguments.length <= 0 ? void 0 : arguments[0]),
        t = ["__proto__", "constructor", "prototype"];
    for (let n = 1; n < arguments.length; n += 1) {
        const i = n < 0 || arguments.length <= n ? void 0 : arguments[n];
        if (i != null && !mc(i)) {
            const s = Object.keys(Object(i)).filter(r => t.indexOf(r) < 0);
            for (let r = 0, l = s.length; r < l; r += 1) {
                const a = s[r],
                    o = Object.getOwnPropertyDescriptor(i, a);
                o !== void 0 && o.enumerable && (Nn(e[a]) && Nn(i[a]) ? i[a].__swiper__ ? e[a] = i[a] : Ie(e[a], i[a]) : !Nn(e[a]) && Nn(i[a]) ? (e[a] = {}, i[a].__swiper__ ? e[a] = i[a] : Ie(e[a], i[a])) : e[a] = i[a])
            }
        }
    }
    return e
}

function $n(e, t, n) {
    e.style.setProperty(t, n)
}

function uo(e) {
    let {
        swiper: t,
        targetPosition: n,
        side: i
    } = e;
    const s = Be(),
        r = -t.translate;
    let l = null,
        a;
    const o = t.params.speed;
    t.wrapperEl.style.scrollSnapType = "none", s.cancelAnimationFrame(t.cssModeFrameID);
    const d = n > r ? "next" : "prev",
        f = (m, g) => d === "next" && m >= g || d === "prev" && m <= g,
        u = () => {
            a = new Date().getTime(), l === null && (l = a);
            const m = Math.max(Math.min((a - l) / o, 1), 0),
                g = .5 - Math.cos(m * Math.PI) / 2;
            let S = r + g * (n - r);
            if (f(S, n) && (S = n), t.wrapperEl.scrollTo({
                    [i]: S
                }), f(S, n)) {
                t.wrapperEl.style.overflow = "hidden", t.wrapperEl.style.scrollSnapType = "", setTimeout(() => {
                    t.wrapperEl.style.overflow = "", t.wrapperEl.scrollTo({
                        [i]: S
                    })
                }), s.cancelAnimationFrame(t.cssModeFrameID);
                return
            }
            t.cssModeFrameID = s.requestAnimationFrame(u)
        };
    u()
}

function Ye(e, t) {
    return t === void 0 && (t = ""), [...e.children].filter(n => n.matches(t))
}

function po(e, t) {
    t === void 0 && (t = []);
    const n = document.createElement(e);
    return n.classList.add(...Array.isArray(t) ? t : [t]), n
}

function vc(e, t) {
    const n = [];
    for (; e.previousElementSibling;) {
        const i = e.previousElementSibling;
        t ? i.matches(t) && n.push(i) : n.push(i), e = i
    }
    return n
}

function yc(e, t) {
    const n = [];
    for (; e.nextElementSibling;) {
        const i = e.nextElementSibling;
        t ? i.matches(t) && n.push(i) : n.push(i), e = i
    }
    return n
}

function dt(e, t) {
    return Be().getComputedStyle(e, null).getPropertyValue(t)
}

function oi(e) {
    let t = e,
        n;
    if (t) {
        for (n = 0;
            (t = t.previousSibling) !== null;) t.nodeType === 1 && (n += 1);
        return n
    }
}

function ho(e, t) {
    const n = [];
    let i = e.parentElement;
    for (; i;) t ? i.matches(t) && n.push(i) : n.push(i), i = i.parentElement;
    return n
}

function Ri(e, t) {
    function n(i) {
        i.target === e && (t.call(e, i), e.removeEventListener("transitionend", n))
    }
    t && e.addEventListener("transitionend", n)
}

function fs(e, t, n) {
    const i = Be();
    return e[t === "width" ? "offsetWidth" : "offsetHeight"] + parseFloat(i.getComputedStyle(e, null).getPropertyValue(t === "width" ? "margin-right" : "margin-top")) + parseFloat(i.getComputedStyle(e, null).getPropertyValue(t === "width" ? "margin-left" : "margin-bottom"))
}
let Ni;

function bc() {
    const e = Be(),
        t = Xe();
    return {
        smoothScroll: t.documentElement && t.documentElement.style && "scrollBehavior" in t.documentElement.style,
        touch: !!("ontouchstart" in e || e.DocumentTouch && t instanceof e.DocumentTouch)
    }
}

function go() {
    return Ni || (Ni = bc()), Ni
}
let $i;

function wc(e) {
    let {
        userAgent: t
    } = e === void 0 ? {} : e;
    const n = go(),
        i = Be(),
        s = i.navigator.platform,
        r = t || i.navigator.userAgent,
        l = {
            ios: !1,
            android: !1
        },
        a = i.screen.width,
        o = i.screen.height,
        d = r.match(/(Android);?[\s\/]+([\d.]+)?/);
    let f = r.match(/(iPad).*OS\s([\d_]+)/);
    const u = r.match(/(iPod)(.*OS\s([\d_]+))?/),
        m = !f && r.match(/(iPhone\sOS|iOS)\s([\d_]+)/),
        g = s === "Win32";
    let S = s === "MacIntel";
    const v = ["1024x1366", "1366x1024", "834x1194", "1194x834", "834x1112", "1112x834", "768x1024", "1024x768", "820x1180", "1180x820", "810x1080", "1080x810"];
    return !f && S && n.touch && v.indexOf(`${a}x${o}`) >= 0 && (f = r.match(/(Version)\/([\d.]+)/), f || (f = [0, 1, "13_0_0"]), S = !1), d && !g && (l.os = "android", l.android = !0), (f || m || u) && (l.os = "ios", l.ios = !0), l
}

function Sc(e) {
    return e === void 0 && (e = {}), $i || ($i = wc(e)), $i
}
let zi;

function Tc() {
    const e = Be();
    let t = !1;

    function n() {
        const i = e.navigator.userAgent.toLowerCase();
        return i.indexOf("safari") >= 0 && i.indexOf("chrome") < 0 && i.indexOf("android") < 0
    }
    if (n()) {
        const i = String(e.navigator.userAgent);
        if (i.includes("Version/")) {
            const [s, r] = i.split("Version/")[1].split(" ")[0].split(".").map(l => Number(l));
            t = s < 16 || s === 16 && r < 2
        }
    }
    return {
        isSafari: t || n(),
        needPerspectiveFix: t,
        isWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(e.navigator.userAgent)
    }
}

function xc() {
    return zi || (zi = Tc()), zi
}

function Ec(e) {
    let {
        swiper: t,
        on: n,
        emit: i
    } = e;
    const s = Be();
    let r = null,
        l = null;
    const a = () => {
            !t || t.destroyed || !t.initialized || (i("beforeResize"), i("resize"))
        },
        o = () => {
            !t || t.destroyed || !t.initialized || (r = new ResizeObserver(u => {
                l = s.requestAnimationFrame(() => {
                    const {
                        width: m,
                        height: g
                    } = t;
                    let S = m,
                        v = g;
                    u.forEach(E => {
                        let {
                            contentBoxSize: x,
                            contentRect: h,
                            target: c
                        } = E;
                        c && c !== t.el || (S = h ? h.width : (x[0] || x).inlineSize, v = h ? h.height : (x[0] || x).blockSize)
                    }), (S !== m || v !== g) && a()
                })
            }), r.observe(t.el))
        },
        d = () => {
            l && s.cancelAnimationFrame(l), r && r.unobserve && t.el && (r.unobserve(t.el), r = null)
        },
        f = () => {
            !t || t.destroyed || !t.initialized || i("orientationchange")
        };
    n("init", () => {
        if (t.params.resizeObserver && typeof s.ResizeObserver < "u") {
            o();
            return
        }
        s.addEventListener("resize", a), s.addEventListener("orientationchange", f)
    }), n("destroy", () => {
        d(), s.removeEventListener("resize", a), s.removeEventListener("orientationchange", f)
    })
}

function Cc(e) {
    let {
        swiper: t,
        extendParams: n,
        on: i,
        emit: s
    } = e;
    const r = [],
        l = Be(),
        a = function(f, u) {
            u === void 0 && (u = {});
            const m = l.MutationObserver || l.WebkitMutationObserver,
                g = new m(S => {
                    if (t.__preventObserver__) return;
                    if (S.length === 1) {
                        s("observerUpdate", S[0]);
                        return
                    }
                    const v = function() {
                        s("observerUpdate", S[0])
                    };
                    l.requestAnimationFrame ? l.requestAnimationFrame(v) : l.setTimeout(v, 0)
                });
            g.observe(f, {
                attributes: typeof u.attributes > "u" ? !0 : u.attributes,
                childList: typeof u.childList > "u" ? !0 : u.childList,
                characterData: typeof u.characterData > "u" ? !0 : u.characterData
            }), r.push(g)
        },
        o = () => {
            if (t.params.observer) {
                if (t.params.observeParents) {
                    const f = ho(t.el);
                    for (let u = 0; u < f.length; u += 1) a(f[u])
                }
                a(t.el, {
                    childList: t.params.observeSlideChildren
                }), a(t.wrapperEl, {
                    attributes: !1
                })
            }
        },
        d = () => {
            r.forEach(f => {
                f.disconnect()
            }), r.splice(0, r.length)
        };
    n({
        observer: !1,
        observeParents: !1,
        observeSlideChildren: !1
    }), i("init", o), i("destroy", d)
}
var _c = {
    on(e, t, n) {
        const i = this;
        if (!i.eventsListeners || i.destroyed || typeof t != "function") return i;
        const s = n ? "unshift" : "push";
        return e.split(" ").forEach(r => {
            i.eventsListeners[r] || (i.eventsListeners[r] = []), i.eventsListeners[r][s](t)
        }), i
    },
    once(e, t, n) {
        const i = this;
        if (!i.eventsListeners || i.destroyed || typeof t != "function") return i;

        function s() {
            i.off(e, s), s.__emitterProxy && delete s.__emitterProxy;
            for (var r = arguments.length, l = new Array(r), a = 0; a < r; a++) l[a] = arguments[a];
            t.apply(i, l)
        }
        return s.__emitterProxy = t, i.on(e, s, n)
    },
    onAny(e, t) {
        const n = this;
        if (!n.eventsListeners || n.destroyed || typeof e != "function") return n;
        const i = t ? "unshift" : "push";
        return n.eventsAnyListeners.indexOf(e) < 0 && n.eventsAnyListeners[i](e), n
    },
    offAny(e) {
        const t = this;
        if (!t.eventsListeners || t.destroyed || !t.eventsAnyListeners) return t;
        const n = t.eventsAnyListeners.indexOf(e);
        return n >= 0 && t.eventsAnyListeners.splice(n, 1), t
    },
    off(e, t) {
        const n = this;
        return !n.eventsListeners || n.destroyed || !n.eventsListeners || e.split(" ").forEach(i => {
            typeof t > "u" ? n.eventsListeners[i] = [] : n.eventsListeners[i] && n.eventsListeners[i].forEach((s, r) => {
                (s === t || s.__emitterProxy && s.__emitterProxy === t) && n.eventsListeners[i].splice(r, 1)
            })
        }), n
    },
    emit() {
        const e = this;
        if (!e.eventsListeners || e.destroyed || !e.eventsListeners) return e;
        let t, n, i;
        for (var s = arguments.length, r = new Array(s), l = 0; l < s; l++) r[l] = arguments[l];
        return typeof r[0] == "string" || Array.isArray(r[0]) ? (t = r[0], n = r.slice(1, r.length), i = e) : (t = r[0].events, n = r[0].data, i = r[0].context || e), n.unshift(i), (Array.isArray(t) ? t : t.split(" ")).forEach(o => {
            e.eventsAnyListeners && e.eventsAnyListeners.length && e.eventsAnyListeners.forEach(d => {
                d.apply(i, [o, ...n])
            }), e.eventsListeners && e.eventsListeners[o] && e.eventsListeners[o].forEach(d => {
                d.apply(i, n)
            })
        }), e
    }
};

function Mc() {
    const e = this;
    let t, n;
    const i = e.el;
    typeof e.params.width < "u" && e.params.width !== null ? t = e.params.width : t = i.clientWidth, typeof e.params.height < "u" && e.params.height !== null ? n = e.params.height : n = i.clientHeight, !(t === 0 && e.isHorizontal() || n === 0 && e.isVertical()) && (t = t - parseInt(dt(i, "padding-left") || 0, 10) - parseInt(dt(i, "padding-right") || 0, 10), n = n - parseInt(dt(i, "padding-top") || 0, 10) - parseInt(dt(i, "padding-bottom") || 0, 10), Number.isNaN(t) && (t = 0), Number.isNaN(n) && (n = 0), Object.assign(e, {
        width: t,
        height: n,
        size: e.isHorizontal() ? t : n
    }))
}

function Pc() {
    const e = this;

    function t(M) {
        return e.isHorizontal() ? M : {
            width: "height",
            "margin-top": "margin-left",
            "margin-bottom ": "margin-right",
            "margin-left": "margin-top",
            "margin-right": "margin-bottom",
            "padding-left": "padding-top",
            "padding-right": "padding-bottom",
            marginRight: "marginBottom"
        }[M]
    }

    function n(M, _) {
        return parseFloat(M.getPropertyValue(t(_)) || 0)
    }
    const i = e.params,
        {
            wrapperEl: s,
            slidesEl: r,
            size: l,
            rtlTranslate: a,
            wrongRTL: o
        } = e,
        d = e.virtual && i.virtual.enabled,
        f = d ? e.virtual.slides.length : e.slides.length,
        u = Ye(r, `.${e.params.slideClass}, swiper-slide`),
        m = d ? e.virtual.slides.length : u.length;
    let g = [];
    const S = [],
        v = [];
    let E = i.slidesOffsetBefore;
    typeof E == "function" && (E = i.slidesOffsetBefore.call(e));
    let x = i.slidesOffsetAfter;
    typeof x == "function" && (x = i.slidesOffsetAfter.call(e));
    const h = e.snapGrid.length,
        c = e.slidesGrid.length;
    let p = i.spaceBetween,
        w = -E,
        C = 0,
        P = 0;
    if (typeof l > "u") return;
    typeof p == "string" && p.indexOf("%") >= 0 ? p = parseFloat(p.replace("%", "")) / 100 * l : typeof p == "string" && (p = parseFloat(p)), e.virtualSize = -p, u.forEach(M => {
        a ? M.style.marginLeft = "" : M.style.marginRight = "", M.style.marginBottom = "", M.style.marginTop = ""
    }), i.centeredSlides && i.cssMode && ($n(s, "--swiper-centered-offset-before", ""), $n(s, "--swiper-centered-offset-after", ""));
    const O = i.grid && i.grid.rows > 1 && e.grid;
    O && e.grid.initSlides(m);
    let b;
    const I = i.slidesPerView === "auto" && i.breakpoints && Object.keys(i.breakpoints).filter(M => typeof i.breakpoints[M].slidesPerView < "u").length > 0;
    for (let M = 0; M < m; M += 1) {
        b = 0;
        let _;
        if (u[M] && (_ = u[M]), O && e.grid.updateSlide(M, _, m, t), !(u[M] && dt(_, "display") === "none")) {
            if (i.slidesPerView === "auto") {
                I && (u[M].style[t("width")] = "");
                const L = getComputedStyle(_),
                    G = _.style.transform,
                    Y = _.style.webkitTransform;
                if (G && (_.style.transform = "none"), Y && (_.style.webkitTransform = "none"), i.roundLengths) b = e.isHorizontal() ? fs(_, "width") : fs(_, "height");
                else {
                    const V = n(L, "width"),
                        k = n(L, "padding-left"),
                        j = n(L, "padding-right"),
                        Z = n(L, "margin-left"),
                        Ce = n(L, "margin-right"),
                        _e = L.getPropertyValue("box-sizing");
                    if (_e && _e === "border-box") b = V + Z + Ce;
                    else {
                        const {
                            clientWidth: De,
                            offsetWidth: _n
                        } = _;
                        b = V + k + j + Z + Ce + (_n - De)
                    }
                }
                G && (_.style.transform = G), Y && (_.style.webkitTransform = Y), i.roundLengths && (b = Math.floor(b))
            } else b = (l - (i.slidesPerView - 1) * p) / i.slidesPerView, i.roundLengths && (b = Math.floor(b)), u[M] && (u[M].style[t("width")] = `${b}px`);
            u[M] && (u[M].swiperSlideSize = b), v.push(b), i.centeredSlides ? (w = w + b / 2 + C / 2 + p, C === 0 && M !== 0 && (w = w - l / 2 - p), M === 0 && (w = w - l / 2 - p), Math.abs(w) < 1 / 1e3 && (w = 0), i.roundLengths && (w = Math.floor(w)), P % i.slidesPerGroup === 0 && g.push(w), S.push(w)) : (i.roundLengths && (w = Math.floor(w)), (P - Math.min(e.params.slidesPerGroupSkip, P)) % e.params.slidesPerGroup === 0 && g.push(w), S.push(w), w = w + b + p), e.virtualSize += b + p, C = b, P += 1
        }
    }
    if (e.virtualSize = Math.max(e.virtualSize, l) + x, a && o && (i.effect === "slide" || i.effect === "coverflow") && (s.style.width = `${e.virtualSize+p}px`), i.setWrapperSize && (s.style[t("width")] = `${e.virtualSize+p}px`), O && e.grid.updateWrapperSize(b, g, t), !i.centeredSlides) {
        const M = [];
        for (let _ = 0; _ < g.length; _ += 1) {
            let L = g[_];
            i.roundLengths && (L = Math.floor(L)), g[_] <= e.virtualSize - l && M.push(L)
        }
        g = M, Math.floor(e.virtualSize - l) - Math.floor(g[g.length - 1]) > 1 && g.push(e.virtualSize - l)
    }
    if (d && i.loop) {
        const M = v[0] + p;
        if (i.slidesPerGroup > 1) {
            const _ = Math.ceil((e.virtual.slidesBefore + e.virtual.slidesAfter) / i.slidesPerGroup),
                L = M * i.slidesPerGroup;
            for (let G = 0; G < _; G += 1) g.push(g[g.length - 1] + L)
        }
        for (let _ = 0; _ < e.virtual.slidesBefore + e.virtual.slidesAfter; _ += 1) i.slidesPerGroup === 1 && g.push(g[g.length - 1] + M), S.push(S[S.length - 1] + M), e.virtualSize += M
    }
    if (g.length === 0 && (g = [0]), p !== 0) {
        const M = e.isHorizontal() && a ? "marginLeft" : t("marginRight");
        u.filter((_, L) => !i.cssMode || i.loop ? !0 : L !== u.length - 1).forEach(_ => {
            _.style[M] = `${p}px`
        })
    }
    if (i.centeredSlides && i.centeredSlidesBounds) {
        let M = 0;
        v.forEach(L => {
            M += L + (p || 0)
        }), M -= p;
        const _ = M - l;
        g = g.map(L => L <= 0 ? -E : L > _ ? _ + x : L)
    }
    if (i.centerInsufficientSlides) {
        let M = 0;
        if (v.forEach(_ => {
                M += _ + (p || 0)
            }), M -= p, M < l) {
            const _ = (l - M) / 2;
            g.forEach((L, G) => {
                g[G] = L - _
            }), S.forEach((L, G) => {
                S[G] = L + _
            })
        }
    }
    if (Object.assign(e, {
            slides: u,
            snapGrid: g,
            slidesGrid: S,
            slidesSizesGrid: v
        }), i.centeredSlides && i.cssMode && !i.centeredSlidesBounds) {
        $n(s, "--swiper-centered-offset-before", `${-g[0]}px`), $n(s, "--swiper-centered-offset-after", `${e.size/2-v[v.length-1]/2}px`);
        const M = -e.snapGrid[0],
            _ = -e.slidesGrid[0];
        e.snapGrid = e.snapGrid.map(L => L + M), e.slidesGrid = e.slidesGrid.map(L => L + _)
    }
    if (m !== f && e.emit("slidesLengthChange"), g.length !== h && (e.params.watchOverflow && e.checkOverflow(), e.emit("snapGridLengthChange")), S.length !== c && e.emit("slidesGridLengthChange"), i.watchSlidesProgress && e.updateSlidesOffset(), !d && !i.cssMode && (i.effect === "slide" || i.effect === "fade")) {
        const M = `${i.containerModifierClass}backface-hidden`,
            _ = e.el.classList.contains(M);
        m <= i.maxBackfaceHiddenSlides ? _ || e.el.classList.add(M) : _ && e.el.classList.remove(M)
    }
}

function Ac(e) {
    const t = this,
        n = [],
        i = t.virtual && t.params.virtual.enabled;
    let s = 0,
        r;
    typeof e == "number" ? t.setTransition(e) : e === !0 && t.setTransition(t.params.speed);
    const l = a => i ? t.slides[t.getSlideIndexByData(a)] : t.slides[a];
    if (t.params.slidesPerView !== "auto" && t.params.slidesPerView > 1)
        if (t.params.centeredSlides)(t.visibleSlides || []).forEach(a => {
            n.push(a)
        });
        else
            for (r = 0; r < Math.ceil(t.params.slidesPerView); r += 1) {
                const a = t.activeIndex + r;
                if (a > t.slides.length && !i) break;
                n.push(l(a))
            } else n.push(l(t.activeIndex));
    for (r = 0; r < n.length; r += 1)
        if (typeof n[r] < "u") {
            const a = n[r].offsetHeight;
            s = a > s ? a : s
        }(s || s === 0) && (t.wrapperEl.style.height = `${s}px`)
}

function Ic() {
    const e = this,
        t = e.slides,
        n = e.isElement ? e.isHorizontal() ? e.wrapperEl.offsetLeft : e.wrapperEl.offsetTop : 0;
    for (let i = 0; i < t.length; i += 1) t[i].swiperSlideOffset = (e.isHorizontal() ? t[i].offsetLeft : t[i].offsetTop) - n - e.cssOverflowAdjustment()
}

function Oc(e) {
    e === void 0 && (e = this && this.translate || 0);
    const t = this,
        n = t.params,
        {
            slides: i,
            rtlTranslate: s,
            snapGrid: r
        } = t;
    if (i.length === 0) return;
    typeof i[0].swiperSlideOffset > "u" && t.updateSlidesOffset();
    let l = -e;
    s && (l = e), i.forEach(o => {
        o.classList.remove(n.slideVisibleClass)
    }), t.visibleSlidesIndexes = [], t.visibleSlides = [];
    let a = n.spaceBetween;
    typeof a == "string" && a.indexOf("%") >= 0 ? a = parseFloat(a.replace("%", "")) / 100 * t.size : typeof a == "string" && (a = parseFloat(a));
    for (let o = 0; o < i.length; o += 1) {
        const d = i[o];
        let f = d.swiperSlideOffset;
        n.cssMode && n.centeredSlides && (f -= i[0].swiperSlideOffset);
        const u = (l + (n.centeredSlides ? t.minTranslate() : 0) - f) / (d.swiperSlideSize + a),
            m = (l - r[0] + (n.centeredSlides ? t.minTranslate() : 0) - f) / (d.swiperSlideSize + a),
            g = -(l - f),
            S = g + t.slidesSizesGrid[o];
        (g >= 0 && g < t.size - 1 || S > 1 && S <= t.size || g <= 0 && S >= t.size) && (t.visibleSlides.push(d), t.visibleSlidesIndexes.push(o), i[o].classList.add(n.slideVisibleClass)), d.progress = s ? -u : u, d.originalProgress = s ? -m : m
    }
}

function Lc(e) {
    const t = this;
    if (typeof e > "u") {
        const f = t.rtlTranslate ? -1 : 1;
        e = t && t.translate && t.translate * f || 0
    }
    const n = t.params,
        i = t.maxTranslate() - t.minTranslate();
    let {
        progress: s,
        isBeginning: r,
        isEnd: l,
        progressLoop: a
    } = t;
    const o = r,
        d = l;
    if (i === 0) s = 0, r = !0, l = !0;
    else {
        s = (e - t.minTranslate()) / i;
        const f = Math.abs(e - t.minTranslate()) < 1,
            u = Math.abs(e - t.maxTranslate()) < 1;
        r = f || s <= 0, l = u || s >= 1, f && (s = 0), u && (s = 1)
    }
    if (n.loop) {
        const f = t.getSlideIndexByData(0),
            u = t.getSlideIndexByData(t.slides.length - 1),
            m = t.slidesGrid[f],
            g = t.slidesGrid[u],
            S = t.slidesGrid[t.slidesGrid.length - 1],
            v = Math.abs(e);
        v >= m ? a = (v - m) / S : a = (v + S - g) / S, a > 1 && (a -= 1)
    }
    Object.assign(t, {
        progress: s,
        progressLoop: a,
        isBeginning: r,
        isEnd: l
    }), (n.watchSlidesProgress || n.centeredSlides && n.autoHeight) && t.updateSlidesProgress(e), r && !o && t.emit("reachBeginning toEdge"), l && !d && t.emit("reachEnd toEdge"), (o && !r || d && !l) && t.emit("fromEdge"), t.emit("progress", s)
}

function Bc() {
    const e = this,
        {
            slides: t,
            params: n,
            slidesEl: i,
            activeIndex: s
        } = e,
        r = e.virtual && n.virtual.enabled,
        l = o => Ye(i, `.${n.slideClass}${o}, swiper-slide${o}`)[0];
    t.forEach(o => {
        o.classList.remove(n.slideActiveClass, n.slideNextClass, n.slidePrevClass)
    });
    let a;
    if (r)
        if (n.loop) {
            let o = s - e.virtual.slidesBefore;
            o < 0 && (o = e.virtual.slides.length + o), o >= e.virtual.slides.length && (o -= e.virtual.slides.length), a = l(`[data-swiper-slide-index="${o}"]`)
        } else a = l(`[data-swiper-slide-index="${s}"]`);
    else a = t[s];
    if (a) {
        a.classList.add(n.slideActiveClass);
        let o = yc(a, `.${n.slideClass}, swiper-slide`)[0];
        n.loop && !o && (o = t[0]), o && o.classList.add(n.slideNextClass);
        let d = vc(a, `.${n.slideClass}, swiper-slide`)[0];
        n.loop && !d === 0 && (d = t[t.length - 1]), d && d.classList.add(n.slidePrevClass)
    }
    e.emitSlidesClasses()
}
const Gn = (e, t) => {
        if (!e || e.destroyed || !e.params) return;
        const n = () => e.isElement ? "swiper-slide" : `.${e.params.slideClass}`,
            i = t.closest(n());
        if (i) {
            const s = i.querySelector(`.${e.params.lazyPreloaderClass}`);
            s && s.remove()
        }
    },
    Vi = (e, t) => {
        if (!e.slides[t]) return;
        const n = e.slides[t].querySelector('[loading="lazy"]');
        n && n.removeAttribute("loading")
    },
    cs = e => {
        if (!e || e.destroyed || !e.params) return;
        let t = e.params.lazyPreloadPrevNext;
        const n = e.slides.length;
        if (!n || !t || t < 0) return;
        t = Math.min(t, n);
        const i = e.params.slidesPerView === "auto" ? e.slidesPerViewDynamic() : Math.ceil(e.params.slidesPerView),
            s = e.activeIndex;
        if (e.params.grid && e.params.grid.rows > 1) {
            const l = s,
                a = [l - t];
            a.push(...Array.from({
                length: t
            }).map((o, d) => l + i + d)), e.slides.forEach((o, d) => {
                a.includes(o.column) && Vi(e, d)
            });
            return
        }
        const r = s + i - 1;
        if (e.params.rewind || e.params.loop)
            for (let l = s - t; l <= r + t; l += 1) {
                const a = (l % n + n) % n;
                (a < s || a > r) && Vi(e, a)
            } else
                for (let l = Math.max(s - t, 0); l <= Math.min(r + t, n - 1); l += 1) l !== s && (l > r || l < s) && Vi(e, l)
    };

function Dc(e) {
    const {
        slidesGrid: t,
        params: n
    } = e, i = e.rtlTranslate ? e.translate : -e.translate;
    let s;
    for (let r = 0; r < t.length; r += 1) typeof t[r + 1] < "u" ? i >= t[r] && i < t[r + 1] - (t[r + 1] - t[r]) / 2 ? s = r : i >= t[r] && i < t[r + 1] && (s = r + 1) : i >= t[r] && (s = r);
    return n.normalizeSlideIndex && (s < 0 || typeof s > "u") && (s = 0), s
}

function Fc(e) {
    const t = this,
        n = t.rtlTranslate ? t.translate : -t.translate,
        {
            snapGrid: i,
            params: s,
            activeIndex: r,
            realIndex: l,
            snapIndex: a
        } = t;
    let o = e,
        d;
    const f = m => {
        let g = m - t.virtual.slidesBefore;
        return g < 0 && (g = t.virtual.slides.length + g), g >= t.virtual.slides.length && (g -= t.virtual.slides.length), g
    };
    if (typeof o > "u" && (o = Dc(t)), i.indexOf(n) >= 0) d = i.indexOf(n);
    else {
        const m = Math.min(s.slidesPerGroupSkip, o);
        d = m + Math.floor((o - m) / s.slidesPerGroup)
    }
    if (d >= i.length && (d = i.length - 1), o === r) {
        d !== a && (t.snapIndex = d, t.emit("snapIndexChange")), t.params.loop && t.virtual && t.params.virtual.enabled && (t.realIndex = f(o));
        return
    }
    let u;
    t.virtual && s.virtual.enabled && s.loop ? u = f(o) : t.slides[o] ? u = parseInt(t.slides[o].getAttribute("data-swiper-slide-index") || o, 10) : u = o, Object.assign(t, {
        previousSnapIndex: a,
        snapIndex: d,
        previousRealIndex: l,
        realIndex: u,
        previousIndex: r,
        activeIndex: o
    }), t.initialized && cs(t), t.emit("activeIndexChange"), t.emit("snapIndexChange"), l !== u && t.emit("realIndexChange"), (t.initialized || t.params.runCallbacksOnInit) && t.emit("slideChange")
}

function Rc(e) {
    const t = this,
        n = t.params,
        i = e.closest(`.${n.slideClass}, swiper-slide`);
    let s = !1,
        r;
    if (i) {
        for (let l = 0; l < t.slides.length; l += 1)
            if (t.slides[l] === i) {
                s = !0, r = l;
                break
            }
    }
    if (i && s) t.clickedSlide = i, t.virtual && t.params.virtual.enabled ? t.clickedIndex = parseInt(i.getAttribute("data-swiper-slide-index"), 10) : t.clickedIndex = r;
    else {
        t.clickedSlide = void 0, t.clickedIndex = void 0;
        return
    }
    n.slideToClickedSlide && t.clickedIndex !== void 0 && t.clickedIndex !== t.activeIndex && t.slideToClickedSlide()
}
var Nc = {
    updateSize: Mc,
    updateSlides: Pc,
    updateAutoHeight: Ac,
    updateSlidesOffset: Ic,
    updateSlidesProgress: Oc,
    updateProgress: Lc,
    updateSlidesClasses: Bc,
    updateActiveIndex: Fc,
    updateClickedSlide: Rc
};

function $c(e) {
    e === void 0 && (e = this.isHorizontal() ? "x" : "y");
    const t = this,
        {
            params: n,
            rtlTranslate: i,
            translate: s,
            wrapperEl: r
        } = t;
    if (n.virtualTranslate) return i ? -s : s;
    if (n.cssMode) return s;
    let l = gc(r, e);
    return l += t.cssOverflowAdjustment(), i && (l = -l), l || 0
}

function zc(e, t) {
    const n = this,
        {
            rtlTranslate: i,
            params: s,
            wrapperEl: r,
            progress: l
        } = n;
    let a = 0,
        o = 0;
    const d = 0;
    n.isHorizontal() ? a = i ? -e : e : o = e, s.roundLengths && (a = Math.floor(a), o = Math.floor(o)), n.previousTranslate = n.translate, n.translate = n.isHorizontal() ? a : o, s.cssMode ? r[n.isHorizontal() ? "scrollLeft" : "scrollTop"] = n.isHorizontal() ? -a : -o : s.virtualTranslate || (n.isHorizontal() ? a -= n.cssOverflowAdjustment() : o -= n.cssOverflowAdjustment(), r.style.transform = `translate3d(${a}px, ${o}px, ${d}px)`);
    let f;
    const u = n.maxTranslate() - n.minTranslate();
    u === 0 ? f = 0 : f = (e - n.minTranslate()) / u, f !== l && n.updateProgress(e), n.emit("setTranslate", n.translate, t)
}

function Vc() {
    return -this.snapGrid[0]
}

function Hc() {
    return -this.snapGrid[this.snapGrid.length - 1]
}

function kc(e, t, n, i, s) {
    e === void 0 && (e = 0), t === void 0 && (t = this.params.speed), n === void 0 && (n = !0), i === void 0 && (i = !0);
    const r = this,
        {
            params: l,
            wrapperEl: a
        } = r;
    if (r.animating && l.preventInteractionOnTransition) return !1;
    const o = r.minTranslate(),
        d = r.maxTranslate();
    let f;
    if (i && e > o ? f = o : i && e < d ? f = d : f = e, r.updateProgress(f), l.cssMode) {
        const u = r.isHorizontal();
        if (t === 0) a[u ? "scrollLeft" : "scrollTop"] = -f;
        else {
            if (!r.support.smoothScroll) return uo({
                swiper: r,
                targetPosition: -f,
                side: u ? "left" : "top"
            }), !0;
            a.scrollTo({
                [u ? "left" : "top"]: -f,
                behavior: "smooth"
            })
        }
        return !0
    }
    return t === 0 ? (r.setTransition(0), r.setTranslate(f), n && (r.emit("beforeTransitionStart", t, s), r.emit("transitionEnd"))) : (r.setTransition(t), r.setTranslate(f), n && (r.emit("beforeTransitionStart", t, s), r.emit("transitionStart")), r.animating || (r.animating = !0, r.onTranslateToWrapperTransitionEnd || (r.onTranslateToWrapperTransitionEnd = function(m) {
        !r || r.destroyed || m.target === this && (r.wrapperEl.removeEventListener("transitionend", r.onTranslateToWrapperTransitionEnd), r.onTranslateToWrapperTransitionEnd = null, delete r.onTranslateToWrapperTransitionEnd, n && r.emit("transitionEnd"))
    }), r.wrapperEl.addEventListener("transitionend", r.onTranslateToWrapperTransitionEnd))), !0
}
var jc = {
    getTranslate: $c,
    setTranslate: zc,
    minTranslate: Vc,
    maxTranslate: Hc,
    translateTo: kc
};

function Gc(e, t) {
    const n = this;
    n.params.cssMode || (n.wrapperEl.style.transitionDuration = `${e}ms`), n.emit("setTransition", e, t)
}

function mo(e) {
    let {
        swiper: t,
        runCallbacks: n,
        direction: i,
        step: s
    } = e;
    const {
        activeIndex: r,
        previousIndex: l
    } = t;
    let a = i;
    if (a || (r > l ? a = "next" : r < l ? a = "prev" : a = "reset"), t.emit(`transition${s}`), n && r !== l) {
        if (a === "reset") {
            t.emit(`slideResetTransition${s}`);
            return
        }
        t.emit(`slideChangeTransition${s}`), a === "next" ? t.emit(`slideNextTransition${s}`) : t.emit(`slidePrevTransition${s}`)
    }
}

function Wc(e, t) {
    e === void 0 && (e = !0);
    const n = this,
        {
            params: i
        } = n;
    i.cssMode || (i.autoHeight && n.updateAutoHeight(), mo({
        swiper: n,
        runCallbacks: e,
        direction: t,
        step: "Start"
    }))
}

function Uc(e, t) {
    e === void 0 && (e = !0);
    const n = this,
        {
            params: i
        } = n;
    n.animating = !1, !i.cssMode && (n.setTransition(0), mo({
        swiper: n,
        runCallbacks: e,
        direction: t,
        step: "End"
    }))
}
var Kc = {
    setTransition: Gc,
    transitionStart: Wc,
    transitionEnd: Uc
};

function qc(e, t, n, i, s) {
    e === void 0 && (e = 0), t === void 0 && (t = this.params.speed), n === void 0 && (n = !0), typeof e == "string" && (e = parseInt(e, 10));
    const r = this;
    let l = e;
    l < 0 && (l = 0);
    const {
        params: a,
        snapGrid: o,
        slidesGrid: d,
        previousIndex: f,
        activeIndex: u,
        rtlTranslate: m,
        wrapperEl: g,
        enabled: S
    } = r;
    if (r.animating && a.preventInteractionOnTransition || !S && !i && !s) return !1;
    const v = Math.min(r.params.slidesPerGroupSkip, l);
    let E = v + Math.floor((l - v) / r.params.slidesPerGroup);
    E >= o.length && (E = o.length - 1);
    const x = -o[E];
    if (a.normalizeSlideIndex)
        for (let c = 0; c < d.length; c += 1) {
            const p = -Math.floor(x * 100),
                w = Math.floor(d[c] * 100),
                C = Math.floor(d[c + 1] * 100);
            typeof d[c + 1] < "u" ? p >= w && p < C - (C - w) / 2 ? l = c : p >= w && p < C && (l = c + 1) : p >= w && (l = c)
        }
    if (r.initialized && l !== u && (!r.allowSlideNext && (m ? x > r.translate && x > r.minTranslate() : x < r.translate && x < r.minTranslate()) || !r.allowSlidePrev && x > r.translate && x > r.maxTranslate() && (u || 0) !== l)) return !1;
    l !== (f || 0) && n && r.emit("beforeSlideChangeStart"), r.updateProgress(x);
    let h;
    if (l > u ? h = "next" : l < u ? h = "prev" : h = "reset", m && -x === r.translate || !m && x === r.translate) return r.updateActiveIndex(l), a.autoHeight && r.updateAutoHeight(), r.updateSlidesClasses(), a.effect !== "slide" && r.setTranslate(x), h !== "reset" && (r.transitionStart(n, h), r.transitionEnd(n, h)), !1;
    if (a.cssMode) {
        const c = r.isHorizontal(),
            p = m ? x : -x;
        if (t === 0) {
            const w = r.virtual && r.params.virtual.enabled;
            w && (r.wrapperEl.style.scrollSnapType = "none", r._immediateVirtual = !0), w && !r._cssModeVirtualInitialSet && r.params.initialSlide > 0 ? (r._cssModeVirtualInitialSet = !0, requestAnimationFrame(() => {
                g[c ? "scrollLeft" : "scrollTop"] = p
            })) : g[c ? "scrollLeft" : "scrollTop"] = p, w && requestAnimationFrame(() => {
                r.wrapperEl.style.scrollSnapType = "", r._immediateVirtual = !1
            })
        } else {
            if (!r.support.smoothScroll) return uo({
                swiper: r,
                targetPosition: p,
                side: c ? "left" : "top"
            }), !0;
            g.scrollTo({
                [c ? "left" : "top"]: p,
                behavior: "smooth"
            })
        }
        return !0
    }
    return r.setTransition(t), r.setTranslate(x), r.updateActiveIndex(l), r.updateSlidesClasses(), r.emit("beforeTransitionStart", t, i), r.transitionStart(n, h), t === 0 ? r.transitionEnd(n, h) : r.animating || (r.animating = !0, r.onSlideToWrapperTransitionEnd || (r.onSlideToWrapperTransitionEnd = function(p) {
        !r || r.destroyed || p.target === this && (r.wrapperEl.removeEventListener("transitionend", r.onSlideToWrapperTransitionEnd), r.onSlideToWrapperTransitionEnd = null, delete r.onSlideToWrapperTransitionEnd, r.transitionEnd(n, h))
    }), r.wrapperEl.addEventListener("transitionend", r.onSlideToWrapperTransitionEnd)), !0
}

function Yc(e, t, n, i) {
    e === void 0 && (e = 0), t === void 0 && (t = this.params.speed), n === void 0 && (n = !0), typeof e == "string" && (e = parseInt(e, 10));
    const s = this;
    let r = e;
    return s.params.loop && (s.virtual && s.params.virtual.enabled ? r = r + s.virtual.slidesBefore : r = s.getSlideIndexByData(r)), s.slideTo(r, t, n, i)
}

function Xc(e, t, n) {
    e === void 0 && (e = this.params.speed), t === void 0 && (t = !0);
    const i = this,
        {
            enabled: s,
            params: r,
            animating: l
        } = i;
    if (!s) return i;
    let a = r.slidesPerGroup;
    r.slidesPerView === "auto" && r.slidesPerGroup === 1 && r.slidesPerGroupAuto && (a = Math.max(i.slidesPerViewDynamic("current", !0), 1));
    const o = i.activeIndex < r.slidesPerGroupSkip ? 1 : a,
        d = i.virtual && r.virtual.enabled;
    if (r.loop) {
        if (l && !d && r.loopPreventsSliding) return !1;
        i.loopFix({
            direction: "next"
        }), i._clientLeft = i.wrapperEl.clientLeft
    }
    return r.rewind && i.isEnd ? i.slideTo(0, e, t, n) : i.slideTo(i.activeIndex + o, e, t, n)
}

function Jc(e, t, n) {
    e === void 0 && (e = this.params.speed), t === void 0 && (t = !0);
    const i = this,
        {
            params: s,
            snapGrid: r,
            slidesGrid: l,
            rtlTranslate: a,
            enabled: o,
            animating: d
        } = i;
    if (!o) return i;
    const f = i.virtual && s.virtual.enabled;
    if (s.loop) {
        if (d && !f && s.loopPreventsSliding) return !1;
        i.loopFix({
            direction: "prev"
        }), i._clientLeft = i.wrapperEl.clientLeft
    }
    const u = a ? i.translate : -i.translate;

    function m(x) {
        return x < 0 ? -Math.floor(Math.abs(x)) : Math.floor(x)
    }
    const g = m(u),
        S = r.map(x => m(x));
    let v = r[S.indexOf(g) - 1];
    if (typeof v > "u" && s.cssMode) {
        let x;
        r.forEach((h, c) => {
            g >= h && (x = c)
        }), typeof x < "u" && (v = r[x > 0 ? x - 1 : x])
    }
    let E = 0;
    if (typeof v < "u" && (E = l.indexOf(v), E < 0 && (E = i.activeIndex - 1), s.slidesPerView === "auto" && s.slidesPerGroup === 1 && s.slidesPerGroupAuto && (E = E - i.slidesPerViewDynamic("previous", !0) + 1, E = Math.max(E, 0))), s.rewind && i.isBeginning) {
        const x = i.params.virtual && i.params.virtual.enabled && i.virtual ? i.virtual.slides.length - 1 : i.slides.length - 1;
        return i.slideTo(x, e, t, n)
    }
    return i.slideTo(E, e, t, n)
}

function Zc(e, t, n) {
    e === void 0 && (e = this.params.speed), t === void 0 && (t = !0);
    const i = this;
    return i.slideTo(i.activeIndex, e, t, n)
}

function Qc(e, t, n, i) {
    e === void 0 && (e = this.params.speed), t === void 0 && (t = !0), i === void 0 && (i = .5);
    const s = this;
    let r = s.activeIndex;
    const l = Math.min(s.params.slidesPerGroupSkip, r),
        a = l + Math.floor((r - l) / s.params.slidesPerGroup),
        o = s.rtlTranslate ? s.translate : -s.translate;
    if (o >= s.snapGrid[a]) {
        const d = s.snapGrid[a],
            f = s.snapGrid[a + 1];
        o - d > (f - d) * i && (r += s.params.slidesPerGroup)
    } else {
        const d = s.snapGrid[a - 1],
            f = s.snapGrid[a];
        o - d <= (f - d) * i && (r -= s.params.slidesPerGroup)
    }
    return r = Math.max(r, 0), r = Math.min(r, s.slidesGrid.length - 1), s.slideTo(r, e, t, n)
}

function eu() {
    const e = this,
        {
            params: t,
            slidesEl: n
        } = e,
        i = t.slidesPerView === "auto" ? e.slidesPerViewDynamic() : t.slidesPerView;
    let s = e.clickedIndex,
        r;
    const l = e.isElement ? "swiper-slide" : `.${t.slideClass}`;
    if (t.loop) {
        if (e.animating) return;
        r = parseInt(e.clickedSlide.getAttribute("data-swiper-slide-index"), 10), t.centeredSlides ? s < e.loopedSlides - i / 2 || s > e.slides.length - e.loopedSlides + i / 2 ? (e.loopFix(), s = e.getSlideIndex(Ye(n, `${l}[data-swiper-slide-index="${r}"]`)[0]), as(() => {
            e.slideTo(s)
        })) : e.slideTo(s) : s > e.slides.length - i ? (e.loopFix(), s = e.getSlideIndex(Ye(n, `${l}[data-swiper-slide-index="${r}"]`)[0]), as(() => {
            e.slideTo(s)
        })) : e.slideTo(s)
    } else e.slideTo(s)
}
var tu = {
    slideTo: qc,
    slideToLoop: Yc,
    slideNext: Xc,
    slidePrev: Jc,
    slideReset: Zc,
    slideToClosest: Qc,
    slideToClickedSlide: eu
};

function nu(e) {
    const t = this,
        {
            params: n,
            slidesEl: i
        } = t;
    if (!n.loop || t.virtual && t.params.virtual.enabled) return;
    Ye(i, `.${n.slideClass}, swiper-slide`).forEach((r, l) => {
        r.setAttribute("data-swiper-slide-index", l)
    }), t.loopFix({
        slideRealIndex: e,
        direction: n.centeredSlides ? void 0 : "next"
    })
}

function iu(e) {
    let {
        slideRealIndex: t,
        slideTo: n = !0,
        direction: i,
        setTranslate: s,
        activeSlideIndex: r,
        byController: l,
        byMousewheel: a
    } = e === void 0 ? {} : e;
    const o = this;
    if (!o.params.loop) return;
    o.emit("beforeLoopFix");
    const {
        slides: d,
        allowSlidePrev: f,
        allowSlideNext: u,
        slidesEl: m,
        params: g
    } = o;
    if (o.allowSlidePrev = !0, o.allowSlideNext = !0, o.virtual && g.virtual.enabled) {
        n && (!g.centeredSlides && o.snapIndex === 0 ? o.slideTo(o.virtual.slides.length, 0, !1, !0) : g.centeredSlides && o.snapIndex < g.slidesPerView ? o.slideTo(o.virtual.slides.length + o.snapIndex, 0, !1, !0) : o.snapIndex === o.snapGrid.length - 1 && o.slideTo(o.virtual.slidesBefore, 0, !1, !0)), o.allowSlidePrev = f, o.allowSlideNext = u, o.emit("loopFix");
        return
    }
    const S = g.slidesPerView === "auto" ? o.slidesPerViewDynamic() : Math.ceil(parseFloat(g.slidesPerView, 10));
    let v = g.loopedSlides || S;
    v % g.slidesPerGroup !== 0 && (v += g.slidesPerGroup - v % g.slidesPerGroup), o.loopedSlides = v;
    const E = [],
        x = [];
    let h = o.activeIndex;
    typeof r > "u" ? r = o.getSlideIndex(o.slides.filter(P => P.classList.contains(g.slideActiveClass))[0]) : h = r;
    const c = i === "next" || !i,
        p = i === "prev" || !i;
    let w = 0,
        C = 0;
    if (r < v) {
        w = Math.max(v - r, g.slidesPerGroup);
        for (let P = 0; P < v - r; P += 1) {
            const O = P - Math.floor(P / d.length) * d.length;
            E.push(d.length - O - 1)
        }
    } else if (r > o.slides.length - v * 2) {
        C = Math.max(r - (o.slides.length - v * 2), g.slidesPerGroup);
        for (let P = 0; P < C; P += 1) {
            const O = P - Math.floor(P / d.length) * d.length;
            x.push(O)
        }
    }
    if (p && E.forEach(P => {
            o.slides[P].swiperLoopMoveDOM = !0, m.prepend(o.slides[P]), o.slides[P].swiperLoopMoveDOM = !1
        }), c && x.forEach(P => {
            o.slides[P].swiperLoopMoveDOM = !0, m.append(o.slides[P]), o.slides[P].swiperLoopMoveDOM = !1
        }), o.recalcSlides(), g.slidesPerView === "auto" && o.updateSlides(), g.watchSlidesProgress && o.updateSlidesOffset(), n) {
        if (E.length > 0 && p)
            if (typeof t > "u") {
                const P = o.slidesGrid[h],
                    b = o.slidesGrid[h + w] - P;
                a ? o.setTranslate(o.translate - b) : (o.slideTo(h + w, 0, !1, !0), s && (o.touches[o.isHorizontal() ? "startX" : "startY"] += b))
            } else s && o.slideToLoop(t, 0, !1, !0);
        else if (x.length > 0 && c)
            if (typeof t > "u") {
                const P = o.slidesGrid[h],
                    b = o.slidesGrid[h - C] - P;
                a ? o.setTranslate(o.translate - b) : (o.slideTo(h - C, 0, !1, !0), s && (o.touches[o.isHorizontal() ? "startX" : "startY"] += b))
            } else o.slideToLoop(t, 0, !1, !0)
    }
    if (o.allowSlidePrev = f, o.allowSlideNext = u, o.controller && o.controller.control && !l) {
        const P = {
            slideRealIndex: t,
            slideTo: !1,
            direction: i,
            setTranslate: s,
            activeSlideIndex: r,
            byController: !0
        };
        Array.isArray(o.controller.control) ? o.controller.control.forEach(O => {
            !O.destroyed && O.params.loop && O.loopFix(P)
        }) : o.controller.control instanceof o.constructor && o.controller.control.params.loop && o.controller.control.loopFix(P)
    }
    o.emit("loopFix")
}

function su() {
    const e = this,
        {
            params: t,
            slidesEl: n
        } = e;
    if (!t.loop || e.virtual && e.params.virtual.enabled) return;
    e.recalcSlides();
    const i = [];
    e.slides.forEach(s => {
        const r = typeof s.swiperSlideIndex > "u" ? s.getAttribute("data-swiper-slide-index") * 1 : s.swiperSlideIndex;
        i[r] = s
    }), e.slides.forEach(s => {
        s.removeAttribute("data-swiper-slide-index")
    }), i.forEach(s => {
        n.append(s)
    }), e.recalcSlides(), e.slideTo(e.realIndex, 0)
}
var ru = {
    loopCreate: nu,
    loopFix: iu,
    loopDestroy: su
};

function lu(e) {
    const t = this;
    if (!t.params.simulateTouch || t.params.watchOverflow && t.isLocked || t.params.cssMode) return;
    const n = t.params.touchEventsTarget === "container" ? t.el : t.wrapperEl;
    t.isElement && (t.__preventObserver__ = !0), n.style.cursor = "move", n.style.cursor = e ? "grabbing" : "grab", t.isElement && requestAnimationFrame(() => {
        t.__preventObserver__ = !1
    })
}

function ou() {
    const e = this;
    e.params.watchOverflow && e.isLocked || e.params.cssMode || (e.isElement && (e.__preventObserver__ = !0), e[e.params.touchEventsTarget === "container" ? "el" : "wrapperEl"].style.cursor = "", e.isElement && requestAnimationFrame(() => {
        e.__preventObserver__ = !1
    }))
}
var au = {
    setGrabCursor: lu,
    unsetGrabCursor: ou
};

function fu(e, t) {
    t === void 0 && (t = this);

    function n(i) {
        if (!i || i === Xe() || i === Be()) return null;
        i.assignedSlot && (i = i.assignedSlot);
        const s = i.closest(e);
        return !s && !i.getRootNode ? null : s || n(i.getRootNode().host)
    }
    return n(t)
}

function cu(e) {
    const t = this,
        n = Xe(),
        i = Be(),
        s = t.touchEventsData;
    s.evCache.push(e);
    const {
        params: r,
        touches: l,
        enabled: a
    } = t;
    if (!a || !r.simulateTouch && e.pointerType === "mouse" || t.animating && r.preventInteractionOnTransition) return;
    !t.animating && r.cssMode && r.loop && t.loopFix();
    let o = e;
    o.originalEvent && (o = o.originalEvent);
    let d = o.target;
    if (r.touchEventsTarget === "wrapper" && !t.wrapperEl.contains(d) || "which" in o && o.which === 3 || "button" in o && o.button > 0 || s.isTouched && s.isMoved) return;
    const f = !!r.noSwipingClass && r.noSwipingClass !== "",
        u = e.composedPath ? e.composedPath() : e.path;
    f && o.target && o.target.shadowRoot && u && (d = u[0]);
    const m = r.noSwipingSelector ? r.noSwipingSelector : `.${r.noSwipingClass}`,
        g = !!(o.target && o.target.shadowRoot);
    if (r.noSwiping && (g ? fu(m, d) : d.closest(m))) {
        t.allowClick = !0;
        return
    }
    if (r.swipeHandler && !d.closest(r.swipeHandler)) return;
    l.currentX = o.pageX, l.currentY = o.pageY;
    const S = l.currentX,
        v = l.currentY,
        E = r.edgeSwipeDetection || r.iOSEdgeSwipeDetection,
        x = r.edgeSwipeThreshold || r.iOSEdgeSwipeThreshold;
    if (E && (S <= x || S >= i.innerWidth - x))
        if (E === "prevent") e.preventDefault();
        else return;
    Object.assign(s, {
        isTouched: !0,
        isMoved: !1,
        allowTouchCallbacks: !0,
        isScrolling: void 0,
        startMoving: void 0
    }), l.startX = S, l.startY = v, s.touchStartTime = _t(), t.allowClick = !0, t.updateSize(), t.swipeDirection = void 0, r.threshold > 0 && (s.allowThresholdMove = !1);
    let h = !0;
    d.matches(s.focusableElements) && (h = !1, d.nodeName === "SELECT" && (s.isTouched = !1)), n.activeElement && n.activeElement.matches(s.focusableElements) && n.activeElement !== d && n.activeElement.blur();
    const c = h && t.allowTouchMove && r.touchStartPreventDefault;
    (r.touchStartForcePreventDefault || c) && !d.isContentEditable && o.preventDefault(), r.freeMode && r.freeMode.enabled && t.freeMode && t.animating && !r.cssMode && t.freeMode.onTouchStart(), t.emit("touchStart", o)
}

function uu(e) {
    const t = Xe(),
        n = this,
        i = n.touchEventsData,
        {
            params: s,
            touches: r,
            rtlTranslate: l,
            enabled: a
        } = n;
    if (!a || !s.simulateTouch && e.pointerType === "mouse") return;
    let o = e;
    if (o.originalEvent && (o = o.originalEvent), !i.isTouched) {
        i.startMoving && i.isScrolling && n.emit("touchMoveOpposite", o);
        return
    }
    const d = i.evCache.findIndex(C => C.pointerId === o.pointerId);
    d >= 0 && (i.evCache[d] = o);
    const f = i.evCache.length > 1 ? i.evCache[0] : o,
        u = f.pageX,
        m = f.pageY;
    if (o.preventedByNestedSwiper) {
        r.startX = u, r.startY = m;
        return
    }
    if (!n.allowTouchMove) {
        o.target.matches(i.focusableElements) || (n.allowClick = !1), i.isTouched && (Object.assign(r, {
            startX: u,
            startY: m,
            prevX: n.touches.currentX,
            prevY: n.touches.currentY,
            currentX: u,
            currentY: m
        }), i.touchStartTime = _t());
        return
    }
    if (s.touchReleaseOnEdges && !s.loop) {
        if (n.isVertical()) {
            if (m < r.startY && n.translate <= n.maxTranslate() || m > r.startY && n.translate >= n.minTranslate()) {
                i.isTouched = !1, i.isMoved = !1;
                return
            }
        } else if (u < r.startX && n.translate <= n.maxTranslate() || u > r.startX && n.translate >= n.minTranslate()) return
    }
    if (t.activeElement && o.target === t.activeElement && o.target.matches(i.focusableElements)) {
        i.isMoved = !0, n.allowClick = !1;
        return
    }
    if (i.allowTouchCallbacks && n.emit("touchMove", o), o.targetTouches && o.targetTouches.length > 1) return;
    r.currentX = u, r.currentY = m;
    const g = r.currentX - r.startX,
        S = r.currentY - r.startY;
    if (n.params.threshold && Math.sqrt(g ** 2 + S ** 2) < n.params.threshold) return;
    if (typeof i.isScrolling > "u") {
        let C;
        n.isHorizontal() && r.currentY === r.startY || n.isVertical() && r.currentX === r.startX ? i.isScrolling = !1 : g * g + S * S >= 25 && (C = Math.atan2(Math.abs(S), Math.abs(g)) * 180 / Math.PI, i.isScrolling = n.isHorizontal() ? C > s.touchAngle : 90 - C > s.touchAngle)
    }
    if (i.isScrolling && n.emit("touchMoveOpposite", o), typeof i.startMoving > "u" && (r.currentX !== r.startX || r.currentY !== r.startY) && (i.startMoving = !0), i.isScrolling || n.zoom && n.params.zoom && n.params.zoom.enabled && i.evCache.length > 1) {
        i.isTouched = !1;
        return
    }
    if (!i.startMoving) return;
    n.allowClick = !1, !s.cssMode && o.cancelable && o.preventDefault(), s.touchMoveStopPropagation && !s.nested && o.stopPropagation();
    let v = n.isHorizontal() ? g : S,
        E = n.isHorizontal() ? r.currentX - r.previousX : r.currentY - r.previousY;
    s.oneWayMovement && (v = Math.abs(v) * (l ? 1 : -1), E = Math.abs(E) * (l ? 1 : -1)), r.diff = v, v *= s.touchRatio, l && (v = -v, E = -E);
    const x = n.touchesDirection;
    n.swipeDirection = v > 0 ? "prev" : "next", n.touchesDirection = E > 0 ? "prev" : "next";
    const h = n.params.loop && !s.cssMode;
    if (!i.isMoved) {
        if (h && n.loopFix({
                direction: n.swipeDirection
            }), i.startTranslate = n.getTranslate(), n.setTransition(0), n.animating) {
            const C = new window.CustomEvent("transitionend", {
                bubbles: !0,
                cancelable: !0
            });
            n.wrapperEl.dispatchEvent(C)
        }
        i.allowMomentumBounce = !1, s.grabCursor && (n.allowSlideNext === !0 || n.allowSlidePrev === !0) && n.setGrabCursor(!0), n.emit("sliderFirstMove", o)
    }
    let c;
    i.isMoved && x !== n.touchesDirection && h && Math.abs(v) >= 1 && (n.loopFix({
        direction: n.swipeDirection,
        setTranslate: !0
    }), c = !0), n.emit("sliderMove", o), i.isMoved = !0, i.currentTranslate = v + i.startTranslate;
    let p = !0,
        w = s.resistanceRatio;
    if (s.touchReleaseOnEdges && (w = 0), v > 0 ? (h && !c && i.currentTranslate > (s.centeredSlides ? n.minTranslate() - n.size / 2 : n.minTranslate()) && n.loopFix({
            direction: "prev",
            setTranslate: !0,
            activeSlideIndex: 0
        }), i.currentTranslate > n.minTranslate() && (p = !1, s.resistance && (i.currentTranslate = n.minTranslate() - 1 + (-n.minTranslate() + i.startTranslate + v) ** w))) : v < 0 && (h && !c && i.currentTranslate < (s.centeredSlides ? n.maxTranslate() + n.size / 2 : n.maxTranslate()) && n.loopFix({
            direction: "next",
            setTranslate: !0,
            activeSlideIndex: n.slides.length - (s.slidesPerView === "auto" ? n.slidesPerViewDynamic() : Math.ceil(parseFloat(s.slidesPerView, 10)))
        }), i.currentTranslate < n.maxTranslate() && (p = !1, s.resistance && (i.currentTranslate = n.maxTranslate() + 1 - (n.maxTranslate() - i.startTranslate - v) ** w))), p && (o.preventedByNestedSwiper = !0), !n.allowSlideNext && n.swipeDirection === "next" && i.currentTranslate < i.startTranslate && (i.currentTranslate = i.startTranslate), !n.allowSlidePrev && n.swipeDirection === "prev" && i.currentTranslate > i.startTranslate && (i.currentTranslate = i.startTranslate), !n.allowSlidePrev && !n.allowSlideNext && (i.currentTranslate = i.startTranslate), s.threshold > 0)
        if (Math.abs(v) > s.threshold || i.allowThresholdMove) {
            if (!i.allowThresholdMove) {
                i.allowThresholdMove = !0, r.startX = r.currentX, r.startY = r.currentY, i.currentTranslate = i.startTranslate, r.diff = n.isHorizontal() ? r.currentX - r.startX : r.currentY - r.startY;
                return
            }
        } else {
            i.currentTranslate = i.startTranslate;
            return
        }!s.followFinger || s.cssMode || ((s.freeMode && s.freeMode.enabled && n.freeMode || s.watchSlidesProgress) && (n.updateActiveIndex(), n.updateSlidesClasses()), s.freeMode && s.freeMode.enabled && n.freeMode && n.freeMode.onTouchMove(), n.updateProgress(i.currentTranslate), n.setTranslate(i.currentTranslate))
}

function du(e) {
    const t = this,
        n = t.touchEventsData,
        i = n.evCache.findIndex(c => c.pointerId === e.pointerId);
    if (i >= 0 && n.evCache.splice(i, 1), ["pointercancel", "pointerout", "pointerleave"].includes(e.type) && !(e.type === "pointercancel" && (t.browser.isSafari || t.browser.isWebView))) return;
    const {
        params: s,
        touches: r,
        rtlTranslate: l,
        slidesGrid: a,
        enabled: o
    } = t;
    if (!o || !s.simulateTouch && e.pointerType === "mouse") return;
    let d = e;
    if (d.originalEvent && (d = d.originalEvent), n.allowTouchCallbacks && t.emit("touchEnd", d), n.allowTouchCallbacks = !1, !n.isTouched) {
        n.isMoved && s.grabCursor && t.setGrabCursor(!1), n.isMoved = !1, n.startMoving = !1;
        return
    }
    s.grabCursor && n.isMoved && n.isTouched && (t.allowSlideNext === !0 || t.allowSlidePrev === !0) && t.setGrabCursor(!1);
    const f = _t(),
        u = f - n.touchStartTime;
    if (t.allowClick) {
        const c = d.path || d.composedPath && d.composedPath();
        t.updateClickedSlide(c && c[0] || d.target), t.emit("tap click", d), u < 300 && f - n.lastClickTime < 300 && t.emit("doubleTap doubleClick", d)
    }
    if (n.lastClickTime = _t(), as(() => {
            t.destroyed || (t.allowClick = !0)
        }), !n.isTouched || !n.isMoved || !t.swipeDirection || r.diff === 0 || n.currentTranslate === n.startTranslate) {
        n.isTouched = !1, n.isMoved = !1, n.startMoving = !1;
        return
    }
    n.isTouched = !1, n.isMoved = !1, n.startMoving = !1;
    let m;
    if (s.followFinger ? m = l ? t.translate : -t.translate : m = -n.currentTranslate, s.cssMode) return;
    if (s.freeMode && s.freeMode.enabled) {
        t.freeMode.onTouchEnd({
            currentPos: m
        });
        return
    }
    let g = 0,
        S = t.slidesSizesGrid[0];
    for (let c = 0; c < a.length; c += c < s.slidesPerGroupSkip ? 1 : s.slidesPerGroup) {
        const p = c < s.slidesPerGroupSkip - 1 ? 1 : s.slidesPerGroup;
        typeof a[c + p] < "u" ? m >= a[c] && m < a[c + p] && (g = c, S = a[c + p] - a[c]) : m >= a[c] && (g = c, S = a[a.length - 1] - a[a.length - 2])
    }
    let v = null,
        E = null;
    s.rewind && (t.isBeginning ? E = s.virtual && s.virtual.enabled && t.virtual ? t.virtual.slides.length - 1 : t.slides.length - 1 : t.isEnd && (v = 0));
    const x = (m - a[g]) / S,
        h = g < s.slidesPerGroupSkip - 1 ? 1 : s.slidesPerGroup;
    if (u > s.longSwipesMs) {
        if (!s.longSwipes) {
            t.slideTo(t.activeIndex);
            return
        }
        t.swipeDirection === "next" && (x >= s.longSwipesRatio ? t.slideTo(s.rewind && t.isEnd ? v : g + h) : t.slideTo(g)), t.swipeDirection === "prev" && (x > 1 - s.longSwipesRatio ? t.slideTo(g + h) : E !== null && x < 0 && Math.abs(x) > s.longSwipesRatio ? t.slideTo(E) : t.slideTo(g))
    } else {
        if (!s.shortSwipes) {
            t.slideTo(t.activeIndex);
            return
        }
        t.navigation && (d.target === t.navigation.nextEl || d.target === t.navigation.prevEl) ? d.target === t.navigation.nextEl ? t.slideTo(g + h) : t.slideTo(g) : (t.swipeDirection === "next" && t.slideTo(v !== null ? v : g + h), t.swipeDirection === "prev" && t.slideTo(E !== null ? E : g))
    }
}

function Mr() {
    const e = this,
        {
            params: t,
            el: n
        } = e;
    if (n && n.offsetWidth === 0) return;
    t.breakpoints && e.setBreakpoint();
    const {
        allowSlideNext: i,
        allowSlidePrev: s,
        snapGrid: r
    } = e, l = e.virtual && e.params.virtual.enabled;
    e.allowSlideNext = !0, e.allowSlidePrev = !0, e.updateSize(), e.updateSlides(), e.updateSlidesClasses();
    const a = l && t.loop;
    (t.slidesPerView === "auto" || t.slidesPerView > 1) && e.isEnd && !e.isBeginning && !e.params.centeredSlides && !a ? e.slideTo(e.slides.length - 1, 0, !1, !0) : e.params.loop && !l ? e.slideToLoop(e.realIndex, 0, !1, !0) : e.slideTo(e.activeIndex, 0, !1, !0), e.autoplay && e.autoplay.running && e.autoplay.paused && (clearTimeout(e.autoplay.resizeTimeout), e.autoplay.resizeTimeout = setTimeout(() => {
        e.autoplay && e.autoplay.running && e.autoplay.paused && e.autoplay.resume()
    }, 500)), e.allowSlidePrev = s, e.allowSlideNext = i, e.params.watchOverflow && r !== e.snapGrid && e.checkOverflow()
}

function pu(e) {
    const t = this;
    t.enabled && (t.allowClick || (t.params.preventClicks && e.preventDefault(), t.params.preventClicksPropagation && t.animating && (e.stopPropagation(), e.stopImmediatePropagation())))
}

function hu() {
    const e = this,
        {
            wrapperEl: t,
            rtlTranslate: n,
            enabled: i
        } = e;
    if (!i) return;
    e.previousTranslate = e.translate, e.isHorizontal() ? e.translate = -t.scrollLeft : e.translate = -t.scrollTop, e.translate === 0 && (e.translate = 0), e.updateActiveIndex(), e.updateSlidesClasses();
    let s;
    const r = e.maxTranslate() - e.minTranslate();
    r === 0 ? s = 0 : s = (e.translate - e.minTranslate()) / r, s !== e.progress && e.updateProgress(n ? -e.translate : e.translate), e.emit("setTranslate", e.translate, !1)
}

function gu(e) {
    const t = this;
    Gn(t, e.target), !(t.params.cssMode || t.params.slidesPerView !== "auto" && !t.params.autoHeight) && t.update()
}
let Pr = !1;

function mu() {}
const vo = (e, t) => {
    const n = Xe(),
        {
            params: i,
            el: s,
            wrapperEl: r,
            device: l
        } = e,
        a = !!i.nested,
        o = t === "on" ? "addEventListener" : "removeEventListener",
        d = t;
    s[o]("pointerdown", e.onTouchStart, {
        passive: !1
    }), n[o]("pointermove", e.onTouchMove, {
        passive: !1,
        capture: a
    }), n[o]("pointerup", e.onTouchEnd, {
        passive: !0
    }), n[o]("pointercancel", e.onTouchEnd, {
        passive: !0
    }), n[o]("pointerout", e.onTouchEnd, {
        passive: !0
    }), n[o]("pointerleave", e.onTouchEnd, {
        passive: !0
    }), (i.preventClicks || i.preventClicksPropagation) && s[o]("click", e.onClick, !0), i.cssMode && r[o]("scroll", e.onScroll), i.updateOnWindowResize ? e[d](l.ios || l.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", Mr, !0) : e[d]("observerUpdate", Mr, !0), s[o]("load", e.onLoad, {
        capture: !0
    })
};

function vu() {
    const e = this,
        t = Xe(),
        {
            params: n
        } = e;
    e.onTouchStart = cu.bind(e), e.onTouchMove = uu.bind(e), e.onTouchEnd = du.bind(e), n.cssMode && (e.onScroll = hu.bind(e)), e.onClick = pu.bind(e), e.onLoad = gu.bind(e), Pr || (t.addEventListener("touchstart", mu), Pr = !0), vo(e, "on")
}

function yu() {
    vo(this, "off")
}
var bu = {
    attachEvents: vu,
    detachEvents: yu
};
const Ar = (e, t) => e.grid && t.grid && t.grid.rows > 1;

function wu() {
    const e = this,
        {
            realIndex: t,
            initialized: n,
            params: i,
            el: s
        } = e,
        r = i.breakpoints;
    if (!r || r && Object.keys(r).length === 0) return;
    const l = e.getBreakpoint(r, e.params.breakpointsBase, e.el);
    if (!l || e.currentBreakpoint === l) return;
    const o = (l in r ? r[l] : void 0) || e.originalParams,
        d = Ar(e, i),
        f = Ar(e, o),
        u = i.enabled;
    d && !f ? (s.classList.remove(`${i.containerModifierClass}grid`, `${i.containerModifierClass}grid-column`), e.emitContainerClasses()) : !d && f && (s.classList.add(`${i.containerModifierClass}grid`), (o.grid.fill && o.grid.fill === "column" || !o.grid.fill && i.grid.fill === "column") && s.classList.add(`${i.containerModifierClass}grid-column`), e.emitContainerClasses()), ["navigation", "pagination", "scrollbar"].forEach(v => {
        if (typeof o[v] > "u") return;
        const E = i[v] && i[v].enabled,
            x = o[v] && o[v].enabled;
        E && !x && e[v].disable(), !E && x && e[v].enable()
    });
    const m = o.direction && o.direction !== i.direction,
        g = i.loop && (o.slidesPerView !== i.slidesPerView || m);
    m && n && e.changeDirection(), Ie(e.params, o);
    const S = e.params.enabled;
    Object.assign(e, {
        allowTouchMove: e.params.allowTouchMove,
        allowSlideNext: e.params.allowSlideNext,
        allowSlidePrev: e.params.allowSlidePrev
    }), u && !S ? e.disable() : !u && S && e.enable(), e.currentBreakpoint = l, e.emit("_beforeBreakpoint", o), g && n && (e.loopDestroy(), e.loopCreate(t), e.updateSlides()), e.emit("breakpoint", o)
}

function Su(e, t, n) {
    if (t === void 0 && (t = "window"), !e || t === "container" && !n) return;
    let i = !1;
    const s = Be(),
        r = t === "window" ? s.innerHeight : n.clientHeight,
        l = Object.keys(e).map(a => {
            if (typeof a == "string" && a.indexOf("@") === 0) {
                const o = parseFloat(a.substr(1));
                return {
                    value: r * o,
                    point: a
                }
            }
            return {
                value: a,
                point: a
            }
        });
    l.sort((a, o) => parseInt(a.value, 10) - parseInt(o.value, 10));
    for (let a = 0; a < l.length; a += 1) {
        const {
            point: o,
            value: d
        } = l[a];
        t === "window" ? s.matchMedia(`(min-width: ${d}px)`).matches && (i = o) : d <= n.clientWidth && (i = o)
    }
    return i || "max"
}
var Tu = {
    setBreakpoint: wu,
    getBreakpoint: Su
};

function xu(e, t) {
    const n = [];
    return e.forEach(i => {
        typeof i == "object" ? Object.keys(i).forEach(s => {
            i[s] && n.push(t + s)
        }) : typeof i == "string" && n.push(t + i)
    }), n
}

function Eu() {
    const e = this,
        {
            classNames: t,
            params: n,
            rtl: i,
            el: s,
            device: r
        } = e,
        l = xu(["initialized", n.direction, {
            "free-mode": e.params.freeMode && n.freeMode.enabled
        }, {
            autoheight: n.autoHeight
        }, {
            rtl: i
        }, {
            grid: n.grid && n.grid.rows > 1
        }, {
            "grid-column": n.grid && n.grid.rows > 1 && n.grid.fill === "column"
        }, {
            android: r.android
        }, {
            ios: r.ios
        }, {
            "css-mode": n.cssMode
        }, {
            centered: n.cssMode && n.centeredSlides
        }, {
            "watch-progress": n.watchSlidesProgress
        }], n.containerModifierClass);
    t.push(...l), s.classList.add(...t), e.emitContainerClasses()
}

function Cu() {
    const e = this,
        {
            el: t,
            classNames: n
        } = e;
    t.classList.remove(...n), e.emitContainerClasses()
}
var _u = {
    addClasses: Eu,
    removeClasses: Cu
};

function Mu() {
    const e = this,
        {
            isLocked: t,
            params: n
        } = e,
        {
            slidesOffsetBefore: i
        } = n;
    if (i) {
        const s = e.slides.length - 1,
            r = e.slidesGrid[s] + e.slidesSizesGrid[s] + i * 2;
        e.isLocked = e.size > r
    } else e.isLocked = e.snapGrid.length === 1;
    n.allowSlideNext === !0 && (e.allowSlideNext = !e.isLocked), n.allowSlidePrev === !0 && (e.allowSlidePrev = !e.isLocked), t && t !== e.isLocked && (e.isEnd = !1), t !== e.isLocked && e.emit(e.isLocked ? "lock" : "unlock")
}
var Pu = {
        checkOverflow: Mu
    },
    Ir = {
        init: !0,
        direction: "horizontal",
        oneWayMovement: !1,
        touchEventsTarget: "wrapper",
        initialSlide: 0,
        speed: 300,
        cssMode: !1,
        updateOnWindowResize: !0,
        resizeObserver: !0,
        nested: !1,
        createElements: !1,
        enabled: !0,
        focusableElements: "input, select, option, textarea, button, video, label",
        width: null,
        height: null,
        preventInteractionOnTransition: !1,
        userAgent: null,
        url: null,
        edgeSwipeDetection: !1,
        edgeSwipeThreshold: 20,
        autoHeight: !1,
        setWrapperSize: !1,
        virtualTranslate: !1,
        effect: "slide",
        breakpoints: void 0,
        breakpointsBase: "window",
        spaceBetween: 0,
        slidesPerView: 1,
        slidesPerGroup: 1,
        slidesPerGroupSkip: 0,
        slidesPerGroupAuto: !1,
        centeredSlides: !1,
        centeredSlidesBounds: !1,
        slidesOffsetBefore: 0,
        slidesOffsetAfter: 0,
        normalizeSlideIndex: !0,
        centerInsufficientSlides: !1,
        watchOverflow: !0,
        roundLengths: !1,
        touchRatio: 1,
        touchAngle: 45,
        simulateTouch: !0,
        shortSwipes: !0,
        longSwipes: !0,
        longSwipesRatio: .5,
        longSwipesMs: 300,
        followFinger: !0,
        allowTouchMove: !0,
        threshold: 5,
        touchMoveStopPropagation: !1,
        touchStartPreventDefault: !0,
        touchStartForcePreventDefault: !1,
        touchReleaseOnEdges: !1,
        uniqueNavElements: !0,
        resistance: !0,
        resistanceRatio: .85,
        watchSlidesProgress: !1,
        grabCursor: !1,
        preventClicks: !0,
        preventClicksPropagation: !0,
        slideToClickedSlide: !1,
        loop: !1,
        loopedSlides: null,
        loopPreventsSliding: !0,
        rewind: !1,
        allowSlidePrev: !0,
        allowSlideNext: !0,
        swipeHandler: null,
        noSwiping: !0,
        noSwipingClass: "swiper-no-swiping",
        noSwipingSelector: null,
        passiveListeners: !0,
        maxBackfaceHiddenSlides: 10,
        containerModifierClass: "swiper-",
        slideClass: "swiper-slide",
        slideActiveClass: "swiper-slide-active",
        slideVisibleClass: "swiper-slide-visible",
        slideNextClass: "swiper-slide-next",
        slidePrevClass: "swiper-slide-prev",
        wrapperClass: "swiper-wrapper",
        lazyPreloaderClass: "swiper-lazy-preloader",
        lazyPreloadPrevNext: 0,
        runCallbacksOnInit: !0,
        _emitClasses: !1
    };

function Au(e, t) {
    return function(i) {
        i === void 0 && (i = {});
        const s = Object.keys(i)[0],
            r = i[s];
        if (typeof r != "object" || r === null) {
            Ie(t, i);
            return
        }
        if (["navigation", "pagination", "scrollbar"].indexOf(s) >= 0 && e[s] === !0 && (e[s] = {
                auto: !0
            }), !(s in e && "enabled" in r)) {
            Ie(t, i);
            return
        }
        e[s] === !0 && (e[s] = {
            enabled: !0
        }), typeof e[s] == "object" && !("enabled" in e[s]) && (e[s].enabled = !0), e[s] || (e[s] = {
            enabled: !1
        }), Ie(t, i)
    }
}
const Hi = {
        eventsEmitter: _c,
        update: Nc,
        translate: jc,
        transition: Kc,
        slide: tu,
        loop: ru,
        grabCursor: au,
        events: bu,
        breakpoints: Tu,
        checkOverflow: Pu,
        classes: _u
    },
    ki = {};
let wn = class Ze {
    constructor() {
        let t, n;
        for (var i = arguments.length, s = new Array(i), r = 0; r < i; r++) s[r] = arguments[r];
        s.length === 1 && s[0].constructor && Object.prototype.toString.call(s[0]).slice(8, -1) === "Object" ? n = s[0] : [t, n] = s, n || (n = {}), n = Ie({}, n), t && !n.el && (n.el = t);
        const l = Xe();
        if (n.el && typeof n.el == "string" && l.querySelectorAll(n.el).length > 1) {
            const f = [];
            return l.querySelectorAll(n.el).forEach(u => {
                const m = Ie({}, n, {
                    el: u
                });
                f.push(new Ze(m))
            }), f
        }
        const a = this;
        a.__swiper__ = !0, a.support = go(), a.device = Sc({
            userAgent: n.userAgent
        }), a.browser = xc(), a.eventsListeners = {}, a.eventsAnyListeners = [], a.modules = [...a.__modules__], n.modules && Array.isArray(n.modules) && a.modules.push(...n.modules);
        const o = {};
        a.modules.forEach(f => {
            f({
                params: n,
                swiper: a,
                extendParams: Au(n, o),
                on: a.on.bind(a),
                once: a.once.bind(a),
                off: a.off.bind(a),
                emit: a.emit.bind(a)
            })
        });
        const d = Ie({}, Ir, o);
        return a.params = Ie({}, d, ki, n), a.originalParams = Ie({}, a.params), a.passedParams = Ie({}, n), a.params && a.params.on && Object.keys(a.params.on).forEach(f => {
            a.on(f, a.params.on[f])
        }), a.params && a.params.onAny && a.onAny(a.params.onAny), Object.assign(a, {
            enabled: a.params.enabled,
            el: t,
            classNames: [],
            slides: [],
            slidesGrid: [],
            snapGrid: [],
            slidesSizesGrid: [],
            isHorizontal() {
                return a.params.direction === "horizontal"
            },
            isVertical() {
                return a.params.direction === "vertical"
            },
            activeIndex: 0,
            realIndex: 0,
            isBeginning: !0,
            isEnd: !1,
            translate: 0,
            previousTranslate: 0,
            progress: 0,
            velocity: 0,
            animating: !1,
            cssOverflowAdjustment() {
                return Math.trunc(this.translate / 2 ** 23) * 2 ** 23
            },
            allowSlideNext: a.params.allowSlideNext,
            allowSlidePrev: a.params.allowSlidePrev,
            touchEventsData: {
                isTouched: void 0,
                isMoved: void 0,
                allowTouchCallbacks: void 0,
                touchStartTime: void 0,
                isScrolling: void 0,
                currentTranslate: void 0,
                startTranslate: void 0,
                allowThresholdMove: void 0,
                focusableElements: a.params.focusableElements,
                lastClickTime: 0,
                clickTimeout: void 0,
                velocities: [],
                allowMomentumBounce: void 0,
                startMoving: void 0,
                evCache: []
            },
            allowClick: !0,
            allowTouchMove: a.params.allowTouchMove,
            touches: {
                startX: 0,
                startY: 0,
                currentX: 0,
                currentY: 0,
                diff: 0
            },
            imagesToLoad: [],
            imagesLoaded: 0
        }), a.emit("_swiper"), a.params.init && a.init(), a
    }
    getSlideIndex(t) {
        const {
            slidesEl: n,
            params: i
        } = this, s = Ye(n, `.${i.slideClass}, swiper-slide`), r = oi(s[0]);
        return oi(t) - r
    }
    getSlideIndexByData(t) {
        return this.getSlideIndex(this.slides.filter(n => n.getAttribute("data-swiper-slide-index") * 1 === t)[0])
    }
    recalcSlides() {
        const t = this,
            {
                slidesEl: n,
                params: i
            } = t;
        t.slides = Ye(n, `.${i.slideClass}, swiper-slide`)
    }
    enable() {
        const t = this;
        t.enabled || (t.enabled = !0, t.params.grabCursor && t.setGrabCursor(), t.emit("enable"))
    }
    disable() {
        const t = this;
        t.enabled && (t.enabled = !1, t.params.grabCursor && t.unsetGrabCursor(), t.emit("disable"))
    }
    setProgress(t, n) {
        const i = this;
        t = Math.min(Math.max(t, 0), 1);
        const s = i.minTranslate(),
            l = (i.maxTranslate() - s) * t + s;
        i.translateTo(l, typeof n > "u" ? 0 : n), i.updateActiveIndex(), i.updateSlidesClasses()
    }
    emitContainerClasses() {
        const t = this;
        if (!t.params._emitClasses || !t.el) return;
        const n = t.el.className.split(" ").filter(i => i.indexOf("swiper") === 0 || i.indexOf(t.params.containerModifierClass) === 0);
        t.emit("_containerClasses", n.join(" "))
    }
    getSlideClasses(t) {
        const n = this;
        return n.destroyed ? "" : t.className.split(" ").filter(i => i.indexOf("swiper-slide") === 0 || i.indexOf(n.params.slideClass) === 0).join(" ")
    }
    emitSlidesClasses() {
        const t = this;
        if (!t.params._emitClasses || !t.el) return;
        const n = [];
        t.slides.forEach(i => {
            const s = t.getSlideClasses(i);
            n.push({
                slideEl: i,
                classNames: s
            }), t.emit("_slideClass", i, s)
        }), t.emit("_slideClasses", n)
    }
    slidesPerViewDynamic(t, n) {
        t === void 0 && (t = "current"), n === void 0 && (n = !1);
        const i = this,
            {
                params: s,
                slides: r,
                slidesGrid: l,
                slidesSizesGrid: a,
                size: o,
                activeIndex: d
            } = i;
        let f = 1;
        if (s.centeredSlides) {
            let u = r[d] ? r[d].swiperSlideSize : 0,
                m;
            for (let g = d + 1; g < r.length; g += 1) r[g] && !m && (u += r[g].swiperSlideSize, f += 1, u > o && (m = !0));
            for (let g = d - 1; g >= 0; g -= 1) r[g] && !m && (u += r[g].swiperSlideSize, f += 1, u > o && (m = !0))
        } else if (t === "current")
            for (let u = d + 1; u < r.length; u += 1)(n ? l[u] + a[u] - l[d] < o : l[u] - l[d] < o) && (f += 1);
        else
            for (let u = d - 1; u >= 0; u -= 1) l[d] - l[u] < o && (f += 1);
        return f
    }
    update() {
        const t = this;
        if (!t || t.destroyed) return;
        const {
            snapGrid: n,
            params: i
        } = t;
        i.breakpoints && t.setBreakpoint(), [...t.el.querySelectorAll('[loading="lazy"]')].forEach(l => {
            l.complete && Gn(t, l)
        }), t.updateSize(), t.updateSlides(), t.updateProgress(), t.updateSlidesClasses();

        function s() {
            const l = t.rtlTranslate ? t.translate * -1 : t.translate,
                a = Math.min(Math.max(l, t.maxTranslate()), t.minTranslate());
            t.setTranslate(a), t.updateActiveIndex(), t.updateSlidesClasses()
        }
        let r;
        if (i.freeMode && i.freeMode.enabled && !i.cssMode) s(), i.autoHeight && t.updateAutoHeight();
        else {
            if ((i.slidesPerView === "auto" || i.slidesPerView > 1) && t.isEnd && !i.centeredSlides) {
                const l = t.virtual && i.virtual.enabled ? t.virtual.slides : t.slides;
                r = t.slideTo(l.length - 1, 0, !1, !0)
            } else r = t.slideTo(t.activeIndex, 0, !1, !0);
            r || s()
        }
        i.watchOverflow && n !== t.snapGrid && t.checkOverflow(), t.emit("update")
    }
    changeDirection(t, n) {
        n === void 0 && (n = !0);
        const i = this,
            s = i.params.direction;
        return t || (t = s === "horizontal" ? "vertical" : "horizontal"), t === s || t !== "horizontal" && t !== "vertical" || (i.el.classList.remove(`${i.params.containerModifierClass}${s}`), i.el.classList.add(`${i.params.containerModifierClass}${t}`), i.emitContainerClasses(), i.params.direction = t, i.slides.forEach(r => {
            t === "vertical" ? r.style.width = "" : r.style.height = ""
        }), i.emit("changeDirection"), n && i.update()), i
    }
    changeLanguageDirection(t) {
        const n = this;
        n.rtl && t === "rtl" || !n.rtl && t === "ltr" || (n.rtl = t === "rtl", n.rtlTranslate = n.params.direction === "horizontal" && n.rtl, n.rtl ? (n.el.classList.add(`${n.params.containerModifierClass}rtl`), n.el.dir = "rtl") : (n.el.classList.remove(`${n.params.containerModifierClass}rtl`), n.el.dir = "ltr"), n.update())
    }
    mount(t) {
        const n = this;
        if (n.mounted) return !0;
        let i = t || n.params.el;
        if (typeof i == "string" && (i = document.querySelector(i)), !i) return !1;
        i.swiper = n, i.parentNode && i.parentNode.host && (n.isElement = !0);
        const s = () => `.${(n.params.wrapperClass||"").trim().split(" ").join(".")}`;
        let l = i && i.shadowRoot && i.shadowRoot.querySelector ? i.shadowRoot.querySelector(s()) : Ye(i, s())[0];
        return !l && n.params.createElements && (l = po("div", n.params.wrapperClass), i.append(l), Ye(i, `.${n.params.slideClass}`).forEach(a => {
            l.append(a)
        })), Object.assign(n, {
            el: i,
            wrapperEl: l,
            slidesEl: n.isElement ? i.parentNode.host : l,
            hostEl: n.isElement ? i.parentNode.host : i,
            mounted: !0,
            rtl: i.dir.toLowerCase() === "rtl" || dt(i, "direction") === "rtl",
            rtlTranslate: n.params.direction === "horizontal" && (i.dir.toLowerCase() === "rtl" || dt(i, "direction") === "rtl"),
            wrongRTL: dt(l, "display") === "-webkit-box"
        }), !0
    }
    init(t) {
        const n = this;
        return n.initialized || n.mount(t) === !1 || (n.emit("beforeInit"), n.params.breakpoints && n.setBreakpoint(), n.addClasses(), n.updateSize(), n.updateSlides(), n.params.watchOverflow && n.checkOverflow(), n.params.grabCursor && n.enabled && n.setGrabCursor(), n.params.loop && n.virtual && n.params.virtual.enabled ? n.slideTo(n.params.initialSlide + n.virtual.slidesBefore, 0, n.params.runCallbacksOnInit, !1, !0) : n.slideTo(n.params.initialSlide, 0, n.params.runCallbacksOnInit, !1, !0), n.params.loop && n.loopCreate(), n.attachEvents(), [...n.el.querySelectorAll('[loading="lazy"]')].forEach(s => {
            s.complete ? Gn(n, s) : s.addEventListener("load", r => {
                Gn(n, r.target)
            })
        }), cs(n), n.initialized = !0, cs(n), n.emit("init"), n.emit("afterInit")), n
    }
    destroy(t, n) {
        t === void 0 && (t = !0), n === void 0 && (n = !0);
        const i = this,
            {
                params: s,
                el: r,
                wrapperEl: l,
                slides: a
            } = i;
        return typeof i.params > "u" || i.destroyed || (i.emit("beforeDestroy"), i.initialized = !1, i.detachEvents(), s.loop && i.loopDestroy(), n && (i.removeClasses(), r.removeAttribute("style"), l.removeAttribute("style"), a && a.length && a.forEach(o => {
            o.classList.remove(s.slideVisibleClass, s.slideActiveClass, s.slideNextClass, s.slidePrevClass), o.removeAttribute("style"), o.removeAttribute("data-swiper-slide-index")
        })), i.emit("destroy"), Object.keys(i.eventsListeners).forEach(o => {
            i.off(o)
        }), t !== !1 && (i.el.swiper = null, pc(i)), i.destroyed = !0), null
    }
    static extendDefaults(t) {
        Ie(ki, t)
    }
    static get extendedDefaults() {
        return ki
    }
    static get defaults() {
        return Ir
    }
    static installModule(t) {
        Ze.prototype.__modules__ || (Ze.prototype.__modules__ = []);
        const n = Ze.prototype.__modules__;
        typeof t == "function" && n.indexOf(t) < 0 && n.push(t)
    }
    static use(t) {
        return Array.isArray(t) ? (t.forEach(n => Ze.installModule(n)), Ze) : (Ze.installModule(t), Ze)
    }
};
Object.keys(Hi).forEach(e => {
    Object.keys(Hi[e]).forEach(t => {
        wn.prototype[t] = Hi[e][t]
    })
});
wn.use([Ec, Cc]);
const yo = ["eventsPrefix", "injectStyles", "injectStylesUrls", "modules", "init", "_direction", "oneWayMovement", "touchEventsTarget", "initialSlide", "_speed", "cssMode", "updateOnWindowResize", "resizeObserver", "nested", "focusableElements", "_enabled", "_width", "_height", "preventInteractionOnTransition", "userAgent", "url", "_edgeSwipeDetection", "_edgeSwipeThreshold", "_freeMode", "_autoHeight", "setWrapperSize", "virtualTranslate", "_effect", "breakpoints", "_spaceBetween", "_slidesPerView", "maxBackfaceHiddenSlides", "_grid", "_slidesPerGroup", "_slidesPerGroupSkip", "_slidesPerGroupAuto", "_centeredSlides", "_centeredSlidesBounds", "_slidesOffsetBefore", "_slidesOffsetAfter", "normalizeSlideIndex", "_centerInsufficientSlides", "_watchOverflow", "roundLengths", "touchRatio", "touchAngle", "simulateTouch", "_shortSwipes", "_longSwipes", "longSwipesRatio", "longSwipesMs", "_followFinger", "allowTouchMove", "_threshold", "touchMoveStopPropagation", "touchStartPreventDefault", "touchStartForcePreventDefault", "touchReleaseOnEdges", "uniqueNavElements", "_resistance", "_resistanceRatio", "_watchSlidesProgress", "_grabCursor", "preventClicks", "preventClicksPropagation", "_slideToClickedSlide", "_loop", "loopedSlides", "loopPreventsSliding", "_rewind", "_allowSlidePrev", "_allowSlideNext", "_swipeHandler", "_noSwiping", "noSwipingClass", "noSwipingSelector", "passiveListeners", "containerModifierClass", "slideClass", "slideActiveClass", "slideVisibleClass", "slideNextClass", "slidePrevClass", "wrapperClass", "lazyPreloaderClass", "lazyPreloadPrevNext", "runCallbacksOnInit", "observer", "observeParents", "observeSlideChildren", "a11y", "_autoplay", "_controller", "coverflowEffect", "cubeEffect", "fadeEffect", "flipEffect", "creativeEffect", "cardsEffect", "hashNavigation", "history", "keyboard", "mousewheel", "_navigation", "_pagination", "parallax", "_scrollbar", "_thumbs", "virtual", "zoom", "control"];

function Ot(e) {
    return typeof e == "object" && e !== null && e.constructor && Object.prototype.toString.call(e).slice(8, -1) === "Object"
}

function pt(e, t) {
    const n = ["__proto__", "constructor", "prototype"];
    Object.keys(t).filter(i => n.indexOf(i) < 0).forEach(i => {
        typeof e[i] > "u" ? e[i] = t[i] : Ot(t[i]) && Ot(e[i]) && Object.keys(t[i]).length > 0 ? t[i].__swiper__ ? e[i] = t[i] : pt(e[i], t[i]) : e[i] = t[i]
    })
}

function bo(e) {
    return e === void 0 && (e = {}), e.navigation && typeof e.navigation.nextEl > "u" && typeof e.navigation.prevEl > "u"
}

function wo(e) {
    return e === void 0 && (e = {}), e.pagination && typeof e.pagination.el > "u"
}

function So(e) {
    return e === void 0 && (e = {}), e.scrollbar && typeof e.scrollbar.el > "u"
}

function To(e) {
    e === void 0 && (e = "");
    const t = e.split(" ").map(i => i.trim()).filter(i => !!i),
        n = [];
    return t.forEach(i => {
        n.indexOf(i) < 0 && n.push(i)
    }), n.join(" ")
}

function Iu(e) {
    return e === void 0 && (e = ""), e ? e.includes("swiper-wrapper") ? e : `swiper-wrapper ${e}` : "swiper-wrapper"
}

function Ou(e) {
    let {
        swiper: t,
        slides: n,
        passedParams: i,
        changedParams: s,
        nextEl: r,
        prevEl: l,
        scrollbarEl: a,
        paginationEl: o
    } = e;
    const d = s.filter(b => b !== "children" && b !== "direction" && b !== "wrapperClass"),
        {
            params: f,
            pagination: u,
            navigation: m,
            scrollbar: g,
            virtual: S,
            thumbs: v
        } = t;
    let E, x, h, c, p, w, C, P;
    s.includes("thumbs") && i.thumbs && i.thumbs.swiper && f.thumbs && !f.thumbs.swiper && (E = !0), s.includes("controller") && i.controller && i.controller.control && f.controller && !f.controller.control && (x = !0), s.includes("pagination") && i.pagination && (i.pagination.el || o) && (f.pagination || f.pagination === !1) && u && !u.el && (h = !0), s.includes("scrollbar") && i.scrollbar && (i.scrollbar.el || a) && (f.scrollbar || f.scrollbar === !1) && g && !g.el && (c = !0), s.includes("navigation") && i.navigation && (i.navigation.prevEl || l) && (i.navigation.nextEl || r) && (f.navigation || f.navigation === !1) && m && !m.prevEl && !m.nextEl && (p = !0);
    const O = b => {
        t[b] && (t[b].destroy(), b === "navigation" ? (t.isElement && (t[b].prevEl.remove(), t[b].nextEl.remove()), f[b].prevEl = void 0, f[b].nextEl = void 0, t[b].prevEl = void 0, t[b].nextEl = void 0) : (t.isElement && t[b].el.remove(), f[b].el = void 0, t[b].el = void 0))
    };
    s.includes("loop") && t.isElement && (f.loop && !i.loop ? w = !0 : !f.loop && i.loop ? C = !0 : P = !0), d.forEach(b => {
        if (Ot(f[b]) && Ot(i[b])) pt(f[b], i[b]), (b === "navigation" || b === "pagination" || b === "scrollbar") && "enabled" in i[b] && !i[b].enabled && O(b);
        else {
            const I = i[b];
            (I === !0 || I === !1) && (b === "navigation" || b === "pagination" || b === "scrollbar") ? I === !1 && O(b): f[b] = i[b]
        }
    }), d.includes("controller") && !x && t.controller && t.controller.control && f.controller && f.controller.control && (t.controller.control = f.controller.control), s.includes("children") && n && S && f.virtual.enabled && (S.slides = n, S.update(!0)), s.includes("children") && n && f.loop && (P = !0), E && v.init() && v.update(!0), x && (t.controller.control = f.controller.control), h && (t.isElement && (!o || typeof o == "string") && (o = document.createElement("div"), o.classList.add("swiper-pagination"), t.el.appendChild(o)), o && (f.pagination.el = o), u.init(), u.render(), u.update()), c && (t.isElement && (!a || typeof a == "string") && (a = document.createElement("div"), a.classList.add("swiper-scrollbar"), t.el.appendChild(a)), a && (f.scrollbar.el = a), g.init(), g.updateSize(), g.setTranslate()), p && (t.isElement && ((!r || typeof r == "string") && (r = document.createElement("div"), r.classList.add("swiper-button-next"), r.innerHTML = t.hostEl.nextButtonSvg, t.el.appendChild(r)), (!l || typeof l == "string") && (l = document.createElement("div"), l.classList.add("swiper-button-prev"), r.innerHTML = t.hostEl.prevButtonSvg, t.el.appendChild(l))), r && (f.navigation.nextEl = r), l && (f.navigation.prevEl = l), m.init(), m.update()), s.includes("allowSlideNext") && (t.allowSlideNext = i.allowSlideNext), s.includes("allowSlidePrev") && (t.allowSlidePrev = i.allowSlidePrev), s.includes("direction") && t.changeDirection(i.direction, !1), (w || P) && t.loopDestroy(), (C || P) && t.loopCreate(), t.update()
}

function Or(e, t) {
    e === void 0 && (e = {});
    const n = {
            on: {}
        },
        i = {},
        s = {};
    pt(n, wn.defaults), pt(n, wn.extendedDefaults), n._emitClasses = !0, n.init = !1;
    const r = {},
        l = yo.map(o => o.replace(/_/, "")),
        a = Object.assign({}, e);
    return Object.keys(a).forEach(o => {
        typeof e[o] > "u" || (l.indexOf(o) >= 0 ? Ot(e[o]) ? (n[o] = {}, s[o] = {}, pt(n[o], e[o]), pt(s[o], e[o])) : (n[o] = e[o], s[o] = e[o]) : o.search(/on[A-Z]/) === 0 && typeof e[o] == "function" ? n.on[`${o[2].toLowerCase()}${o.substr(3)}`] = e[o] : r[o] = e[o])
    }), ["navigation", "pagination", "scrollbar"].forEach(o => {
        n[o] === !0 && (n[o] = {}), n[o] === !1 && delete n[o]
    }), {
        params: n,
        passedParams: s,
        rest: r,
        events: i
    }
}

function Lu(e, t) {
    let {
        el: n,
        nextEl: i,
        prevEl: s,
        paginationEl: r,
        scrollbarEl: l,
        swiper: a
    } = e;
    bo(t) && i && s && (a.params.navigation.nextEl = i, a.originalParams.navigation.nextEl = i, a.params.navigation.prevEl = s, a.originalParams.navigation.prevEl = s), wo(t) && r && (a.params.pagination.el = r, a.originalParams.pagination.el = r), So(t) && l && (a.params.scrollbar.el = l, a.originalParams.scrollbar.el = l), a.init(n)
}

function Bu(e, t, n, i, s) {
    const r = [];
    if (!t) return r;
    const l = o => {
        r.indexOf(o) < 0 && r.push(o)
    };
    if (n && i) {
        const o = i.map(s),
            d = n.map(s);
        o.join("") !== d.join("") && l("children"), i.length !== n.length && l("children")
    }
    return yo.filter(o => o[0] === "_").map(o => o.replace(/_/, "")).forEach(o => {
        if (o in e && o in t)
            if (Ot(e[o]) && Ot(t[o])) {
                const d = Object.keys(e[o]),
                    f = Object.keys(t[o]);
                d.length !== f.length ? l(o) : (d.forEach(u => {
                    e[o][u] !== t[o][u] && l(o)
                }), f.forEach(u => {
                    e[o][u] !== t[o][u] && l(o)
                }))
            } else e[o] !== t[o] && l(o)
    }), r
}
const Du = e => {
    !e || e.destroyed || !e.params.virtual || e.params.virtual && !e.params.virtual.enabled || (e.updateSlides(), e.updateProgress(), e.updateSlidesClasses(), e.parallax && e.params.parallax && e.params.parallax.enabled && e.parallax.setTranslate())
};

function ji(e, t, n) {
    e === void 0 && (e = {});
    const i = [],
        s = {
            "container-start": [],
            "container-end": [],
            "wrapper-start": [],
            "wrapper-end": []
        },
        r = (l, a) => {
            Array.isArray(l) && l.forEach(o => {
                const d = typeof o.type == "symbol";
                a === "default" && (a = "container-end"), d && o.children ? r(o.children, a) : o.type && (o.type.name === "SwiperSlide" || o.type.name === "AsyncComponentWrapper") ? i.push(o) : s[a] && s[a].push(o)
            })
        };
    return Object.keys(e).forEach(l => {
        if (typeof e[l] != "function") return;
        const a = e[l]();
        r(a, l)
    }), n.value = t.value, t.value = i, {
        slides: i,
        slots: s
    }
}

function Fu(e, t, n) {
    if (!n) return null;
    const i = f => {
            let u = f;
            return f < 0 ? u = t.length + f : u >= t.length && (u = u - t.length), u
        },
        s = e.value.isHorizontal() ? {
            [e.value.rtlTranslate ? "right" : "left"]: `${n.offset}px`
        } : {
            top: `${n.offset}px`
        },
        {
            from: r,
            to: l
        } = n,
        a = e.value.params.loop ? -t.length : 0,
        o = e.value.params.loop ? t.length * 2 : t.length,
        d = [];
    for (let f = a; f < o; f += 1) f >= r && f <= l && d.push(t[i(f)]);
    return d.map(f => (f.props || (f.props = {}), f.props.style || (f.props.style = {}), f.props.swiperRef = e, f.props.style = s, Re(f.type, { ...f.props
    }, f.children)))
}
const Td = {
        name: "Swiper",
        props: {
            tag: {
                type: String,
                default: "div"
            },
            wrapperTag: {
                type: String,
                default: "div"
            },
            modules: {
                type: Array,
                default: void 0
            },
            init: {
                type: Boolean,
                default: void 0
            },
            direction: {
                type: String,
                default: void 0
            },
            oneWayMovement: {
                type: Boolean,
                default: void 0
            },
            touchEventsTarget: {
                type: String,
                default: void 0
            },
            initialSlide: {
                type: Number,
                default: void 0
            },
            speed: {
                type: Number,
                default: void 0
            },
            cssMode: {
                type: Boolean,
                default: void 0
            },
            updateOnWindowResize: {
                type: Boolean,
                default: void 0
            },
            resizeObserver: {
                type: Boolean,
                default: void 0
            },
            nested: {
                type: Boolean,
                default: void 0
            },
            focusableElements: {
                type: String,
                default: void 0
            },
            width: {
                type: Number,
                default: void 0
            },
            height: {
                type: Number,
                default: void 0
            },
            preventInteractionOnTransition: {
                type: Boolean,
                default: void 0
            },
            userAgent: {
                type: String,
                default: void 0
            },
            url: {
                type: String,
                default: void 0
            },
            edgeSwipeDetection: {
                type: [Boolean, String],
                default: void 0
            },
            edgeSwipeThreshold: {
                type: Number,
                default: void 0
            },
            autoHeight: {
                type: Boolean,
                default: void 0
            },
            setWrapperSize: {
                type: Boolean,
                default: void 0
            },
            virtualTranslate: {
                type: Boolean,
                default: void 0
            },
            effect: {
                type: String,
                default: void 0
            },
            breakpoints: {
                type: Object,
                default: void 0
            },
            spaceBetween: {
                type: [Number, String],
                default: void 0
            },
            slidesPerView: {
                type: [Number, String],
                default: void 0
            },
            maxBackfaceHiddenSlides: {
                type: Number,
                default: void 0
            },
            slidesPerGroup: {
                type: Number,
                default: void 0
            },
            slidesPerGroupSkip: {
                type: Number,
                default: void 0
            },
            slidesPerGroupAuto: {
                type: Boolean,
                default: void 0
            },
            centeredSlides: {
                type: Boolean,
                default: void 0
            },
            centeredSlidesBounds: {
                type: Boolean,
                default: void 0
            },
            slidesOffsetBefore: {
                type: Number,
                default: void 0
            },
            slidesOffsetAfter: {
                type: Number,
                default: void 0
            },
            normalizeSlideIndex: {
                type: Boolean,
                default: void 0
            },
            centerInsufficientSlides: {
                type: Boolean,
                default: void 0
            },
            watchOverflow: {
                type: Boolean,
                default: void 0
            },
            roundLengths: {
                type: Boolean,
                default: void 0
            },
            touchRatio: {
                type: Number,
                default: void 0
            },
            touchAngle: {
                type: Number,
                default: void 0
            },
            simulateTouch: {
                type: Boolean,
                default: void 0
            },
            shortSwipes: {
                type: Boolean,
                default: void 0
            },
            longSwipes: {
                type: Boolean,
                default: void 0
            },
            longSwipesRatio: {
                type: Number,
                default: void 0
            },
            longSwipesMs: {
                type: Number,
                default: void 0
            },
            followFinger: {
                type: Boolean,
                default: void 0
            },
            allowTouchMove: {
                type: Boolean,
                default: void 0
            },
            threshold: {
                type: Number,
                default: void 0
            },
            touchMoveStopPropagation: {
                type: Boolean,
                default: void 0
            },
            touchStartPreventDefault: {
                type: Boolean,
                default: void 0
            },
            touchStartForcePreventDefault: {
                type: Boolean,
                default: void 0
            },
            touchReleaseOnEdges: {
                type: Boolean,
                default: void 0
            },
            uniqueNavElements: {
                type: Boolean,
                default: void 0
            },
            resistance: {
                type: Boolean,
                default: void 0
            },
            resistanceRatio: {
                type: Number,
                default: void 0
            },
            watchSlidesProgress: {
                type: Boolean,
                default: void 0
            },
            grabCursor: {
                type: Boolean,
                default: void 0
            },
            preventClicks: {
                type: Boolean,
                default: void 0
            },
            preventClicksPropagation: {
                type: Boolean,
                default: void 0
            },
            slideToClickedSlide: {
                type: Boolean,
                default: void 0
            },
            loop: {
                type: Boolean,
                default: void 0
            },
            loopedSlides: {
                type: Number,
                default: void 0
            },
            loopPreventsSliding: {
                type: Boolean,
                default: void 0
            },
            rewind: {
                type: Boolean,
                default: void 0
            },
            allowSlidePrev: {
                type: Boolean,
                default: void 0
            },
            allowSlideNext: {
                type: Boolean,
                default: void 0
            },
            swipeHandler: {
                type: Boolean,
                default: void 0
            },
            noSwiping: {
                type: Boolean,
                default: void 0
            },
            noSwipingClass: {
                type: String,
                default: void 0
            },
            noSwipingSelector: {
                type: String,
                default: void 0
            },
            passiveListeners: {
                type: Boolean,
                default: void 0
            },
            containerModifierClass: {
                type: String,
                default: void 0
            },
            slideClass: {
                type: String,
                default: void 0
            },
            slideActiveClass: {
                type: String,
                default: void 0
            },
            slideVisibleClass: {
                type: String,
                default: void 0
            },
            slideNextClass: {
                type: String,
                default: void 0
            },
            slidePrevClass: {
                type: String,
                default: void 0
            },
            wrapperClass: {
                type: String,
                default: void 0
            },
            lazyPreloaderClass: {
                type: String,
                default: void 0
            },
            lazyPreloadPrevNext: {
                type: Number,
                default: void 0
            },
            runCallbacksOnInit: {
                type: Boolean,
                default: void 0
            },
            observer: {
                type: Boolean,
                default: void 0
            },
            observeParents: {
                type: Boolean,
                default: void 0
            },
            observeSlideChildren: {
                type: Boolean,
                default: void 0
            },
            a11y: {
                type: [Boolean, Object],
                default: void 0
            },
            autoplay: {
                type: [Boolean, Object],
                default: void 0
            },
            controller: {
                type: Object,
                default: void 0
            },
            coverflowEffect: {
                type: Object,
                default: void 0
            },
            cubeEffect: {
                type: Object,
                default: void 0
            },
            fadeEffect: {
                type: Object,
                default: void 0
            },
            flipEffect: {
                type: Object,
                default: void 0
            },
            creativeEffect: {
                type: Object,
                default: void 0
            },
            cardsEffect: {
                type: Object,
                default: void 0
            },
            hashNavigation: {
                type: [Boolean, Object],
                default: void 0
            },
            history: {
                type: [Boolean, Object],
                default: void 0
            },
            keyboard: {
                type: [Boolean, Object],
                default: void 0
            },
            mousewheel: {
                type: [Boolean, Object],
                default: void 0
            },
            navigation: {
                type: [Boolean, Object],
                default: void 0
            },
            pagination: {
                type: [Boolean, Object],
                default: void 0
            },
            parallax: {
                type: [Boolean, Object],
                default: void 0
            },
            scrollbar: {
                type: [Boolean, Object],
                default: void 0
            },
            thumbs: {
                type: Object,
                default: void 0
            },
            virtual: {
                type: [Boolean, Object],
                default: void 0
            },
            zoom: {
                type: [Boolean, Object],
                default: void 0
            },
            grid: {
                type: [Object],
                default: void 0
            },
            freeMode: {
                type: [Boolean, Object],
                default: void 0
            },
            enabled: {
                type: Boolean,
                default: void 0
            }
        },
        emits: ["_beforeBreakpoint", "_containerClasses", "_slideClass", "_slideClasses", "_swiper", "_freeModeNoMomentumRelease", "activeIndexChange", "afterInit", "autoplay", "autoplayStart", "autoplayStop", "autoplayPause", "autoplayResume", "autoplayTimeLeft", "beforeDestroy", "beforeInit", "beforeLoopFix", "beforeResize", "beforeSlideChangeStart", "beforeTransitionStart", "breakpoint", "changeDirection", "click", "disable", "doubleTap", "doubleClick", "destroy", "enable", "fromEdge", "hashChange", "hashSet", "init", "keyPress", "lock", "loopFix", "momentumBounce", "navigationHide", "navigationShow", "navigationPrev", "navigationNext", "observerUpdate", "orientationchange", "paginationHide", "paginationRender", "paginationShow", "paginationUpdate", "progress", "reachBeginning", "reachEnd", "realIndexChange", "resize", "scroll", "scrollbarDragEnd", "scrollbarDragMove", "scrollbarDragStart", "setTransition", "setTranslate", "slideChange", "slideChangeTransitionEnd", "slideChangeTransitionStart", "slideNextTransitionEnd", "slideNextTransitionStart", "slidePrevTransitionEnd", "slidePrevTransitionStart", "slideResetTransitionStart", "slideResetTransitionEnd", "sliderMove", "sliderFirstMove", "slidesLengthChange", "slidesGridLengthChange", "snapGridLengthChange", "snapIndexChange", "swiper", "tap", "toEdge", "touchEnd", "touchMove", "touchMoveOpposite", "touchStart", "transitionEnd", "transitionStart", "unlock", "update", "virtualUpdate", "zoomChange"],
        setup(e, t) {
            let {
                slots: n,
                emit: i
            } = t;
            const {
                tag: s,
                wrapperTag: r
            } = e, l = pe("swiper"), a = pe(null), o = pe(!1), d = pe(!1), f = pe(null), u = pe(null), m = pe(null), g = {
                value: []
            }, S = {
                value: []
            }, v = pe(null), E = pe(null), x = pe(null), h = pe(null), {
                params: c,
                passedParams: p
            } = Or(e);
            ji(n, g, S), m.value = p, S.value = g.value;
            const w = () => {
                ji(n, g, S), o.value = !0
            };
            c.onAny = function(O) {
                for (var b = arguments.length, I = new Array(b > 1 ? b - 1 : 0), M = 1; M < b; M++) I[M - 1] = arguments[M];
                i(O, ...I)
            }, Object.assign(c.on, {
                _beforeBreakpoint: w,
                _containerClasses(O, b) {
                    l.value = b
                }
            });
            const C = { ...c
            };
            if (delete C.wrapperClass, u.value = new wn(C), u.value.virtual && u.value.params.virtual.enabled) {
                u.value.virtual.slides = g.value;
                const O = {
                    cache: !1,
                    slides: g.value,
                    renderExternal: b => {
                        a.value = b
                    },
                    renderExternalUpdate: !1
                };
                pt(u.value.params.virtual, O), pt(u.value.originalParams.virtual, O)
            }
            En(() => {
                !d.value && u.value && (u.value.emitSlidesClasses(), d.value = !0);
                const {
                    passedParams: O
                } = Or(e), b = Bu(O, m.value, g.value, S.value, I => I.props && I.props.key);
                m.value = O, (b.length || o.value) && u.value && !u.value.destroyed && Ou({
                    swiper: u.value,
                    slides: g.value,
                    passedParams: O,
                    changedParams: b,
                    nextEl: v.value,
                    prevEl: E.value,
                    scrollbarEl: h.value,
                    paginationEl: x.value
                }), o.value = !1
            }), Ls("swiper", u), kt(a, () => {
                Es(() => {
                    Du(u.value)
                })
            }), Zt(() => {
                f.value && (Lu({
                    el: f.value,
                    nextEl: v.value,
                    prevEl: E.value,
                    paginationEl: x.value,
                    scrollbarEl: h.value,
                    swiper: u.value
                }, c), i("swiper", u.value))
            }), Cn(() => {
                u.value && !u.value.destroyed && u.value.destroy(!0, !1)
            });

            function P(O) {
                return c.virtual ? Fu(u, O, a.value) : (O.forEach((b, I) => {
                    b.props || (b.props = {}), b.props.swiperRef = u, b.props.swiperSlideIndex = I
                }), O)
            }
            return () => {
                const {
                    slides: O,
                    slots: b
                } = ji(n, g, S);
                return Re(s, {
                    ref: f,
                    class: To(l.value)
                }, [b["container-start"], Re(r, {
                    class: Iu(c.wrapperClass)
                }, [b["wrapper-start"], P(O), b["wrapper-end"]]), bo(e) && [Re("div", {
                    ref: E,
                    class: "swiper-button-prev"
                }), Re("div", {
                    ref: v,
                    class: "swiper-button-next"
                })], So(e) && Re("div", {
                    ref: h,
                    class: "swiper-scrollbar"
                }), wo(e) && Re("div", {
                    ref: x,
                    class: "swiper-pagination"
                }), b["container-end"]])
            }
        }
    },
    xd = {
        name: "SwiperSlide",
        props: {
            tag: {
                type: String,
                default: "div"
            },
            swiperRef: {
                type: Object,
                required: !1
            },
            swiperSlideIndex: {
                type: Number,
                default: void 0,
                required: !1
            },
            zoom: {
                type: Boolean,
                default: void 0,
                required: !1
            },
            lazy: {
                type: Boolean,
                default: !1,
                required: !1
            },
            virtualIndex: {
                type: [String, Number],
                default: void 0
            }
        },
        setup(e, t) {
            let {
                slots: n
            } = t, i = !1;
            const {
                swiperRef: s
            } = e, r = pe(null), l = pe("swiper-slide"), a = pe(!1);

            function o(u, m, g) {
                m === r.value && (l.value = g)
            }
            Zt(() => {
                !s || !s.value || (s.value.on("_slideClass", o), i = !0)
            }), Ps(() => {
                i || !s || !s.value || (s.value.on("_slideClass", o), i = !0)
            }), En(() => {
                !r.value || !s || !s.value || (typeof e.swiperSlideIndex < "u" && (r.value.swiperSlideIndex = e.swiperSlideIndex), s.value.destroyed && l.value !== "swiper-slide" && (l.value = "swiper-slide"))
            }), Cn(() => {
                !s || !s.value || s.value.off("_slideClass", o)
            });
            const d = Xl(() => ({
                isActive: l.value.indexOf("swiper-slide-active") >= 0,
                isVisible: l.value.indexOf("swiper-slide-visible") >= 0,
                isPrev: l.value.indexOf("swiper-slide-prev") >= 0,
                isNext: l.value.indexOf("swiper-slide-next") >= 0
            }));
            Ls("swiperSlide", d);
            const f = () => {
                a.value = !0
            };
            return () => Re(e.tag, {
                class: To(`${l.value}`),
                ref: r,
                "data-swiper-slide-index": typeof e.virtualIndex > "u" && s && s.value && s.value.params.loop ? e.swiperSlideIndex : e.virtualIndex,
                onLoadCapture: f
            }, e.zoom ? Re("div", {
                class: "swiper-zoom-container",
                "data-swiper-zoom": typeof e.zoom == "number" ? e.zoom : void 0
            }, [n.default && n.default(d.value), e.lazy && !a.value && Re("div", {
                class: "swiper-lazy-preloader"
            })]) : [n.default && n.default(d.value), e.lazy && !a.value && Re("div", {
                class: "swiper-lazy-preloader"
            })])
        }
    };

function xo(e, t, n, i) {
    return e.params.createElements && Object.keys(i).forEach(s => {
        if (!n[s] && n.auto === !0) {
            let r = Ye(e.el, `.${i[s]}`)[0];
            r || (r = po("div", i[s]), r.className = i[s], e.el.append(r)), n[s] = r, t[s] = r
        }
    }), n
}

function Ed(e) {
    let {
        swiper: t,
        extendParams: n,
        on: i,
        emit: s
    } = e;
    n({
        navigation: {
            nextEl: null,
            prevEl: null,
            hideOnClick: !1,
            disabledClass: "swiper-button-disabled",
            hiddenClass: "swiper-button-hidden",
            lockClass: "swiper-button-lock",
            navigationDisabledClass: "swiper-navigation-disabled"
        }
    }), t.navigation = {
        nextEl: null,
        prevEl: null
    };
    const r = v => (Array.isArray(v) || (v = [v].filter(E => !!E)), v);

    function l(v) {
        let E;
        return v && typeof v == "string" && t.isElement && (E = t.el.querySelector(v), E) ? E : (v && (typeof v == "string" && (E = [...document.querySelectorAll(v)]), t.params.uniqueNavElements && typeof v == "string" && E.length > 1 && t.el.querySelectorAll(v).length === 1 && (E = t.el.querySelector(v))), v && !E ? v : E)
    }

    function a(v, E) {
        const x = t.params.navigation;
        v = r(v), v.forEach(h => {
            h && (h.classList[E ? "add" : "remove"](...x.disabledClass.split(" ")), h.tagName === "BUTTON" && (h.disabled = E), t.params.watchOverflow && t.enabled && h.classList[t.isLocked ? "add" : "remove"](x.lockClass))
        })
    }

    function o() {
        const {
            nextEl: v,
            prevEl: E
        } = t.navigation;
        if (t.params.loop) {
            a(E, !1), a(v, !1);
            return
        }
        a(E, t.isBeginning && !t.params.rewind), a(v, t.isEnd && !t.params.rewind)
    }

    function d(v) {
        v.preventDefault(), !(t.isBeginning && !t.params.loop && !t.params.rewind) && (t.slidePrev(), s("navigationPrev"))
    }

    function f(v) {
        v.preventDefault(), !(t.isEnd && !t.params.loop && !t.params.rewind) && (t.slideNext(), s("navigationNext"))
    }

    function u() {
        const v = t.params.navigation;
        if (t.params.navigation = xo(t, t.originalParams.navigation, t.params.navigation, {
                nextEl: "swiper-button-next",
                prevEl: "swiper-button-prev"
            }), !(v.nextEl || v.prevEl)) return;
        let E = l(v.nextEl),
            x = l(v.prevEl);
        Object.assign(t.navigation, {
            nextEl: E,
            prevEl: x
        }), E = r(E), x = r(x);
        const h = (c, p) => {
            c && c.addEventListener("click", p === "next" ? f : d), !t.enabled && c && c.classList.add(...v.lockClass.split(" "))
        };
        E.forEach(c => h(c, "next")), x.forEach(c => h(c, "prev"))
    }

    function m() {
        let {
            nextEl: v,
            prevEl: E
        } = t.navigation;
        v = r(v), E = r(E);
        const x = (h, c) => {
            h.removeEventListener("click", c === "next" ? f : d), h.classList.remove(...t.params.navigation.disabledClass.split(" "))
        };
        v.forEach(h => x(h, "next")), E.forEach(h => x(h, "prev"))
    }
    i("init", () => {
        t.params.navigation.enabled === !1 ? S() : (u(), o())
    }), i("toEdge fromEdge lock unlock", () => {
        o()
    }), i("destroy", () => {
        m()
    }), i("enable disable", () => {
        let {
            nextEl: v,
            prevEl: E
        } = t.navigation;
        v = r(v), E = r(E), [...v, ...E].filter(x => !!x).forEach(x => x.classList[t.enabled ? "remove" : "add"](t.params.navigation.lockClass))
    }), i("click", (v, E) => {
        let {
            nextEl: x,
            prevEl: h
        } = t.navigation;
        x = r(x), h = r(h);
        const c = E.target;
        if (t.params.navigation.hideOnClick && !h.includes(c) && !x.includes(c)) {
            if (t.pagination && t.params.pagination && t.params.pagination.clickable && (t.pagination.el === c || t.pagination.el.contains(c))) return;
            let p;
            x.length ? p = x[0].classList.contains(t.params.navigation.hiddenClass) : h.length && (p = h[0].classList.contains(t.params.navigation.hiddenClass)), s(p === !0 ? "navigationShow" : "navigationHide"), [...x, ...h].filter(w => !!w).forEach(w => w.classList.toggle(t.params.navigation.hiddenClass))
        }
    });
    const g = () => {
            t.el.classList.remove(...t.params.navigation.navigationDisabledClass.split(" ")), u(), o()
        },
        S = () => {
            t.el.classList.add(...t.params.navigation.navigationDisabledClass.split(" ")), m()
        };
    Object.assign(t.navigation, {
        enable: g,
        disable: S,
        update: o,
        init: u,
        destroy: m
    })
}

function rn(e) {
    return e === void 0 && (e = ""), `.${e.trim().replace(/([\.:!+\/])/g,"\\$1").replace(/ /g,".")}`
}

function Cd(e) {
    let {
        swiper: t,
        extendParams: n,
        on: i,
        emit: s
    } = e;
    const r = "swiper-pagination";
    n({
        pagination: {
            el: null,
            bulletElement: "span",
            clickable: !1,
            hideOnClick: !1,
            renderBullet: null,
            renderProgressbar: null,
            renderFraction: null,
            renderCustom: null,
            progressbarOpposite: !1,
            type: "bullets",
            dynamicBullets: !1,
            dynamicMainBullets: 1,
            formatFractionCurrent: h => h,
            formatFractionTotal: h => h,
            bulletClass: `${r}-bullet`,
            bulletActiveClass: `${r}-bullet-active`,
            modifierClass: `${r}-`,
            currentClass: `${r}-current`,
            totalClass: `${r}-total`,
            hiddenClass: `${r}-hidden`,
            progressbarFillClass: `${r}-progressbar-fill`,
            progressbarOppositeClass: `${r}-progressbar-opposite`,
            clickableClass: `${r}-clickable`,
            lockClass: `${r}-lock`,
            horizontalClass: `${r}-horizontal`,
            verticalClass: `${r}-vertical`,
            paginationDisabledClass: `${r}-disabled`
        }
    }), t.pagination = {
        el: null,
        bullets: []
    };
    let l, a = 0;
    const o = h => (Array.isArray(h) || (h = [h].filter(c => !!c)), h);

    function d() {
        return !t.params.pagination.el || !t.pagination.el || Array.isArray(t.pagination.el) && t.pagination.el.length === 0
    }

    function f(h, c) {
        const {
            bulletActiveClass: p
        } = t.params.pagination;
        h && (h = h[`${c==="prev"?"previous":"next"}ElementSibling`], h && (h.classList.add(`${p}-${c}`), h = h[`${c==="prev"?"previous":"next"}ElementSibling`], h && h.classList.add(`${p}-${c}-${c}`)))
    }

    function u(h) {
        const c = h.target.closest(rn(t.params.pagination.bulletClass));
        if (!c) return;
        h.preventDefault();
        const p = oi(c) * t.params.slidesPerGroup;
        if (t.params.loop) {
            if (t.realIndex === p) return;
            const w = t.getSlideIndexByData(p),
                C = t.getSlideIndexByData(t.realIndex);
            w > t.slides.length - t.loopedSlides && t.loopFix({
                direction: w > C ? "next" : "prev",
                activeSlideIndex: w,
                slideTo: !1
            }), t.slideToLoop(p)
        } else t.slideTo(p)
    }

    function m() {
        const h = t.rtl,
            c = t.params.pagination;
        if (d()) return;
        let p = t.pagination.el;
        p = o(p);
        let w, C;
        const P = t.virtual && t.params.virtual.enabled ? t.virtual.slides.length : t.slides.length,
            O = t.params.loop ? Math.ceil(P / t.params.slidesPerGroup) : t.snapGrid.length;
        if (t.params.loop ? (C = t.previousRealIndex || 0, w = t.params.slidesPerGroup > 1 ? Math.floor(t.realIndex / t.params.slidesPerGroup) : t.realIndex) : typeof t.snapIndex < "u" ? (w = t.snapIndex, C = t.previousSnapIndex) : (C = t.previousIndex || 0, w = t.activeIndex || 0), c.type === "bullets" && t.pagination.bullets && t.pagination.bullets.length > 0) {
            const b = t.pagination.bullets;
            let I, M, _;
            if (c.dynamicBullets && (l = fs(b[0], t.isHorizontal() ? "width" : "height"), p.forEach(L => {
                    L.style[t.isHorizontal() ? "width" : "height"] = `${l*(c.dynamicMainBullets+4)}px`
                }), c.dynamicMainBullets > 1 && C !== void 0 && (a += w - (C || 0), a > c.dynamicMainBullets - 1 ? a = c.dynamicMainBullets - 1 : a < 0 && (a = 0)), I = Math.max(w - a, 0), M = I + (Math.min(b.length, c.dynamicMainBullets) - 1), _ = (M + I) / 2), b.forEach(L => {
                    const G = [...["", "-next", "-next-next", "-prev", "-prev-prev", "-main"].map(Y => `${c.bulletActiveClass}${Y}`)].map(Y => typeof Y == "string" && Y.includes(" ") ? Y.split(" ") : Y).flat();
                    L.classList.remove(...G)
                }), p.length > 1) b.forEach(L => {
                const G = oi(L);
                G === w ? L.classList.add(...c.bulletActiveClass.split(" ")) : t.isElement && L.setAttribute("part", "bullet"), c.dynamicBullets && (G >= I && G <= M && L.classList.add(...`${c.bulletActiveClass}-main`.split(" ")), G === I && f(L, "prev"), G === M && f(L, "next"))
            });
            else {
                const L = b[w];
                if (L && L.classList.add(...c.bulletActiveClass.split(" ")), t.isElement && b.forEach((G, Y) => {
                        G.setAttribute("part", Y === w ? "bullet-active" : "bullet")
                    }), c.dynamicBullets) {
                    const G = b[I],
                        Y = b[M];
                    for (let V = I; V <= M; V += 1) b[V] && b[V].classList.add(...`${c.bulletActiveClass}-main`.split(" "));
                    f(G, "prev"), f(Y, "next")
                }
            }
            if (c.dynamicBullets) {
                const L = Math.min(b.length, c.dynamicMainBullets + 4),
                    G = (l * L - l) / 2 - _ * l,
                    Y = h ? "right" : "left";
                b.forEach(V => {
                    V.style[t.isHorizontal() ? Y : "top"] = `${G}px`
                })
            }
        }
        p.forEach((b, I) => {
            if (c.type === "fraction" && (b.querySelectorAll(rn(c.currentClass)).forEach(M => {
                    M.textContent = c.formatFractionCurrent(w + 1)
                }), b.querySelectorAll(rn(c.totalClass)).forEach(M => {
                    M.textContent = c.formatFractionTotal(O)
                })), c.type === "progressbar") {
                let M;
                c.progressbarOpposite ? M = t.isHorizontal() ? "vertical" : "horizontal" : M = t.isHorizontal() ? "horizontal" : "vertical";
                const _ = (w + 1) / O;
                let L = 1,
                    G = 1;
                M === "horizontal" ? L = _ : G = _, b.querySelectorAll(rn(c.progressbarFillClass)).forEach(Y => {
                    Y.style.transform = `translate3d(0,0,0) scaleX(${L}) scaleY(${G})`, Y.style.transitionDuration = `${t.params.speed}ms`
                })
            }
            c.type === "custom" && c.renderCustom ? (b.innerHTML = c.renderCustom(t, w + 1, O), I === 0 && s("paginationRender", b)) : (I === 0 && s("paginationRender", b), s("paginationUpdate", b)), t.params.watchOverflow && t.enabled && b.classList[t.isLocked ? "add" : "remove"](c.lockClass)
        })
    }

    function g() {
        const h = t.params.pagination;
        if (d()) return;
        const c = t.virtual && t.params.virtual.enabled ? t.virtual.slides.length : t.slides.length;
        let p = t.pagination.el;
        p = o(p);
        let w = "";
        if (h.type === "bullets") {
            let C = t.params.loop ? Math.ceil(c / t.params.slidesPerGroup) : t.snapGrid.length;
            t.params.freeMode && t.params.freeMode.enabled && C > c && (C = c);
            for (let P = 0; P < C; P += 1) h.renderBullet ? w += h.renderBullet.call(t, P, h.bulletClass) : w += `<${h.bulletElement} ${t.isElement?'part="bullet"':""} class="${h.bulletClass}"></${h.bulletElement}>`
        }
        h.type === "fraction" && (h.renderFraction ? w = h.renderFraction.call(t, h.currentClass, h.totalClass) : w = `<span class="${h.currentClass}"></span> / <span class="${h.totalClass}"></span>`), h.type === "progressbar" && (h.renderProgressbar ? w = h.renderProgressbar.call(t, h.progressbarFillClass) : w = `<span class="${h.progressbarFillClass}"></span>`), t.pagination.bullets = [], p.forEach(C => {
            h.type !== "custom" && (C.innerHTML = w || ""), h.type === "bullets" && t.pagination.bullets.push(...C.querySelectorAll(rn(h.bulletClass)))
        }), h.type !== "custom" && s("paginationRender", p[0])
    }

    function S() {
        t.params.pagination = xo(t, t.originalParams.pagination, t.params.pagination, {
            el: "swiper-pagination"
        });
        const h = t.params.pagination;
        if (!h.el) return;
        let c;
        typeof h.el == "string" && t.isElement && (c = t.el.querySelector(h.el)), !c && typeof h.el == "string" && (c = [...document.querySelectorAll(h.el)]), c || (c = h.el), !(!c || c.length === 0) && (t.params.uniqueNavElements && typeof h.el == "string" && Array.isArray(c) && c.length > 1 && (c = [...t.el.querySelectorAll(h.el)], c.length > 1 && (c = c.filter(p => ho(p, ".swiper")[0] === t.el)[0])), Array.isArray(c) && c.length === 1 && (c = c[0]), Object.assign(t.pagination, {
            el: c
        }), c = o(c), c.forEach(p => {
            h.type === "bullets" && h.clickable && p.classList.add(h.clickableClass), p.classList.add(h.modifierClass + h.type), p.classList.add(t.isHorizontal() ? h.horizontalClass : h.verticalClass), h.type === "bullets" && h.dynamicBullets && (p.classList.add(`${h.modifierClass}${h.type}-dynamic`), a = 0, h.dynamicMainBullets < 1 && (h.dynamicMainBullets = 1)), h.type === "progressbar" && h.progressbarOpposite && p.classList.add(h.progressbarOppositeClass), h.clickable && p.addEventListener("click", u), t.enabled || p.classList.add(h.lockClass)
        }))
    }

    function v() {
        const h = t.params.pagination;
        if (d()) return;
        let c = t.pagination.el;
        c && (c = o(c), c.forEach(p => {
            p.classList.remove(h.hiddenClass), p.classList.remove(h.modifierClass + h.type), p.classList.remove(t.isHorizontal() ? h.horizontalClass : h.verticalClass), h.clickable && p.removeEventListener("click", u)
        })), t.pagination.bullets && t.pagination.bullets.forEach(p => p.classList.remove(...h.bulletActiveClass.split(" ")))
    }
    i("changeDirection", () => {
        if (!t.pagination || !t.pagination.el) return;
        const h = t.params.pagination;
        let {
            el: c
        } = t.pagination;
        c = o(c), c.forEach(p => {
            p.classList.remove(h.horizontalClass, h.verticalClass), p.classList.add(t.isHorizontal() ? h.horizontalClass : h.verticalClass)
        })
    }), i("init", () => {
        t.params.pagination.enabled === !1 ? x() : (S(), g(), m())
    }), i("activeIndexChange", () => {
        typeof t.snapIndex > "u" && m()
    }), i("snapIndexChange", () => {
        m()
    }), i("snapGridLengthChange", () => {
        g(), m()
    }), i("destroy", () => {
        v()
    }), i("enable disable", () => {
        let {
            el: h
        } = t.pagination;
        h && (h = o(h), h.forEach(c => c.classList[t.enabled ? "remove" : "add"](t.params.pagination.lockClass)))
    }), i("lock unlock", () => {
        m()
    }), i("click", (h, c) => {
        const p = c.target,
            w = o(t.pagination.el);
        if (t.params.pagination.el && t.params.pagination.hideOnClick && w && w.length > 0 && !p.classList.contains(t.params.pagination.bulletClass)) {
            if (t.navigation && (t.navigation.nextEl && p === t.navigation.nextEl || t.navigation.prevEl && p === t.navigation.prevEl)) return;
            const C = w[0].classList.contains(t.params.pagination.hiddenClass);
            s(C === !0 ? "paginationShow" : "paginationHide"), w.forEach(P => P.classList.toggle(t.params.pagination.hiddenClass))
        }
    });
    const E = () => {
            t.el.classList.remove(t.params.pagination.paginationDisabledClass);
            let {
                el: h
            } = t.pagination;
            h && (h = o(h), h.forEach(c => c.classList.remove(t.params.pagination.paginationDisabledClass))), S(), g(), m()
        },
        x = () => {
            t.el.classList.add(t.params.pagination.paginationDisabledClass);
            let {
                el: h
            } = t.pagination;
            h && (h = o(h), h.forEach(c => c.classList.add(t.params.pagination.paginationDisabledClass))), v()
        };
    Object.assign(t.pagination, {
        enable: E,
        disable: x,
        render: g,
        update: m,
        init: S,
        destroy: v
    })
}

function _d(e) {
    let {
        swiper: t,
        extendParams: n,
        on: i,
        emit: s,
        params: r
    } = e;
    t.autoplay = {
        running: !1,
        paused: !1,
        timeLeft: 0
    }, n({
        autoplay: {
            enabled: !1,
            delay: 3e3,
            waitForTransition: !0,
            disableOnInteraction: !0,
            stopOnLastSlide: !1,
            reverseDirection: !1,
            pauseOnMouseEnter: !1
        }
    });
    let l, a, o = r && r.autoplay ? r.autoplay.delay : 3e3,
        d = r && r.autoplay ? r.autoplay.delay : 3e3,
        f, u = new Date().getTime,
        m, g, S, v, E, x;

    function h(k) {
        !t || t.destroyed || !t.wrapperEl || k.target === t.wrapperEl && (t.wrapperEl.removeEventListener("transitionend", h), b())
    }
    const c = () => {
            if (t.destroyed || !t.autoplay.running) return;
            t.autoplay.paused ? m = !0 : m && (d = f, m = !1);
            const k = t.autoplay.paused ? f : u + d - new Date().getTime();
            t.autoplay.timeLeft = k, s("autoplayTimeLeft", k, k / o), a = requestAnimationFrame(() => {
                c()
            })
        },
        p = () => {
            let k;
            return t.virtual && t.params.virtual.enabled ? k = t.slides.filter(Z => Z.classList.contains("swiper-slide-active"))[0] : k = t.slides[t.activeIndex], k ? parseInt(k.getAttribute("data-swiper-autoplay"), 10) : void 0
        },
        w = k => {
            if (t.destroyed || !t.autoplay.running) return;
            cancelAnimationFrame(a), c();
            let j = typeof k > "u" ? t.params.autoplay.delay : k;
            o = t.params.autoplay.delay, d = t.params.autoplay.delay;
            const Z = p();
            !Number.isNaN(Z) && Z > 0 && typeof k > "u" && (j = Z, o = Z, d = Z), f = j;
            const Ce = t.params.speed,
                _e = () => {
                    !t || t.destroyed || (t.params.autoplay.reverseDirection ? !t.isBeginning || t.params.loop || t.params.rewind ? (t.slidePrev(Ce, !0, !0), s("autoplay")) : t.params.autoplay.stopOnLastSlide || (t.slideTo(t.slides.length - 1, Ce, !0, !0), s("autoplay")) : !t.isEnd || t.params.loop || t.params.rewind ? (t.slideNext(Ce, !0, !0), s("autoplay")) : t.params.autoplay.stopOnLastSlide || (t.slideTo(0, Ce, !0, !0), s("autoplay")), t.params.cssMode && (u = new Date().getTime(), requestAnimationFrame(() => {
                        w()
                    })))
                };
            return j > 0 ? (clearTimeout(l), l = setTimeout(() => {
                _e()
            }, j)) : requestAnimationFrame(() => {
                _e()
            }), j
        },
        C = () => {
            t.autoplay.running = !0, w(), s("autoplayStart")
        },
        P = () => {
            t.autoplay.running = !1, clearTimeout(l), cancelAnimationFrame(a), s("autoplayStop")
        },
        O = (k, j) => {
            if (t.destroyed || !t.autoplay.running) return;
            clearTimeout(l), k || (x = !0);
            const Z = () => {
                s("autoplayPause"), t.params.autoplay.waitForTransition ? t.wrapperEl.addEventListener("transitionend", h) : b()
            };
            if (t.autoplay.paused = !0, j) {
                E && (f = t.params.autoplay.delay), E = !1, Z();
                return
            }
            f = (f || t.params.autoplay.delay) - (new Date().getTime() - u), !(t.isEnd && f < 0 && !t.params.loop) && (f < 0 && (f = 0), Z())
        },
        b = () => {
            t.isEnd && f < 0 && !t.params.loop || t.destroyed || !t.autoplay.running || (u = new Date().getTime(), x ? (x = !1, w(f)) : w(), t.autoplay.paused = !1, s("autoplayResume"))
        },
        I = () => {
            if (t.destroyed || !t.autoplay.running) return;
            const k = Xe();
            k.visibilityState === "hidden" && (x = !0, O(!0)), k.visibilityState === "visible" && b()
        },
        M = k => {
            k.pointerType === "mouse" && (x = !0, O(!0))
        },
        _ = k => {
            k.pointerType === "mouse" && t.autoplay.paused && b()
        },
        L = () => {
            t.params.autoplay.pauseOnMouseEnter && (t.el.addEventListener("pointerenter", M), t.el.addEventListener("pointerleave", _))
        },
        G = () => {
            t.el.removeEventListener("pointerenter", M), t.el.removeEventListener("pointerleave", _)
        },
        Y = () => {
            Xe().addEventListener("visibilitychange", I)
        },
        V = () => {
            Xe().removeEventListener("visibilitychange", I)
        };
    i("init", () => {
        t.params.autoplay.enabled && (L(), Y(), u = new Date().getTime(), C())
    }), i("destroy", () => {
        G(), V(), t.autoplay.running && P()
    }), i("beforeTransitionStart", (k, j, Z) => {
        t.destroyed || !t.autoplay.running || (Z || !t.params.autoplay.disableOnInteraction ? O(!0, !0) : P())
    }), i("sliderFirstMove", () => {
        if (!(t.destroyed || !t.autoplay.running)) {
            if (t.params.autoplay.disableOnInteraction) {
                P();
                return
            }
            g = !0, S = !1, x = !1, v = setTimeout(() => {
                x = !0, S = !0, O(!0)
            }, 200)
        }
    }), i("touchEnd", () => {
        if (!(t.destroyed || !t.autoplay.running || !g)) {
            if (clearTimeout(v), clearTimeout(l), t.params.autoplay.disableOnInteraction) {
                S = !1, g = !1;
                return
            }
            S && t.params.cssMode && b(), S = !1, g = !1
        }
    }), i("slideChange", () => {
        t.destroyed || !t.autoplay.running || (E = !0)
    }), Object.assign(t.autoplay, {
        start: C,
        stop: P,
        pause: O,
        resume: b
    })
}

function Md(e) {
    let {
        swiper: t,
        extendParams: n,
        emit: i,
        once: s
    } = e;
    n({
        freeMode: {
            enabled: !1,
            momentum: !0,
            momentumRatio: 1,
            momentumBounce: !0,
            momentumBounceRatio: 1,
            momentumVelocityRatio: 1,
            sticky: !1,
            minimumVelocity: .02
        }
    });

    function r() {
        if (t.params.cssMode) return;
        const o = t.getTranslate();
        t.setTranslate(o), t.setTransition(0), t.touchEventsData.velocities.length = 0, t.freeMode.onTouchEnd({
            currentPos: t.rtl ? t.translate : -t.translate
        })
    }

    function l() {
        if (t.params.cssMode) return;
        const {
            touchEventsData: o,
            touches: d
        } = t;
        o.velocities.length === 0 && o.velocities.push({
            position: d[t.isHorizontal() ? "startX" : "startY"],
            time: o.touchStartTime
        }), o.velocities.push({
            position: d[t.isHorizontal() ? "currentX" : "currentY"],
            time: _t()
        })
    }

    function a(o) {
        let {
            currentPos: d
        } = o;
        if (t.params.cssMode) return;
        const {
            params: f,
            wrapperEl: u,
            rtlTranslate: m,
            snapGrid: g,
            touchEventsData: S
        } = t, E = _t() - S.touchStartTime;
        if (d < -t.minTranslate()) {
            t.slideTo(t.activeIndex);
            return
        }
        if (d > -t.maxTranslate()) {
            t.slides.length < g.length ? t.slideTo(g.length - 1) : t.slideTo(t.slides.length - 1);
            return
        }
        if (f.freeMode.momentum) {
            if (S.velocities.length > 1) {
                const O = S.velocities.pop(),
                    b = S.velocities.pop(),
                    I = O.position - b.position,
                    M = O.time - b.time;
                t.velocity = I / M, t.velocity /= 2, Math.abs(t.velocity) < f.freeMode.minimumVelocity && (t.velocity = 0), (M > 150 || _t() - O.time > 300) && (t.velocity = 0)
            } else t.velocity = 0;
            t.velocity *= f.freeMode.momentumVelocityRatio, S.velocities.length = 0;
            let x = 1e3 * f.freeMode.momentumRatio;
            const h = t.velocity * x;
            let c = t.translate + h;
            m && (c = -c);
            let p = !1,
                w;
            const C = Math.abs(t.velocity) * 20 * f.freeMode.momentumBounceRatio;
            let P;
            if (c < t.maxTranslate()) f.freeMode.momentumBounce ? (c + t.maxTranslate() < -C && (c = t.maxTranslate() - C), w = t.maxTranslate(), p = !0, S.allowMomentumBounce = !0) : c = t.maxTranslate(), f.loop && f.centeredSlides && (P = !0);
            else if (c > t.minTranslate()) f.freeMode.momentumBounce ? (c - t.minTranslate() > C && (c = t.minTranslate() + C), w = t.minTranslate(), p = !0, S.allowMomentumBounce = !0) : c = t.minTranslate(), f.loop && f.centeredSlides && (P = !0);
            else if (f.freeMode.sticky) {
                let O;
                for (let b = 0; b < g.length; b += 1)
                    if (g[b] > -c) {
                        O = b;
                        break
                    }
                Math.abs(g[O] - c) < Math.abs(g[O - 1] - c) || t.swipeDirection === "next" ? c = g[O] : c = g[O - 1], c = -c
            }
            if (P && s("transitionEnd", () => {
                    t.loopFix()
                }), t.velocity !== 0) {
                if (m ? x = Math.abs((-c - t.translate) / t.velocity) : x = Math.abs((c - t.translate) / t.velocity), f.freeMode.sticky) {
                    const O = Math.abs((m ? -c : c) - t.translate),
                        b = t.slidesSizesGrid[t.activeIndex];
                    O < b ? x = f.speed : O < 2 * b ? x = f.speed * 1.5 : x = f.speed * 2.5
                }
            } else if (f.freeMode.sticky) {
                t.slideToClosest();
                return
            }
            f.freeMode.momentumBounce && p ? (t.updateProgress(w), t.setTransition(x), t.setTranslate(c), t.transitionStart(!0, t.swipeDirection), t.animating = !0, Ri(u, () => {
                !t || t.destroyed || !S.allowMomentumBounce || (i("momentumBounce"), t.setTransition(f.speed), setTimeout(() => {
                    t.setTranslate(w), Ri(u, () => {
                        !t || t.destroyed || t.transitionEnd()
                    })
                }, 0))
            })) : t.velocity ? (i("_freeModeNoMomentumRelease"), t.updateProgress(c), t.setTransition(x), t.setTranslate(c), t.transitionStart(!0, t.swipeDirection), t.animating || (t.animating = !0, Ri(u, () => {
                !t || t.destroyed || t.transitionEnd()
            }))) : t.updateProgress(c), t.updateActiveIndex(), t.updateSlidesClasses()
        } else if (f.freeMode.sticky) {
            t.slideToClosest();
            return
        } else f.freeMode && i("_freeModeNoMomentumRelease");
        (!f.freeMode.momentum || E >= f.longSwipesMs) && (t.updateProgress(), t.updateActiveIndex(), t.updateSlidesClasses())
    }
    Object.assign(t, {
        freeMode: {
            onTouchStart: r,
            onTouchMove: l,
            onTouchEnd: a
        }
    })
}

function Pd(e) {
    let {
        swiper: t,
        extendParams: n
    } = e;
    n({
        grid: {
            rows: 1,
            fill: "column"
        }
    });
    let i, s, r;
    const l = () => {
            let f = t.params.spaceBetween;
            return typeof f == "string" && f.indexOf("%") >= 0 ? f = parseFloat(f.replace("%", "")) / 100 * t.size : typeof f == "string" && (f = parseFloat(f)), f
        },
        a = f => {
            const {
                slidesPerView: u
            } = t.params, {
                rows: m,
                fill: g
            } = t.params.grid;
            r = Math.floor(f / m), Math.floor(f / m) === f / m ? i = f : i = Math.ceil(f / m) * m, u !== "auto" && g === "row" && (i = Math.max(i, u * m)), s = i / m
        },
        o = (f, u, m, g) => {
            const {
                slidesPerGroup: S
            } = t.params, v = l(), {
                rows: E,
                fill: x
            } = t.params.grid;
            let h, c, p;
            if (x === "row" && S > 1) {
                const w = Math.floor(f / (S * E)),
                    C = f - E * S * w,
                    P = w === 0 ? S : Math.min(Math.ceil((m - w * E * S) / E), S);
                p = Math.floor(C / P), c = C - p * P + w * S, h = c + p * i / E, u.style.order = h
            } else x === "column" ? (c = Math.floor(f / E), p = f - c * E, (c > r || c === r && p === E - 1) && (p += 1, p >= E && (p = 0, c += 1))) : (p = Math.floor(f / s), c = f - p * s);
            u.row = p, u.column = c, u.style[g("margin-top")] = p !== 0 ? v && `${v}px` : ""
        },
        d = (f, u, m) => {
            const {
                centeredSlides: g,
                roundLengths: S
            } = t.params, v = l(), {
                rows: E
            } = t.params.grid;
            if (t.virtualSize = (f + v) * i, t.virtualSize = Math.ceil(t.virtualSize / E) - v, t.wrapperEl.style[m("width")] = `${t.virtualSize+v}px`, g) {
                const x = [];
                for (let h = 0; h < u.length; h += 1) {
                    let c = u[h];
                    S && (c = Math.floor(c)), u[h] < t.virtualSize + u[0] && x.push(c)
                }
                u.splice(0, u.length), u.push(...x)
            }
        };
    t.grid = {
        initSlides: a,
        updateSlide: o,
        updateWrapperSize: d
    }
}
export {
    Qu as $, Re as A, Zt as B, As as C, oe as D, fi as E, ge as F, At as G, ce as H, Ls as I, Tf as J, Ku as K, pd as L, da as M, qu as N, el as O, Pt as P, Uu as Q, En as R, fd as S, Ct as T, es as U, ni as V, Sa as W, Yu as X, ku as Y, nd as Z, cd as _, lt as a, Wl as a0, zo as a1, Ul as a2, za as a3, Sd as a4, wd as a5, ud as a6, di as a7, dd as a8, Ju as a9, sd as aA, ju as aB, Ps as aC, Cd as aD, Pd as aE, Md as aF, gd as aG, zn as aH, yd as aa, Wu as ab, id as ac, ad, hd as ae, Ru as af, Sf as ag, td as ah, Zu as ai, Td as aj, Ed as ak, _d as al, xd as am, ui as an, zu as ao, rd as ap, Gu as aq, Xu as ar, bd as as, Tr as at, vd as au, Fa as av, it as aw, ed as ax, md as ay, Le as az, pe as b, Q as c, Xl as d, Nu as e, he as f, Vo as g, ld as h, Hn as i, xt as j, Vu as k, od as l, oa as m, Es as n, $u as o, Cn as p, Ba as q, Ss as r, la as s, Hu as t, nl as u, If as v, kt as w, La as x, aa as y, Ca as z
};