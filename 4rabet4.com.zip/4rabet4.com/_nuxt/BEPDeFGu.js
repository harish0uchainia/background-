import {
    b4 as O
} from "./BbvgifQp.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "5487d2b1-7a04-44ca-961e-4000e8fe0778", e._sentryDebugIdIdentifier = "sentry-dbid-5487d2b1-7a04-44ca-961e-4000e8fe0778")
    } catch {}
})();

function l(e) {
    if (typeof e.getRootNode != "function") {
        for (; e.parentNode;) e = e.parentNode;
        return e !== document ? null : document
    }
    const t = e.getRootNode();
    return t !== document && t.getRootNode({
        composed: !0
    }) !== document ? null : t
}

function k(e, t) {
    if (!O) return;
    const o = t.modifiers || {},
        n = t.value,
        {
            handler: s,
            options: u
        } = typeof n == "object" ? n : {
            handler: n,
            options: {}
        },
        i = new IntersectionObserver(function() {
            var a;
            let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [],
                h = arguments.length > 1 ? arguments[1] : void 0;
            const r = (a = e._observe) == null ? void 0 : a[t.instance.$.uid];
            if (!r) return;
            const c = d.some(w => w.isIntersecting);
            s && (!o.quiet || r.init) && (!o.once || c || r.init) && s(c, d, h), c && o.once ? v(e, t) : r.init = !0
        }, u);
    e._observe = Object(e._observe), e._observe[t.instance.$.uid] = {
        init: !1,
        observer: i
    }, i.observe(e)
}

function v(e, t) {
    var n;
    const o = (n = e._observe) == null ? void 0 : n[t.instance.$.uid];
    o && (o.observer.unobserve(e), delete e._observe[t.instance.$.uid])
}
const p = {
    mounted: k,
    unmounted: v
};

function y() {
    return !0
}

function m(e, t, o) {
    if (!e || _(e, o) === !1) return !1;
    const n = l(t);
    if (typeof ShadowRoot < "u" && n instanceof ShadowRoot && n.host === e.target) return !1;
    const s = (typeof o.value == "object" && o.value.include || (() => []))();
    return s.push(t), !s.some(u => u == null ? void 0 : u.contains(e.target))
}

function _(e, t) {
    return (typeof t.value == "object" && t.value.closeConditional || y)(e)
}

function I(e, t, o) {
    const n = typeof o.value == "function" ? o.value : o.value.handler;
    e.shadowTarget = e.target, t._clickOutside.lastMousedownWasOutside && m(e, t, o) && setTimeout(() => {
        _(e, o) && n && n(e)
    }, 0)
}

function f(e, t) {
    const o = l(e);
    t(document), typeof ShadowRoot < "u" && o instanceof ShadowRoot && t(o)
}
const R = {
    mounted(e, t) {
        const o = s => I(s, e, t),
            n = s => {
                e._clickOutside.lastMousedownWasOutside = m(s, e, t)
            };
        f(e, s => {
            s.addEventListener("click", o, !0), s.addEventListener("mousedown", n, !0)
        }), e._clickOutside || (e._clickOutside = {
            lastMousedownWasOutside: !1
        }), e._clickOutside[t.instance.$.uid] = {
            onClick: o,
            onMousedown: n
        }
    },
    beforeUnmount(e, t) {
        e._clickOutside && (f(e, o => {
            var u;
            if (!o || !((u = e._clickOutside) != null && u[t.instance.$.uid])) return;
            const {
                onClick: n,
                onMousedown: s
            } = e._clickOutside[t.instance.$.uid];
            o.removeEventListener("click", n, !0), o.removeEventListener("mousedown", s, !0)
        }), delete e._clickOutside[t.instance.$.uid])
    }
};
export {
    R as C, p as I
};