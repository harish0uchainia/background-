import {
    q as g,
    v as R,
    w as D,
    t as I,
    bi as U
} from "./BbvgifQp.js";
import {
    u as C
} from "./D5xT9ef6.js";
import {
    d as e
} from "./BBZLTf3A.js";
(function() {
    try {
        var o = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            s = new o.Error().stack;
        s && (o._sentryDebugIds = o._sentryDebugIds || {}, o._sentryDebugIds[s] = "9517cd17-88ee-4166-a50d-24b9f4ab0bac", o._sentryDebugIdIdentifier = "sentry-dbid-9517cd17-88ee-4166-a50d-24b9f4ab0bac")
    } catch {}
})();
const S = [{
    iso_code: "BRL",
    flag: "BR",
    symbol: "R$"
}, {
    iso_code: "TRY",
    flag: "TR",
    symbol: "&#8378;"
}, {
    iso_code: "PKR",
    flag: "PK",
    symbol: "&#8360;"
}, {
    iso_code: "IDR",
    flag: "ID",
    symbol: "&#8377;"
}, {
    iso_code: "INR",
    flag: "HI",
    symbol: "&#8377;"
}, {
    iso_code: "USD",
    flag: "US",
    symbol: "&#36;"
}, {
    iso_code: "EUR",
    flag: "EU",
    symbol: "&#8364;"
}, {
    iso_code: "UZS",
    flag: "UZ",
    symbol: "&#1083;&#1074;"
}, {
    iso_code: "BDT",
    flag: "BN",
    symbol: "BDT"
}, {
    iso_code: "UAH",
    flag: "UK",
    symbol: "₴"
}, {
    iso_code: "THB",
    flag: "TH",
    symbol: "&#3647"
}, {
    iso_code: "MYR",
    flag: "MY",
    symbol: "R&#77"
}, {
    iso_code: "PHP",
    flag: "PH",
    symbol: "&#8369"
}, {
    iso_code: "VND",
    flag: "VI",
    symbol: "&#8363"
}, {
    iso_code: "NPR",
    flag: "NP",
    symbol: "रु॰"
}, {
    iso_code: "MMK",
    flag: "MM",
    symbol: "K"
}, {
    iso_code: "FRA",
    flag: "FR",
    symbol: "&#8364;"
}, {
    iso_code: "ZMW",
    flag: "ZM",
    symbol: "ZMW"
}, {
    iso_code: "BIF",
    flag: "BIF",
    symbol: "FBu"
}, {
    iso_code: "RWF",
    flag: "RWF",
    symbol: "FRw"
}, {
    iso_code: "MZN",
    flag: "MZ",
    symbol: "MT"
}, {
    iso_code: "TZS",
    flag: "TZ",
    symbol: "TSh"
}, {
    iso_code: "UGX",
    flag: "UG",
    symbol: "Ush"
}, {
    iso_code: "XAF",
    flag: "CM",
    symbol: "₣"
}, {
    iso_code: "XOF",
    flag: "BF",
    symbol: "₣"
}, {
    iso_code: "GHS",
    flag: "GH",
    symbol: "GH₵"
}, {
    iso_code: "LKR",
    flag: "LK",
    symbol: "රු"
}, {
    iso_code: "CDF",
    flag: "CD",
    symbol: "CDF"
}];

function v() {
    const {
        appDefaultCurrency: o
    } = g(), {
        userGeo: s
    } = R(D()), r = I(), a = e(() => r.query.val_cur), {
        userDefaultCurrency: d,
        userCurrency: t,
        userUUID: y
    } = C(), n = e(() => ["USD", "EUR", "GBP"]), f = e(() => s.value || "IN"), u = U, i = e(() => {
        const l = f.value;
        return l in u ? u[l] : "INR"
    }), b = e(() => o || d.value), m = e(() => y.value ? t.value ? ? "INR" : n.value.includes(a.value ? ? "") ? a.value ? ? "INR" : i.value);
    return {
        codeToSymbol: l => {
            const c = S.find(_ => _.iso_code === l);
            return c == null ? void 0 : c.symbol
        },
        appDefaultCurrency: b,
        bonusesCurrencyByGeo: m
    }
}
export {
    v as u
};