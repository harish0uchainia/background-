import {
    w as R,
    bH as q,
    bI as C,
    bJ as B,
    bC as F,
    v as G,
    k as H,
    g as J,
    f as V,
    t as L,
    bK as j,
    bn as x
} from "./BbvgifQp.js";
import {
    u as K
} from "./D5xT9ef6.js";
import {
    u as X
} from "./WQ5Cu1Fz.js";
import {
    d as w
} from "./BBZLTf3A.js";
(function() {
    try {
        var n = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            r = new n.Error().stack;
        r && (n._sentryDebugIds = n._sentryDebugIds || {}, n._sentryDebugIds[r] = "e86d796d-2031-49df-8ac9-bd4e501912c9", n._sentryDebugIdIdentifier = "sentry-dbid-e86d796d-2031-49df-8ac9-bd4e501912c9")
    } catch {}
})();

function Z() {
    const {
        uuidv4: n
    } = C(), {
        userUUID: r
    } = K(), {
        sendUserDepositStatistic: p
    } = R(), m = () => n();
    let u = null,
        s = null;
    return {
        trackDepositStatistics: async d => {
            const {
                event: i,
                tokenMethod: D,
                amount: l,
                place: v,
                tokenTransaction: I,
                errorTag: T
            } = d;
            try {
                const a = i === "open";
                if (i === "open" && !s && (s = m(), s && localStorage.setItem("openId", s)), v || (u = B()), !r.value) {
                    console.warn("[trackDepositStatistics] - User is unknown");
                    return
                }
                if (!u) {
                    console.warn("[trackDepositStatistics] - Place is unknown");
                    return
                }
                s = localStorage.getItem("openId");
                const P = {
                    open_id: s,
                    player_uuid: r.value,
                    token_method: a || !D ? null : D,
                    event: i,
                    amount: a || !l ? null : Number(l),
                    place: u,
                    token_transaction: a || !I ? null : I,
                    error_tag: T || null
                };
                await p(P)
            } catch (a) {
                F(a)
            }
        },
        clearValuesAfterModalClosed: () => {
            s = null, u = null, q(), localStorage.removeItem("openId")
        }
    }
}
const b = 5;

function $() {
    const {
        userUUID: n,
        isUserDepositAmount: r
    } = G(H()), {
        isAuthenticated: p
    } = J(), {
        dayjs: m
    } = x(), {
        fetchDepositHistory: u
    } = X(), {
        openDialog: s,
        dialogName: k
    } = V(), y = L();
    let d;
    const i = w(() => j + n.value),
        D = w(() => !+r.value);

    function l() {
        sessionStorage.removeItem(i.value)
    }

    function v(e) {
        sessionStorage.setItem(i.value, JSON.stringify(e))
    }

    function I() {
        const e = sessionStorage.getItem(i.value);
        return typeof e == "string" ? JSON.parse(e) : e
    }

    function T(e) {
        v({ ...e,
            date: new Date
        })
    }

    function a(e) {
        const o = m(e);
        return m().diff(o, "minute")
    }

    function P(e) {
        return a(e) >= b
    }

    function _(e) {
        const o = a(e);
        return o >= b ? 0 : (b - o) * 60 * 1e3
    }
    async function A() {
        var o, t, f;
        const e = {
            isError: !1,
            isProgress: !1,
            isSuccess: !1
        };
        try {
            const c = await u(1, 1);
            return e.isError = ((o = c.data) == null ? void 0 : o[0].status) === "error", e.isProgress = ((t = c.data) == null ? void 0 : t[0].status) === "in_progress", e.isSuccess = ((f = c.data) == null ? void 0 : f[0].status) === "success", e
        } catch (c) {
            return console.error(c), e
        }
    }
    async function E(e = !1) {
        const o = typeof y.name == "string" && y.name.includes("-slot-id");
        if (!p.value || !D.value || k.value || o) return;
        const t = I();
        if (!t) return;
        const f = t.status === "fail",
            c = t.request === "create" && t.status === "pending",
            M = t.request === "create" && t.status === "success",
            N = t.request === "immediate-and-no-request" && t.status === null;
        if (f || c || M || N) {
            s("depositCompleteAgain"), l();
            return
        }
        const S = await A(),
            g = P(t.date),
            h = g && !S.isSuccess,
            U = !g && (S.isProgress || S.isError),
            O = g && S.isError;
        (U || h) && (s("depositCompleteAgain"), (!O || e) && l()), g && !e ? await E(!0) : !g && !e && (d && clearTimeout(d), console.info("Deposit banner start timeout", _(t.date)), d = setTimeout(() => {
            E(!0)
        }, _(t.date)))
    }
    return {
        defineBannerTrigger: T,
        checkBannerTrigger: E,
        clearStorageDepositBanner: l
    }
}
export {
    $ as a, Z as u
};