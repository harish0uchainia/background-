import {
    _ as J
} from "./DHxCvf5R.js";
import {
    _ as X
} from "./CyEI51nD.js";
import {
    z as Y,
    Z as Q,
    b as p,
    d as f,
    w as ee,
    Y as I,
    _ as T,
    V as k,
    a7 as te,
    u as a,
    D as g,
    J as se,
    ax as ae,
    f as ne,
    W as C,
    a2 as oe,
    a1 as z,
    L as ie,
    a8 as re,
    a0 as m,
    F as le,
    a9 as de,
    ae as M
} from "./BBZLTf3A.js";
import {
    h as ue,
    v as ce,
    k as pe,
    l as fe,
    _ as ge
} from "./BbvgifQp.js";
import {
    C as me
} from "./BEPDeFGu.js";
(function() {
    try {
        var d = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            h = new d.Error().stack;
        h && (d._sentryDebugIds = d._sentryDebugIds || {}, d._sentryDebugIds[h] = "e869fc04-310c-4285-a5d4-8b3a112ea2eb", d._sentryDebugIdIdentifier = "sentry-dbid-e869fc04-310c-4285-a5d4-8b3a112ea2eb")
    } catch {}
})();
const he = {
        class: "input-pwd_tooltip-holder"
    },
    ve = {
        class: "input-pwd_tooltip-holder_item-icon"
    },
    we = {
        class: "input-pwd_tooltip-holder_item-text"
    },
    _e = Y({
        __name: "AppInputPwd",
        props: {
            autocomplete: {},
            backgroundColor: {},
            customClassName: {},
            appendInnerIcon: {},
            height: {},
            label: {},
            variant: {},
            density: {},
            rules: {},
            tabindex: {},
            value: {},
            requiresTooltip: {
                type: Boolean
            },
            errorMessages: {},
            hideDetails: {
                type: Boolean
            },
            name: {},
            dataAutoTestEl: {},
            placeholder: {},
            persistentPlaceholder: {
                type: Boolean
            },
            skipRequiredValid: {
                type: Boolean
            },
            innerInputId: {}
        },
        emits: ["input", "click:append", "validate:custom-rules"],
        setup(d, {
            emit: h
        }) {
            const {
                t: c
            } = ue(), t = d, R = Q(), E = h, {
                isHasUpdatedPassword: L
            } = ce(pe()), v = p(!0), u = p(!1), l = p(t.value || ""), P = ["text", "password"], q = ["mdi-eye", "mdi-eye-off"], N = /[a-zA-Z!@#$%^&*()_\-+()[\]{}><\\|"'.,:;0-9]*/g, y = [{
                id: 0,
                name: "validations.passwordMinLength",
                regex: ".{8,}",
                configTranslate: {
                    minLength: 8
                }
            }, {
                id: 1,
                name: "validations.passwordDigit",
                regex: "(?=.*[0-9])"
            }, {
                id: 2,
                name: "validations.passwordLowerCase",
                regex: "(?=.*[a-z])"
            }, {
                id: 3,
                name: "validations.passwordUpperCase",
                regex: "(?=.*[A-Z])"
            }], A = p(!1), D = p(!1), r = f(() => L.value > 0 && t.requiresTooltip), $ = f(() => ({
                input(e) {
                    E("input", e.target.value)
                }
            })), Z = f(() => {
                var e;
                return r.value ? u.value ? 0 : (e = S.value) == null ? void 0 : e.length : 1
            }), w = e => new RegExp(e).test(l.value), F = () => {
                u.value = !!t.requiresTooltip, D.value = !0
            }, V = () => {
                u.value = !1, A.value = !0, D.value = !1
            }, U = () => {
                t.innerInputId && setTimeout(() => {
                    const e = document.getElementById(t.innerInputId);
                    e == null || e.focus(), e && e.setSelectionRange(e.value.length, e.value.length)
                }, 0)
            }, H = e => {
                (e.which || e.keyCode) === 32 && e.preventDefault()
            }, B = e => {
                if (!t.requiresTooltip || !r.value) {
                    e instanceof KeyboardEvent && H(e);
                    return
                }
                const n = 32,
                    o = e.target,
                    i = o.value;
                if (e instanceof KeyboardEvent) {
                    if (e.key.length === 1) {
                        const s = e.key;
                        (!/^[a-zA-Z!@#$%^&*()_\-+\[\]{}><\\|"'.,:;0-9]$/.test(s) || (i == null ? void 0 : i.length) >= n) && e.preventDefault()
                    }
                } else if (e instanceof ClipboardEvent) {
                    const {
                        clipboardData: s
                    } = e;
                    if (!s) return;
                    const x = [...s.getData("text")].filter(G => /^[a-zA-Z!@#$%^&*()_\-+\[\]{}><\\|"'.,:;0-9]$/.test(G)).join("");
                    e.preventDefault();
                    const b = o.selectionStart || 0,
                        j = o.selectionEnd || 0,
                        _ = i.slice(0, b) + x + i.slice(j);
                    if ((_ == null ? void 0 : _.length) > n) return;
                    o.value = _, o.setSelectionRange(b + x.length, b + x.length), o.dispatchEvent(new Event("input", {
                        bubbles: !0
                    }))
                }
            }, K = () => {
                v.value = !v.value
            }, O = f(() => u.value || !r.value ? null : y.filter(e => !w(e.regex)).map(e => c(e.name, e.configTranslate || {}))), S = f(() => {
                var n, o, i;
                const e = (n = t == null ? void 0 : t.rules) == null ? void 0 : n.map(s => s(l.value)).filter(s => typeof s == "string");
                if (!l.value && A.value && !t.skipRequiredValid) return r.value ? [c("validations.requiredField")] : [c("validations.pwdRules")];
                if (!r.value) {
                    if (e != null && e.length) return e;
                    if (!((o = t.errorMessages) != null && o.length)) return null
                }
                return l.value.length > 0 ? e != null && e.length ? e : (i = t.errorMessages) != null && i.length ? t.errorMessages : O.value : t.errorMessages || null
            });
            return ee(l, () => {
                r.value && E("validate:custom-rules", y.every(e => w(e.regex)))
            }), (e, n) => {
                const o = J,
                    i = X;
                return I((k(), T("div", {
                    class: te(["input-pwd", {
                        "input-pwd--hide-errors": e.requiresTooltip && a(u) && a(r)
                    }])
                }, [g(o, se({
                    modelValue: a(l),
                    "onUpdate:modelValue": n[0] || (n[0] = s => ne(l) ? l.value = s : null)
                }, { ...t,
                    ...a(R)
                }, {
                    maxlength: a(r) ? 32 : void 0,
                    type: P[+a(v)],
                    placeholder: e.placeholder,
                    "dynamic-regex-change": !0,
                    regex: N,
                    "max-errors": a(Z),
                    "error-messages": a(S),
                    "hide-details": a(u) && a(r) && a(l).length > 0 || t.hideDetails,
                    "data-auto-test-el": e.dataAutoTestEl
                }, ae(a($)), {
                    onKeypress: B,
                    onPaste: B,
                    onFocusin: F,
                    onFocusout: V
                }), {
                    "append-inner": C(() => [g(fe, {
                        onClick: K
                    }, {
                        default: C(() => [oe(z(q[+a(v)]), 1)]),
                        _: 1
                    })]),
                    _: 1
                }, 16, ["modelValue", "maxlength", "type", "placeholder", "max-errors", "error-messages", "hide-details", "data-auto-test-el"]), g(ie, {
                    name: "fade"
                }, {
                    default: C(() => [e.requiresTooltip && a(u) && a(r) ? (k(), T("div", {
                        key: 0,
                        class: "input-pwd_tooltip",
                        onMousedown: U
                    }, [n[1] || (n[1] = m("div", {
                        class: "input-pwd_tooltip-triangle"
                    }, null, -1)), m("div", he, [(k(), T(le, null, de(y, s => m("div", {
                        key: s.id,
                        class: "input-pwd_tooltip-holder_item"
                    }, [m("div", ve, [I(g(i, {
                        size: 10,
                        height: 10,
                        "symbol-id": "success-password-rule"
                    }, null, 512), [
                        [M, w(s.regex)]
                    ]), I(g(i, {
                        size: 10,
                        height: 10,
                        "symbol-id": "invalid-password-rule"
                    }, null, 512), [
                        [M, !w(s.regex)]
                    ])]), m("div", we, z(a(c)(s.name, s.configTranslate)), 1)])), 64))])], 32)) : re("", !0)]),
                    _: 1
                })], 2)), [
                    [me, V]
                ])
            }
        }
    }),
    ke = ge(_e, [
        ["__scopeId", "data-v-a592dfc6"]
    ]);
export {
    ke as A
};