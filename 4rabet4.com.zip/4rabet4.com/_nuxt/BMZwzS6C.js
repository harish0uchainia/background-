import {
    T as Q
} from "./1xKHoBf3.js";
import {
    z as X,
    G as _,
    v as I,
    u as Y,
    A as Z,
    h as ee,
    t as te,
    n as re,
    C as oe,
    p as ae,
    c as ne,
    o as ie,
    f as se,
    g as le,
    b as ce,
    a as ue
} from "./BbvgifQp.js";
import {
    b as de,
    d as pe
} from "./BBZLTf3A.js";
(function() {
    try {
        var i = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            s = new i.Error().stack;
        s && (i._sentryDebugIds = i._sentryDebugIds || {}, i._sentryDebugIds[s] = "c3b61227-bb20-454a-b9cb-5fc025025de5", i._sentryDebugIdIdentifier = "sentry-dbid-c3b61227-bb20-454a-b9cb-5fc025025de5")
    } catch {}
})();
const S = {
    "american-roulette-4661": "american-roulette-10",
    "auto-roulette-4646": "auto-roulette-8",
    "auto-roulette-vip": "auto-roulette-vip-1",
    "bac-bo": "bac-bo-1",
    "balloon-race": "balloon-race-1",
    "cash-or-crash": "cash-or-crash-1",
    "craps-10419": "craps-2",
    "dead-or-alive-saloon": "dead-or-alive-saloon-1",
    "dragon-tiger-evolution": "dragon-tiger-13",
    "dream-catcher": "dream-catcher-2",
    "easy-blackjack": "easy-blackjack-0",
    "extra-chilli-epic-spins": "extra-chilli-epic-spins-1",
    "fan-tan": "fan-tan-2",
    "first-person-american-roulette": "first-person-american-roulette-1",
    "first-person-baccarat-10417": "first-person-baccarat-1",
    "first-person-blackjack": "first-person-blackjack-1",
    "first-person-craps": "first-person-craps-1",
    "first-person-deal-or-no-deal": "first-person-deal-or-no-deal-1",
    "first-person-dragon-tiger-10421": "first-person-dragon-tiger-1",
    "first-person-dream-catcher": "first-person-dream-catcher-1",
    "first-person-golden-wealth-baccarat": "first-person-golden-wealth-baccarat-1",
    "first-person-hilo": "first-person-hilo-1",
    "first-person-lightning-baccarat": "first-person-lightning-baccarat-1",
    "first-person-lightning-blackjack": "first-person-lightning-blackjack-1",
    "first-person-lightning-roulette": "first-person-lightning-roulette-1",
    "first-person-mega-ball-10415": "first-person-mega-ball-1",
    "first-person-prosperity-tree-baccarat": "first-person-prosperity-tree-baccarat-1",
    "first-person-roulette-26117": "first-person-roulette-1",
    "first-person-super-sic-bo": "first-person-super-sic-bo-1",
    "first-person-top-card-10416": "first-person-top-card-1",
    "first-person-video-poker": "first-person-video-poker-1",
    "first-person-xxxtreme-lightning-baccarat": "first-person-xxxtreme-lightning-baccarat-1",
    "first-person-xxxtreme-lightning-roulette": "first-person-xxxtreme-lightning-roulette-1",
    "football-studio": "football-studio-1",
    "football-studio-dice": "football-studio-dice-1",
    "football-studio-roulette": "football-studio-roulette-1",
    "gold-vault-roulette": "gold-vault-roulette-1",
    "golden-wealth-baccarat": "golden-wealth-baccarat-1",
    "gonzos-treasure-map": "gonzos-treasure-map-1",
    "immersive-roulette-17250": "immersive-roulette-1",
    "imperial-quest": "imperial-quest-1",
    "infinite-blackjack": "infinite-blackjack-1",
    "instant-roulette-17262": "instant-roulette-1",
    "lightning-baccarat-25673": "lightning-baccarat-1",
    "lightning-dragon-tiger": "lightning-dragon-tiger-1",
    "lightning-sic-bo": "lightning-sic-bo-1",
    "no-commission-baccarat-27343": "no-commission-baccarat-2",
    "peek-baccarat": "peek-baccarat-1",
    "power-blackjack-17227": "power-blackjack-1",
    "prosperity-tree-baccarat": "prosperity-tree-baccarat-1",
    "roulette-17286": "roulette-12",
    "speed-auto-roulette-17278": "speed-auto-roulette-6",
    "speed-roulette": "speed-roulette-8",
    "stock-market": "stock-market-1",
    "super-andar-bahar": "super-andar-bahar-1",
    "super-sic-bo": "super-sic-bo-1",
    "super-speed-baccarat": "super-speed-baccarat-0",
    "teen-patti-22479": "teen-patti-2",
    "vip-roulette-17289": "vip-roulette-4",
    "video-poker": "video-poker-3",
    "xxxtreme-lightning-baccarat": "xxxtreme-lightning-baccarat-1",
    "mega-ball-10414": "mega-ball-0",
    "deal-or-no-deal": "deal-or-no-deal-2",
    "extreme-texas-holdem": "extreme-texas-holdem-1",
    "lightning-blackjack": "lightning-blackjack-0",
    "crazy-coin-flip": "crazy-coin-flip-1",
    "crazy-pachinko": "crazy-pachinko-1",
    "crazy-time-10418": "crazy-time-1",
    "crazy-time-a": "crazy-time-a-0",
    "funky-time": "funky-time-1",
    "lightning-roulette-16859": "lightning-roulette-1",
    "lightning-storm": "lightning-storm-2",
    "monopoly-big-baller": "monopoly-big-baller-1",
    "monopoly-live": "monopoly-live-1",
    "xxxtreme-lightning-roulette": "xxxtreme-lightning-roulette-1",
    "2-hand-casino-holdem": "2-hand-casino-holdem-1",
    "always-8-baccarat": "always-8-baccarat-0",
    "caribbean-stud-poker": "caribbean-stud-poker-2",
    "casino-holdem-4655": "casino-holdem-6",
    "crazy-balls": "crazy-balls-0",
    "double-ball-roulette-17279": "double-ball-roulette-1",
    "dragonara-roulette": "dragonara-roulette-1",
    "hindi-lightning-roulette": "hindi-lightning-roulette-0",
    "infinite-free-bet-blackjack": "infinite-free-bet-blackjack-1",
    "lightning-ball": "lightning-ball-1",
    "lightning-dice": "lightning-dice-1",
    "red-door-roulette": "red-door-roulette-1",
    "salon-prive-roulette": "salon-prive-roulette-1",
    "texas-holdem-bonus-poker": "texas-holdem-bonus-poker-1",
    "triple-card-poker": "triple-card-poker-1",
    "french-roulette-gold-17288": "french-roulette-gold-1"
};

function ke() {
    const {
        $API: i
    } = X(), {
        setExternalProviderId: s,
        saveRunningGameData: l,
        setSlotUrl: b,
        setSlotData: j,
        setIsTvBetSlot: D,
        setPlayGame: h,
        setRedirectSlotAuth: G
    } = _(), {
        externalProviderId: T,
        letPlayGame: z,
        slotUrl: B,
        slotData: P,
        redirectSlotAuth: A,
        birthDayIsUpdated: L
    } = I(_()), E = ue(), {
        config: g
    } = Y(), U = Z(), {
        locale: $
    } = ee(), k = te(), c = re(), u = oe(), d = de(null), {
        hashLink: O,
        isGoogleBot: R,
        fullDomain: m
    } = ae(), {
        getSubdirUrlPart: C
    } = ne(), {
        currentBonusId: N
    } = I(ie()), q = pe(() => `/${C(0,k.path)}`), {
        openDialog: p
    } = se(), {
        isAuthenticated: K
    } = le();
    async function M({
        id: a,
        currency: e,
        balance: t,
        lang: r
    }) {
        try {
            const n = await i.ApiGames.slotStartPlayByIdOrSlug(a, {
                demo: 0,
                currency: e,
                balance: t,
                lang: r
            });
            if (n && n.status === 200) return n.data;
            throw n
        } catch (n) {
            throw console.info("[use-game.js]: Error while fetching url for promo game", n), n
        }
    }
    async function f(a, e = {}) {
        try {
            const t = {
                device: U.width.value <= Q ? "mobile" : "desktop",
                ...e
            };
            t.demo !== void 0 && (t.demo = t.demo ? 1 : 0), m.value && (t.return_url = m.value);
            let r = a;
            g.value.NEW_LD_SLOTS && S[r] && (r = S[r]), r === "chicken-road" && (r = "chicken-road-0");
            const o = await i.ApiGames.slotPlayByIdOrSlug(r, t);
            return l(o == null ? void 0 : o.data), o == null ? void 0 : o.data
        } catch (t) {
            throw console.error("[use-game.js]: Error while fetching url for game data", t), t
        }
    }

    function F(a, e, t) {
        const r = "tv-bet";
        let o = ce("i18n_lang").value || $.value;
        o === "pt" && (o = "br");
        const n = E.public.env.TVBET_ID;
        new window.TvbetFrame({
            lng: o,
            clientId: n,
            tokenAuth: a,
            server: e,
            floatTop: "#main-header",
            containerId: r,
            game_id: t
        })
    }
    async function y() {
        var a;
        K.value || (a = k.query) != null && a.demo || (d.value = "Please log in to play", !O.value && !R.value && p("auth"))
    }
    async function H(a) {
        const e = {
            demo: 0
        };
        d.value = null;
        try {
            const t = await f(a, e).catch(r => {
                throw c.push(u("/")), r
            });
            if (t) {
                if (!(t != null && t.is_wager_playable) && N.value) return g.value.SLOT_BONUS_BLOCK ? p("slotBonusBlock") : p("wagerNoPossible");
                window.location.href = t == null ? void 0 : t.url
            }
        } catch {
            d.value = "Cannot get game url"
        }
    }

    function V(a) {
        return y().then(() => H(a))
    }

    function W(a, e, t) {
        var x, w;
        h(!0);
        const r = {
                3: "casino",
                24: "live-dealers",
                35: "tv-games"
            },
            o = (e == null ? void 0 : e.link_name) || (e == null ? void 0 : e.friendly_url) || (e == null ? void 0 : e.id);
        let n = q.value;
        const v = (e == null ? void 0 : e.section_id) || 3;
        e != null && e.section_id && r[v] && (n = `${r[v]}`), t ? c.push(u({
            path: `${n}/slot/${o}`,
            query: {
                demo: 1
            }
        })) : (b(a), ((x = e == null ? void 0 : e.external_provider) != null && x.id || e != null && e.external_provider_id) && s(((w = e == null ? void 0 : e.external_provider) == null ? void 0 : w.id) || (e == null ? void 0 : e.external_provider_id)), c.push(u({
            path: `${n}/slot/${o}`
        })))
    }
    async function J(a, e, t) {
        const r = {
            demo: t
        };
        e && (r.token = e);
        const o = await f(a, r);
        return o == null ? void 0 : o.url
    }
    return {
        fetchUrlPromoGame: M,
        startGameSlotMobile: V,
        slotUrl: B,
        externalProviderId: T,
        setExternalProviderId: s,
        setPlayGame: h,
        saveRunningGameData: l,
        birthDayIsUpdated: L,
        setSlotData: j,
        slotData: P,
        goToGame: W,
        letPlayGame: z,
        initTvBet: F,
        getTokenSlot: y,
        setRedirectSlotAuth: G,
        redirectSlotAuth: A,
        setSlotUrl: b,
        setIsTvBetSlot: D,
        getGameData: f,
        getGameUrl: J
    }
}
export {
    ke as u
};