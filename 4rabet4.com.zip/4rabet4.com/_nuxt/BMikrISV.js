import {
    _ as d
} from "./Crl4dfne.js";
import f from "./D3cdnUJq.js";
import {
    _ as l
} from "./Dqf_al40.js";
import {
    u as y,
    f as g,
    t as b,
    g as D
} from "./BbvgifQp.js";
import {
    u as h
} from "./B99ZEpuR.js";
import {
    z as w,
    d as x,
    B as k,
    U as r,
    W as I,
    V as t,
    _ as B,
    u as n,
    D as E
} from "./BBZLTf3A.js";
import "./CyEI51nD.js";
import "./D5xT9ef6.js";
import "./Cc4FcFuq.js";
import "./1xKHoBf3.js";
import "./CRXlgDsv.js";
import "./D_nsTU_t.js";
import "./CNVksA_o.js";
import "./BMZwzS6C.js";
(function() {
    try {
        var o = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            e = new o.Error().stack;
        e && (o._sentryDebugIds = o._sentryDebugIds || {}, o._sentryDebugIds[e] = "293e1262-0f83-4878-a7e0-4f0cd0a0aa77", o._sentryDebugIdIdentifier = "sentry-dbid-293e1262-0f83-4878-a7e0-4f0cd0a0aa77")
    } catch {}
})();
const S = {
        key: 1,
        class: "font-weight-black mb-5 mx-5 px-5 py-5"
    },
    U = w({
        __name: "[id]",
        setup(o) {
            const {
                config: e
            } = y(), {
                openDialog: s
            } = g(), {
                scrollToTop: c
            } = h(), i = b(), {
                isAuthenticated: a
            } = D(), p = x(() => i.query.gsp);
            return k(() => {
                e.value.DOWNTIME_MODAL_SHOW && s("downTime"), c()
            }), (T, W) => {
                const _ = d,
                    m = f,
                    u = l;
                return t(), r(u, null, {
                    default: I(() => [n(a) || n(p) || !n(a) ? (t(), r(_, {
                        key: 0
                    })) : (t(), B("h2", S, [E(m, {
                        class: "my-10"
                    })]))]),
                    _: 1
                })
            }
        }
    });
export {
    U as
    default
};