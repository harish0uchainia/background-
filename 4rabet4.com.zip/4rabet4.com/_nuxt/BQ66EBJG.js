import {
    bD as U,
    v as n,
    k as _,
    o as S,
    w
} from "./BbvgifQp.js";
import {
    u as L
} from "./CbNZPVTM.js";
import {
    d,
    w as g
} from "./BBZLTf3A.js";
(function() {
    try {
        var r = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            u = new r.Error().stack;
        u && (r._sentryDebugIds = r._sentryDebugIds || {}, r._sentryDebugIds[u] = "4bb24d9b-b1a7-4457-9276-91e3e4eb6ecb", r._sentryDebugIdIdentifier = "sentry-dbid-4bb24d9b-b1a7-4457-9276-91e3e4eb6ecb")
    } catch {}
})();

function E() {
    const {
        balance: r
    } = L(), {
        getUUID: u
    } = U(), {
        userRegBonusCode: c
    } = n(_()), {
        activeBonus: a
    } = n(S()), {
        userGeo: m
    } = n(w()), s = d(() => {
        const e = u.value;
        return e && typeof e == "string" ? e : null
    }), v = d(() => m.value || ""), D = d(() => c.value || ""), i = (e, t) => {
        if (typeof window > "u") {
            console.warn(`SEO data layer update skipped (SSR) - ${e}`);
            return
        }
        window.dataLayer = window.dataLayer || [], window.dataLayer.push({
            event: e,
            ...t
        })
    }, y = (e = {}) => {
        if (!s.value) {
            console.warn("Skipping trackRegistration: userUUID is missing");
            return
        }
        i("registration", {
            registration: {
                userID: s.value,
                userCountry: v.value,
                bonus: D.value,
                ...e
            }
        })
    }, p = (e = {}) => {
        if (!s.value) {
            console.warn("Skipping trackDeposit: userUUID is missing");
            return
        }
        i("depo", {
            depo: {
                userID: s.value,
                ...e
            }
        })
    }, k = (e = {}) => {
        if (!s.value) {
            console.warn("Skipping trackLogin: userUUID is missing");
            return
        }
        i("login", {
            login: {
                userID: s.value,
                ...e
            }
        })
    }, b = (e = {}) => {
        var t, o;
        if (!s.value) {
            console.warn("Skipping trackBonusClaim: userUUID is missing");
            return
        }
        i("bonus_claim", {
            bonus_claim: {
                userID: s.value,
                bonusType: ((t = a.value) == null ? void 0 : t.type) || "",
                bonusID: ((o = a.value) == null ? void 0 : o.id) || "",
                ...e
            }
        })
    }, I = (e = {}) => {
        i("ad_click", {
            ad_click: {
                userID: s.value,
                ...e
            }
        })
    };
    return g(r, (e, t) => {
        var o, f, l;
        s.value && Number(((o = e == null ? void 0 : e.total_deposit) == null ? void 0 : o.amount) || 0) > Number(((f = t == null ? void 0 : t.total_deposit) == null ? void 0 : f.amount) || 0) && p({
            amount: Number(((l = e == null ? void 0 : e.total_deposit) == null ? void 0 : l.amount) || 0)
        })
    }), g(a, (e, t) => {
        e != null && e.id && e.id !== (t == null ? void 0 : t.id) && b()
    }), {
        trackRegistration: y,
        trackDeposit: p,
        trackLogin: k,
        trackBonusClaim: b,
        trackAdClick: I
    }
}
export {
    E as u
};