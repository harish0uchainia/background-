import {
    c as H
} from "./BulKdswA.js";
import {
    U as te,
    W as le,
    a2 as ne,
    A as oe,
    ah as se,
    aM as G,
    bg as ae,
    aQ as q,
    a4 as re,
    ae as ie,
    X as ue,
    bh as ce,
    Y as fe,
    ab as L,
    b1 as de,
    l as N
} from "./BbvgifQp.js";
import {
    y as S,
    d as g,
    w as ve,
    D as h,
    B as pe,
    O as he
} from "./BBZLTf3A.js";
(function() {
    try {
        var l = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new l.Error().stack;
        n && (l._sentryDebugIds = l._sentryDebugIds || {}, l._sentryDebugIds[n] = "a6aa7d93-7a92-4fac-8f4e-9dde5ed85c61", l._sentryDebugIdIdentifier = "sentry-dbid-a6aa7d93-7a92-4fac-8f4e-9dde5ed85c61")
    } catch {}
})();

function ge(l) {
    let {
        selectedElement: n,
        containerElement: s,
        isRtl: r,
        isHorizontal: d
    } = l;
    const v = m(d, s),
        a = K(d, r, s),
        p = m(d, n),
        c = Q(d, n),
        y = p * .4;
    return a > c ? c - y : a + v < c + p ? c - v + p + y : a
}

function ye(l) {
    let {
        selectedElement: n,
        containerElement: s,
        isHorizontal: r
    } = l;
    const d = m(r, s),
        v = Q(r, n),
        a = m(r, n);
    return v - d / 2 + a / 2
}

function U(l, n) {
    const s = l ? "scrollWidth" : "scrollHeight";
    return (n == null ? void 0 : n[s]) || 0
}

function Se(l, n) {
    const s = l ? "clientWidth" : "clientHeight";
    return (n == null ? void 0 : n[s]) || 0
}

function K(l, n, s) {
    if (!s) return 0;
    const {
        scrollLeft: r,
        offsetWidth: d,
        scrollWidth: v
    } = s;
    return l ? n ? v - d + r : r : s.scrollTop
}

function m(l, n) {
    const s = l ? "offsetWidth" : "offsetHeight";
    return (n == null ? void 0 : n[s]) || 0
}

function Q(l, n) {
    const s = l ? "offsetLeft" : "offsetTop";
    return (n == null ? void 0 : n[s]) || 0
}
const be = Symbol.for("vuetify:v-slide-group"),
    me = le({
        centerActive: Boolean,
        direction: {
            type: String,
            default: "horizontal"
        },
        symbol: {
            type: null,
            default: be
        },
        nextIcon: {
            type: L,
            default: "$next"
        },
        prevIcon: {
            type: L,
            default: "$prev"
        },
        showArrows: {
            type: [Boolean, String],
            validator: l => typeof l == "boolean" || ["always", "desktop", "mobile"].includes(l)
        },
        ...fe(),
        ...ce({
            mobile: null
        }),
        ...ue(),
        ...ie({
            selectedClass: "v-slide-group-item--active"
        })
    }, "VSlideGroup"),
    ke = te()({
        name: "VSlideGroup",
        props: me(),
        emits: {
            "update:modelValue": l => !0
        },
        setup(l, n) {
            let {
                slots: s
            } = n;
            const {
                isRtl: r
            } = ne(), {
                displayClasses: d,
                mobile: v
            } = oe(l), a = se(l, l.symbol), p = S(!1), c = S(0), y = S(0), W = S(0), i = g(() => l.direction === "horizontal"), {
                resizeRef: u,
                contentRect: w
            } = G(), {
                resizeRef: f,
                contentRect: k
            } = G(), C = ae(), M = g(() => ({
                container: u.el,
                duration: 200,
                easing: "easeOutQuart"
            })), $ = g(() => a.selected.value.length ? a.items.value.findIndex(t => t.id === a.selected.value[0]) : -1), X = g(() => a.selected.value.length ? a.items.value.findIndex(t => t.id === a.selected.value[a.selected.value.length - 1]) : -1);
            if (q) {
                let t = -1;
                ve(() => [a.selected.value, w.value, k.value, i.value], () => {
                    cancelAnimationFrame(t), t = requestAnimationFrame(() => {
                        if (w.value && k.value) {
                            const e = i.value ? "width" : "height";
                            y.value = w.value[e], W.value = k.value[e], p.value = y.value + 1 < W.value
                        }
                        if ($.value >= 0 && f.el) {
                            const e = f.el.children[X.value];
                            V(e, l.centerActive)
                        }
                    })
                })
            }
            const x = S(!1);

            function V(t, e) {
                let o = 0;
                e ? o = ye({
                    containerElement: u.el,
                    isHorizontal: i.value,
                    selectedElement: t
                }) : o = ge({
                    containerElement: u.el,
                    isHorizontal: i.value,
                    isRtl: r.value,
                    selectedElement: t
                }), B(o)
            }

            function B(t) {
                if (!q || !u.el) return;
                const e = m(i.value, u.el),
                    o = K(i.value, r.value, u.el);
                if (!(U(i.value, u.el) <= e || Math.abs(t - o) < 16)) {
                    if (i.value && r.value && u.el) {
                        const {
                            scrollWidth: O,
                            offsetWidth: P
                        } = u.el;
                        t = O - P - t
                    }
                    i.value ? C.horizontal(t, M.value) : C(t, M.value)
                }
            }

            function Y(t) {
                const {
                    scrollTop: e,
                    scrollLeft: o
                } = t.target;
                c.value = i.value ? o : e
            }

            function j(t) {
                if (x.value = !0, !(!p.value || !f.el)) {
                    for (const e of t.composedPath())
                        for (const o of f.el.children)
                            if (o === e) {
                                V(o);
                                return
                            }
                }
            }

            function J(t) {
                x.value = !1
            }
            let E = !1;

            function Z(t) {
                var e;
                !E && !x.value && !(t.relatedTarget && ((e = f.el) != null && e.contains(t.relatedTarget))) && b(), E = !1
            }

            function D() {
                E = !0
            }

            function ee(t) {
                if (!f.el) return;

                function e(o) {
                    t.preventDefault(), b(o)
                }
                i.value ? t.key === "ArrowRight" ? e(r.value ? "prev" : "next") : t.key === "ArrowLeft" && e(r.value ? "next" : "prev") : t.key === "ArrowDown" ? e("next") : t.key === "ArrowUp" && e("prev"), t.key === "Home" ? e("first") : t.key === "End" && e("last")
            }

            function z(t, e) {
                if (!t) return;
                let o = t;
                do o = o == null ? void 0 : o[e === "next" ? "nextElementSibling" : "previousElementSibling"]; while (o != null && o.hasAttribute("disabled"));
                return o
            }

            function b(t) {
                if (!f.el) return;
                let e;
                if (!t) e = de(f.el)[0];
                else if (t === "next") {
                    if (e = z(f.el.querySelector(":focus"), t), !e) return b("first")
                } else if (t === "prev") {
                    if (e = z(f.el.querySelector(":focus"), t), !e) return b("last")
                } else t === "first" ? (e = f.el.firstElementChild, e != null && e.hasAttribute("disabled") && (e = z(e, "next"))) : t === "last" && (e = f.el.lastElementChild, e != null && e.hasAttribute("disabled") && (e = z(e, "prev")));
                e && e.focus({
                    preventScroll: !0
                })
            }

            function I(t) {
                const e = i.value && r.value ? -1 : 1,
                    o = (t === "prev" ? -e : e) * y.value;
                let T = c.value + o;
                if (i.value && r.value && u.el) {
                    const {
                        scrollWidth: O,
                        offsetWidth: P
                    } = u.el;
                    T += O - P
                }
                B(T)
            }
            const A = g(() => ({
                    next: a.next,
                    prev: a.prev,
                    select: a.select,
                    isSelected: a.isSelected
                })),
                R = g(() => {
                    switch (l.showArrows) {
                        case "always":
                            return !0;
                        case "desktop":
                            return !v.value;
                        case !0:
                            return p.value || Math.abs(c.value) > 0;
                        case "mobile":
                            return v.value || p.value || Math.abs(c.value) > 0;
                        default:
                            return !v.value && (p.value || Math.abs(c.value) > 0)
                    }
                }),
                _ = g(() => Math.abs(c.value) > 1),
                F = g(() => {
                    if (!u.value) return !1;
                    const t = U(i.value, u.el),
                        e = Se(i.value, u.el);
                    return t - e - Math.abs(c.value) > 1
                });
            return re(() => h(l.tag, {
                class: ["v-slide-group", {
                    "v-slide-group--vertical": !i.value,
                    "v-slide-group--has-affixes": R.value,
                    "v-slide-group--is-overflowing": p.value
                }, d.value, l.class],
                style: l.style,
                tabindex: x.value || a.selected.value.length ? -1 : 0,
                onFocus: Z
            }, {
                default: () => {
                    var t, e, o;
                    return [R.value && h("div", {
                        key: "prev",
                        class: ["v-slide-group__prev", {
                            "v-slide-group__prev--disabled": !_.value
                        }],
                        onMousedown: D,
                        onClick: () => _.value && I("prev")
                    }, [((t = s.prev) == null ? void 0 : t.call(s, A.value)) ? ? h(H, null, {
                        default: () => [h(N, {
                            icon: r.value ? l.nextIcon : l.prevIcon
                        }, null)]
                    })]), h("div", {
                        key: "container",
                        ref: u,
                        class: "v-slide-group__container",
                        onScroll: Y
                    }, [h("div", {
                        ref: f,
                        class: "v-slide-group__content",
                        onFocusin: j,
                        onFocusout: J,
                        onKeydown: ee
                    }, [(e = s.default) == null ? void 0 : e.call(s, A.value)])]), R.value && h("div", {
                        key: "next",
                        class: ["v-slide-group__next", {
                            "v-slide-group__next--disabled": !F.value
                        }],
                        onMousedown: D,
                        onClick: () => F.value && I("next")
                    }, [((o = s.next) == null ? void 0 : o.call(s, A.value)) ? ? h(H, null, {
                        default: () => [h(N, {
                            icon: r.value ? l.prevIcon : l.nextIcon
                        }, null)]
                    })])]
                }
            })), {
                selected: a.selected,
                scrollTo: I,
                scrollOffset: c,
                focus: b,
                hasPrev: _,
                hasNext: F
            }
        }
    });

function Ee() {
    const l = S(!1);
    return pe(() => {
        window.requestAnimationFrame(() => {
            l.value = !0
        })
    }), {
        ssrBootStyles: g(() => l.value ? void 0 : {
            transition: "none !important"
        }),
        isBooted: he(l)
    }
}
export {
    ke as V, me as m, Ee as u
};