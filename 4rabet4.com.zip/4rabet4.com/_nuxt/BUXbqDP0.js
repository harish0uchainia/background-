import {
    u as E,
    k as a,
    v as c,
    $ as T,
    f as R,
    o as l,
    G as w,
    bl as B,
    bm as k
} from "./BbvgifQp.js";
import {
    u as C
} from "./Cc4FcFuq.js";
import {
    n as h
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            s = new e.Error().stack;
        s && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[s] = "b3cb6d82-ec7f-4990-aaba-9260e3f1769a", e._sentryDebugIdIdentifier = "sentry-dbid-b3cb6d82-ec7f-4990-aaba-9260e3f1769a")
    } catch {}
})();

function M(e) {
    return e != null && e.crash ? "reg-cra" : e != null && e.bets ? "reg-bet" : e != null && e.casino ? "reg-cas" : "reg-gen"
}

function G() {
    const {
        config: e
    } = E(), {
        setUserRegBonusCode: s
    } = a(), {
        promo: o
    } = c(T()), {
        closeDialog: u
    } = R(), {
        onPlayerActivity: f,
        onSaveFingerprint: d,
        setUuidv4ForStatistic: g,
        onRedirectToAuthKeeper: y,
        getPlayerMe: p,
        getPlayerBalance: v
    } = a(), {
        getWelcomeBonuses: I
    } = c(l()), {
        setBonusListId: D
    } = l(), {
        isMobile: P,
        isDesktop: S
    } = C(), {
        onUpdatePlayASlots: m
    } = w();
    async function A(_) {
        var r, i;
        B(k.AFTER_REG);
        const {
            formData: t
        } = _ ? ? {}, n = t != null && t.isPromo ? o.value.bonus : (r = I.value) == null ? void 0 : r.find(b => b.id === (t == null ? void 0 : t.bonus));
        u(), y({
            type: "set"
        }), await p(), v(), D(null), (i = e.value) != null && i.ACTIVITY && h(() => {
            f({
                action: "login"
            })
        }), m({
            isDesktop: S.value,
            isMobile: P.value
        }), d(), g(null), n && s(M(n))
    }
    return {
        getUserData: A
    }
}
export {
    G as u
};