import {
    a as s,
    m as n
} from "./iTYf75jB.js";
import {
    U as a,
    W as d,
    a4 as i
} from "./BbvgifQp.js";
import {
    D as c,
    J as l
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            o = new e.Error().stack;
        o && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[o] = "84cb1703-c08b-4737-94e4-3e6876a60e93", e._sentryDebugIdIdentifier = "sentry-dbid-84cb1703-c08b-4737-94e4-3e6876a60e93")
    } catch {}
})();
const f = d({ ...n({
            falseIcon: "$radioOff",
            trueIcon: "$radioOn"
        })
    }, "VRadio"),
    m = a()({
        name: "VRadio",
        props: f(),
        setup(e, o) {
            let {
                slots: r
            } = o;
            return i(() => {
                const t = s.filterProps(e);
                return c(s, l(t, {
                    class: ["v-radio", e.class],
                    style: e.style,
                    type: "radio"
                }), r)
            }), {}
        }
    });
export {
    m as V
};