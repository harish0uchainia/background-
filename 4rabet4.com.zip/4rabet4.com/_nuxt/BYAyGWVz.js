import {
    U as b,
    W as p,
    a4 as y,
    Y as v
} from "./BbvgifQp.js";
import {
    e as g,
    f as D
} from "./CNgVgUb9.js";
import {
    f as F
} from "./CbxP4vag.js";
import {
    b as V,
    D as h
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "8f2ec9a3-c0d8-4368-9b20-c94b804dbafb", e._sentryDebugIdIdentifier = "sentry-dbid-8f2ec9a3-c0d8-4368-9b20-c94b804dbafb")
    } catch {}
})();
const w = p({ ...v(),
        ...D()
    }, "VForm"),
    _ = b()({
        name: "VForm",
        props: w(),
        emits: {
            "update:modelValue": e => !0,
            submit: e => !0
        },
        setup(e, n) {
            let {
                slots: a,
                emit: i
            } = n;
            const s = g(e),
                f = V();

            function m(r) {
                r.preventDefault(), s.reset()
            }

            function c(r) {
                const o = r,
                    t = s.validate();
                o.then = t.then.bind(t), o.catch = t.catch.bind(t), o.finally = t.finally.bind(t), i("submit", o), o.defaultPrevented || t.then(u => {
                    var d;
                    let {
                        valid: l
                    } = u;
                    l && ((d = f.value) == null || d.submit())
                }), o.preventDefault()
            }
            return y(() => {
                var r;
                return h("form", {
                    ref: f,
                    class: ["v-form", e.class],
                    style: e.style,
                    novalidate: !0,
                    onReset: m,
                    onSubmit: c
                }, [(r = a.default) == null ? void 0 : r.call(a, s)])
            }), F(s, f)
        }
    });
export {
    _ as V
};