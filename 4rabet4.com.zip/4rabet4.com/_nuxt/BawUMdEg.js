(function() {
    try {
        var t = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            e = new t.Error().stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "17401faa-6ec3-48f3-ad06-9bc27b3e1e22", t._sentryDebugIdIdentifier = "sentry-dbid-17401faa-6ec3-48f3-ad06-9bc27b3e1e22")
    } catch {}
})();
const a = {
    $vuetify: {
        open: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Open"
            }
        },
        close: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Close"
            }
        },
        input: {
            appendAction: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Append"
                }
            }
        }
    },
    buttons: {
        email: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Email"
            }
        },
        phone: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Phone"
            }
        },
        showMore: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Show more..."
            }
        },
        roleUp: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Role up"
            }
        },
        checkPromoCode: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Check a promo code"
            }
        },
        clearSlip: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Clear a bet slip"
            }
        },
        deposit: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Deposit"
            }
        },
        goToHome: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Go to Homepage"
            }
        },
        playWithoutBonus: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play without bonus"
            }
        },
        outcome: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Withdraw"
            }
        },
        withdrawal: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Withdrawal"
            }
        },
        placeBet: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Place a bet"
            }
        },
        recoverPassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Recover a password"
            }
        },
        register: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Registration"
            }
        },
        send: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Send"
            }
        },
        signIn: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Sign in"
            }
        },
        signUp: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Sign up"
            }
        },
        goToAccount: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "My profile"
            }
        },
        completeProfile: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Сomplete my profile"
            }
        },
        completeProfileMsg: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Сomplete your profile to activate the bonus balance"
            }
        },
        reportProblem: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Report a problem"
            }
        },
        googleAccount: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Google account"
            }
        },
        fbAccount: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter with facebook"
            }
        },
        telegramAccount: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter with telegram"
            }
        },
        check: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Check"
            }
        },
        reset: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Reset"
            }
        },
        apply: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Apply"
            }
        },
        changeToRealBalance: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Change on real balance"
            }
        },
        noThanks: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "No, Thanks"
            }
        },
        okButton: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Ok"
            }
        },
        confirmEmail: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Confirm the email"
            }
        },
        getBonus: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Get bonus"
            }
        },
        next: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Next"
            }
        },
        show: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Show"
            }
        },
        hide: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Hide"
            }
        },
        back: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Back"
            }
        },
        copy: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Copy"
            }
        },
        cancel: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Cancel"
            }
        },
        confirm: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Confirm"
            }
        },
        updateData: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Update data"
            }
        },
        play: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play"
            }
        },
        demo: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Demo"
            }
        },
        activeBonuses: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Active Bonuses"
            }
        },
        bonusesList: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bonuses list"
            }
        },
        details: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Details"
            }
        },
        proceed: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Proceed"
            }
        },
        yes: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Yes"
            }
        },
        no: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "No"
            }
        },
        readMore: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Read more"
            }
        },
        readLess: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Read less"
            }
        },
        onRealBalance: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Change to real balance"
            }
        },
        continue: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Continue"
            }
        },
        gotoProfile: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Go to Profile"
            }
        },
        verify: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Verify"
            }
        },
        resend: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Resend"
            }
        },
        promoCode: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Promo code"
            }
        },
        showAll: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Show All"
            }
        },
        games: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Games"
            }
        },
        checkStatus: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "check status"
            }
        },
        availableNow: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Available Now"
            }
        },
        playAnyway: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play anyway"
            }
        },
        useRealBalance: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play using real balance"
            }
        },
        saveBonus: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "No, save the bonus money"
            }
        },
        refresh: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Refresh"
            }
        },
        unsubscribe: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Unsubscribe"
            }
        },
        changePassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Change password"
            }
        },
        download: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Download"
            }
        }
    },
    dialogs: {
        auth: {
            tip: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Fill your email and password"
                }
            },
            social: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Enter with social"
                }
            },
            remember: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Don’t remember?"
                }
            }
        },
        registration: {
            bonus: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Choose your bonus"
                }
            },
            welcome_bonus: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Your welcome bonus"
                }
            },
            confirm1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "I confirm that I am informed and<br> completely agree"
                }
            },
            min_deposit: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "The minimum deposit to activate the bonus is"
                }
            },
            max_deposit: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "(max. bonus is"
                }
            },
            or: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "OR"
                }
            },
            havePromoCode: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "I have a promo code"
                }
            },
            sign_up_with_google: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "SIGN UP WITH GOOGLE"
                }
            },
            login_with_google: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "LOGIN WITH GOOGLE"
                }
            },
            google_text_1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Account with this email already exists. Please log in using this email and password."
                }
            },
            google_text_2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Account with this email was already registered via Google."
                }
            },
            google_text_3: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Choose Welcome bonus"
                }
            },
            google_text_4: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "USE BONUS"
                }
            },
            google_text_5: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Account with this phone number already exists. Please log in using this phone number and password."
                }
            },
            google_text_6: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Account with this email and phone number already exists. Please log in using these credentials."
                }
            },
            user_already_registered: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "The user is already registered. <br /> Do you want to log in?"
                }
            },
            popup_phone_error: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 4,
                        k: "mentionedPhone"
                    }, {
                        t: 3,
                        v: " phone number already exists"
                    }]
                }
            },
            popup_email_error: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 4,
                        k: "mentionedEmail"
                    }, {
                        t: 3,
                        v: " email already exists"
                    }]
                }
            },
            terms_of_user_agreement: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Terms of user agreement"
                }
            },
            over18: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "and that I am over 18"
                }
            },
            agreement0: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "I confirm all the"
                }
            },
            agreement1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "I confirm that I am informed and completely agree with the rules of bets 'acceptance and wins' pay-outs, rules of gambling games."
                }
            },
            agreement2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "I confirm that I am of legal age."
                }
            },
            subCheckBox: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "I want to receive newsletters and be updated on 4rabet news, events and offers."
                }
            }
        },
        reset: {
            tip: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Fill your email and we send you new password"
                }
            },
            tipPhone: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Please fill in your phone number below to get a new password"
                }
            }
        },
        resetdialog: {
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Dear user! You can`t use current balance in this section. Please change to real balance."
                }
            }
        },
        zeroBalance: {
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Dear user! Your bonus balance are zero. Please change to real balance"
                }
            }
        },
        checkBonusType: {
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Dear user, in this section you cannot use funds from the current bonus account, please choose another account"
                }
            }
        },
        successWithdraw: {
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "It will be done within 24 hours, but we are doing our best to make it happen faster. Thanks for understanding."
                }
            },
            text_2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Please note the withdrawal amount is deducted from your balance only once your request is moderated."
                }
            }
        },
        successWithdrawTitle: {
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "The payment is successfully ordered"
                }
            }
        },
        confirmDialog: {
            subText: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Do you want to receive newsletters and be updated on 4rabet news, events and offers?"
                }
            },
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Only users who have passed the email verification can withdraw, at the moment your email is not confirmed"
                }
            }
        },
        confirmDialog2: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Promocode"
                }
            },
            subtitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "You activate <br /> Free Bet Promocode"
                }
            },
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "If you confirm promo code, bonuses will not be available."
                }
            }
        },
        infoDialog: {
            text1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Dear users we know about the issue with money withdrawals."
                }
            },
            text2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "We are working hard at the moment to resolve the issue."
                }
            },
            text3: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Withdrawals will be available soon as only we fix the problem."
                }
            },
            text4: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "It is also possible that the display of withdrawals in history is incorrect, but don’t worry all your money are safe, soon it will be shown correctly."
                }
            },
            text5: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "We apologize for any inconvenience caused."
                }
            }
        },
        infoHistory: {
            text1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Dear users we know about the issue with previous bets."
                }
            },
            text2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "We are working hard at the moment to resolve the issue."
                }
            },
            text3: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: " All your old bets will be resolved and you will receive your wins."
                }
            },
            text4: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "All new bets will be calculated fast and will not be effected."
                }
            },
            text5: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "We apologize for any inconvenience caused."
                }
            }
        },
        refresh: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Refresh the page"
                }
            },
            body: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Please refresh the page to run the latest version of 4rabet"
                }
            }
        },
        bonusDialog: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Choosing of a bonus"
                }
            },
            deposit: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Deposit"
                }
            },
            get: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Get"
                }
            },
            sum: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Sum"
                }
            },
            minimum: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Minimum"
                }
            },
            toAccount: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "To the account"
                }
            },
            bonus: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Bonus"
                }
            },
            rules: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Rules"
                }
            }
        },
        depositBonus: {
            btnOpen: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Open Deposit Bonus Dialog"
                }
            },
            btnGetBonus: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Get Bonus"
                }
            },
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Welcome, Dear User!"
                }
            }
        },
        emailConfirmation: {
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Email verified"
                }
            },
            expired: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Your email confirmation link has expired"
                }
            }
        },
        wagerNotification: {
            text1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Dear user, according to our rules, for withdrawal from our platform you need to make a 100% turnover of your deposit."
                }
            },
            text2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "For example, if you made a deposit of 300 Pakistani rupee, then you should place bets of 300 Pakistani rupee, bets can be placed both in the casino and in the bookmaker (the minimum coefficient is 1.3). As soon as you place bets, a withdrawal will be immediately available to you."
                }
            },
            text3: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Left to place:"
                }
            },
            pak_rupee: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Pakistani rupee"
                }
            },
            inr_rupee: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Indian rupee"
                }
            }
        },
        withdrawOnceDay: {
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Submitting a withdrawal request is available only once every 24 hours"
                }
            }
        },
        countryBlock: {
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "This resource is not accessible from your country."
                }
            }
        },
        userBlock: {
            text: {
                t: 0,
                b: {
                    static: "",
                    t: 2,
                    i: []
                }
            }
        },
        withdrawBonusBalance: {
            message: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "If you request a withdrawal of funds, your bonus will be deactivated. Are you sure you want to request a withdrawal of funds?"
                }
            },
            attention_with_bonus_amount: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: 'Attention! If you request a withdrawal of funds, you will lose your <span class="bonuses-balance">'
                    }, {
                        t: 4,
                        k: "amount"
                    }, {
                        t: 3,
                        v: " "
                    }, {
                        t: 4,
                        k: "currency"
                    }, {
                        t: 3,
                        v: "</span> bonus money! <br> <br> Are you sure you want to continue?"
                    }]
                }
            },
            attention_without_bonus_amount: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Attention! If you request a withdrawal of funds, you will lose your bonus money! <br> <br> Are you sure you want to continue?"
                }
            }
        },
        deposit: {
            titleIPL: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Welcome pack 700% <br> for new customers"
                }
            },
            titleCwc23: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "welcome pack 600% <br> up to 60000₹ <br> for new customers"
                }
            },
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "WELCOME, DEAR USER!"
                }
            },
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Don’t miss a chance to double your balance with special first deposit bonus!"
                }
            },
            redirect: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "The next step requires opening the web page of the chosen payment system"
                }
            },
            QRandUTR: {
                stepOneTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Step 1"
                    }
                },
                stepTwoTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Step 2"
                    }
                },
                stepOneDescription: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Please upload the QR code to your favorite UPI app or send the money to provided UPI id"
                    }
                },
                stepTwoDescription: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: 'Activate your deposit by entering the UTR and pressing the "Deposit" button'
                    }
                }
            }
        },
        promoConfirmation: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "You activate <br> Free Bet Promocode"
                }
            },
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "If you confirm promo code, bonuses will not be available."
                }
            }
        },
        promocodeDialog: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Congratulations!"
                }
            },
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "You have received <strong>"
                    }, {
                        t: 4,
                        k: "amountBonus"
                    }, {
                        t: 3,
                        v: " "
                    }, {
                        t: 4,
                        k: "currencyBonus"
                    }, {
                        t: 3,
                        v: "</strong> of Bonus Free Money For more information on the bonus wagering terms, please visit the Active Bonuses page"
                    }]
                }
            }
        },
        bonusInstruction: {
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Please note that a bonus balance is available for you. It can be activated by selecting it from the profile menu."
                }
            }
        },
        wagerNoPossible: {
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Please note that wagering of your active bonus balance is not possible in this game."
                }
            },
            description: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "For more information check your bonus description."
                }
            }
        },
        slotBonusBlock: {
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "You cannot wager this bonus balance in this game"
                }
            }
        },
        changeBalanceForSlot: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Changing the balance will reset the game. <br> Are you sure you want to change the balance?"
            }
        },
        downTime: {
            infoText: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Dear user, casino section is temporarily undergoing technical works. We apologize for the inconvenience. At the moment, we have TV Games section available! <br> <br> You can also contact the live chat of the support service and get compensation for the inconvenience.<br> <br> Best regards, 4rabet team"
                }
            },
            btn: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "TV Games"
                }
            }
        },
        gameSlotPromo: {
            message: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Please log in or register to play the game"
                }
            },
            signIn: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "sign in"
                }
            },
            signUp: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "sign up"
                }
            }
        },
        appInstall: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Its time to Update"
                }
            },
            oldApp: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Old application will <b>not</b> be supported soon!"
                }
            },
            description: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "<span>Download</span> newest official <span>4rabet app</span> to continue enjoying your favourite games including aviator and cricket betting"
                }
            },
            massage: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "If the application did not download after clicking the button, simply copy this link and open it in your browser"
                }
            },
            yourLink: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Your link is"
                }
            },
            linkCopied: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Link copied"
                }
            },
            copy: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Copy"
                }
            }
        }
    },
    footer: {
        links: {
            odds: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "4rabet Odds & Predictions"
                }
            },
            iplApp: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "4Rabet App"
                }
            },
            affiliateProgram: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Affiliate program"
                }
            },
            generalTermsAndConditions: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Terms and conditions"
                }
            },
            licenceAgreement: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "End-user licence agreement"
                }
            },
            privacyPolicy: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Privacy Policy"
                }
            },
            responsibleGaming: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Responsible Gaming Policy"
                }
            },
            bonusTerms: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Bonus Terms"
                }
            },
            rulesOnSeparateSports: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Rules on a separate sport"
                }
            },
            rulesForSpecific: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Rules for Specific sports"
                }
            },
            onlineBettingInIndia: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Online Betting in India"
                }
            },
            footballBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Football Betting"
                }
            },
            basketballBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Basketball Betting"
                }
            },
            tennisBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Tennis Betting"
                }
            },
            tableTennisBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Table Tennis Betting"
                }
            },
            baseballBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Baseball Betting"
                }
            },
            cricketBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Cricket Betting"
                }
            },
            horseRacingBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Horse Racing Betting"
                }
            },
            liveBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Live Betting"
                }
            },
            liveCricketBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Live Cricket Betting"
                }
            },
            onlineCasino: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Online Casino"
                }
            },
            onlineCasinoBonus: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Online Casino Bonus"
                }
            },
            freeSlots: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Free Slots"
                }
            },
            noDepositBonus: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "No Deposit Bonus"
                }
            },
            freeSpins: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Free Spins"
                }
            },
            onlineSlots: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Online Slots"
                }
            },
            mobileSlots: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Mobile Slots"
                }
            },
            newGames: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "New Games"
                }
            },
            videoPoker: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Video Poker"
                }
            },
            onlineBlackjack: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Online Blackjack"
                }
            },
            onlineRoulette: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Online Roulette"
                }
            },
            americanRoulette: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "American Roulette"
                }
            },
            frenchRoulette: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "French Roulette"
                }
            },
            liveRoulette: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Live Roulette"
                }
            },
            onlineKeno: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Online Keno"
                }
            },
            onlineBingo: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Online Bingo"
                }
            },
            liveCasino: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Live Casino"
                }
            },
            virtualSportsBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Virtual Sports Betting"
                }
            },
            jokerPoker: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Joker Poker"
                }
            },
            iplCricketBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "IPL Cricket Betting"
                }
            },
            liveIplCricketBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Live IPL Cricket Betting"
                }
            },
            "4rabetReview": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "4rabet Review"
                }
            },
            iplBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "IPL Betting"
                }
            },
            liveIplBetting: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Live IPL Betting"
                }
            },
            onlineBaccarat: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Online Baccarat"
                }
            },
            amlKycPolicy: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "AML/KYC Policy"
                }
            },
            news: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "News"
                }
            }
        },
        socials: {
            android: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Android App"
                }
            },
            ios: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Ios App"
                }
            }
        },
        about: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: '<a href="'
                }, {
                    t: 4,
                    k: "domain"
                }, {
                    t: 3,
                    v: '" class="footer__link">4rabet.com</a> is owned and operated by New Entertainment Development N.V., with its address at Abraham de Veerstraat 9, Curaçao. You acknowledge that, unless stated otherwise, the Games are organized in Curaçao and your participation in these Games takes place within the aforementioned territory. Any contractual relationships between you and New Entertainment Development N.V. shall be deemed to have been entered into and performed by the parties in Curaçao, at the registered address of Abraham de Veerstraat 9, Curaçao. The parties agree that any dispute, controversy or claim arising out of or in connection with these Terms and Conditions, or the breach, termination or invalidity thereof, shall be submitted to the exclusive jurisdiction of courts of Curaçao.'
                }]
            }
        },
        address1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Company: Umbrella Development B.V. Address:"
            }
        },
        address2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Curaçao, Chuchubiweg 17."
            }
        },
        address3: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: 'Support mail: <a href="mailto:support@4rabet.com" class="footer__link">support@4rabet.com</a>'
            }
        },
        copyright: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Copyright © "
            }
        },
        reservedAndProtected: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "All rights are reserved and protected by law"
            }
        },
        license: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Cyrasao Licence"
            }
        },
        businessPurposes: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Business purposes"
            }
        },
        seoTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4RABET official website: start to play casino & betting games"
            }
        }
    },
    labels: {
        acceptBetAny: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Accept a bet with any odd"
            }
        },
        accountName: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Account name"
            }
        },
        accountNumber: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Account number"
            }
        },
        accumulator: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Accumulator"
            }
        },
        alreadyRegistered: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Already registered?"
            }
        },
        bets: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bets"
            }
        },
        bonus: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bonus"
            }
        },
        category: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Category"
            }
        },
        changePassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Change password"
            }
        },
        choosePlaceBet: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose an odd to place a bet"
            }
        },
        coefChange: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The odd was changed"
            }
        },
        confirmPassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Repeat password"
            }
        },
        confirmRules: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "I confirm that I am informed and completely agree with the rules of bets 'acceptance and wins' pay-outs, rules of gambling games."
            }
        },
        chooseDefault: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose as Default"
            }
        },
        day: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Day"
            }
        },
        email: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "E-mail"
            }
        },
        enterEmail: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter your email"
            }
        },
        ifscCode: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "IFSC code"
            }
        },
        logOut: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Logout"
            }
        },
        maxBet: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Maximal bet - "
            }
        },
        maximalRate: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Maximal rate"
            }
        },
        minBet: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Minimal bet - "
            }
        },
        month: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Month"
            }
        },
        name: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Name"
            }
        },
        birthDay: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Birthday"
            }
        },
        newPassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "New password"
            }
        },
        noAccount: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Don't have an account?"
            }
        },
        oldPassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Old password"
            }
        },
        overallOdd: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Overall odd"
            }
        },
        pageNotFound: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Page not found"
            }
        },
        phone: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Phone"
            }
        },
        provider: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Provider"
            }
        },
        save: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Save"
            }
        },
        saveAll: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Save All"
            }
        },
        gender: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Gender"
            }
        },
        city: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "City"
            }
        },
        country: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Country"
            }
        },
        selectLang: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Language"
            }
        },
        single: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Single"
            }
        },
        sum: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Sum"
            }
        },
        surname: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Surname"
            }
        },
        viaEmail: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Via e-mail"
            }
        },
        win: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Win"
            }
        },
        year: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Year"
            }
        },
        showFavoritesOnly: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Show favorites only"
            }
        },
        disablesBonuses: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "You have already used the promo code!"
            }
        },
        confirm: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "* Please, confirm your email"
            }
        },
        emailConfirmed: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Email Confirmed"
            }
        },
        confirmed: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Confirmed"
            }
        },
        paidOut: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "paid out"
            }
        },
        phoneNumber: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Phone number"
            }
        },
        phoneValidation: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Phone number must be valid"
            }
        },
        example: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Example :"
            }
        },
        firstPart: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "UP TO"
            }
        },
        secondPart: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "ON FIRST DEPOSIT"
            }
        },
        regBanner: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "On the best innovate sportsbook and casino"
            }
        },
        regBannerNew: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: 'Join us for THE BIG <span style="color: #FAFF00">WINNING</span> DAYS with exclusive casino betting events!'
            }
        },
        authBanner: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Welcome back!"
            }
        },
        confirmOld: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Confirm that you are 18"
            }
        },
        waitingDeposit: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Waiting for deposit"
            }
        },
        activated: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Activated"
            }
        },
        expired: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Expired"
            }
        },
        incorrect: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Incorrect"
            }
        },
        phoneVerification: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Use the code sent to your phone number"
            }
        },
        phoneConfirmed: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Phone confirmed"
            }
        },
        new: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "NEW"
            }
        },
        openInNewTab: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Open in new window"
            }
        }
    },
    menu: {
        blog: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Blog"
            }
        },
        bonuses: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bonuses"
            }
        },
        activeBonuses: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Active Bonuses"
            }
        },
        casino: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Casino"
            }
        },
        depositWithdraw: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Deposit/Withdrawal"
            }
        },
        help: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Help"
            }
        },
        line: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "SPORTS"
            }
        },
        footerLine: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Line"
            }
        },
        live: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "LIVE"
            }
        },
        main: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Main"
            }
        },
        cricket: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Cricket"
            }
        },
        ipl: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "IPL"
            }
        },
        liveCasino: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live Dealers"
            }
        },
        liveDealers: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live Dealers"
            }
        },
        plinko: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Plinko"
            }
        },
        personalAccount: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Personal Data"
            }
        },
        tvGames: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "TV Games"
            }
        },
        virtualSport: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual Sports"
            }
        },
        cyberSport: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "eSport"
            }
        },
        Baccarat: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Baccarat LIVE"
            }
        },
        aviator: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Aviator"
            }
        },
        crazyTime: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Crazy Time"
            }
        },
        downloadApp: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Download app"
            }
        },
        chooseEveryDay: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose from over 1000 teams available every day!"
            }
        },
        football: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Football"
            }
        },
        sport: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Sport"
            }
        },
        rewards: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "levelUP"
            }
        },
        chat: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Chat"
            }
        },
        new: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "NEW"
            }
        },
        mainTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Main"
            }
        },
        icc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "ICC 2025"
            }
        }
    },
    mobileMenu: {
        menu: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Menu"
            }
        },
        personalData: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Personal data"
            }
        },
        deposit: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Deposit"
            }
        },
        depositInfo: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Deposit Info"
            }
        },
        bonuses: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bonuses"
            }
        },
        tvGames: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "TV games"
            }
        },
        blog: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Blog"
            }
        },
        history: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "History"
            }
        },
        help: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Help"
            }
        },
        settings: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Settings"
            }
        },
        verification: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Verification"
            }
        },
        rules: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Rules"
            }
        },
        enterSlotName: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter slots name"
            }
        },
        chooseCountry: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose your country..."
            }
        },
        chooseCity: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose your city..."
            }
        },
        enterSurname: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter your Surname"
            }
        },
        enterName: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter your Name"
            }
        },
        chooseGender: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose your gender..."
            }
        },
        enterBirthday: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter your birthday..."
            }
        },
        enterPass: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter pass..."
            }
        },
        ourApplications: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Our applications"
            }
        }
    },
    breadcrumbs: {
        casino: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "casino"
            }
        },
        "live-dealers": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "live-dealers"
            }
        },
        "tv-games": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "tv-games"
            }
        },
        category: {
            popular: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "popular"
                }
            },
            "new-games": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "new-games"
                }
            },
            slots: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "slots"
                }
            },
            baccarat: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "baccarat"
                }
            },
            roulette: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "roulette"
                }
            },
            blackjack: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "blackjack"
                }
            },
            table: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "table"
                }
            },
            board: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "board"
                }
            },
            lottery: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "lottery"
                }
            },
            "video-poker": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "video-poker"
                }
            },
            keno: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "keno"
                }
            },
            bingo: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "bingo"
                }
            },
            other: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "other"
                }
            }
        }
    },
    placeholders: {
        all: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "All"
            }
        },
        email: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Email"
            }
        },
        password: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Password"
            }
        },
        promoCode: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Promo code (if you have)"
            }
        },
        promoCodeThirdType: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Add promo code here"
            }
        },
        repeatPassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Repeat the password"
            }
        },
        search: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Search"
            }
        },
        enterSlotName: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Search"
            }
        },
        chooseCountry: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose your country..."
            }
        },
        chooseCity: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose your city..."
            }
        },
        enterSurname: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter your Surname"
            }
        },
        enterName: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter your Name"
            }
        },
        chooseGender: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose your gender..."
            }
        },
        enterBirthday: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter your birthday..."
            }
        },
        enterPass: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter pass..."
            }
        }
    },
    profile: {
        contactSupport: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "contact support"
            }
        },
        updateConsidered: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Please wait while your change request will be considered"
            }
        },
        changeData: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "If you have a necessity to change data in some fields which are not editable - please "
            }
        },
        balance: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Balance"
            }
        },
        wager: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Wager"
            }
        },
        default: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Default"
            }
        },
        male: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Male"
            }
        },
        female: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Female"
            }
        },
        other: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Other"
            }
        },
        profileAccept: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "By checking this box I accept the Terms and Conditions, Privacy policy and confirm that I am over 18 years of age."
            }
        },
        wrongOldPassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "You entered an incorrect Old password"
            }
        },
        invalidRecoveryToken: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "You have already used this link to recover your password"
            }
        },
        "phone-tip": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The phone number should be at least 7 digits"
            }
        },
        profileUpdated: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The profile was updated"
            }
        },
        passwordUpdated: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The password was updated"
            }
        },
        passwordRecovery: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "A password recovery email has been sent to your email address"
            }
        },
        passwordRecoveryPhone: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "A password recovery sms has been sent to your phone number"
            }
        },
        passwordRestored: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The password was restored"
            }
        },
        emailToYou: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "We sent a mail to your email"
            }
        },
        withdraw: {
            makeDeposit: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Make Deposit"
                }
            },
            orderPayment: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Order the payment"
                }
            },
            paymentMethod: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Select payment method and amount"
                }
            },
            itemsTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Choose a withdrawal method2"
                }
            },
            amount: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Amount"
                }
            },
            availableCash: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Available withdrawal: (from 500 to 250 000)"
                }
            },
            availableCashPaytm: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Available withdrawal: (from 500 to 40 000)"
                }
            },
            availableCashFrom: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Available withdrawal: (from "
                }
            },
            availableCashTo: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: " to "
                }
            },
            availableCashCubix: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Available withdrawal: (from 1000 to 100 000)"
                }
            },
            availableCashPkr: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Available withdrawal: (from 2000 to 250 000)"
                }
            },
            availableCashKes: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Available withdrawal: (minimum 100)"
                }
            },
            availableCashBdt: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Available withdrawal: (from 1000 to 30 000)"
                }
            },
            availableCashUzs: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Available withdrawal: (from 75000 to 5 000 000)"
                }
            },
            onRealBalance: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "On real balance"
                }
            },
            withdrawText: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Dear player! In order to avoid fraud you need to wager the amount of your deposit at least one time placing bets with the odd equivalent 1.01 or higher. Exactly the amount for which you have placed bets will be available for you for withdrawal. Once you have placed bets on the amount of your deposit, you can withdraw as much money as you want."
                }
            },
            notAvailableWithdraw: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Unfortunately, there is no way for your country to withdraw funds at this time. We are aware of this problem and are taking all measures to correct it. To withdraw funds now - write to the support service."
                }
            },
            processingTime: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: 'Processing time for withdrawal up to 24 hours after you clicked "withdraw", please wait for payment'
                }
            },
            requestLimit: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Withdrawal requests limit is exceeded"
                }
            },
            timerLimit: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "AVAILABLE IN"
                }
            }
        },
        operations: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Operations"
                }
            },
            confirm: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Confirm"
                }
            }
        },
        deposit: {
            all: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "All"
                }
            },
            recommended: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Recommended"
                }
            },
            bankCards: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Bank cards"
                }
            },
            ewallet: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "E-Wallet"
                }
            },
            mobilePayment: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Mobile Payment"
                }
            },
            paymentSystems: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Payment Systems"
                }
            },
            internetBanking: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Internet Banking"
                }
            },
            cryptocurrency: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Cryptocurrency"
                }
            }
        },
        bonuses: {
            enterPromoCode: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Enter your Promocode"
                }
            },
            all: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "All"
                }
            },
            sports: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Sports"
                }
            },
            casino: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Casino"
                }
            },
            activated: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Activated"
                }
            },
            pending: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Pending"
                }
            },
            silver: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Silver"
                }
            },
            wagerPlayed: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Wager played"
                }
            },
            cancelBonuses: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Cancel bonus"
                }
            },
            conditions: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Conditions"
                }
            },
            listIsEmpty: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "List is empty"
                }
            },
            cancelMessage: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Do you want to cancel this bonus?"
                }
            },
            cancelSelectedBonus: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Do you want to cancel your selected bonus?"
                }
            },
            additionallyBonus: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Additionally, you will receive on your bonus balance:"
                }
            },
            minAmountDepositBonus: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Min deposit to get the bonus: "
                }
            },
            notDepCasinoTitleDescriptionINR: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Casino Welcome Bonus 100% up to 20,000 INR"
                }
            },
            notDepCasinoCardDescriptionINR: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Make a deposit and get up to 20,000 INR bonus for casino games"
                }
            },
            notDepCasinoTitleDescriptionPKR: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Casino Welcome Bonus 100% up to 40,000 PKR"
                }
            },
            notDepCasinoCardDescriptionPKR: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Make a deposit and get up to 40,000 PKR bonus for casino games"
                }
            },
            notDepCasinoTitleDescriptionBRL: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Casino Welcome Bonus 100% up to 2,000 BRL"
                }
            },
            notDepCasinoCardDescriptionBRL: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Make a deposit and get up to 2,000 BRL bonus for casino games"
                }
            },
            notDepSportTitleDescriptionINR: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Sports betting Welcome bonus 100% up to 15,000 INR"
                }
            },
            notDepSportCardDescriptionINR: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Make a deposit and get up to 15,000 INR on your bonus account"
                }
            },
            notDepSportTitleDescriptionPKR: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Sports betting Welcome bonus 100% up to 30,000 PKR"
                }
            },
            notDepSportCardDescriptionPKR: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Make a deposit and get up to 30,000 PKR on your bonus account"
                }
            },
            notDepSportTitleDescriptionBRL: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Sports betting Welcome bonus 100% up to 1,300 BRL"
                }
            },
            notDepSportCardDescriptionBRL: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Make a deposit and get up to 1,300 BRL on your bonus account"
                }
            },
            titleDescription: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Welcome bonus up to 50,000 kzt + 22 bet points for sports betting"
                }
            },
            cardDescription: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Make your first deposit and get a 100% bonus up to 50,000 KZT and 22 Bet Points"
                }
            },
            not_available: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Game does not work with bonus balance."
                }
            },
            activation_message: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "In order to activate “"
                    }, {
                        t: 4,
                        k: "bonusName"
                    }, {
                        t: 3,
                        v: "” you need to have less than "
                    }, {
                        t: 4,
                        k: "sum"
                    }, {
                        t: 3,
                        v: " "
                    }, {
                        t: 4,
                        k: "currency"
                    }, {
                        t: 3,
                        v: " on your real balance"
                    }]
                }
            },
            timer: {
                timesUp: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Time's Up!"
                    }
                }
            },
            freebet: {
                title: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Freebet Bonus"
                    }
                },
                text: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Congratulations! You have received freebet bonus! Enjoy playing with 4RABET!"
                    }
                }
            },
            ipl: {
                title: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Welcome Cricket!"
                    }
                },
                text: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Bonus 100% up to"
                    }
                }
            },
            activeBonusCard: {
                remainToWager: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "REMAIN TO WAGER"
                    }
                },
                days: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "DAYS"
                    }
                },
                hours: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "HOURS"
                    }
                },
                mins: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "MINS"
                    }
                },
                secs: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "SECS"
                    }
                }
            }
        },
        menu: {
            bonus: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Bonus"
                }
            },
            deposits: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Deposits"
                }
            },
            depositWithdraw: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Deposit/Withdrawal"
                }
            },
            historyDeposits: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "History of deposits"
                }
            },
            historyPay: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "History of pay-outs"
                }
            },
            historyWithdrawals: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "History of withdrawals"
                }
            },
            myBets: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "My bets"
                }
            },
            myProfile: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Profile"
                }
            },
            myHistory: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Payments history"
                }
            },
            myBetsHistory: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Bets history"
                }
            },
            cashInCashOut: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Cash in/cash out"
                }
            },
            rules: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Rules"
                }
            }
        },
        tabs: {
            activated: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Active"
                }
            }
        },
        history: {
            statusFilters: {
                all: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "All Bets"
                    }
                },
                pending: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Open"
                    }
                },
                approved: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Wins"
                    }
                },
                declined: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Lost"
                    }
                },
                cancelled: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Returned"
                    }
                }
            },
            periodFilters: {
                all: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "All Time"
                    }
                },
                tweek: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Current Week"
                    }
                },
                lweek: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Last Week"
                    }
                },
                month: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Last Month"
                    }
                },
                last_3_months: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Last 3 Months"
                    }
                }
            },
            sport: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Sports"
                }
            },
            casino: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Casino"
                }
            }
        }
    },
    statuses: {
        verified: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Verified"
            }
        },
        onCheck: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "On check"
            }
        },
        rejected: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Rejected"
            }
        },
        sent: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Sent"
            }
        },
        inProgress: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "In process"
            }
        },
        won: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Won"
            }
        },
        lose: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Lose"
            }
        },
        notCalculated: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Not calculated"
            }
        },
        coming_soon: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Coming soon"
            }
        },
        available: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Available for"
            }
        },
        waiting_deposit: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Waiting for deposit"
            }
        },
        list_empty: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "List is empty"
            }
        }
    },
    historyStatuses: {
        IN_PROCESSING: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "In processing"
            }
        },
        PAID_OUT: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Paid out"
            }
        },
        CANCELLED: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Cancelled"
            }
        },
        CREATED: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Created"
            }
        },
        CLOSED: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Closed"
            }
        },
        DECLINED: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Declined"
            }
        },
        VERIFICATION_DECLINED: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Verification declined"
            }
        }
    },
    tables: {
        header: {
            id: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "ID"
                }
            },
            dateTime: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Date/Time"
                }
            },
            token: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Token"
                }
            },
            system: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "System"
                }
            },
            requisites: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Requisites"
                }
            },
            account_number: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Account Number"
                }
            },
            description: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Description"
                }
            },
            status: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Status"
                }
            },
            count: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "FREE SPINS"
                }
            },
            countLeft: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "LEFT"
                }
            },
            bet: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "BET"
                }
            },
            earned: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "EARNED FROM SPINS"
                }
            },
            wager: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Wager"
                }
            },
            name: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Name"
                }
            },
            type: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Type"
                }
            },
            info: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Info"
                }
            },
            amount_received: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Amount Received"
                }
            },
            transfer_to_real_balance: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Transfer To Real Balance"
                }
            }
        }
    },
    titles: {
        noAvailableSlots: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "There are no available slots"
            }
        },
        enterPromocode: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter your Promocode"
            }
        },
        enterNewPassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter new password"
            }
        },
        unsubscribeFromMailing: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Unsubscribe from mailing"
            }
        },
        loadingBanner: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Loading banner"
            }
        },
        noDataAvailable: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "No data available"
            }
        },
        noActiveBonuses: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "No active bonuses"
            }
        },
        bonuses: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bonuses"
            }
        },
        active: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Active"
            }
        },
        bonusHistory: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bonuses history"
            }
        },
        cupon: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet slip"
            }
        },
        deposits: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Select payment method and amount"
            }
        },
        historyPayments: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "History of payments"
            }
        },
        line: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Line"
            }
        },
        live: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live"
            }
        },
        casino: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Casino"
            }
        },
        liveCasino: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live Dealers"
            }
        },
        tvGames: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "TV Games"
            }
        },
        orderPayment: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Order the payment"
            }
        },
        personalData: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Personal data"
            }
        },
        recoverPassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Recover a password"
            }
        },
        registrationGamingAccount: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Registration of a gaming account"
            }
        },
        login: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Login"
            }
        },
        welcome: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Login with email, phone or social"
            }
        },
        altWelcome: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Welcome! Choose your bonus!"
            }
        },
        virtualSport: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual Sports"
            }
        },
        howToPlay: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "How to play at"
            }
        }
    },
    tabs: {
        betsHistory: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bets History"
            }
        },
        depositHistory: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Deposit History"
            }
        },
        withdrawalHistory: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Withdrawal History"
            }
        },
        sportBonuses: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Sport"
            }
        },
        casinoBonuses: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Casino"
            }
        },
        freeSpins: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Free Spins"
            }
        },
        allBonuses: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "All Bonuses"
            }
        }
    },
    categories: {
        categories: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Categories"
            }
        },
        allGames: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "All Games"
            }
        },
        liveDealers: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live Dealers"
            }
        },
        tvGames: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "TV Games"
            }
        },
        virtualSport: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual Sports"
            }
        },
        popular: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Popular"
            }
        },
        newGames: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "New Games"
            }
        },
        other: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Other"
            }
        },
        slots: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Slots"
            }
        },
        baccarat: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Baccarat"
            }
        },
        roulette: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Roulette"
            }
        },
        blackJack: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Black Jack"
            }
        },
        table: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Table"
            }
        },
        board: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Board"
            }
        },
        lottery: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Lottery"
            }
        },
        videoPoker: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Video Poker"
            }
        },
        keno: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Keno"
            }
        },
        bingo: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bingo"
            }
        }
    },
    casinoTags: {
        seeAll: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "See all"
            }
        },
        search: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Search"
            }
        },
        favorites: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Favorites"
            }
        },
        favorites_empty_text: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Add favorite games by clicking on the star"
            }
        },
        recommended: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Recommended"
            }
        }
    },
    rightMenu: {
        cricket: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Cricket"
            }
        },
        liveDealer: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Top Live Dealer"
            }
        },
        support: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Support"
            }
        },
        slots: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Slots"
            }
        },
        roulettes: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Roulettes"
            }
        },
        tutorials: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Tutorials"
            }
        }
    },
    casinoCategories: {
        crash: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Crash Games"
            }
        },
        other: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Other"
            }
        },
        vip: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "VIP Games"
            }
        },
        fast: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Fast Games"
            }
        },
        local: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Local Games"
            }
        },
        live: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live Games"
            }
        },
        exclusives: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4RABET Exclusives"
            }
        },
        keno: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Keno"
            }
        },
        bingo: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bingo"
            }
        },
        "video-poker": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Video Poker"
            }
        },
        lottery: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Lottery"
            }
        },
        board: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Board"
            }
        },
        blackjack: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Blackjack"
            }
        },
        roulette: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Roulette"
            }
        },
        baccarat: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Baccarat"
            }
        },
        slots: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Slots"
            }
        },
        "new-games": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "New Games"
            }
        },
        popular: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Popular"
            }
        },
        table: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Table"
            }
        },
        "virtual-soccer": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual Soccer"
            }
        },
        "virtual-tennis": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual Tennis"
            }
        },
        "virtual-basketball": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual Basketball"
            }
        },
        "virtual-dog-racing": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual dog racing"
            }
        },
        "virtual-horses": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual Horses"
            }
        },
        "virtual-baseball": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual Baseball"
            }
        },
        "virtual-racing": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual Racing"
            }
        },
        "virtual-golf": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual Golf"
            }
        },
        evolution: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Evolution"
            }
        },
        "local-tables": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Local Tables"
            }
        },
        "vip-tables": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "VIP Tables"
            }
        },
        game_shows: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Game Shows"
            }
        },
        virtual_sports: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual Sports"
            }
        }
    },
    h1Text: {
        "/casino/bingoH1text": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The Best Casino Bingo Games Collection from 4Rabet"
            }
        },
        "/casino/video-pokerH1text": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The Best Collection of the Video Poker Games for Avid Players"
            }
        },
        "/casino/blackjackH1text": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Blackjack Online Games – Play For Free and For Real Money"
            }
        },
        "/casino/new-gamesH1text": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "New Casino Games and Slots by 4Rabet.com"
            }
        },
        "/live-dealers/new-gamesH1text": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Full List of New Live Dealer Games for the 4Rabet Players"
            }
        },
        "/tv-gamesH1text": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The Best Online TV Games Exclusively for the 4Rabet Players"
            }
        },
        "/deposit-withdrawH1text": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Deposit or Withdraw Your Winnings – 4Rabet"
            }
        },
        "/rulesH1text": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Official Page for the 4Rabet Rules and Regulations"
            }
        },
        "/liveH1text": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Live Betting: Check the List of the Latest Live Games at 4Rabet Betting Company"
            }
        }
    },
    withdraw: {
        profileVerifIsNeeded: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Profile verification is needed"
            }
        },
        cryptoCurrency: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "To make payment, send "
                }, {
                    t: 4,
                    k: "type"
                }, {
                    t: 3,
                    v: " to address below."
                }]
            }
        },
        fiatCurrency: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "The funds sent will be converted into "
                }, {
                    t: 4,
                    k: "currency"
                }, {
                    t: 3,
                    v: ` after the transaction
        is confirmed by the blockchain and credited to the balance
        automatically. The blockchain commission is paid by the user.`
                }]
            }
        },
        depositAmont: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Please choose or enter deposit amount"
            }
        },
        enterAmount: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enter amount"
            }
        },
        minDeposit: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Min. deposit:"
            }
        },
        maxDeposit: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Max. deposit:"
            }
        },
        bannerText1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Additionally, you will receive on your bonus balance: "
            }
        },
        bannerText2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Minimum amount to receive the bonus:"
            }
        },
        backText: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose other payment"
            }
        },
        fee: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Fee"
            }
        },
        totalAmount: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Total amount"
            }
        },
        totalAmountTextFee: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "Current withdrawal has a "
                }, {
                    t: 4,
                    k: "fee"
                }, {
                    t: 3,
                    v: "% fee"
                }]
            }
        },
        totalAmountTextFeeOnceDay: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "You are able to withdraw without a fee once a day. All the following withdrawals at the same day have a "
                }, {
                    t: 4,
                    k: "fee"
                }, {
                    t: 3,
                    v: "% fee"
                }]
            }
        },
        totalAmountTextFeeDay: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "You are able to withdraw without a fee "
                }, {
                    t: 4,
                    k: "day"
                }, {
                    t: 3,
                    v: " times a day. All the following withdrawals on the same day have a "
                }, {
                    t: 4,
                    k: "fee"
                }, {
                    t: 3,
                    v: "% fee"
                }]
            }
        },
        casmaAccumulated: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The payment is done for the sum of"
            }
        },
        casmaMinimal: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "But the minimal deposit is"
            }
        },
        casmaNeed: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Please, fill in the balance with another"
            }
        },
        balancePopup: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Switch your balances here"
            }
        },
        emailConfirm: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "To withdraw funds, please fill out your profile details and confirm your email."
            }
        },
        labels: {
            idNumber: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Identification number"
                }
            },
            name: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Your full name"
                }
            },
            zip: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "ZIP Code"
                }
            },
            email: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Email"
                }
            },
            phone: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Phone"
                }
            }
        },
        selectAmount: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Select amount"
            }
        },
        choicestPaymentType: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Сhoicest Payment type"
            }
        },
        limitText: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "You are able to order up to "
                }, {
                    t: 4,
                    k: "limit"
                }, {
                    t: 3,
                    v: " withdrawals every day!"
                }]
            }
        },
        alertText: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Do NOT use UPI to make a transaction. Deposit will NOT be accepted. Make the payment ONLY from your Paytm WALLET to our Paytm WALLET."
            }
        },
        withdrawLimits: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "Submitting a withdrawal request is available only "
                }, {
                    t: 4,
                    k: "limit"
                }, {
                    t: 3,
                    v: " times every 24 hours"
                }]
            }
        },
        fillAllProfileFields: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Unverified users can't withdraw funds from the account. Please, fill in all fields in your profile and confirm your e-mail and phone number."
            }
        },
        dearPlayerWithdrawMoney: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "Dear player! To withdraw money, you need to make bets in the amount of "
                }, {
                    t: 4,
                    k: "percent"
                }, {
                    t: 3,
                    v: "% of your deposit. Once you have done so, you are able to withdraw as much as you want."
                }]
            }
        },
        sport: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Sport"
            }
        },
        dearPlayerWithdrawMoney_text_1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "Odds should be "
                }, {
                    t: 4,
                    k: "value"
                }, {
                    t: 3,
                    v: " or higher (all losing bets count)"
                }]
            }
        },
        casino: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Casino"
            }
        },
        all_games: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "All games"
            }
        },
        remainingWager: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Remaining wager"
            }
        }
    },
    errors: {
        registration: {
            promoNotActive: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "This promo code is no longer active."
                }
            },
            promoNotExists: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "This promo code does not exist."
                }
            },
            promoNotActiveThirdType: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "This promo code is no longer active"
                }
            },
            promoNotExistsThirdType: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "This promo code does not exist"
                }
            },
            emptyPromo: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Enter promo code"
                }
            }
        },
        occured: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "An error occurred"
            }
        },
        somethingWentWrong: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Oops! Something went wrong"
            }
        },
        fillFullDate: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Fill full date"
            }
        },
        youMustBe18YearsOld: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "You must be 18 years old"
            }
        },
        cantSelectFutureDate: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Can't select a future date"
            }
        },
        incorrectData: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Incorrect data"
            }
        },
        freeSpinBalance: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "You can play this game only with casino bonus balance"
            }
        }
    },
    success: {
        registration: {
            isSuccessPromo: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Your promo code was successfully applied"
                }
            },
            isSuccessPromoThirdType: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Your promo code was successfully applied"
                }
            },
            completed: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "The registration completed successfully"
                }
            }
        },
        authentication: {
            completed: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Authentication was successful"
                }
            }
        }
    },
    deposit: {
        bonusPercent: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "You selected a bonus! <br> Make deposit and get "
                }, {
                    t: 4,
                    k: "percent"
                }, {
                    t: 3,
                    v: "%"
                }]
            }
        },
        freespinBonus: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "You selected a bonus!  <br> Make deposit and get "
                }, {
                    t: 4,
                    k: "freespins"
                }, {
                    t: 3,
                    v: " free spins"
                }]
            }
        },
        freespinDepositBonus: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Make deposit and get your bonus!"
            }
        },
        cryptoCurrency: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "If the deposit amount is less than the minimum amount, the funds will not be credited to the balance and cannot be refunded."
            }
        },
        informer: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "Balance replenishment usually takes about "
                }, {
                    t: 4,
                    k: "minValue"
                }, {
                    t: 3,
                    v: " "
                }, {
                    t: 4,
                    k: "minUnit"
                }, {
                    t: 3,
                    v: ", however, it could take up to "
                }, {
                    t: 4,
                    k: "maxValue"
                }, {
                    t: 3,
                    v: " "
                }, {
                    t: 4,
                    k: "maxUnit"
                }, {
                    t: 3,
                    v: " on rare occasions. If the funds haven't come to your balance in an hour, please contact technical support."
                }]
            }
        },
        balanceReplenished: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The balance replenished"
            }
        },
        changeAmount: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Change amount"
            }
        },
        supportForRedirectPayment: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "If the download is not completed, <a id='support'>contact support</a> or use another method"
            }
        },
        messengerTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Beware of scammers!"
            }
        },
        messengerBlock1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: 'We never write to users first. Operator will send you the deposit instructions only after clicking on the "Deposit via WhatsApp" button or after your direct inquiry to already existing WhatsApp chat with 4RABET'
            }
        },
        messengerFooterDesktopText: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: `Please scan the QR or click at "Deposit via WhatsApp" button to start the chat with 4RABET operator.
Please note that chat can be used only for deposits.`
            }
        },
        messengerFooterMobileText: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: `Please click at "Deposit via WhatsApp" button to start the chat with 4RABET operator.
Please note that chat can be used only for deposits.`
            }
        },
        whatsAppBtn: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Deposit via WhatsApp"
            }
        },
        step2: {
            phonePeTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Please send a deposit payment only to the specified PhonePe number. If you send a transfer to any other previous account, your deposit may be delayed for a long time."
                }
            },
            gpayTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: 'Send money to the our actual UPI account. Click on the "Next" and enter the transaction ID.'
                }
            },
            upiTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: 'Send money to the our actual UPI account. Click on the "Next" and enter the transaction ID.'
                }
            },
            helpText1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "The amount in"
                }
            },
            helpText2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "must be more than"
                }
            },
            helpText3: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "and less than"
                }
            },
            howMake: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "How to make a deposit?"
                }
            }
        },
        step3: {
            phonePeTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Specify the Transaction ID. Money will be credited to the account immediately. If your transaction is not found, please try again in a few minutes."
                }
            },
            gpayTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Specify the amount sent and Transaction ID. Money will be credited to the account immediately. If your transaction is not found, please try again in a few minutes."
                }
            },
            upiTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Specify the amount sent and Transaction ID. Money will be credited to the account immediately. If your transaction is not found, please try again in a few minutes."
                }
            }
        },
        step4: {
            titleQueue: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Attention"
                }
            },
            titleSuccess: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Processed successfully"
                }
            },
            titleFail: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Something <br> went wrong"
                }
            },
            textQueue: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "You can refresh current page to see an actual status of transaction."
                }
            },
            textSuccess: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Check your balance"
                }
            },
            textFail: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Check please card’s details and your balance, <br> after this please try again."
                }
            },
            btnTextQueue: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "main page"
                }
            },
            btnTextSuccess: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "main page"
                }
            },
            btnTextFail: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Try again"
                }
            },
            titleFailDeposit: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Payment has not been completed. <br /> Please try again now."
                }
            },
            textFailDeposit: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "An error occurred due to a bank issue. Select an alternative payment method to finalize your deposit."
                }
            },
            btnFailDeposit: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Try Again"
                }
            }
        },
        step7: {
            pix: {
                alertText: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Use only your bank account connected to previously mentioned CPF. Otherwise the deposit can NOT be accepted"
                    }
                },
                text: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Scan the QR or use the provided code to make a deposit via your bank app."
                    }
                }
            },
            picPay: {
                alertText: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Use only your PicPay account connected to previously mentioned CPF. Otherwise the deposit can NOT be accepted"
                    }
                },
                text: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Scan the QR above with the PicPay app, or click the button to make the paymen."
                    }
                }
            }
        },
        qrType: {
            text1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Please scan the provided QR with your camera or scanner app."
                }
            },
            text2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Choose your preferred UPI application and make the payment."
                }
            },
            text3: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "The money will be credited to the account immediately."
                }
            }
        },
        paykassmaAttention: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Attention"
            }
        },
        paykassmaChooseDesktopMethod: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Please choose your preferred UPI application to make the deposit"
            }
        },
        paykassmaChooseMobileMethod: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: 'Please come back and click "Check Status" button after making the payment in your UPI application'
            }
        },
        paykassmaQrTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: 'Please scan the provided QR and complete the payment using your UPI application. Click "Check Status" button after you finish the payment'
            }
        },
        paykassmaQrTitleMobile: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: 'Please make a screenshot of the provided QR. Open your favorite UPI app, upload the screenshot and confirm the payment. Click "Check Status" button after you finish the payment'
            }
        },
        bdPayTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Please make a screenshot of the QR and upload to your preferred UPI app or click at one of the wallet icons bellow"
            }
        },
        bdPayTitleWithoutLinks: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Please make a screenshot of the provided QR and upload to your preferred UPI app"
            }
        },
        completeAgain: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Kindly try to complete your deposit again, as it may not always be successful on the first attempt"
                }
            },
            text_1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Try using 2-3 alternative payment methods, as banks may sometimes experience downtimes."
                }
            },
            text_2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Ensure all the information you have entered is correct."
                }
            },
            text_3: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Make sure that you have enough money in your bank account to complete the deposit."
                }
            }
        },
        bdPayCheckText: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Click at “CHECK STATUS” button after you complete the payment"
            }
        }
    },
    notifications: {
        emailExist: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 4,
                    k: "mentionedEmail"
                }, {
                    t: 3,
                    v: " email already exists"
                }]
            }
        },
        phoneNumberError: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Phone number is not registered"
            }
        },
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Notifications"
            }
        },
        clearAll: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Clear All"
            }
        },
        readAll: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Read All"
            }
        },
        empty: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "No new notification"
            }
        },
        payoutsCancelForBet: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Withdrawal request canceled!"
                }
            },
            text: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Your withdrawal request ("
                    }, {
                        t: 4,
                        k: "amount"
                    }, {
                        t: 3,
                        v: ") has been canceled due to a low of money on your balance."
                    }]
                }
            }
        },
        freeSpin: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Dear user! You are awarded free rounds in the provider's games %s. Number of free rounds: %s"
            }
        },
        freeSpinGames: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: `Dear user! You are awarded free rounds in the provider's games <a href="`
                }, {
                    t: 4,
                    k: "domain"
                }, {
                    t: 3,
                    v: "/casino/slot/"
                }, {
                    t: 4,
                    k: "id"
                }, {
                    t: 3,
                    v: '">'
                }, {
                    t: 4,
                    k: "game"
                }, {
                    t: 3,
                    v: "</a>. Number of free rounds: "
                }, {
                    t: 4,
                    k: "spin"
                }]
            }
        },
        pageNoFound: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "This page could not be found"
            }
        },
        incorrectOldPassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "You entered an incorrect Old password"
            }
        },
        userExist: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The user already exist"
            }
        },
        success: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Success"
            }
        },
        buttons: {
            readAll: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Read All"
                }
            },
            back: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Back"
                }
            },
            loadMore: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Load more"
                }
            },
            archive: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Archive"
                }
            }
        },
        promoCode: {
            notActive: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Ops! It seems like the promo code is no longer active"
                }
            },
            notExist: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Ops! It seems like the promo code doesn`t exist"
                }
            }
        },
        manyAttempts: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Attempts limit is exceeded. Please try again later"
            }
        },
        corsError: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Communication error occurred. Please retry after 30 seconds."
            }
        }
    },
    validations: {
        invalidEmail: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "E-mail must be valid"
            }
        },
        emailIsRequired: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Email is required"
            }
        },
        phoneIsRequired: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Phone number must be valid"
            }
        },
        pwdRules: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Min 6 characters"
            }
        },
        alphabeticSymbolsName: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The first name should contains alphabetic symbols"
            }
        },
        alphabeticSymbolsSurname: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The surname should contains alphabetic symbols"
            }
        },
        alphabeticSymbolsCity: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The city should contains alphabetic symbols"
            }
        },
        onlyNumbers: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The field should contains only numbers"
            }
        },
        valueNoEmpty: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The value should not be empty"
            }
        },
        max20characters: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Max 20 characters"
            }
        },
        IFSCcodeNoValid: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "IFSC code must be valid"
            }
        },
        MPesaNumberNoValid: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "M-Pesa number must be valid"
            }
        },
        minDeposit2000inr: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Minimum deposit amount is 2000 INR"
            }
        },
        promoCodeMustContain: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Promo code must contain 0-9"
            }
        },
        promoCodeMaxLength12char: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Promo code max length is 12 characters!"
            }
        },
        withdrawalLimit: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "Withdrawal limit is "
                }, {
                    t: 4,
                    k: "limitWithdraw"
                }, {
                    t: 3,
                    v: ". Create a withdrawal request according to this limit"
                }]
            }
        },
        lengthForPaytmRules: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The number of characters should be 10"
            }
        },
        mPesaRequired: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "M-Pesa number Required"
            }
        },
        cmpPwdRule: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The password doesn't match"
            }
        },
        withdrawalIsNotAvailable: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Withdrawal is not available. Please wager the amount of your deposit."
            }
        },
        passwordMinLength: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "At least "
                }, {
                    t: 4,
                    k: "minLength"
                }, {
                    t: 3,
                    v: " symbols"
                }]
            }
        },
        passwordDigit: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "At least 1 digit (0-9)"
            }
        },
        passwordLowerCase: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "At least 1 lowercase character (a-z)"
            }
        },
        passwordUpperCase: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "At least 1 uppercase character (A-Z)"
            }
        },
        passwordWasUsed: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "You've used this password before, please choose a new one instead."
            }
        },
        passwordEqualsEmail: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Password cannot be the same as your email"
            }
        },
        requiredField: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Required field"
            }
        },
        passwordsDontMatch: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Passwords don't match"
            }
        },
        incorrectOldPassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "You entered an incorrect old password"
            }
        },
        restoredPassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The password was restored"
            }
        },
        updatedPassword: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The password was updated"
            }
        },
        loading: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Loading..."
            }
        },
        symbolsLength: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "Symbols length must be at least "
                }, {
                    t: 4,
                    k: "length"
                }, {
                    t: 3,
                    v: "."
                }]
            }
        },
        promocode: {
            required: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Promocode is required"
                }
            },
            minLength: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Promocode must be at least "
                    }, {
                        t: 4,
                        k: "length"
                    }, {
                        t: 3,
                        v: " characters"
                    }]
                }
            },
            maxLength: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Promocode must be at most "
                    }, {
                        t: 4,
                        k: "length"
                    }, {
                        t: 3,
                        v: " characters"
                    }]
                }
            },
            alphanumeric: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Promocode must contain only letters and numbers"
                }
            }
        }
    },
    banner: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Only within an hour after registration"
            }
        },
        titleIplNew: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Ready to Claim Your Royal Rewards?"
            }
        },
        drawerTitleIplNew: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Casino Or Sports Betting?"
            }
        },
        titlePlant: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Crash and Sport"
            }
        },
        titlePopUpICC: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Casino and Sport"
            }
        },
        titlePlantNew: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Join Diwali Race to Share the <br> Prize Pool"
            }
        },
        titleDrawerPlant: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Crash-games or Sportsbetting?"
            }
        },
        titleDrawerPlantNew: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Join Diwali Race to Share the <br> Prize Pool"
            }
        },
        titleSmall: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Only within an hour"
            }
        },
        subtitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "for the first deposit!"
            }
        },
        subtitleIplNew: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: 'Win <span class="yellow--text">10 Lakh & a BMW X3</span> in <br> Royal Challenge 2024!'
            }
        },
        titleICC: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Casino or Sportsbetting?"
            }
        },
        subtitleICC: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose One and <br> Get Welcome Bonus <br> After Deposit!"
            }
        },
        subtitlePopUpICC: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "WELCOME OFFERS <br> CHOOSE ONE AND <br> GET YOUR BONUS!"
            }
        },
        drawerSubtitleIplNew: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose and Get <br> Welcome Bonus <br>After Deposit!"
            }
        },
        subtitlePlant: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Welcome Offers 700% <br> Choose one and get <br> your bonus!"
            }
        },
        subtitlePlantNew: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "60 LAKH <br> FORTUNE TOURNEY"
            }
        },
        subtitleDrawerPlant: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Choose one and get a 700% bonus <br> on 4 deposits!"
            }
        },
        subtitleDrawerPlantNew: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "60 LAKH FORTUNE TOURNEY"
            }
        },
        participate: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Participate"
            }
        },
        proceed: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Proceed"
            }
        },
        getNow: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "TAKE BONUS"
            }
        },
        iplBtn: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Find out more"
            }
        },
        takeBonus: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "TAKE BONUS"
            }
        },
        get: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Get a bonus"
            }
        },
        left: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Left:"
            }
        },
        joinNow: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Join now"
            }
        }
    },
    pageTitles: {
        bannerTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Sportsbook and Casino Games"
            }
        },
        defaultTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Online Betting - Sports Betting and Odds at 4Rabet"
            }
        },
        mainDescDefault: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Get the best live sports betting odds & bet online with exciting sporting action around the clock. Sign up & place your bets in-play with 4Rabet."
            }
        },
        "/casino/new-gamesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet New Casino Games & Slots in India: Play for Free & Real Money"
            }
        },
        "/casino/new-gamesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Looking for the news free casino games and slots? You’ll find a lot of it here! Latest releases right from the official providers are waiting for you!"
            }
        },
        "/casino/video-pokerTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Video Poker Online in India: Play for Free & Real Money"
            }
        },
        "/casino/video-pokerDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Looking for the latest and freshest video poker games? You’ve come to the right place! Dozens of games are waiting for you!"
            }
        },
        "/casino/blackjackTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Blackjack Online Games | Play at 4Rabet Casino in India"
            }
        },
        "/casino/blackjackDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play the Blackjack Online Games in India on the 4rabet official website ⚡ Sign Up today and GET 700% welcome bonus up to 40000₹."
            }
        },
        "/casino/newGamesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "New TV slot games"
            }
        },
        "/casino/newGamesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "New TV casino games in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        "/casino/crashTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Crash online casino games - Play at 4rabet India"
            }
        },
        "/casino/crashDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play the crash online casino games in India on the 4rabet official website ⚡ Sign Up today and GET 700% welcome bonus up to 40000₹."
            }
        },
        "/casino/otherTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Other online casino games - Play at 4rabet India"
            }
        },
        "/casino/otherDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play the other online casino in India on the 4rabet official website."
            }
        },
        "/casino/fastTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Fast online casino games - Play at 4rabet India"
            }
        },
        "/casino/fastDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play the fast online casino games in India on the 4rabet official website ⚡ Sign Up today and GET 700% welcome bonus up to 40000₹."
            }
        },
        "/casino/liveTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live online casino games - Play at 4rabet India"
            }
        },
        "/casino/liveDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play the live online casino in India on the 4rabet official website ⚡ Sign Up today and GET 700% welcome bonus up to 40000₹."
            }
        },
        "/casino/tableTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Table online casino games - Play at 4rabet India"
            }
        },
        "/casino/tableDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play the table online casino in India on the 4rabet official website ⚡ Sign Up today and GET 700% welcome bonus up to 40000₹."
            }
        },
        "/casino/localTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Local online casino games - Play at 4rabet India"
            }
        },
        "/casino/localDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play the local online casino in India on the 4rabet official website ⚡ Sign Up today and GET 700% welcome bonus up to 40000₹."
            }
        },
        "/casino/popularTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Popular Casino Games Online - Play at 4rabet India"
            }
        },
        "/casino/popularDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play the popular online casino in India on the 4rabet official website ⚡ Sign Up today and GET 700% welcome bonus up to 40000₹."
            }
        },
        "/casino/virtualSportsTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Virtual Sports - online casino games - Play at 4rabet India"
            }
        },
        "/casino/virtualSportsDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play the virtual sports games in India on the 4rabet official website ⚡ Sign Up today and GET 700% welcome bonus up to 40000₹."
            }
        },
        "/casino/vipTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Vip online casino games - Play at 4rabet India"
            }
        },
        "/casino/vipDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play the vip online casino in India on the 4rabet official website ⚡ Sign Up today and GET 700% welcome bonus up to 40000₹."
            }
        },
        "/sportsTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Online Sports Betting in India | 4Rabet Sportsbook"
            }
        },
        "/sportsDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Looking for the best sportsbook in India to bet on your favorite sport events and matches? Save your time and let's start with online betting at 4Rabet! ▶ Lines and fair predictions ▶ bonuses for new players ▶ bet on cricket, football, boxing, kabaddi and other sports today!"
            }
        },
        "/sports/baseballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Baseball Betting Online | Baseball Odds & Lines | 4Rabet India"
            }
        },
        "/sports/baseballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "View list of the upcoming baseball matches and games. Bet on game lines and MLB Futures, or try out Live Betting with 4Rabet Sportsbook. Start to win today!"
            }
        },
        "/sports/basketballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Basketball Betting | Betting Lines & Odds | Bet Online in India"
            }
        },
        "/sports/basketballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Basketball online betting has never been so fun and easy! Start to bet with 4Rabet India, choose your favorite games, check odds and start to gain big numbers in winnings!"
            }
        },
        "/sports/cricketTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Cricket Betting & Odds | Online Cricket Betting in India | Bet on Cricket"
            }
        },
        "/sports/cricketDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Cricket betting on ODI, T20 & Test Matches ▶ Safe and Secure Deposits ▶ Fair odds and lines ▶ Browse your favorite cricket games and bet with 4Rabet Sportsbook"
            }
        },
        "/sports/cricket-iplTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "IPL Cricket Betting | Lines & Odds for IPL Betting India | Bet on IPL"
            }
        },
        "/sports/cricket-iplDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet on Indian Premier League with 4Rabet Sportsbook and browse the latest Indian Premier League betting odds ▶ Register today and get IPL betting tips and predictions!"
            }
        },
        "/sports/cricket-bangladeshTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Online Cricket Betting Site & Odds in Bangladesh"
            }
        },
        "/sports/cricket-bangladeshDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Get the best cricket betting odds & bet online with exciting sporting action around the clock. Sign up & place your bets in-play with 4Rabet in Bangladesh."
            }
        },
        "/sports/dotaTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Dota-2 Betting India | eSports Betting Odds & Lines | 4Rabet India"
            }
        },
        "/sports/dotaDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Looking for the one of the most popular eSports, Dota-2 betting website? You've come to the right place! Register at 4Rabet Sportsbook and get your Dota-2 odds and full info right now!"
            }
        },
        "/sports/footballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Football Betting & Odds | 4Rabet India Sportsbook"
            }
        },
        "/sports/footballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Football betting with 4Rabet Sportsbook has never been so easy and joyful! Get the latest football odds on all your favorite leagues and matches with 4Rabet India!"
            }
        },
        "/sports/horse-racingTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Horse Racing Betting & Odds | 4Rabet India Sportsbook | Bet on Horses"
            }
        },
        "/sports/horse-racingDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet on horse racing with 4Rabet Sportsbook and find out the best odds and predictions for the upcoming tournaments ✓Secure Deposits ✓Fast Withdrawals ✓Fair Odds"
            }
        },
        "/sports/table-tennisTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Table Tennis Betting & Odds | 4Rabet India Sportsbook"
            }
        },
        "/sports/table-tennisDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet on Table Tennis Online in India ▷ Best Table Tennis betting site ▷ Get the highest odds and instant payouts ▷ Enjoy sports betting at 4Rabet Sportsbook!"
            }
        },
        "/sports/tennisTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Tennis Betting & Odds | 4Rabet India Sportsbook | WTA, ATP Betting"
            }
        },
        "/sports/tennisDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet with the 4Rabet Sportsbook on Tennis ✓ Get your latest tennis odds ✓ Get your winnings with fast payouts and easy deposits in India"
            }
        },
        "/sports/ecricketTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "eCricket Betting India | eSports Betting Odds & Lines | 4Rabet India"
            }
        },
        "/sports/ecricketDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Start with eCricket betting as the most interesting part of eSports betting today ▷ Freshest and fair odds ▷ Secure deposits and fast withdrawals ▷ 4Rabet Sportsbook"
            }
        },
        "/sports/soccerTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Soccer Betting | Odds, Predictions & Tips | 4Rabet India"
            }
        },
        "/sports/soccerDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Soccer betting with 4Rabet Sportsbook has never been so easy and joyful! Get the latest soccer odds on all your favorite leagues and matches with 4Rabet India!"
            }
        },
        "/sports/fifaTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "FIFA Betting Odds & Lines | 4Rabet India Betting | Bet on FIFA"
            }
        },
        "/sports/fifaDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "FIFA Online Betting: Prepare yourself for the best betting odds and fresh lines with the 4Rabet sportsbook ▷ Best FIFA Betting Site for Indian Players"
            }
        },
        "/sports/ice-hockeyTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Ice Hockey Betting | Odds, Predictions & Tips | 4Rabet India"
            }
        },
        "/sports/ice-hockeyDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Browse all the latest Ice Hockey Betting Odds and markets online, including NHL Betting, with 4Rabet sportsbook ✓ Choose yours across 70 different markets"
            }
        },
        "/sports/nbaTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "NBA2K Betting India | eSports Betting Odds & Lines | 4Rabet India"
            }
        },
        "/sports/nbaDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Go for your favorite esports matches, including NBA 2K matches at 4Rabet Betting sportsbook ▶ Check the latest odds and fair predictions ▶ Register today and start to win!"
            }
        },
        "/sports/boxingTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Boxing Betting & Odds | Online Betting Sportsbook | 4Rabet India"
            }
        },
        "/sports/boxingDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Browse the latest Boxing odds and offers with 4Rabet sportsbook, for a range of markets! ✓Boxing Betting ✓Matches ✓Potential Fights ✓ Best odds for Indian players"
            }
        },
        "/sports/aussie-rulesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Aussie Rules Online Betting | Predictions & Odds | 4Rabet India"
            }
        },
        "/sports/aussie-rulesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Aussie Rules is a high-scoring sport you'll enjoy the most? Start to bet on Aussie rules today with the 4Rabet sportsbook ▶ Fair odds ▶ Secure Deposits ▶ Fast Payouts"
            }
        },
        "/sports/kabaddiTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Kabaddi Online Betting | Odds & Predictions | 4Rabet Sportsbook"
            }
        },
        "/sports/kabaddiDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Start with Kabaddi betting online with the best Indian sportsbook 4Rabet ✓ Get the latest odds ✓ Start to bet with registration bonuses ✓ Enjoy your winnings"
            }
        },
        "/sports/volleyballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Volleyball Odds & Lines | 4Rabet India Betting | Bet on Volleyball"
            }
        },
        "/sports/volleyballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Volleyball betting with 4Rabet Sportsbook has never been so easy and joyful ▶ Get the latest volleyball odds on all your favorite leagues and matches with 4Rabet India!"
            }
        },
        "/sports/counter-strikeTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Counter Strike Betting India | eSports CS Betting Odds & Lines | 4Rabet India"
            }
        },
        "/sports/counter-strikeDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet on CS:GO Betting with 4Rabet Sportsbook ▷ Make your first REAL MONEY bet on Counter Strike: Global Offensive (CS:GO) ▷ eSports betting odds & lines"
            }
        },
        "/sports/mmaTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "MMA Betting Odds & Predictions | MMA Online Betting Sportsbook | 4Rabet India"
            }
        },
        "/sports/mmaDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Compare the latest UFC/MMA fight odds and betting lines from the top Indian sportsbook ✓ Bet on the most up-to-date MMA odds, lines, and spreads"
            }
        },
        "/sports/iplTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "IPL Betting at 4Rabet: Odds, Stats & Results"
            }
        },
        "/sports/iplDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "IPL betting  ▷ Odds, stats & results for all  matches and leagues ▷ INR deposit/withdrawal for Indian players!  ▷ Start to play at 4Rabet India!"
            }
        },
        "/liveTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Live Sports Betting ⚽ Bet on Sports at 4Rabet 🏀"
            }
        },
        "/liveDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Find your favorite live tournament online and bet on live events today! Choose across the best matches, register, and start with the best live betting odds with the 4Rabet live betting sportsbook!"
            }
        },
        "/live/soccerTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Live Soccer Score, Results & Live Odds"
            }
        },
        "/live/soccerDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Are you a fan of the soccer, and want to try your luck at the live betting, while your favorite teams in play? Start with the 4Rabet live soccer betting and start to win with the best odds and predictions!"
            }
        },
        "/live/ecricketTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Live eCricket Score & Today's Live eCricket Matches"
            }
        },
        "/live/ecricketDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Dive into the heart of the eCricket action with real-time scores and updates on today's electrifying eCricket matchups. Stay ahead of the game, track every thrilling moment, and experience the digital cricketing universe like never before."
            }
        },
        "/live/cricketTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live Cricket Betting - Today's Match Odds, Bets & Predictions"
            }
        },
        "/live/cricketDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Immerse yourself in the excitement of live cricket betting! Explore today's match odds, place live bets, and unlock the power of predictions. Elevate your cricketing experience by engaging with the pulse-pounding action in real-time."
            }
        },
        "/live/cricket-iplTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live cricket IPL - Betting at 4Rabet"
            }
        },
        "/live/cricket-iplDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live cricket IPL 2025 ▷ betting odds, stats & results for all matches and leagues ▷ INR deposit/withdrawal for Indian players! ▷ Start to play at 4Rabet India!"
            }
        },
        "/live/volleyballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Volleyball Live Score, Odds and Predictions"
            }
        },
        "/live/volleyballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Elevate your volleyball passion! Follow live scores, analyze odds, and make insightful predictions on 4Rabet. Whether you're a fan or a bettor, our platform offers a dynamic way to experience every serve, spike, and rally."
            }
        },
        "/live/fifaTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet FIFA World Cup Live - Bet Online Today's Matches"
            }
        },
        "/live/fifaDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The FIFA World Cup frenzy is here! Bet online on today's matches, dive into the thrilling action of the world's most prestigious football tournament, and experience the passion of the game with every goal, save, and victory."
            }
        },
        "/live/ebaseballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet eBaseball Betting - Live Odds and Predictions on Today's Matches"
            }
        },
        "/live/ebaseballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Swing into the world of eBaseball! Explore live odds, place your bets, and make informed predictions on today's matches. Experience the virtual diamond come alive with every pitch, hit, and homerun."
            }
        },
        "/live/table-tennisTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Table Tennis Live Betting - Live Score & Odds on Tennis"
            }
        },
        "/live/table-tennisDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Serve up the excitement with live table tennis betting! Stay updated with real-time scores, explore dynamic odds, and engage in live betting on the fast-paced world of table tennis. Experience the thrill as every point unfolds."
            }
        },
        "/live/ice-hockeyTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Ice Hockey Live Betting - Bet on Today's Hockey Live Matches"
            }
        },
        "/live/ice-hockeyDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Break the ice with live hockey betting! Bet on today's live matches, feel the adrenaline rush with every powerplay, goal, and save. Dive into the action-packed world of ice hockey like never before."
            }
        },
        "/live/boxingTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Live Boxing - Today's Boxing Matches & Best Live Odds"
            }
        },
        "/live/boxingDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Join the adrenaline-pumping world of boxing with 4Rabet Live Boxing! Catch today's most anticipated matches live and elevate the excitement by placing your bets in real-time. Get the best live odds on your favorite fighters, witnessing every punch, jab, and knockout moment with unparalleled thrill."
            }
        },
        "/live/mmaTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet MMA and UFC Live Betting | Live Odds & Predictions"
            }
        },
        "/live/mmaDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Dive into the heart-pounding realm of MMA and UFC through 4Rabet's Live Betting. Experience the raw intensity of each fight as it happens, while leveraging live odds and predictions to make informed wagers in real-time."
            }
        },
        "/live/horse-racingTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Live Horse Racing Betting | Bet on Live Events Today"
            }
        },
        "/live/horse-racingDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Immerse yourself in the electrifying world of live horse racing betting with 4Rabet! Witness the thundering hooves and exhilarating races as they unfold in real-time. Bet on live events happening today, feel the rush of the tracks, and revel in the excitement of every stride toward the finish line."
            }
        },
        "/live/footballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Live Football Betting - Start to Bet Live on Today's Football Matches"
            }
        },
        "/live/footballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Engage in the thrill of live football betting with 4Rabet! Don't just watch; be part of the action by betting live on today's football matches. Experience the intensity on the field while seizing the opportunity to place bets in real-time."
            }
        },
        "/live/baseballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Baseball Betting | Odds and Predictions on Today's Live Matches"
            }
        },
        "/live/baseballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Try your luck at the live baseball betting at 4Rabet! Dozens of popular matches, live events with the freshest odds are waiting for you -- register and start to play right now!"
            }
        },
        "/live/iplTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "IPL live betting at 4Rabet: Odds, Stats & Results"
            }
        },
        "/live/iplDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live ipl betting  ▷ Odds, stats & results for all  matches and leagues ▷ INR deposit/withdrawal for Indian players!  ▷ Start to play at 4Rabet India!"
            }
        },
        "/live-dealers/new-gamesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live Dealers: New Games and Latest Releases"
            }
        },
        "/live-dealers/new-gamesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Are you tired of the standard live dealer games? We have a lot of new live dealer games and releases, just check it out here!"
            }
        },
        "/tv-gamesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "TV casino games - Slots"
            }
        },
        "/tv-gamesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Plat online TV casino games in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        "/deposit-withdrawTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Deposit or Withdraw Your Winnings – 4Rabet"
            }
        },
        "/deposit-withdrawDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Want to start a game for real money or already have the winnings to withdraw? Go here and make your choice!"
            }
        },
        "/rulesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Rules for Specific sports - 4Rabet"
            }
        },
        "/rulesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Rules for Specific sports - New Entertainment Development N.V. 4rabet official website."
            }
        },
        "/slot/crazyTimeTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Crazy Time game – Play online casino India"
            }
        },
        "/slot/crazyTimeDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Login and play Crazy Time game online at 4Rabet 🎰 Official website for betting and casino in India. Download mobile app for free. Latest version of apk file."
            }
        },
        "/slot/dragonTigerTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Dragon Tiger Play Live at 4rabet | Download 4raber App"
            }
        },
        "/slot/dragonTigerDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "More than just a game - an ancient Asian tradition on your device at 4rabet!"
            }
        },
        "/slot/chickenRoadTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Chicken Road 🐤 Play Casino Game For Free and Real Money"
            }
        },
        "/slot/chickenRoadDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Chicken Road is a new slot game by InOut Games with RTP of 98%, which has become massively popular among casino players. Join the 4Rabet casino and play this amazing game of chance for free or for real money!"
            }
        },
        "/slot/jetXTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Jet X Slot: Play Online At The 4Rabet Casino"
            }
        },
        "/slot/jetXDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "The jet’s tank is loaded up and the flight is set to begin! Try and test yourself to win even more today! Play Jet X Casino Slot at 4RABET."
            }
        },
        "/live/tennisTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live Tennis Betting 🥎 Watch Online Events at 4Rabet"
            }
        },
        "/live/tennisDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet live on thrilling tennis matches! Follow real-time action and place smart bets as the game unfolds only at 4Rabet."
            }
        },
        "/slot/aviatrixTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Aviatrix Game ✈️ Play Crash Game for Free & Real Money"
            }
        },
        "/slot/aviatrixDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Fly high with Aviatrix! Play the exciting crash game at 4Rabet for free or real money and cash out before the plane crashes."
            }
        },
        "/slot/balloonTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Balloon Slot Game 🎈 Review & Free Play at 4Rabet Casino"
            }
        },
        "/slot/balloonDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Float into fun with the Balloon slot! Try it for free at 4Rabet and pop your way to exciting wins in this light and vibrant game."
            }
        },
        "/slot/luckyMinesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Lucky Mines Game 💣 Play for Free at 4Rabet Casino"
            }
        },
        "/slot/luckyMinesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Dig for treasure in Lucky Mines! Avoid hidden bombs, collect rewards, and enjoy explosive fun for free at 4Rabet Casino."
            }
        },
        "/live/basketballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live Basketball 🏀 Bet On Live Events at 4Rabet"
            }
        },
        "/live/basketballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Catch every slam dunk and buzzer-beater live! Bet on basketball games in real time with 4Rabet’s live sports betting."
            }
        },
        "/slot/luckyCaptainTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Lucky Captain Slot 🍀 Free Demo & Review"
            }
        },
        "/slot/luckyCaptainDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Try your personal luck with the immersive Lucky Captain slot! Read full review, recommendation and game tactics to play for free or win real money."
            }
        },
        "RW/defaultTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Rwanda Official Website | Sports Betting and Casino"
            }
        },
        "RW/defaultDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Looking for the best online betting and casino website in Rwanda? Try 4Rabet with a small R₣ deposit and huge bonuses! Casino games, live events and big jackpots are waiting for you!"
            }
        },
        "RW/liveTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Rwanda Live Betting, Live Match | Bet on Live Sports & Casino"
            }
        },
        "RW/liveDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Start to bet on the live match with Live Score predictions only! Best odds and predictions, thousands of live events and live casino games at 4Rabet Rwanda"
            }
        },
        "RW/bonusTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Rwanda - Casino Bonuses and Promo Codes"
            }
        },
        "RW/bonusDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Looking for the freshest and latest casino promocodes and bonuses? Get the BEST casino offers for new and existing players at 4Rabet Rwanda."
            }
        },
        "RW/casinoTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Online Casino Games | Rwandian Online Casino | 4Rabet Games"
            }
        },
        "RW/casinoDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "List of the 6000+ online casino games at the best Rwandian online casino 4Rabet is waiting for you! Find the best casino games like crash games, table games, live games, online slots and many more!"
            }
        },
        "RW/casino/slotsTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Online Slot Games | 4Rabet Rwanda Casino | Play Online Slots"
            }
        },
        "RW/casino/slotsDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Register at 4Rabet Rwanda and choose the best online slot games among 5000+ available games!"
            }
        },
        "RW/casino/slot/aviatorTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Aviator Online Slot Game | Sign up and Play at 4Rabet Rwanda"
            }
        },
        "RW/casino/slot/aviatorDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Do you like crash games? If you do, you should try to play at one of the world's popular games Aviator. Register, grab your bonuses and play at Aviator slot game at 4Rabet Rwanda."
            }
        },
        "RW/casino/rouletteTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Roulette Casino Games | 4Rabet Rwanda Casino"
            }
        },
        "RW/casino/rouletteDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Roulette is your favorite casino game? Choose among dozens of different roulettes and find the favorite one today. Register, get bonuses, and play at 4Rabet Rwanda Roulette casino games"
            }
        },
        "RW/casino/popularTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Popular Casino Games | Choose the Most Popular at 4Rabet Rwanda"
            }
        },
        "RW/casino/popularDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "What are the most popular casino games so far? Check it out at 4Rabet Rwanda Casino platform and choose which one would be your favorite!"
            }
        },
        "RW/casino/new-gamesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "New Casino Games | 4Rabet Rwanda New Releases"
            }
        },
        "RW/casino/new-gamesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Check out the updated list of the newest casino games you haven't played yet! Register, get your bonuses, and try your luck at the new slots and other games!"
            }
        },
        "RW/casino/lotteryTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Online Lottery Games | Online Casino Lottery at 4Rabet Rwanda"
            }
        },
        "RW/casino/lotteryDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet on the World's Biggest Lotteries, Find Better Odds and Bigger Jackpots with the 4Rabet Rwandian casino. Find your lucky lottery tickets and win real money today!"
            }
        },
        "RW/casino/kenoTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Keno Casino Games Online | 4Rabet Rwanda"
            }
        },
        "RW/casino/kenoDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Watch the Keno casino game draw and check your ticket to see if you have won! Check the Lastest Keno Results & Winning Numbers Online at 4Rabet Rwanda."
            }
        },
        "RW/casino/blackjackTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Blackjack Casino Games | Play Free or For Real Money | 4Rabet Rwanda"
            }
        },
        "RW/casino/blackjackDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play free blackjack games and real money games at the one of the most popular casinos online. Easy to read cards. You versus the dealer! Play immediately."
            }
        },
        "RW/casino/bingoTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Rwanda Bingo Games: Start to play at Online Bingo Today"
            }
        },
        "RW/casino/bingoDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Looking for the best place to play at bingo online? Start with 4Rabet Rwanda, and choose among dozens of bingo games available at our online casino."
            }
        },
        "RW/casino/baccaratTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Baccarat Casino Games | 4Rabet Rwanda Casino"
            }
        },
        "RW/casino/baccaratDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enjoy the authentic baccarat casino games at 4Rabet Rwanda Casino. Play the classic version of the famous game and win real money."
            }
        },
        "RW/sports/tennisTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Tennis Betting Online at 4Rabet Rwanda"
            }
        },
        "RW/sports/tennisDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Rwanda offers a comprehensive range of tennis betting options, from Grand Slam tournaments to ATP, WTA, and Challenger events. Register today and bet on your favorite tennis events!"
            }
        },
        "RW/sports/table-tennisTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Table Tennis Betting Online at 4Rabet Rwanda"
            }
        },
        "RW/sports/table-tennisDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet on table tennis games online, check the freshest odds and get the best prediction to win real money with 4Rabet Rwanda bookmaker!"
            }
        },
        "RW/sports/footballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Rwanda Football Betting: Predictions, Odds and Live Bets"
            }
        },
        "RW/sports/footballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Sign up at 4Rabet Rwanda and GET the best football betting odds and predictions! Start to play with the huge bonuses, trustful tips and bet on live events today."
            }
        },
        "RW/sports/cricketTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Rwanda Cricket Betting | Sign Up and Bet on Cricket"
            }
        },
        "RW/sports/cricketDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet on cricket with 4Rabet Rwanda betting company: sign up, get your bonuses, choose the upcoming cricket game, check predictions and prepare for winnings!"
            }
        },
        "RW/sports/basketballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Basketball Betting Online | Pre-Match and Live Odds | 4Rabet Rwanda"
            }
        },
        "RW/sports/basketballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Shoot for the win with 4Rabet Rwanda basketball betting. Offering the best basketball pre-match odds and dynamic live odds for every match."
            }
        },
        "RW/sports/baseballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Rwanda Baseball Betting | Today's Betting Lines & Spreads"
            }
        },
        "RW/sports/baseballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Our 4Rabet Rwanda online sportsbook offers a wide range of betting options, including MLB game lines, World Series odds, various MLB prop bets, and futures."
            }
        },
        "RW/sportsTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Rwanda Sports Betting | Bet on Sports Events and Win Today!"
            }
        },
        "RW/sportsDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Looking for the place to bet on upcoming matches at different sports, like football, MMA, boxing, tennis or any other? Sign up at 4Rabet Rwanda with bonuses and start to play!"
            }
        },
        "RW/tv-gamesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "TV Games Online | Play Favorite TV Games at 4Rabet Rwanda"
            }
        },
        "RW/tv-gamesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play your favorite TV games and watch the live results at the TV games with the 4Rabet Rwanda casino and bookmaker company!"
            }
        },
        "RW/reviewTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Rwanda Review: Company Overview and User Opinions"
            }
        },
        "RW/reviewDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Does 4Rabet Rwanda is trusted casino and bookmaker? Absolutely! Check out the 4Rabet review and latest user opinions about this casino."
            }
        },
        "RW/live/tennisTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Rwanda Live Tennis Betting | Bet on Tennis Matches"
            }
        },
        "RW/live/tennisDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live tennis matches waiting for you! Choose your favorite tennis event, check the odds and predictions, and start to play at 4Rabet Betting Company!"
            }
        },
        "RW/live-dealersTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Rwanda Casino Live Dealers | Sign up and Play at 4Rabet"
            }
        },
        "RW/live-dealersDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Register at 4Rabet Rwanda and get access to the full list of the casino live dealers, with the freshest and the most popular live dealer games."
            }
        },
        "RW/live-dealers/baccaratTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play Live Dealers Baccarat at 4Rabet Rwanda Casino"
            }
        },
        "RW/live-dealers/baccaratDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play at live dealers baccarat games and win real money today with 4Rabet Rwandian casino. Sign up, get your bonuses and choose the classic game you love!"
            }
        },
        "RW/live-dealers/rouletteTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Live Roulette Games | 4Rabet Rwanda"
            }
        },
        "RW/live-dealers/rouletteDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Roulette games online: live roulette dealers for European roulette, classic roulette, and namy other roulette games are waiting for you -- sign up at 4Rabet Rwanda and start to win."
            }
        },
        "RW/appTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: `Official 4Rabet Casino App for Rwandian Players | Download Latest Version
`
            }
        },
        "RW/appDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: `Would like to play from your smartphone? Download the 4Rabet app, created specially for Rwandian casino and betting players: full functionality, all payment methods, aplicable at all devices (.apk and iOS)
`
            }
        },
        "RW/depositTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Deposit & Withdrawal: Official Terms and Rules"
            }
        },
        "RW/depositDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "How to make deposit at 4Rabet, and how to withdraw your winnings? Any problems with withdrawal? Terms, rules, time, methods and step-by-step guide for 4Rabet users."
            }
        },
        "ZM/casino/slotsTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Online Slot Games | 4Rabet Zambia Casino | Play Slots Online"
            }
        },
        "ZM/casino/slotsDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Register at 4Rabet Zambia and explore a vast selection of online slot games from over 5000 options!"
            }
        },
        "ZM/casino/slot/aviatorTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Aviator Online Slot Game | Join and Play at 4Rabet Zambia"
            }
        },
        "ZM/casino/slot/aviatorDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Fancy crash games? Explore one of the world's most beloved games, Aviator. Register, claim your bonuses, and immerse yourself in Aviator slot game action at 4Rabet Zambia."
            }
        },
        "ZM/casino/rouletteTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Roulette Casino Games | 4Rabet Zambia Casino"
            }
        },
        "ZM/casino/rouletteDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Is roulette your go-to casino game? Delve into dozens of different roulette variations and discover your favorite today. Register, claim bonuses, and indulge in roulette casino games at 4Rabet Zambia."
            }
        },
        "ZM/casino/popularTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Popular Casino Games | Explore the Most Popular at 4Rabet Zambia"
            }
        },
        "ZM/casino/popularDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Curious about the most popular casino games to date? Explore them all at the 4Rabet Zambia Casino platform and find your new favorite!"
            }
        },
        "ZM/casino/new-gamesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "New Casino Games | Latest Releases at 4Rabet Zambia"
            }
        },
        "ZM/casino/new-gamesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Stay updated with the latest additions to the casino game library that you haven't tried yet! Register, claim bonuses, and test your luck on the new slots and other games!"
            }
        },
        "ZM/casino/lotteryTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Online Lottery Games | Casino Lottery at 4Rabet Zambia"
            }
        },
        "ZM/casino/lotteryDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet on the world's most prominent lotteries, uncover better odds, and chase bigger jackpots with 4Rabet Zambian casino. Discover your lucky lottery tickets and seize real money victories today!"
            }
        },
        "ZM/casino/kenoTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Keno Casino Games Online | Try Your Luck at 4Rabet Zambia"
            }
        },
        "ZM/casino/kenoDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Witness the Keno casino game draw and verify your ticket for potential wins! Check out the Latest Keno Results & Winning Numbers Online at 4Rabet Zambia."
            }
        },
        "ZM/casino/blackjackTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Blackjack Casino Games | Enjoy Free or Real Money Play | 4Rabet Zambia"
            }
        },
        "ZM/casino/blackjackDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Engage in free blackjack games and real money games at one of the most beloved online casinos. Easy-to-read cards. You versus the dealer! Start playing now."
            }
        },
        "ZM/casino/bingoTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Zambia Bingo Games: Start to play at Online Bingo Today"
            }
        },
        "ZM/casino/bingoDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Seeking the ultimate destination for online bingo? Kick off your bingo journey at 4Rabet Zambia, offering a plethora of bingo games at our virtual casino."
            }
        },
        "ZM/casino/baccaratTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Baccarat Casino Games | 4Rabet Zambia Casino"
            }
        },
        "ZM/casino/baccaratDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Experience the thrill of authentic baccarat casino games at 4Rabet Zambia Casino. Engage in the classic version of this renowned game and seize real money rewards."
            }
        },
        "ZM/casinoTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Online Casino Games | Zambian Online Casino | 4Rabet Games"
            }
        },
        "ZM/casinoDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Explore a catalog of over 6000 online casino games at Zambia's top-rated online casino, 4Rabet! Dive into premier casino games like crash games, table games, live games, online slots, and much more!"
            }
        },
        "ZM/bonusTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Zambia - Casino Bonuses and Promo Codes"
            }
        },
        "ZM/bonusDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Still searching for the newest and most lucrative casino promo codes and bonuses? Uncover the TOP casino offers for both new and existing players at 4Rabet Zambia."
            }
        },
        "ZM/appTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Official 4Rabet Casino App for Zambian Players | Download Latest Version"
            }
        },
        "ZM/appDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Eager to play from your smartphone? Download the 4Rabet app, tailor-made for Zambian casino and betting enthusiasts: enjoy full functionality, diverse payment methods, compatible across all devices (.apk and iOS)."
            }
        },
        "ZM/depositTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Deposit & Withdrawal: Official Terms and Rules"
            }
        },
        "ZM/depositDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "How to make deposit at 4Rabet, and how to withdraw your winnings? Any problems with withdrawal? Terms, rules, time, methods and step-by-step guide for 4Rabet users."
            }
        },
        "ZM/defaultTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Zambia Official Website | Sports Betting and Casino"
            }
        },
        "ZM/defaultDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Seeking the best online betting and casino platform in Zambia? Discover 4Rabet with a minimal deposit and outstanding bonuses! Dive into casino games, live events, and hefty jackpots today!"
            }
        },
        "ZM/tv-gamesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "TV Games Online | Enjoy Popular TV Games at 4Rabet Zambia"
            }
        },
        "ZM/tv-gamesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Indulge in your preferred TV games and catch the live results with 4Rabet Zambia's casino and bookmaker services!"
            }
        },
        "ZM/sports/tennisTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Tennis Betting Online at 4Rabet Zambia"
            }
        },
        "ZM/sports/tennisDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Explore a diverse array of tennis betting options at 4Rabet Zambia, spanning from Grand Slam tournaments to ATP, WTA, and Challenger events. Sign up today and wager on your favorite tennis matches!"
            }
        },
        "ZM/sports/table-tennisTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Table Tennis Betting Online at 4Rabet Zambia"
            }
        },
        "ZM/sports/table-tennisDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Place bets on online table tennis games, review the latest odds, and receive top-notch predictions to secure real money wins with 4Rabet Zambia bookmaker!"
            }
        },
        "ZM/sports/footballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Zambia Football Betting: Predictions, Odds and Live Bets"
            }
        },
        "ZM/sports/footballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Join 4Rabet Zambia and ACCESS the finest football betting odds and predictions! Dive into action with generous bonuses, reliable tips, and live event betting today."
            }
        },
        "ZM/sports/cricketTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Zambia Cricket Betting | Register and Bet on Cricket"
            }
        },
        "ZM/sports/cricketDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Place your cricket bets with 4Rabet Zambia betting company: sign up, seize your bonuses, pick your desired cricket game, review predictions, and gear up for winnings!"
            }
        },
        "ZM/sports/basketballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Basketball Betting Online | Explore Pre-Match and Live Odds | 4Rabet Zambia"
            }
        },
        "ZM/sports/basketballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Aim for victory with 4Rabet Zambia basketball betting. Offering the finest pre-match odds and dynamic live odds for every basketball match."
            }
        },
        "ZM/sports/baseballTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Zambia Baseball Betting | Check Today's Lines & Spreads"
            }
        },
        "ZM/sports/baseballDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Discover an extensive selection of betting options at our 4Rabet Zambia online sportsbook, covering MLB game lines, World Series odds, various MLB prop bets, and futures."
            }
        },
        "ZM/sportsTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Zambia Sports Betting | Wager on Sports Events and Win Today!"
            }
        },
        "ZM/sportsDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Looking for a platform to wager on upcoming matches across various sports such as football, MMA, boxing, tennis, and more? Register at 4Rabet Zambia, claim your bonuses, and dive into action!"
            }
        },
        "ZM/reviewTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Zambia Review: Company Overview and User Opinions"
            }
        },
        "ZM/reviewDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Is 4Rabet Zambia a trustworthy casino and bookmaker? Without a doubt! Check out the 4Rabet review and the latest user feedback to affirm the credibility of our casino and bookmaker company!"
            }
        },
        "ZM/live/tennisTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Zambia Live Tennis Betting | Bet on Tennis Matches"
            }
        },
        "ZM/live/tennisDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Exciting live tennis matches await! Select your preferred tennis event, review the odds and predictions, and engage in thrilling gameplay at 4Rabet Betting Company!"
            }
        },
        "ZM/live-dealersTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Zambia Casino Live Dealers | Join Now and Play at 4Rabet"
            }
        },
        "ZM/live-dealersDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enroll at 4Rabet Zambia and unlock the complete roster of casino live dealers, featuring the freshest and most popular live dealer games."
            }
        },
        "ZM/live-dealers/baccaratTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Experience Live Dealers Baccarat at 4Rabet Zambia Casino"
            }
        },
        "ZM/live-dealers/baccaratDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Participate in live dealers baccarat games and rake in real money rewards today with 4Rabet Zambian casino. Sign up, claim bonuses, and immerse yourself in the classic game you adore!"
            }
        },
        "ZM/live-dealers/rouletteTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Live Roulette Games | 4Rabet Zambia Casino"
            }
        },
        "ZM/live-dealers/rouletteDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Explore a variety of online roulette games, including live roulette dealers for European roulette, classic roulette, and many others – sign up at 4Rabet Zambia and embark on your winning journey."
            }
        },
        "ZM/liveTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Zambia Live Betting, Live Match | Bet on Live Sports & Casino"
            }
        },
        "ZM/liveDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Engage in live match betting with Live Score predictions exclusively! Access the finest odds and predictions, along with a dozens of live events and live casino games at 4Rabet Zambia."
            }
        },
        slotRandomTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 4,
                    k: "gameName"
                }, {
                    t: 3,
                    v: " Game – Play online for free"
                }]
            }
        },
        slotRandomDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "Login and play "
                }, {
                    t: 4,
                    k: "gameName"
                }, {
                    t: 3,
                    v: " game online at 4Rabet ⮕ Official website for betting and casino in India. Download mobile app for free. Latest version of apk file"
                }]
            }
        },
        "first/betbyRandomTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 4,
                    k: "gameName"
                }, {
                    t: 3,
                    v: " Betting at 4Rabet: Betting Odds, Stats & Results"
                }]
            }
        },
        "second/betbyRandomTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "Online "
                }, {
                    t: 4,
                    k: "gameName"
                }, {
                    t: 3,
                    v: " Betting at 4Rabet in India: Full List of Matches & Leagues"
                }]
            }
        },
        "third/betbyRandomTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "The Best "
                }, {
                    t: 4,
                    k: "gameName"
                }, {
                    t: 3,
                    v: " Betting Odds at 4Rabet: Play and Win!"
                }]
            }
        },
        "first/betbyRandomDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "Love "
                }, {
                    t: 4,
                    k: "gameName"
                }, {
                    t: 3,
                    v: " betting and would like to bet on your favorite tournaments? Don’t waste time and start to play with 4Rabet! ▷ Download official 4Rabet app for Android and iOS ▷ Highest odds & Instant payouts!"
                }]
            }
        },
        "second/betbyRandomDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3,
                    v: "Bet on "
                }, {
                    t: 4,
                    k: "gameName"
                }, {
                    t: 3,
                    v: " at the best "
                }, {
                    t: 4,
                    k: "gameName"
                }, {
                    t: 3,
                    v: " betting website 4Rabet! ▷ All schedules, "
                }, {
                    t: 4,
                    k: "gameName"
                }, {
                    t: 3,
                    v: " live scores, results and the best odds to win! ▷ Join 4Rabet today!"
                }]
            }
        },
        "third/betbyRandomDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 4,
                    k: "gameName"
                }, {
                    t: 3,
                    v: " betting ▷ "
                }, {
                    t: 4,
                    k: "gameName"
                }, {
                    t: 3,
                    v: " betting odds, stats & results for all "
                }, {
                    t: 4,
                    k: "gameName"
                }, {
                    t: 3,
                    v: " matches and leagues ▷ INR deposit/withdrawal for Indian players!  ▷ Start to play at 4Rabet India!"
                }]
            }
        },
        baccaratTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Baccarat Online Casino Games in India: Play for Free & Real Money"
            }
        },
        baccaratDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Baccarat online with no commission is here to save you from your daily routine - master one of the classic casino games."
            }
        },
        plinkoTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Plinko Game – Play Online at 4Rabet India and Win Real Money!"
            }
        },
        plinkoDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Try out all Plinko games from the well-known providers at 4Rabet India! Register, choose your Plinko game, and try a demo-version for free or start to play for real money!"
            }
        },
        exclusivesTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Exclusive casino games - Play at 4rabet India"
            }
        },
        exclusivesDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Exclusive online casino with live dealers in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        bonusTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Promo Code Today - Registration & Sign UP Bonuses India"
            }
        },
        bonusDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Discover how to redeem the 4rabet promo code and fruitfully use your welcome bonus for sports or casinos 2025."
            }
        },
        rouletteTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Online Roulette Games in India: Play for Free & Real Money"
            }
        },
        rouletteDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Want to try your luck with the online roulette? You found the right place! Don’t miss the time and play right now!"
            }
        },
        slotAviatorTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Aviator game - Play online at 4Rabet India"
            }
        },
        slotAviatorDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Login and play Aviator game online at 4Rabet 🎰 Official website for betting and casino in India. Download mobile app for free. Latest version of apk file."
            }
        },
        slotsTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Slots game online - Indian casino for real money"
            }
        },
        casinoSlotId: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Slot Games: Play For Free & Real Money Slots"
            }
        },
        liveDealersSlotId: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live Dealers Slot Games: Play at 4Rabet for Free & Real Money"
            }
        },
        tvGamesSlotId: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "TV Games Slots: Play TV Slot Games at 4Rabet Official Website"
            }
        },
        slotsDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Start to play the best casino games for real money with 4Rabet India 🎲 Sign Up, get bonuses 💰 and start to win real money!"
            }
        },
        appTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet App Download for Android (.apk) and iOS 📲 2025"
            }
        },
        appDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Why is 4Rabet app considered as the best cricket betting app for Indian players by various authoritative websites? Check the advantages of the best online cricket betting app and GET your bonuses!"
            }
        },
        cricketBetTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Cricket Betting App 💰 Live Bet On Your Phone With 4Rabet!"
            }
        },
        cricketBetDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Looking for the best cricket betting app on your iOS or Android phone? We have a betting app for any and all cricket evenings with the best odds, check it out and don’t miss time to place your first bet!"
            }
        },
        liveDealersTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Live Casino in India: Play for Free & Real Money"
            }
        },
        liveDealersDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Want to play roulette, baccarat, poker or any other casino games with a live dealer? Visit 4RABET and find your best live casino game!"
            }
        },
        reviewTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Review: Is It Real or Fake, Legal & Safe?"
            }
        },
        reviewDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Are you looking for the 4rabet review, but don’t know where’s find the best one? In this review, you’ll find comprehensive information from the guys behind the 4rabet website, so let’s take a look!"
            }
        },
        depositTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Deposit & Withdrawal: Official Terms and Rules"
            }
        },
        depositDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "How to make deposit at 4Rabet, and how to withdraw your winnings? Any problems with withdrawal? Terms, rules, time, methods and step-by-step guide for 4Rabet users."
            }
        },
        mainTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4RABET Official Online Website #1 - Sports Betting in India [Login & Registration]"
            }
        },
        mainDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet © Official Website: Login or Register and GET Your Welcome Bonuses for favorite casino and betting games today!"
            }
        },
        defaultTitleBd: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4RABET Official Online Website #1 - Sports Betting in Bangladesh [Login & Registration]"
            }
        },
        defaultDescBd: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet © Official Website: Login or Register and GET Your Welcome Bonuses for favorite casino and betting games today!"
            }
        },
        mainTitleSecond: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4RABET Official Online Website #1 - Sports Betting in India [Login & Registration]"
            }
        },
        mainDescSecond: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Start winning today with 4RABET at your favorite games! Get the best online betting experience in India, exclusive offers and many more right now!"
            }
        },
        lineCricketTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Cricket Betting: Upcoming Games & Cricket Matches at 4Rabet India"
            }
        },
        lineCricketDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet today on live cricket events, get your predictions and live odds from our experts. Cricket bet with 4RABET India - your place to WIN today!"
            }
        },
        liveCricketTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Live Cricket Betting Online | Check Live Rates & Scores at 4Rabet India"
            }
        },
        liveCricketDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Get to know the best insights on cricket betting, explore game-changing tips, and simply feel the art of cricket!"
            }
        },
        lineTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Betting: Upcoming Matches & Tournaments | 3000+ Upcoming Events"
            }
        },
        lineDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Get the best live sports betting odds & bet online with exciting sporting action around the clock. Sign up & place your bets in-play with 4Rabet."
            }
        },
        liveTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Live Betting: Cricket, Tennis, Football and 3000+ Sports Live Events"
            }
        },
        liveDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Get the best live sports betting odds & bet online with exciting sporting action around the clock. Sign up & place your bets in-play with 4Rabet."
            }
        },
        lineFootballTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Online Football | Upcoming Matches, Odds & Predictions - 4Rabet Betting"
            }
        },
        lineFootballDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Get the best live sports betting odds & bet online with exciting sporting action around the clock. Sign up & place your bets in-play with 4Rabet."
            }
        },
        kenoTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Keno Games Online in India: Play For Free & Real Money"
            }
        },
        kenoDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Online Betting - Sports Betting and Odds at 4Rabet"
            }
        },
        bingoTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Online Bingo Games in India: Play For Free & Real Money"
            }
        },
        bingoDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Online Betting - Sports Betting and Odds at 4Rabet"
            }
        },
        lotteryTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Lotto Online in India: Play for Free & Real Money"
            }
        },
        lotteryDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Online Betting - Sports Betting and Odds at 4Rabet"
            }
        },
        virtualSportTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "eSports Games Online | Place Your Bet on The Most Popular Virtual Sports - 4Rabet"
            }
        },
        virtualSportDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Online Betting - Sports Betting and Odds at 4Rabet"
            }
        },
        amlKycTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "AML & KYC Policies - 4Rabet Sportsbook Company"
            }
        },
        tutorialsTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Betting Tutorials & Recommendations"
            }
        },
        blackjackTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Blackjack Online Games | Play Your Favorite Blackjack Games - 4Rabet Casino"
            }
        },
        liveDealersNewGamesTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "New online casino with live dealers - Play for free"
            }
        },
        liveDealersNewGamesDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "New online casino with live dealers in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        liveDealersPopularTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Popular online casino with live dealers - Play for free"
            }
        },
        liveDealersPopularDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Popular online casino with live dealers in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        liveDealersVipTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Vip online casino with live dealers - Play for free"
            }
        },
        liveDealersVipDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Vip online casino with live dealers in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        liveDealersGameShowsTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Game shows with live dealers - Play for free"
            }
        },
        liveDealersGameShowsDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Game shows with live dealers in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        liveDealersEvolutionTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Evolution game with live dealers - Play for free"
            }
        },
        liveDealersEvolutionDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Evolution game with live dealers in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        liveDealersLocalTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Local online casino with live dealers - Play for free"
            }
        },
        liveDealersLocalDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Local online casino with live dealers in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        liveDealersBoardTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Board online casino with live dealers - Play for free"
            }
        },
        liveDealersBoardDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Board online casino with live dealers in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        liveDealersRouletteTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Roulette - online casino with live dealers - Play for free"
            }
        },
        liveDealersRouletteDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Roulette - online casino with live dealers in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        liveDealersOtherTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Other online casino with live dealers - Play for free"
            }
        },
        liveDealersOtherDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Other online casino with live dealers in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        casinoTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Online casino games - Play at 4rabet India"
            }
        },
        casinoDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play the best online casino in India on the 4rabet official website ⚡ Sign Up today and GET 700% welcome bonus up to 40000₹."
            }
        },
        privacyPolicyTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Privacy Policy - 4Rabet Sportsbook Company"
            }
        },
        privacyPolicyDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Privacy Policy - 4rabet official website."
            }
        },
        gamingPolicyTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Gaming Policy - 4Rabet Sportsbook Company"
            }
        },
        gamingPolicyDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Responsible Gaming Policy - 4rabet official website."
            }
        },
        rulesPageTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Rules for Specific sports - 4Rabet"
            }
        },
        rulesPageDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Rules for Specific sports - New Entertainment Development N.V. 4rabet official website."
            }
        },
        termsAndConditionsDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "TERMS AND CONDITIONS - New Entertainment Development N.V. 4rabet official website."
            }
        },
        bonusTermsDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bonus Terms - New Entertainment Development N.V. 4rabet official website."
            }
        },
        amlKycDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "AML & KYC Policy - New Entertainment Development N.V. 4rabet official website."
            }
        },
        infoTutorials: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "How to play at 4rabet? Betting Tutorials & Recommendations."
            }
        },
        liveDealersBaccaratTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live Baccarat Games With Live Dealers - 4Rabet Casino"
            }
        },
        liveDealersBlackJackTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live Blackjack Games With Live Dealers - 4Rabet Casino"
            }
        },
        popularTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Popular Casino Games - Choose Your Best Game at 4Rabet Casino"
            }
        },
        boardTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Board Casino Games - 4Rabet Casino"
            }
        },
        "tv-games/boardTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Board TV slot games"
            }
        },
        "tv-games/boardDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Board TV casino games in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        "tv-games/otherTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Other TV slot games"
            }
        },
        "tv-games/otherDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Other TV casino games in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        "tv-games/popularTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Popular TV slot games - 4Rabet Casino"
            }
        },
        "tv-games/popularDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Popular TV casino games in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        "tv-games/newGamesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "New TV slot games"
            }
        },
        "tv-games/newGamesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "New TV casino games in India on the 4rabet official website. Play for Free & Real Money."
            }
        },
        tableTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Casino Table Games - 4Rabet Casino"
            }
        },
        tvGamesPopularTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Popular TV Games - 4Rabet Casino"
            }
        },
        lineBasketballTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Basketball | Upcoming Matches, Odds & Predictions - 4Rabet Betting"
            }
        },
        lineTableTennisTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Table Tennis Games | Upcoming Matches, Odds & Predictions - 4Rabet Betting"
            }
        },
        lineTennisTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Tennis Bets Online | Predictions & Odds -- 4Rabet Betting"
            }
        },
        lineBaseballTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Baseball Betting & Live Scores | 4Rabet Betting"
            }
        },
        lineHorseRacingTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Horse Racing Betting | Upcoming Matches, Predictions & Odds - 4Rabet"
            }
        },
        "terms-and-conditions": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Terms & Conditions"
            }
        },
        "bonus-terms": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Bonuses Terms & Conditions: How To Use & Rules"
            }
        },
        bonuses: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Registration & Sign UP Bonuses, Promo Codes Up To 70000₹"
            }
        },
        profileHistory: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Login: Start To Win With Us & Get Bonuses Today"
            }
        },
        profilePage: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Sign Up: Register Today and GET Promo Codes for Registration"
            }
        },
        lineDota2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Dota-2 Betting: Live Matches, Predictions and Odds"
            }
        },
        iplAppTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4RABET IPL app | Download and Place Bets on Cricket"
            }
        },
        iplAppDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "IPL 2023 is going to rock our minds. Use the 4rabet IPL app as your main argument to succeed with your favorite IPL team!"
            }
        },
        oddsTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4RABET Best Live Cricket Satta Rates 2023 | Place bets and Win Today!"
            }
        },
        oddsDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: `Gentlemen - IPL is back! The best manifestation of a cricket masterpiece is available at 4rabet with the best rates on the market. 

In recent years, the sports betting landscape in India has changed with a significant increase. As a result, 4rabet has found the right place in the hearts of cricket lovers. For the passionate betting enthusiasts - we have set the best live cricket satta rates. You can find out what makes 4rabet so unique and why betting here can be worthwhile

4rabet is working on several markets at this moment and was first launched in 2018. From that time, 4rabet has spread to Bangladesh, Brazil, and Uzbekistan. 4rabet will soon be available in Marathi, Kannada, and Tamil languages.`
            }
        },
        bdMainTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet - Official Sports Betting and Casino Site | Login"
            }
        },
        bdMainDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Join 4Rabet - #1 official site for sports betting and casino in Bangladesh. Fast registration and great welcome bonuses. Login 4Rabet betting site now!"
            }
        },
        bdAppTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet App Download APK for Android and iOS - Free Version 2025"
            }
        },
        bdAppDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Download 4Rabet app on your device for free in Bangladesh! Bet on your favorite sports, enjoy casino games with the latest version of the mobile application for Android and iOS."
            }
        },
        bdBonusTermsTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Bonus Terms and Conditions"
            }
        },
        bdBonusTermsDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Read the 4Rabet Bonus Terms and Conditions. Find out how to use bonuses, free bets, and cashback offers effectively."
            }
        },
        bdBonusesTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Bonuses: Best Offers and Promo Codes - 2025"
            }
        },
        bdBonusesDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Discover exclusive 4Rabet bonuses and promo codes in 2025 for players from Bangladesh. Try our welcome bonus for casino and sports betting."
            }
        },
        bdTutorialsTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Tutorials: Learn How to Bet and Win"
            }
        },
        bdTutorialsDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Learn everything you need to get started placing bets at 4Rabet with our step-by-step tutorials."
            }
        },
        bdLiveTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Live Sports Betting | Best Odds at 4Rabet"
            }
        },
        bdLiveDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Join 4Rabet in Bangladesh and enjoy live betting on sports. Get the latest odds, follow live matches, and make the right moves to big wins."
            }
        },
        bdPlinkoTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Plinko Game: Play Online in Bangladesh"
            }
        },
        bdPlinkoDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play Plinko Game at 4Rabet and win real money! Get positive emotions and have great time with a generous welcome bonus for new online casino players."
            }
        },
        bdSportsTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Sports Betting | Best Odds at 4Rabet Sportsbook"
            }
        },
        bdSportsDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet on your favorite sports at 4Rabet in Bangladesh. Sign up and enjoy betting. Get the latest odds, follow live matches, and make the right moves to big wins."
            }
        },
        bdCasinoTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Casino: Play and Win Real Money | Get 700% Bonus"
            }
        },
        bdCasinoDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Start your journey with 4Rabet casino in Bangladesh. Enjoy casino games: slots, live dealers, table games. Log in to 4Rabet and get 700% Bonus."
            }
        },
        bdLiveDealersTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Play Live Casino Games | 4Rabet Casino in Bangladesh"
            }
        },
        bdLiveDealersDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enjoy Live Casino Games at 4Rabet site in Bangladesh. Register now to get 700% Welcome Bonus, play with live dealers and win real money."
            }
        },
        bdDepositTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "4Rabet Withdrawal and Deposit Methods | Your Guide"
            }
        },
        bdDepositDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet in Bangladesh offers reliable deposit methods with fast withdrawal times. Learn more about 4Rabet payment options, withdrawal timelines, and any limits."
            }
        },
        bdTvGamesTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Play TV Games Online | 4Rabet Casino in Bangladesh"
            }
        },
        bdTvGamesDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enjoy TV Games at 4Rabet site in Bangladesh. Register now and play in demo or for real money with 700% Welcome Bonus."
            }
        },
        bdAviatorTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Aviator Game - Login & Play Online for Real Money"
            }
        },
        bdAviatorDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Login and start playing 4Rabet Aviator game in Bangladesh! Discover the best tips and strategies to maximize your wins 📲 Download 4Rabet Aviator app and get generous Crash Bonus."
            }
        },
        bdCrazyTimeTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Crazy Time Live Game: Play Online in Bangladesh"
            }
        },
        bdCrazyTimeDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Play Crazy Time Game at 4Rabet and win real money! Get positive emotions and have great time with a generous welcome bonus for new online casino players."
            }
        },
        bdProfileHistoryTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }, {
                    t: 9
                }, {
                    t: 3
                }],
                s: "Profile History | 4RabetSiteBD"
            }
        },
        bdProfileHistoryDesc: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Keep track of your bets, deposits, and withdrawals with personal 4Rabet history page."
            }
        },
        dynamicBd: {
            "bd-casinoSlotTitle": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Play Online Games "
                    }, {
                        t: 9,
                        v: "|"
                    }, {
                        t: 3,
                        v: " 4Rabet Bangladesh"
                    }]
                }
            },
            "bd-casinoSlotDesc": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Play "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " and run after big prizes with a mix of casino games at 4Rabet. Play for real cash and in the demo way"
                    }]
                }
            },
            "bd-liveSlotTitle": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Online: Play to Win at 4Rabet BD"
                    }]
                }
            },
            "bd-liveSlotDesc": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Try "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " and seek big prizes with different choice of live casino fun at 4Rabet. Play for real cash, and in demo mode!"
                    }]
                }
            },
            "bd-casinoCategoryTitle": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Play "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Online Casino Games "
                    }, {
                        t: 9,
                        v: "|"
                    }, {
                        t: 3,
                        v: " 4Rabet Bangladesh"
                    }]
                }
            },
            "bd-casinoCategoryDesc": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Have fun with "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Games at 4Rabet site in Bangladesh. Sign up now to play in demo or for the real cash with 700% Welcome Bonus,"
                    }]
                }
            },
            "bd-liveCategoryTitle": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Play "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " with Live Dealer "
                    }, {
                        t: 9,
                        v: "|"
                    }, {
                        t: 3,
                        v: " 4Rabet Casino"
                    }]
                }
            },
            "bd-liveCategoryDesc": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Have fun with live "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " games at 4Rabet site in Bangladesh. Sign up now for get 700% welcome bonus. Play with live dealer and win real money!"
                    }]
                }
            },
            "bd-tvGamesTitle": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Play "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " TV Games at 4Rabet Casino Online"
                    }]
                }
            },
            "bd-tvGamesDesc": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Try "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " TV games at 4rabet site in Bangladesh. Sign up now to play in a demo or for real cash with the 700% welcome bonus,"
                    }]
                }
            },
            "bd-liveSportsTitle": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Bet Live on "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " with 4Rabet's Top Odds"
                    }]
                }
            },
            "bd-liveSportsDesc": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Join 4Rabet at Bangladesh and have fun with live "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " bets. Get the new odds, watch live games and make the smart moves to big win's"
                    }]
                }
            },
            "bd-sportsTitle": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Betting Made Easy with 4Rabet's Best Odds"
                    }]
                }
            },
            "bd-sportsDesc": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Bet on "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " with 4Rabet in Bangladesh. Join up and have fun with "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " bets. Get the new odds, watch live games and make good choices for big wins!"
                    }]
                }
            },
            bdCasinoSlotTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Play Online "
                    }, {
                        t: 9,
                        v: "|"
                    }, {
                        t: 3,
                        v: " 4RabetSiteBD"
                    }]
                }
            },
            bdCasinoSlotDesc: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Enjoy "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " and chase big wins with diverse selection of casino games at 4Rabet. Play for real money and in demo mode"
                    }]
                }
            },
            bdLiveSlotTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Game Play Online "
                    }, {
                        t: 9,
                        v: "|"
                    }, {
                        t: 3,
                        v: " 4RabetSiteBD"
                    }]
                }
            },
            bdLiveSlotDesc: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Try "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " and chase big wins with diverse selection of live casino games at 4Rabet. Play for real money and in demo mode"
                    }]
                }
            },
            bdCasinoCategoryTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Play "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Games Online "
                    }, {
                        t: 9,
                        v: "|"
                    }, {
                        t: 3,
                        v: " 4Rabet Casino in Bangladesh"
                    }]
                }
            },
            bdCasinoCategoryDesc: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Enjoy "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Games at 4Rabet site in Bangladesh. Register now to play in demo or for real money with 700% Welcome Bonus"
                    }]
                }
            },
            bdLiveCategoryTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Play "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Games with Live Dealer "
                    }, {
                        t: 9,
                        v: "|"
                    }, {
                        t: 3,
                        v: " 4Rabet Casino"
                    }]
                }
            },
            bdLiveCategoryDesc: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Enjoy Live "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Games at 4Rabet site in Bangladesh. Register now to get 700% Welcome Bonus. Play with live dealers and win real money"
                    }]
                }
            },
            bdTvGamesTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Play "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " TV Games Online "
                    }, {
                        t: 9,
                        v: "|"
                    }, {
                        t: 3,
                        v: " 4Rabet Casino in Bangladesh"
                    }]
                }
            },
            bdTvGamesDesc: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Enjoy "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " TV Games at 4Rabet site in Bangladesh. Register now to play in demo or for real money with 700% Welcome Bonus"
                    }]
                }
            },
            bdLiveSportsTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Live "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Betting "
                    }, {
                        t: 9,
                        v: "|"
                    }, {
                        t: 3,
                        v: " Best Odds at 4Rabet"
                    }]
                }
            },
            bdLiveSportsDesc: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Join 4Rabet in Bangladesh and enjoy live "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " betting. Get the latest odds, follow live matches, and make the right moves to big wins"
                    }]
                }
            },
            bdSportsTitle: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " Betting "
                    }, {
                        t: 9,
                        v: "|"
                    }, {
                        t: 3,
                        v: " Best Odds at 4Rabet"
                    }]
                }
            },
            bdSportsDesc: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3,
                        v: "Bet on "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " with 4Rabet in Bangladesh. Sign up and enjoy "
                    }, {
                        t: 4,
                        k: "name"
                    }, {
                        t: 3,
                        v: " betting. Get the latest odds, follow live matches, and make the right moves to big wins"
                    }]
                }
            }
        },
        "bd-mainTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Official Site for Sports Betting and Online Casino"
            }
        },
        "bd-mainDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Join 4Rabet today for sports betting and online casino fun! Use prom"
            }
        },
        "bd-appTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Download 4rabet App for Android & iOS - Latest APK 2025 Available!"
            }
        },
        "bd-appDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Download the 4rabet app for Android and iOS! Get the latest version of our mobile application, complete with a guide on how to download and install."
            }
        },
        "bd-liveTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Live Sports Betting and Games with live dealers"
            }
        },
        "bd-liveDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Join 4Rabet for live sports betting and thrilling casino games with live dealers! Enjoy a generous welcome bonus and start betting today on the best bookmaker in India!"
            }
        },
        "bd-casinoTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Casino: Claim Your Bonus and Play Online Slots & Games"
            }
        },
        "bd-casinoDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Claim your 4rabet Casino welcome bonus, explore exciting live dealer games, and enjoy thrilling slots at 4Rabet online casino today!"
            }
        },
        "bd-bonusesTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet Bonuses: Best Offers and Promo Codes - 2025"
            }
        },
        "bd-bonusesDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "4Rabet bonuses and promo codes in 2025 for players from Bangladesh. Try our welcome bonus for casino and sports betting."
            }
        },
        "bd-crazyTimeTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Crazy Time at 4rabet Casino: Bonuses, Tips & Live Action"
            }
        },
        "bd-crazyTimeDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Turn the wheel and win large with Crazy Time at 4rabet Casino! Find special gifts, learn the game with our tricks, and feel the joy of live casino fun. Join up now!"
            }
        },
        "bd-promo-codeTitle": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Best 4Rabet Promo Codes in Bangladesh - Get Exclusive Bonuses & Rewards"
            }
        },
        "bd-promo-codeDesc": {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Maximize your winnings with 4Rabet promo codes in Bangladesh. Learn the latest promo codes, tips for effective use, and how to redeem for exciting bonuses. Don’t miss out on boosting your bankroll today!"
            }
        }
    },
    timer: {
        days: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Days"
            }
        },
        hours: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Hours"
            }
        },
        mins: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Mins"
            }
        },
        secs: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Secs"
            }
        }
    },
    bonuses: {
        timeToUse: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "time to use"
            }
        },
        progress: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Progress"
            }
        },
        freeSpins: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Freespins:"
            }
        },
        wagerFreeSpins: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Wager Free Spin Bonus"
            }
        },
        left: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Left"
            }
        },
        bet: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Bet"
            }
        },
        earned: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Earned"
            }
        },
        freeRoundArrived: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Dear user! You are awarded free rounds in the game <span>4 OF A KING</span>. Number of free rounds: <span>25</span>"
            }
        },
        bonusBalanceFormation: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Dear user! As a result of free rounds, you are awarded a free rounds bonus of <span>5000 INR</span>. For further information please review the active bonus details."
            }
        }
    },
    newMain: {
        mainBanner: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "WELCOME PACK"
                }
            },
            subTitle1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "700%"
                }
            },
            subTitle2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "UP TO 90,000₹"
                }
            },
            download: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "DOWNLOAD THE APP RIGHT NOW!"
                }
            }
        },
        enjoy: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Enjoy your <span>Experience!</span>"
            }
        },
        welcomeBonus: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "WELCOME BONUS"
            }
        },
        liveDealers: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live <span>Dealers</span>"
            }
        },
        cardSubTitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Total rounds for today"
            }
        },
        topSections: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Top sections"
                }
            },
            titlePart1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Top"
                }
            },
            titlePart2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "sections"
                }
            },
            JetX: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "JetX"
                }
            },
            sports: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Sports"
                }
            },
            sportsv2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Sports"
                }
            },
            "live-casino": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Live Casino"
                }
            },
            evolution: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Evolution"
                }
            },
            casino: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Casino"
                }
            },
            aviator: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Aviator"
                }
            },
            vip: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "VIP Club"
                }
            },
            deposit: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Deposit"
                }
            },
            football: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Football"
                }
            },
            cricket: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Cricket"
                }
            },
            pragmatic: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Pragmatic"
                }
            },
            rewards: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "levelUP"
                }
            },
            open: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Open"
                }
            },
            trends: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Trends"
                }
            },
            "chicken-road": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Chicken Road"
                }
            }
        },
        sportSections: {
            cwc23: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Cricket World Cup"
                }
            },
            cricket: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "cricket"
                }
            },
            football: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "football"
                }
            },
            ecricket: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "ecricket"
                }
            },
            basketball: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "basketball"
                }
            },
            tennis: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "tennis"
                }
            },
            fifa: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "fifa"
                }
            },
            "table-tennis": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "table tennis"
                }
            },
            volleyball: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "volleyball"
                }
            },
            "ice-hockey": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "ice hockey"
                }
            },
            baseball: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "baseball"
                }
            },
            mma: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "MMA"
                }
            },
            handball: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "handball"
                }
            },
            "virtual-sports": {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "virtual sports"
                }
            },
            ICC: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "ICC 2025"
                }
            },
            IPL: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "IPL 2025"
                }
            }
        },
        gameSection: {
            live: {
                title: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Live Casino"
                    }
                },
                linkText: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "More Live Dealers"
                    }
                },
                minorTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "awesome"
                    }
                },
                minorSubTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Live Dealers"
                    }
                },
                title1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Total rounds for today"
                    }
                },
                title2: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Active tables"
                    }
                },
                title3: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Top table/games"
                    }
                },
                title4: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Highest win of the day"
                    }
                },
                bage1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "live"
                    }
                }
            },
            sport: {
                title: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Sports"
                    }
                },
                linkText: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "More LIVE events"
                    }
                },
                minorTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "it's time to"
                    }
                },
                minorSubTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Place a Bet"
                    }
                },
                title1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Highest win of the day"
                    }
                },
                title2: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Highest win of the month"
                    }
                },
                title3: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Highest win of all time"
                    }
                },
                bage1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "live"
                    }
                },
                bage2: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "line"
                    }
                },
                bage3: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "line"
                    }
                }
            },
            crash: {
                title: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Crash games"
                    }
                },
                minorTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "awesome"
                    }
                },
                minorSubTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Crash games"
                    }
                },
                title1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Total rounds for today"
                    }
                },
                title2: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Top game"
                    }
                },
                title3: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Highest win of the day"
                    }
                },
                title4: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Highest jackpot"
                    }
                },
                linkText: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "More Crash games"
                    }
                },
                bage1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "live"
                    }
                }
            },
            slots: {
                title: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Slots"
                    }
                },
                minorTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "the best"
                    }
                },
                minorSubTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Slots"
                    }
                },
                title1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Highest win"
                    }
                },
                title2: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Jackpot"
                    }
                },
                title3: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Spins this week"
                    }
                },
                linkText: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "See all"
                    }
                }
            },
            casino: {
                title: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Casino"
                    }
                },
                linkText: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "More Casino Games"
                    }
                },
                minorTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "awesome"
                    }
                },
                minorSubTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "TOP Casino Games"
                    }
                },
                title1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Spins this week"
                    }
                },
                title2: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Highest win"
                    }
                },
                title3: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Highest jackpot"
                    }
                },
                bage1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "max"
                    }
                },
                bage2: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "min"
                    }
                }
            },
            exclusives: {
                title: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "4RABET Exclusives"
                    }
                },
                linkText: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "See all"
                    }
                },
                minorTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "awesome"
                    }
                },
                minorSubTitle: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "4RABET Exclusives"
                    }
                },
                title1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Spins this week"
                    }
                },
                title2: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Top Game"
                    }
                },
                title3: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Highest win"
                    }
                },
                bage1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "12.06.2024"
                    }
                }
            }
        },
        bonusSection: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Bonuses"
                }
            },
            showMore: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "More bonuses"
                }
            }
        }
    },
    verification: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Verification"
            }
        },
        close: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Close"
            }
        },
        verification_is_success: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Verified"
            }
        },
        verification_is_failed: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Verification is failed"
            }
        },
        verification_is_failed_text1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Withdrawal is not available for verification failure reasons. For more details please"
            }
        },
        verification_is_failed_text2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "contact support"
            }
        },
        verification_is_failed_text3: {
            t: 0,
            b: {
                static: "",
                t: 2,
                i: []
            }
        },
        verification_is_required: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Verification is required"
            }
        },
        verification_is_required_text1: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "To be able to withdraw, please complete the verification"
            }
        },
        verification_is_required_text2: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "To be able to withdraw, please complete the additional verification"
            }
        },
        verification_recomended_title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Profile verification"
            }
        },
        verification_recomended_btn: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Verification"
            }
        },
        verification_recomended_text: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Upgrade your account by completing verification to get exclusive offers"
            }
        },
        verification_recomended_label: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Verified"
            }
        },
        verification_recomended_label_failed: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Verification failed"
            }
        }
    },
    guide: {
        step: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "STEP"
            }
        },
        download: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "4RABET APP DOWNLOAD GUIDE: <br/> 4 STEPS TO GET 4RABET APK ON YOUR ANDROID SMARTPHONE"
                }
            },
            textStep1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Find the Download Buttons at this page. You can use either the direct links from the beginning of this page, or use the Android and iOS download buttons in the upper right corner."
                }
            },
            textStep2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Choose the appropriate 4Rabet app version for your operating system. If you’d like to download 4Rabet apk – press the Android icon, if you’d like to install the iOS version – click on the iOS button."
                }
            },
            textStep3: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Download the .apk file on your phone. By clicking the Android icon, download will start automatically and end in a few seconds."
                }
            },
            downloadApk: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Download 4rabet APK"
                }
            },
            textStep4: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Faced with any problems? Write to the 4Rabet support and get help from our team."
                }
            }
        },
        install: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "4RABET APK INSTALLING GUIDE"
                }
            },
            textStep1: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Find the privacy section on your phone."
                }
            },
            textStep2: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Allow to install unknown apps. This function allows you to download apps and .apk files not only from the Play Market, but from the direct download links as well."
                }
            },
            textStep3: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Click the “Install” button and the installation process will be started and finished automatically."
                }
            },
            textStep4: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: "Find the 4Rabet app icon on your smartphone desktop screen. From this point, you can register or log in to the 4Rabet app and play!"
                }
            }
        },
        cricketBettingApp: {
            title: {
                t: 0,
                b: {
                    t: 2,
                    i: [{
                        t: 3
                    }],
                    s: " Cricket Betting App: How to Download and Start to Use (Including 4Rabet.apk) ?"
                }
            },
            android: {
                title: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "INSTALLATION ON ANDROID"
                    }
                },
                text1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Click the 'Download' button from your Android device."
                    }
                },
                text2: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "When the file is downloaded, click 'Install'. If the device asks for additional confirmation, then confirm."
                    }
                },
                text3: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "If you have an account on our site, then login, if not, then register."
                    }
                }
            },
            apple: {
                title: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "INSTALLATION ON APPLE"
                    }
                },
                text1: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Open this page in Safari browser."
                    }
                },
                text2: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Tap on 'Share' icon in the menu at the bottom of your screen."
                    }
                },
                text3: {
                    t: 0,
                    b: {
                        t: 2,
                        i: [{
                            t: 3
                        }],
                        s: "Tap 'Go to Home Screen' and then 'Finish'. Subsequently, the application will be successfully installed on your phone."
                    }
                }
            }
        }
    },
    tutotial: {
        registration: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Registration"
            }
        },
        welcomeBonus: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Welcome bonus"
            }
        },
        bettingTutorial: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Betting Tutorial"
            }
        },
        casinoTutorial: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Casino tutorial"
            }
        },
        withdrawalYouWinning: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Withdrawal you winning"
            }
        }
    },
    footerNew: {
        personal: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Personal"
            }
        },
        support: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Support"
            }
        },
        terms: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Terms"
            }
        },
        betting: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Betting"
            }
        },
        casino: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Casino"
            }
        },
        reportProblem: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Report problem"
            }
        },
        downloadAndroid: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "<span>Download for</span><strong>Android</strong>"
            }
        },
        downloadIOS: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "<span>Download for</span><strong>iOS</strong>"
            }
        },
        downloadApp: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "DOWNLOAD THE APP RIGHT NOW!"
            }
        },
        live: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Live"
            }
        }
    },
    registrationBanner: {
        title: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: 'Get Welcome offer 700% <span class="sign_up_text">Right Now</span>'
            }
        },
        subtitle: {
            t: 0,
            b: {
                t: 2,
                i: [{
                    t: 3
                }],
                s: "Quick Sign Up"
            }
        }
    }
};
export {
    a as
    default
};