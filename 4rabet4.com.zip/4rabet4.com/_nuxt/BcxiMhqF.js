import {
    u as d
} from "./CNVksA_o.js";
import {
    d as o
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            s = new e.Error().stack;
        s && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[s] = "c8c74d4a-b23d-4588-88ae-58bac0719dbc", e._sentryDebugIdIdentifier = "sentry-dbid-c8c74d4a-b23d-4588-88ae-58bac0719dbc")
    } catch {}
})();

function c() {
    const e = d(),
        s = "iphone",
        n = o(() => e.isIos || (e.isApple || e.isSafari) && e.isMobileOrTablet),
        t = o(() => n.value ? s : "");
    return {
        isIphone: n,
        classForIphone: t
    }
}
export {
    c as u
};