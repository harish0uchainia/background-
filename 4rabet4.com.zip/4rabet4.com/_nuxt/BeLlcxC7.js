import {
    h as v,
    _ as g
} from "./BbvgifQp.js";
import {
    a as I
} from "./DDGpYvNX.js";
import {
    z as B,
    d as k,
    _ as w,
    V as S,
    D as V,
    u as i,
    O as D,
    f as T,
    ai as j,
    W as p,
    $ as f,
    a0 as m,
    a1 as c,
    J as y
} from "./BBZLTf3A.js";
(function() {
    try {
        var l = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            t = new l.Error().stack;
        t && (l._sentryDebugIds = l._sentryDebugIds || {}, l._sentryDebugIds[t] = "d5408249-37ed-4921-9883-39c0c0d59cca", l._sentryDebugIdIdentifier = "sentry-dbid-d5408249-37ed-4921-9883-39c0c0d59cca")
    } catch {}
})();
const C = {
        class: "select"
    },
    O = B({
        __name: "AppSelect",
        props: {
            appendIcon: {
                default: ""
            },
            prependIcon: {
                default: ""
            },
            error: {
                type: Boolean,
                default: !1
            },
            prependInnerIcon: {
                default: ""
            },
            fullWidth: {
                type: Boolean,
                default: !0
            },
            displayDropdown: {
                type: Boolean,
                default: !1
            },
            run: {
                type: Boolean,
                default: !0
            },
            itemColor: {
                default: ""
            },
            backgroundColor: {
                default: "var(--color-form)"
            },
            itemText: {
                default: ""
            },
            itemValue: {
                default: ""
            },
            isSlotableItem: {
                type: Boolean,
                default: !1
            },
            isSlotableSelection: {
                type: Boolean,
                default: !1
            },
            placeholder: {
                default: ""
            },
            menuIcon: {
                default: "mdi-chevron-down"
            },
            color: {
                default: "#fff"
            },
            items: {
                default: () => []
            },
            height: {
                default: 50
            },
            disabled: {
                type: Boolean,
                default: !1
            },
            readonly: {
                type: Boolean,
                default: !1
            },
            dense: {
                type: Boolean,
                default: !1
            },
            returnObject: {
                type: Boolean
            },
            value: {
                default: null
            },
            dark: {
                type: Boolean
            },
            multiple: {
                type: Boolean
            },
            menuProps: {
                default: void 0
            }
        },
        emits: ["value"],
        setup(l, {
            emit: t
        }) {
            const o = l,
                {
                    t: b
                } = v(),
                d = t,
                a = k({
                    get() {
                        return ["string", "number"].includes(typeof o.value) && o.items.find(e => typeof e == "object" && e ? e[o.itemValue] === o.value : e === o.value) || o.value
                    },
                    set(e) {
                        if (o.returnObject) {
                            d("value", e);
                            return
                        }
                        d("value", e[o.itemText])
                    }
                });
            a.value = o.value;

            function u(e) {
                return o.itemText === "translation" ? b(e.translation) : e[o.itemText]
            }
            return (e, s) => (S(), w("div", C, [V(I, {
                modelValue: i(a),
                "onUpdate:modelValue": s[0] || (s[0] = n => T(a) ? a.value = n : null),
                dense: e.dense,
                attach: "",
                variant: "outlined",
                density: "compact",
                "menu-icon": e.menuIcon,
                items: e.items,
                "append-icon": e.appendIcon,
                "prepend-icon": e.prependIcon,
                "prepend-inner-icon": e.prependInnerIcon,
                "full-width": e.fullWidth,
                "item-color": e.itemColor,
                "background-color": e.backgroundColor,
                "item-title": e.itemText,
                "item-value": e.itemValue,
                placeholder: e.placeholder,
                color: e.color,
                run: e.run,
                height: e.height,
                disabled: e.disabled,
                readonly: "readonly" in e ? e.readonly : i(D),
                "return-object": e.returnObject,
                dark: e.dark,
                multiple: e.multiple,
                "menu-props": e.menuProps,
                menu: e.displayDropdown,
                "error-messages": e.error ? "This field is required" : "",
                "hide-details": !e.error
            }, j({
                _: 2
            }, [e.isSlotableItem ? {
                name: "item",
                fn: p(({
                    props: n,
                    item: {
                        value: r
                    },
                    index: h
                }) => [f(e.$slots, "item", y({ ...n,
                    index: h
                }, {
                    item: r
                }), () => [m("span", null, c(u(r)), 1)], !0)]),
                key: "0"
            } : void 0, e.isSlotableSelection ? {
                name: "selection",
                fn: p(({
                    item: {
                        value: n
                    },
                    ...r
                }) => [f(e.$slots, "selection", y({
                    item: n
                }, r), () => [m("span", null, c(u(n)), 1)], !0)]),
                key: "1"
            } : void 0]), 1032, ["modelValue", "dense", "menu-icon", "items", "append-icon", "prepend-icon", "prepend-inner-icon", "full-width", "item-color", "background-color", "item-title", "item-value", "placeholder", "color", "run", "height", "disabled", "readonly", "return-object", "dark", "multiple", "menu-props", "menu", "error-messages", "hide-details"])]))
        }
    }),
    E = g(O, [
        ["__scopeId", "data-v-fec14248"]
    ]);
export {
    E as _
};