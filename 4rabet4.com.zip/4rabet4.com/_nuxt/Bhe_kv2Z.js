import {
    N as $,
    bL as j,
    v as P,
    w as I,
    z as E,
    B as S,
    e as B,
    d as M,
    bM as z,
    t as w,
    h as A,
    bN as W,
    bO as h
} from "./BbvgifQp.js";
import {
    d as o,
    b as Z,
    w as H
} from "./BBZLTf3A.js";
(function() {
    try {
        var t = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            i = new t.Error().stack;
        i && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[i] = "e460caaa-71ed-4b5d-9273-1d896a38624e", t._sentryDebugIdIdentifier = "sentry-dbid-e460caaa-71ed-4b5d-9273-1d896a38624e")
    } catch {}
})();

function O(t, i) {
    const {
        title: e,
        titleTemplate: a,
        ...l
    } = t;
    return $({
        title: e,
        titleTemplate: a,
        _flatMeta: l
    }, { ...i,
        transform(c) {
            const T = j({ ...c._flatMeta
            });
            return delete c._flatMeta, { ...c,
                meta: T
            }
        }
    })
}

function U(t, i) {
    return o(() => {
        const e = `/${i.value}`;
        return t.path.replace(e, "").replace(/^\//, "")
    })
}

function X(t, i) {
    const {
        userGeo: e
    } = P(I()), {
        $i18n: a
    } = E(), l = o(() => a.locale.value === "en"), c = o(() => ["ZM", "RW"].includes(e.value)), T = p => {
        const g = i[p];
        return (g == null ? void 0 : g[t]) || null
    };
    return {
        metaInfo: o(() => {
            if (l.value && c.value) {
                const p = T(e.value);
                if (p) return p
            }
            return i[t] || {}
        })
    }
}
const F = {
        casino: {
            title: "pageTitles.casinoTitle",
            description: "pageTitles.casinoDesc"
        },
        "casino/bingo": {
            title: "pageTitles.bingoTitle",
            description: "pageTitles.bingoDesc"
        },
        "casino/keno": {
            title: "pageTitles.kenoTitle",
            description: "pageTitles.kenoDesc"
        },
        "casino/roulette": {
            title: "pageTitles.rouletteTitle",
            description: "pageTitles.rouletteDesc"
        },
        "casino/lottery": {
            title: "pageTitles.lotteryTitle",
            description: "pageTitles.lotteryDesc"
        },
        "casino/blackjack": {
            title: "pageTitles./casino/blackjackTitle",
            description: "pageTitles./casino/blackjackDesc"
        },
        "casino/new-games": {
            title: "pageTitles./casino/newGamesTitle",
            description: "pageTitles./casino/newGamesDesc"
        },
        "casino/crash": {
            title: "pageTitles./casino/crashTitle",
            description: "pageTitles./casino/crashDesc"
        },
        "casino/other": {
            title: "pageTitles./casino/otherTitle",
            description: "pageTitles./casino/otherDesc"
        },
        "casino/fast": {
            title: "pageTitles./casino/fastTitle",
            description: "pageTitles./casino/fastDesc"
        },
        "casino/live": {
            title: "pageTitles./casino/liveTitle",
            description: "pageTitles./casino/liveDesc"
        },
        "casino/table": {
            title: "pageTitles./casino/tableTitle",
            description: "pageTitles./casino/tableDesc"
        },
        "casino/local": {
            title: "pageTitles./casino/localTitle",
            description: "pageTitles./casino/localDesc"
        },
        "casino/popular": {
            title: "pageTitles./casino/popularTitle",
            description: "pageTitles./casino/popularDesc"
        },
        "casino/virtual_sports": {
            title: "pageTitles./casino/virtualSportsTitle",
            description: "pageTitles./casino/virtualSportsDesc"
        },
        "casino/vip": {
            title: "pageTitles./casino/vipTitle",
            description: "pageTitles./casino/vipDesc"
        },
        "casino/slots": {
            title: "pageTitles.slotsTitle",
            description: "pageTitles.slotsDesc"
        },
        "casino/baccarat": {
            title: "pageTitles.baccaratTitle",
            description: "pageTitles.baccaratDesc"
        },
        "casino/exclusives": {
            title: "pageTitles.exclusivesTitle",
            description: "pageTitles.exclusivesDesc"
        },
        "casino/slot/aviatrix": {
            title: "pageTitles./slot/aviatrixTitle",
            description: "pageTitles./slot/aviatrixDesc"
        },
        "casino/slot/balloon": {
            title: "pageTitles./slot/balloonTitle",
            description: "pageTitles./slot/balloonDesc"
        },
        "casino/slot/lucky-mines": {
            title: "pageTitles./slot/luckyMinesTitle",
            description: "pageTitles./slot/luckyMinesDesc"
        },
        "casino/slot/lucky-captain-0": {
            title: "pageTitles./slot/luckyCaptainTitle",
            description: "pageTitles./slot/luckyCaptainDesc"
        },
        "casino/slot/aviator": {
            title: "pageTitles.slotAviatorTitle",
            description: "pageTitles.slotAviatorDesc"
        },
        "casino/slot/chicken-road-0": {
            title: "pageTitles./slot/chickenRoadTitle",
            description: "pageTitles./slot/chickenRoadDesc"
        },
        "casino/slot/jetx": {
            title: "pageTitles./slot/jetXTitle",
            description: "pageTitles./slot/jetXDesc"
        },
        "casino/slot/jetx-m": {
            title: "pageTitles./slot/jetXTitle",
            description: "pageTitles./slot/jetXDesc"
        },
        "casino/slot/crazy-time-10418": {
            title: "pageTitles./slot/crazyTimeTitle",
            description: "pageTitles./slot/crazyTimeDesc"
        },
        "casino/slot/dragon-tiger-evolution": {
            title: "pageTitles./slot/dragonTigerTitle",
            description: "pageTitles./slot/dragonTigerDesc"
        },
        ZM: {
            casino: {
                title: "pageTitles.ZM/casinoTitle",
                description: "pageTitles.ZM/casinoDesc"
            },
            "casino/slots": {
                title: "pageTitles.ZM/casino/slotsTitle",
                description: "pageTitles.ZM/casino/slotsDesc"
            },
            "casino/roulette": {
                title: "pageTitles.ZM/casino/rouletteTitle",
                description: "pageTitles.ZM/casino/rouletteDesc"
            },
            "casino/popular": {
                title: "pageTitles.ZM/casino/popularTitle",
                description: "pageTitles.ZM/casino/popularDesc"
            },
            "casino/new-games": {
                title: "pageTitles.ZM/casino/new-gamesTitle",
                description: "pageTitles.ZM/casino/new-gamesDesc"
            },
            "casino/lottery": {
                title: "pageTitles.ZM/casino/lotteryTitle",
                description: "pageTitles.ZM/casino/lotteryDesc"
            },
            "casino/keno": {
                title: "pageTitles.ZM/casino/kenoTitle",
                description: "pageTitles.ZM/casino/kenoDesc"
            },
            "casino/blackjack": {
                title: "pageTitles.ZM/casino/blackjackTitle",
                description: "pageTitles.ZM/casino/blackjackDesc"
            },
            "casino/bingo": {
                title: "pageTitles.ZM/casino/bingoTitle",
                description: "pageTitles.ZM/casino/bingoDesc"
            },
            "casino/baccarat": {
                title: "pageTitles.ZM/casino/baccaratTitle",
                description: "pageTitles.ZM/casino/baccaratDesc"
            },
            "casino/slot/aviator": {
                title: "pageTitles.ZM/casino/slot/aviatorTitle",
                description: "pageTitles.ZM/casino/slot/aviatorDesc"
            }
        },
        RW: {
            casino: {
                title: "pageTitles.RW/casinoTitle",
                description: "pageTitles.RW/casinoDesc"
            },
            "casino/slots": {
                title: "pageTitles.RW/casino/slotsTitle",
                description: "pageTitles.RW/casino/slotsDesc"
            },
            "casino/roulette": {
                title: "pageTitles.RW/casino/rouletteTitle",
                description: "pageTitles.RW/casino/rouletteDesc"
            },
            "casino/popular": {
                title: "pageTitles.RW/casino/popularTitle",
                description: "pageTitles.RW/casino/popularDesc"
            },
            "casino/new-games": {
                title: "pageTitles.RW/casino/new-gamesTitle",
                description: "pageTitles.RW/casino/new-gamesDesc"
            },
            "casino/lottery": {
                title: "pageTitles.RW/casino/lotteryTitle",
                description: "pageTitles.RW/casino/lotteryDesc"
            },
            "casino/keno": {
                title: "pageTitles.RW/casino/kenoTitle",
                description: "pageTitles.RW/casino/kenoDesc"
            },
            "casino/blackjack": {
                title: "pageTitles.RW/casino/blackjackTitle",
                description: "pageTitles.RW/casino/blackjackDesc"
            },
            "casino/bingo": {
                title: "pageTitles.RW/casino/bingoTitle",
                description: "pageTitles.RW/casino/bingoDesc"
            },
            "casino/baccarat": {
                title: "pageTitles.RW/casino/baccaratTitle",
                description: "pageTitles.RW/casino/baccaratDesc"
            },
            "casino/slot/aviator": {
                title: "pageTitles.RW/casino/slot/aviatorTitle",
                description: "pageTitles.RW/casino/slot/aviatorDesc"
            }
        }
    },
    K = {
        ZM: {
            "live-dealers/baccarat": {
                title: "pageTitles.ZM/live-dealers/baccaratTitle",
                description: "pageTitles.ZM/live-dealers/baccaratDesc"
            },
            "live-dealers/roulette": {
                title: "pageTitles.ZM/live-dealers/rouletteTitle",
                description: "pageTitles.ZM/live-dealers/rouletteDesc"
            },
            "live-dealers": {
                title: "pageTitles.ZM/live-dealersTitle",
                description: "pageTitles.ZM/live-dealersDesc"
            }
        },
        RW: {
            "live-dealers/baccarat": {
                title: "pageTitles.RW/live-dealers/baccaratTitle",
                description: "pageTitles.RW/live-dealers/baccaratDesc"
            },
            "live-dealers/roulette": {
                title: "pageTitles.RW/live-dealers/rouletteTitle",
                description: "pageTitles.RW/live-dealers/rouletteDesc"
            },
            "live-dealers": {
                title: "pageTitles.RW/live-dealersTitle",
                description: "pageTitles.RW/live-dealersDesc"
            }
        },
        "rules-page": {
            title: "pageTitles./rulesTitle",
            description: "pageTitles./rulesDesc"
        },
        "live-dealers/baccarat": {
            title: "pageTitles.liveDealersBaccaratTitle",
            description: ""
        },
        "live-dealers/new-games": {
            title: "pageTitles.liveDealersNewGamesTitle",
            description: "pageTitles.liveDealersNewGamesDesc"
        },
        "live-dealers/popular": {
            title: "pageTitles.liveDealersPopularTitle",
            description: "pageTitles.liveDealersPopularDesc"
        },
        "live-dealers/vip": {
            title: "pageTitles.liveDealersVipTitle",
            description: "pageTitles.liveDealersVipDesc"
        },
        "live-dealers/game_shows": {
            title: "pageTitles.liveDealersGameShowsTitle",
            description: "pageTitles.liveDealersGameShowsDesc"
        },
        "live-dealers/evolution": {
            title: "pageTitles.liveDealersEvolutionTitle",
            description: "pageTitles.liveDealersEvolutionDesc"
        },
        "live-dealers/local": {
            title: "pageTitles.liveDealersLocalTitle",
            description: "pageTitles.liveDealersLocalDesc"
        },
        "live-dealers/board": {
            title: "pageTitles.liveDealersBoardTitle",
            description: "pageTitles.liveDealersBoardDesc"
        },
        "live-dealers/other": {
            title: "pageTitles.liveDealersOtherTitle",
            description: "pageTitles.liveDealersOtherDesc"
        },
        "live-dealers/roulette": {
            title: "pageTitles.liveDealersRouletteTitle",
            description: "pageTitles.liveDealersRouletteDesc"
        },
        "live-dealers": {
            title: "pageTitles.liveDealersTitle",
            description: "pageTitles.liveDealersDesc"
        }
    },
    V = {
        live: {
            title: "pageTitles./liveTitle",
            description: "pageTitles./liveDesc"
        },
        "live/soccer": {
            title: "pageTitles./live/soccerTitle",
            description: "pageTitles./live/soccerDesc"
        },
        "live/ecricket": {
            title: "pageTitles./live/ecricketTitle",
            description: "pageTitles./live/ecricketDesc"
        },
        "live/cricket": {
            title: "pageTitles./live/cricketTitle",
            description: "pageTitles./live/cricketDesc"
        },
        "live/cricket-ipl": {
            title: "pageTitles./live/cricket-iplTitle",
            description: "pageTitles./live/cricket-iplDesc"
        },
        "live/volleyball": {
            title: "pageTitles./live/volleyballTitle",
            description: "pageTitles./live/volleyballDesc"
        },
        "live/fifa": {
            title: "pageTitles./live/fifaTitle",
            description: "pageTitles./live/fifaDesc"
        },
        "live/ebaseball": {
            title: "pageTitles./live/ebaseballTitle",
            description: "pageTitles./live/ebaseballDesc"
        },
        "live/table-tennis": {
            title: "pageTitles./live/table-tennisTitle",
            description: "pageTitles./live/table-tennisDesc"
        },
        "live/ice-hockey": {
            title: "pageTitles./live/ice-hockeyTitle",
            description: "pageTitles./live/ice-hockeyDesc"
        },
        "live/boxing": {
            title: "pageTitles./live/boxingTitle",
            description: "pageTitles./live/boxingDesc"
        },
        "live/mma": {
            title: "pageTitles./live/mmaTitle",
            description: "pageTitles./live/mmaDesc"
        },
        "live/horse-racing": {
            title: "pageTitles./live/horse-racingTitle",
            description: "pageTitles./live/horse-racingDesc"
        },
        "live/football": {
            title: "pageTitles./live/footballTitle",
            description: "pageTitles./live/footballDesc"
        },
        "live/baseball": {
            title: "pageTitles./live/baseballTitle",
            description: "pageTitles./live/baseballDesc"
        },
        "live/ipl": {
            title: "pageTitles./live/iplTitle",
            description: "pageTitles./live/iplDesc"
        },
        "live/tennis": {
            title: "pageTitles./live/tennisTitle",
            description: "pageTitles./live/tennisDesc"
        },
        "live/basketball": {
            title: "pageTitles./live/basketballTitle",
            description: "pageTitles./live/basketballDesc"
        },
        ZM: {
            "live/tennis": {
                title: "pageTitles.ZM/live/tennisTitle",
                description: "pageTitles.ZM/live/tennisDesc"
            },
            live: {
                title: "pageTitles.ZM/liveTitle",
                description: "pageTitles.ZM/liveDesc"
            }
        },
        RW: {
            "live/tennis": {
                title: "pageTitles.RW/live/tennisTitle",
                description: "pageTitles.RW/live/tennisDesc"
            },
            live: {
                title: "pageTitles.RW/liveTitle",
                description: "pageTitles.RW/liveDesc"
            }
        }
    },
    q = {
        sports: {
            title: "pageTitles./sportsTitle",
            description: "pageTitles./sportsDesc"
        },
        "sports/baseball": {
            title: "pageTitles./sports/baseballTitle",
            description: "pageTitles./sports/baseballDesc"
        },
        "sports/basketball": {
            title: "pageTitles./sports/basketballTitle",
            description: "pageTitles./sports/basketballDesc"
        },
        "sports/cricket": {
            title: "pageTitles./sports/cricketTitle",
            description: "pageTitles./sports/cricketDesc"
        },
        "sports/cricket-ipl": {
            title: "pageTitles./sports/cricket-iplTitle",
            description: "pageTitles./sports/cricket-iplDesc"
        },
        "sports/cricket/bangladesh": {
            title: "pageTitles./sports/cricket-bangladeshTitle",
            description: "pageTitles./sports/cricket-bangladeshDesc"
        },
        "sports/dota-2": {
            title: "pageTitles./sports/dotaTitle",
            description: "pageTitles./sports/dotaDesc"
        },
        "sports/football": {
            title: "pageTitles./sports/footballTitle",
            description: "pageTitles./sports/footballDesc"
        },
        "sports/horse-racing": {
            title: "pageTitles./sports/horse-racingTitle",
            description: "pageTitles./sports/horse-racingDesc"
        },
        "sports/table-tennis": {
            title: "pageTitles./sports/table-tennisTitle",
            description: "pageTitles./sports/table-tennisDesc"
        },
        "sports/tennis": {
            title: "pageTitles./sports/tennisTitle",
            description: "pageTitles./sports/tennisDesc"
        },
        "sports/ecricket": {
            title: "pageTitles./sports/ecricketTitle",
            description: "pageTitles./sports/ecricketDesc"
        },
        "sports/soccer": {
            title: "pageTitles./sports/soccerTitle",
            description: "pageTitles./sports/soccerDesc"
        },
        "sports/fifa": {
            title: "pageTitles./sports/fifaTitle",
            description: "pageTitles./sports/fifaDesc"
        },
        "sports/ice-hockey": {
            title: "pageTitles./sports/ice-hockeyTitle",
            description: "pageTitles./sports/ice-hockeyDesc"
        },
        "sports/nba-2k-302": {
            title: "pageTitles./sports/nbaTitle",
            description: "pageTitles./sports/nbaDesc"
        },
        "sports/boxing": {
            title: "pageTitles./sports/boxingTitle",
            description: "pageTitles./sports/boxingDesc"
        },
        "sports/aussie-rules": {
            title: "pageTitles./sports/aussie-rulesTitle",
            description: "pageTitles./sports/aussie-rulesDesc"
        },
        "sports/kabaddi-138": {
            title: "pageTitles./sports/kabaddiTitle",
            description: "pageTitles./sports/kabaddiDesc"
        },
        "sports/volleyball": {
            title: "pageTitles./sports/volleyballTitle",
            description: "pageTitles./sports/volleyballDesc"
        },
        "sports/counter-strike": {
            title: "pageTitles./sports/counter-strikeTitle",
            description: "pageTitles./sports/counter-strikeDesc"
        },
        "sports/mma": {
            title: "pageTitles./sports/mmaTitle",
            description: "pageTitles./sports/mmaDesc"
        },
        "sports/ipl": {
            title: "pageTitles./sports/iplTitle",
            description: "pageTitles./sports/iplDesc"
        },
        ZM: {
            sports: {
                title: "pageTitles.ZM/sportsTitle",
                description: "pageTitles.ZM/sportsDesc"
            },
            "sports/tennis": {
                title: "pageTitles.ZM/sports/tennisTitle",
                description: "pageTitles.ZM/sports/tennisDesc"
            },
            "sports/table-tennis": {
                title: "pageTitles.ZM/sports/table-tennisTitle",
                description: "pageTitles.ZM/sports/table-tennisDesc"
            },
            "sports/football": {
                title: "pageTitles.ZM/sports/footballTitle",
                description: "pageTitles.ZM/sports/footballDesc"
            },
            "sports/cricket": {
                title: "pageTitles.ZM/sports/cricketTitle",
                description: "pageTitles.ZM/sports/cricketDesc"
            },
            "sports/basketball": {
                title: "pageTitles.ZM/sports/basketballTitle",
                description: "pageTitles.ZM/sports/basketballDesc"
            },
            "sports/baseball": {
                title: "pageTitles.ZM/sports/baseballTitle",
                description: "pageTitles.ZM/sports/baseballDesc"
            }
        },
        RW: {
            sports: {
                title: "pageTitles.RW/sportsTitle",
                description: "pageTitles.RW/sportsDesc"
            },
            "sports/tennis": {
                title: "pageTitles.RW/sports/tennisTitle",
                description: "pageTitles.RW/sports/tennisDesc"
            },
            "sports/table-tennis": {
                title: "pageTitles.RW/sports/table-tennisTitle",
                description: "pageTitles.RW/sports/table-tennisDesc"
            },
            "sports/football": {
                title: "pageTitles.RW/sports/footballTitle",
                description: "pageTitles.RW/sports/footballDesc"
            },
            "sports/cricket": {
                title: "pageTitles.RW/sports/cricketTitle",
                description: "pageTitles.RW/sports/cricketDesc"
            },
            "sports/basketball": {
                title: "pageTitles.RW/sports/basketballTitle",
                description: "pageTitles.RW/sports/basketballDesc"
            },
            "sports/baseball": {
                title: "pageTitles.RW/sports/baseballTitle",
                description: "pageTitles.RW/sports/baseballDesc"
            }
        }
    },
    J = {
        "tv-games/board": {
            title: "pageTitles.tv-games/boardTitle",
            description: "pageTitles.tv-games/boardDesc"
        },
        "tv-games/other": {
            title: "pageTitles.tv-games/otherTitle",
            description: "pageTitles.tv-games/otherDesc"
        },
        "tv-games/popular": {
            title: "pageTitles.tv-games/popularTitle",
            description: "pageTitles.tv-games/popularDesc"
        },
        "tv-games/new-games": {
            title: "pageTitles.tv-games/newGamesTitle",
            description: "pageTitles.tv-games/newGamesDesc"
        }
    },
    Q = {
        "virtual-sport/bingo": {
            title: "pageTitles./virtualSport/bingoTitle",
            description: "pageTitles./virtualSport/bingoDesc"
        },
        "virtual-sport": {
            title: "pageTitles.virtualSportTitle",
            description: "pageTitles.virtualSportDesc"
        }
    },
    Y = { ...F,
        ...K,
        ...V,
        ...q,
        ...J,
        ...Q,
        "privacy-policy": {
            title: "pageTitles.privacyPolicyTitle",
            description: "pageTitles.privacyPolicyDesc"
        },
        app: {
            title: "pageTitles.appTitle",
            description: "pageTitles.appDesc"
        },
        deposit: {
            title: "pageTitles.depositTitle",
            description: "pageTitles.depositDesc"
        },
        RW: {
            app: {
                title: "pageTitles.RW/appTitle",
                description: "pageTitles.RW/appDesc"
            },
            deposit: {
                title: "pageTitles.RW/depositTitle",
                description: "pageTitles.RW/depositDesc"
            },
            review: {
                title: "pageTitles.RW/reviewTitle",
                description: "pageTitles.RW/reviewDesc"
            },
            "tv-games": {
                title: "pageTitles.RW/tv-gamesTitle",
                description: "pageTitles.RW/tv-gamesDesc"
            },
            bonuses: {
                title: "pageTitles.RW/bonusTitle",
                description: "pageTitles.RW/bonusDesc"
            }
        },
        ZM: {
            app: {
                title: "pageTitles.ZM/appTitle",
                description: "pageTitles.ZM/appDesc"
            },
            deposit: {
                title: "pageTitles.ZM/depositTitle",
                description: "pageTitles.ZM/depositDesc"
            },
            review: {
                title: "pageTitles.ZM/reviewTitle",
                description: "pageTitles.ZM/reviewDesc"
            },
            "tv-games": {
                title: "pageTitles.ZM/tv-gamesTitle",
                description: "pageTitles.ZM/tv-gamesDesc"
            },
            bonuses: {
                title: "pageTitles.ZM/bonusTitle",
                description: "pageTitles.ZM/bonusDesc"
            }
        },
        "info/tutorials": {
            title: "pageTitles.tutorialsTitle",
            description: "pageTitles.infoTutorials"
        },
        "bonus-terms": {
            title: "pageTitles.bonus-terms",
            description: "pageTitles.bonusTermsDesc"
        },
        "aml-kyc": {
            title: "pageTitles.amlKycTitle",
            description: "pageTitles.amlKycDesc"
        },
        "terms-and-conditions": {
            title: "pageTitles.terms-and-conditions",
            description: "pageTitles.termsAndConditionsDesc"
        },
        "gaming-policy": {
            title: "pageTitles.privacyPolicyTitle",
            description: "pageTitles.privacyPolicyDesc"
        },
        review: {
            title: "pageTitles.reviewTitle",
            description: "pageTitles.reviewDesc"
        },
        odds: {
            title: "pageTitles.oddsTitle",
            description: "pageTitles.oddsDesc"
        },
        profile: {
            title: "pageTitles.profilePage",
            description: "pageTitles.mainDescDefault"
        },
        "profile/history": {
            title: "pageTitles.profileHistory",
            description: "pageTitles.mainDescDefault"
        },
        "profile/ipl-app": {
            title: "pageTitles.iplAppTitle",
            description: "pageTitles.iplAppDesc"
        },
        "cricket-betting-app": {
            title: "pageTitles.cricketBetTitle",
            description: "pageTitles.cricketBetDesc"
        },
        bonuses: {
            title: "pageTitles.bonusTitle",
            description: "pageTitles.bonusDesc"
        },
        "virtual-sport": {
            title: "pageTitles.virtualSportTitle",
            description: "pageTitles.virtualSportDesc"
        },
        "tv-games": {
            title: "pageTitles./tv-gamesTitle",
            description: "pageTitles./tv-gamesDesc"
        },
        plinko: {
            title: "pageTitles.plinkoTitle",
            description: "pageTitles.plinkoDesc"
        }
    },
    G = {
        [B]: {
            "": {
                title: "pageTitles.bd-mainTitle",
                description: "pageTitles.bd-mainDesc"
            },
            app: {
                title: "pageTitles.bd-appTitle",
                description: "pageTitles.bd-appDesc"
            },
            live: {
                title: "pageTitles.bd-liveTitle",
                description: "pageTitles.bd-liveDesc"
            },
            casino: {
                title: "pageTitles.bd-casinoTitle",
                description: "pageTitles.bd-casinoDesc"
            },
            bonuses: {
                title: "pageTitles.bd-bonusesTitle",
                description: "pageTitles.bd-bonusesDesc"
            },
            "casino/slot/crazy-time-10418": {
                title: "pageTitles.bd-crazyTimeTitle",
                description: "pageTitles.bd-crazyTimeDesc"
            },
            "promo-code": {
                title: "pageTitles.bd-promo-codeTitle",
                description: "pageTitles.bd-promo-codeDesc"
            }
        },
        [S]: {
            "": {
                title: "pageTitles.bdMainTitle",
                description: "pageTitles.bdMainDesc"
            },
            app: {
                title: "pageTitles.bdAppTitle",
                description: "pageTitles.bdAppDesc"
            },
            "bonus-terms": {
                title: "pageTitles.bdBonusTermsTitle",
                description: "pageTitles.bdBonusTermsDesc"
            },
            bonuses: {
                title: "pageTitles.bdBonusesTitle",
                description: "pageTitles.bdBonusesDesc"
            },
            "info/tutorials": {
                title: "pageTitles.bdTutorialsTitle",
                description: "pageTitles.bdTutorialsDesc"
            },
            live: {
                title: "pageTitles.bdLiveTitle",
                description: "pageTitles.bdLiveDesc"
            },
            plinko: {
                title: "pageTitles.bdPlinkoTitle",
                description: "pageTitles.bdPlinkoDesc"
            },
            sports: {
                title: "pageTitles.bdSportsTitle",
                description: "pageTitles.bdSportsDesc"
            },
            casino: {
                title: "pageTitles.bdCasinoTitle",
                description: "pageTitles.bdCasinoDesc"
            },
            "live-dealers": {
                title: "pageTitles.bdLiveDealersTitle",
                description: "pageTitles.bdLiveDealersDesc"
            },
            deposit: {
                title: "pageTitles.bdDepositTitle",
                description: "pageTitles.bdDepositDesc"
            },
            "tv-games": {
                title: "pageTitles.bdTvGamesTitle",
                description: "pageTitles.bdTvGamesDesc"
            },
            "casino/slot/aviator": {
                title: "pageTitles.bdAviatorTitle",
                description: "pageTitles.bdAviatorDesc"
            },
            "casino/slot/crazy-time-10418": {
                title: "pageTitles.bdCrazyTimeTitle",
                description: "pageTitles.bdCrazyTimeDesc"
            },
            "profile/history": {
                title: "pageTitles.bdProfileHistoryTitle",
                description: "pageTitles.bdProfileHistoryDesc"
            }
        }
    },
    v = t => t ? M().host === z ? t.replace(/\bIndia\b/g, "Bangladesh") : t : "";

function C(t) {
    return t ? t.replace(/-\d+$/, "").replace(/-/g, " ").replace(/\b\w/g, i => i.toUpperCase()) : ""
}

function le() {
    const t = w(),
        i = M(),
        {
            t: e,
            te: a,
            locale: l
        } = A(),
        c = Z(""),
        T = Z(""),
        d = o(() => {
            var s;
            return ((s = U(t, l)) == null ? void 0 : s.value) || ""
        }),
        {
            title: p,
            description: g
        } = te(),
        k = () => h === i.host ? e("pageTitles.mainTitle") : e("pageTitles.mainTitleSecond"),
        r = () => h === i.host ? e("pageTitles.mainDesc") : e("pageTitles.mainDescDefault"),
        n = o(() => d.value.includes("sports")),
        u = o(() => ["live-dealers/slot", "tv-games/slot", "virtual-sport/slot", "casino/slot"].some(s => d.value.includes(s))),
        D = o(() => {
            const s = d.value.match(/slot\/([^/]+)/);
            return s ? C(s[1]) : ""
        }),
        m = () => p.value ? p.value : n.value ? L(D.value) : u.value ? x(D.value) : k(),
        y = () => g.value ? g.value : n.value ? N(D.value) : u.value ? _(D.value) : r(),
        L = s => {
            const b = [e("pageTitles.first/betbyRandomTitle", {
                gameName: s
            }), e("pageTitles.second/betbyRandomTitle", {
                gameName: s
            }), e("pageTitles.third/betbyRandomTitle", {
                gameName: s
            })];
            return b[Math.floor(Math.random() * b.length)]
        },
        N = s => {
            const b = [e("pageTitles.first/betbyRandomDesc", {
                gameName: s
            }), e("pageTitles.second/betbyRandomDesc", {
                gameName: s
            }), e("pageTitles.third/betbyRandomDesc", {
                gameName: s
            })];
            return b[Math.floor(Math.random() * b.length)]
        },
        x = s => e("pageTitles.slotRandomTitle", {
            gameName: s
        }),
        _ = s => e("pageTitles.slotRandomDesc", {
            gameName: s
        }),
        R = () => {
            const s = G[i.host] || {},
                b = { ...Y,
                    ...s
                },
                {
                    metaInfo: f
                } = X(d.value, b);
            c.value = p.value ? v(p.value) : a(f.value.title) ? v(e(f.value.title)) : W.includes(i.host) ? v(e("pageTitles.defaultTitleBd")) : v(m()), T.value = g.value ? v(g.value) : a(f.value.description) ? v(e(f.value.description)) : W.includes(i.host) ? v(e("pageTitles.defaultDescBd")) : v(y()), O({
                title: c.value,
                description: T.value,
                ogDescription: T.value
            })
        };
    return H(t, R, {
        immediate: !0
    }), {
        setHead: R,
        routeWithoutLocale: d,
        isSportsPage: n,
        isGamesSlotPage: u,
        gameName: D,
        metaTitle: c,
        metaDescription: T
    }
}

function ee(t, i, e) {
    const a = G[i],
        l = a == null ? void 0 : a[e];
    return typeof(l == null ? void 0 : l.title) == "string" && typeof(l == null ? void 0 : l.description) == "string" ? {
        title: t(l.title),
        description: t(l.description)
    } : null
}

function te() {
    const t = M(),
        i = w(),
        e = t.host,
        {
            t: a
        } = A(),
        l = o(() => i.path.split("/").filter(Boolean).slice(0, 3).join("/")),
        c = [
            [/^casino\/slot\/([^/]+)$/, "pageTitles.dynamicBd.bd-casinoSlotTitle", "pageTitles.dynamicBd.bd-casinoSlotDesc"],
            [/^live-dealers\/slot\/([^/]+)$/, "pageTitles.dynamicBd.bd-liveSlotTitle", "pageTitles.dynamicBd.bd-liveSlotDesc"],
            [/^casino\/([^/]+)$/, "pageTitles.dynamicBd.bd-casinoCategoryTitle", "pageTitles.dynamicBd.bd-casinoCategoryDesc"],
            [/^live-dealers\/([^/]+)$/, "pageTitles.dynamicBd.bd-liveCategoryTitle", "pageTitles.dynamicBd.bd-liveCategoryDesc"],
            [/^tv-games\/([^/]+)$/, "pageTitles.dynamicBd.bd-tvGamesTitle", "pageTitles.dynamicBd.bd-tvGamesDesc"],
            [/^live\/([^/]+)$/, "pageTitles.dynamicBd.bd-liveSportsTitle", "pageTitles.dynamicBd.bd-liveSportsDesc"],
            [/^sports\/([^/]+)$/, "pageTitles.dynamicBd.bd-sportsTitle", "pageTitles.dynamicBd.bd-sportsDesc"]
        ],
        T = [
            [/^casino\/slot\/([^/]+)$/, "pageTitles.dynamicBd.bdCasinoSlotTitle", "pageTitles.dynamicBd.bdCasinoSlotDesc"],
            [/^live-dealers\/slot\/([^/]+)$/, "pageTitles.dynamicBd.bdLiveSlotTitle", "pageTitles.dynamicBd.bdLiveSlotDesc"],
            [/^casino\/([^/]+)$/, "pageTitles.dynamicBd.bdCasinoCategoryTitle", "pageTitles.dynamicBd.bdCasinoCategoryDesc"],
            [/^live-dealers\/([^/]+)$/, "pageTitles.dynamicBd.bdLiveCategoryTitle", "pageTitles.dynamicBd.bdLiveCategoryDesc"],
            [/^tv-games\/([^/]+)$/, "pageTitles.dynamicBd.bdTvGamesTitle", "pageTitles.dynamicBd.bdTvGamesDesc"],
            [/^live\/([^/]+)$/, "pageTitles.dynamicBd.bdLiveSportsTitle", "pageTitles.dynamicBd.bdLiveSportsDesc"],
            [/^sports\/([^/]+)$/, "pageTitles.dynamicBd.bdSportsTitle", "pageTitles.dynamicBd.bdSportsDesc"]
        ],
        d = o(() => {
            const r = e === B ? c : e === S ? T : null;
            if (!r) return null;
            for (const [n, u, D] of r) {
                const m = l.value.match(n);
                if (m) {
                    const y = C(m[1]);
                    return {
                        title: a(u, {
                            name: y
                        }),
                        description: a(D, {
                            name: y
                        })
                    }
                }
            }
            return null
        }),
        p = o(() => ee(a, e, l.value)),
        g = o(() => {
            var r, n;
            return ((r = d.value) == null ? void 0 : r.title) || ((n = p.value) == null ? void 0 : n.title) || ""
        }),
        k = o(() => {
            var r, n;
            return ((r = d.value) == null ? void 0 : r.description) || ((n = p.value) == null ? void 0 : n.description) || ""
        });
    return {
        title: g,
        description: k
    }
}
export {
    U as g, le as u
};