import {
    h as R,
    v as D,
    w as N,
    u as $,
    a1 as u,
    _ as w
} from "./BbvgifQp.js";
import {
    L as A
} from "./quAyFRoR.js";
import {
    z as C,
    i as E,
    d as g,
    _ as i,
    V as r,
    a7 as p,
    u as o,
    a0 as n,
    a8 as d,
    a1 as y
} from "./BBZLTf3A.js";
import {
    u as k
} from "./Eh0EvCQt.js";
(function() {
    try {
        var a = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            l = new a.Error().stack;
        l && (a._sentryDebugIds = a._sentryDebugIds || {}, a._sentryDebugIds[l] = "5d6fc929-03d5-4aa5-83c6-eef1a974e30a", a._sentryDebugIdIdentifier = "sentry-dbid-5d6fc929-03d5-4aa5-83c6-eef1a974e30a")
    } catch {}
})();
const T = {
        class: "modal__content-item-bg"
    },
    S = ["src"],
    z = {
        class: "modal__content-block"
    },
    G = {
        key: 0,
        class: "mb-9 modal__content-text"
    },
    O = {
        key: 1,
        class: "modal__content-logo-wrapper"
    },
    U = ["src"],
    M = ["src"],
    P = C({
        __name: "RegistrationAdditionDialog",
        props: {
            hideLogo: {
                type: Boolean
            },
            summary: {},
            title: {},
            sourceComponentType: {
                default: "register"
            }
        },
        setup(a) {
            const {
                locale: l
            } = R(), {
                userGeo: t
            } = D(N()), {
                imageUrl: e
            } = k(), {
                config: h
            } = $(), _ = E(A), I = ["ru", "th", "pt", "uk", "uz", "hi"], b = u.AUTH_BANNERS_BY_GEO, m = u.AFRICA_COUNTRIES, f = u.ASIA_COUNTRIES, c = g(() => h.value.IS_IPL && ["IN", "BD"].includes(t.value)), B = g(() => {
                const s = "old";
                return _ && a.sourceComponentType === "login" ? "" : _ ? `-${c.value?"IPL25":s}` : c.value ? "-IPL25" : `-${b[t.value]||s}`
            }), v = g(() => {
                switch (t.value) {
                    case "IN":
                        return `${e.value}/svgflags/HI.svg`;
                    case "BD":
                        return `${e.value}/svgflags/BN.svg`;
                    case "BR":
                        return `${e.value}/svgflags/BR.svg`;
                    case "MM":
                        return `${e.value}/svgflags/MY.svg`;
                    case "CD":
                        return `${e.value}/svgflags/CD.svg`;
                    default:
                        return m[t.value] ? `${e.value}/${m[t.value].flag}` : f[t.value] ? `${e.value}/${f[t.value].flag}` : ""
                }
            });
            return (s, L) => (r(), i("div", {
                class: p(["modal__content-item", o(c) ? "" : "with-gradient"])
            }, [n("picture", T, [n("div", null, [n("img", {
                src: `${o(e)}/registration-modal${o(B)}.webp?v=1`,
                alt: "image welcome back",
                title: "image welcome back",
                class: "modal__content-item-img",
                loading: "lazy"
            }, null, 8, S)])]), n("div", z, [n("h3", {
                class: p(["mb-4 modal__content-title", {
                    isLang: I.includes(o(l))
                }])
            }, y(s.title), 3), s.summary ? (r(), i("p", G, y(s.summary), 1)) : d("", !0), s.hideLogo ? d("", !0) : (r(), i("div", O, [n("img", {
                src: `${o(e)}/logo-bg-black.svg`,
                width: "147",
                height: "38",
                alt: "image mini logo",
                title: "image mini logo",
                class: "modal__content-img",
                loading: "lazy"
            }, null, 8, U), o(v) ? (r(), i("img", {
                key: 0,
                class: "modal__content-logo-country",
                src: o(v),
                alt: "4Rabet country logo",
                title: "4Rabet country logo",
                loading: "lazy"
            }, null, 8, M)) : d("", !0)]))])], 2))
        }
    }),
    j = w(P, [
        ["__scopeId", "data-v-89cf38bb"]
    ]);
export {
    j as
    default
};