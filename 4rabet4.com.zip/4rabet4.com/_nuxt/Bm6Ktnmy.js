import {
    U as Q,
    W as Z,
    a7 as ee,
    bu as te,
    ag as ae,
    am as se,
    ap as oe,
    bV as ne,
    aR as ie,
    bW as le,
    a4 as re,
    aa as ce,
    ad as ue,
    ac as me,
    ax as de,
    bv as fe,
    bw as ve,
    bX as _e,
    at as pe,
    m as W,
    au as be,
    bB as ye,
    l as E,
    _ as C,
    h as ke
} from "./BbvgifQp.js";
import {
    c as z,
    m as ge
} from "./D9sqA5Xl.js";
import {
    f as he
} from "./CbxP4vag.js";
import {
    u as we
} from "./B9YIqgoQ.js";
import {
    b as V,
    y as D,
    i as Ve,
    w as O,
    B as Y,
    d as h,
    D as m,
    J as N,
    o as xe,
    n as Te,
    l as Ne,
    z as I,
    _ as b,
    V as y,
    f as F,
    u as l,
    W as $,
    a0 as g,
    an as Pe,
    a8 as L,
    a1 as k,
    a2 as w,
    ax as Se,
    C as Ce
} from "./BBZLTf3A.js";
import {
    V as Ie
} from "./BX3KejHb.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            s = new e.Error().stack;
        s && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[s] = "989a60f6-f6ca-4c8b-ac79-e360e6c7eb8a", e._sentryDebugIdIdentifier = "sentry-dbid-989a60f6-f6ca-4c8b-ac79-e360e6c7eb8a")
    } catch {}
})();

function Be(e) {
    const s = D(e());
    let a = -1;

    function t() {
        clearInterval(a)
    }

    function r() {
        t(), Te(() => s.value = e())
    }

    function o(n) {
        const d = n ? getComputedStyle(n) : {
                transitionDuration: .2
            },
            _ = parseFloat(d.transitionDuration) * 1e3 || 200;
        if (t(), s.value <= 0) return;
        const f = performance.now();
        a = window.setInterval(() => {
            const c = performance.now() - f + _;
            s.value = Math.max(e() - c, 0), s.value <= 0 && t()
        }, _)
    }
    return xe(t), {
        clear: t,
        time: s,
        start: o,
        reset: r
    }
}
const De = Z({
        multiLine: Boolean,
        text: String,
        timer: [Boolean, String],
        timeout: {
            type: [Number, String],
            default: 5e3
        },
        vertical: Boolean,
        ...ve({
            location: "bottom"
        }),
        ...fe(),
        ...de(),
        ...me(),
        ...ue(),
        ...ce(ge({
            transition: "v-snackbar-transition"
        }), ["persistent", "noClickAnimation", "scrim", "scrollStrategy"])
    }, "VSnackbar"),
    $e = Q()({
        name: "VSnackbar",
        props: De(),
        emits: {
            "update:modelValue": e => !0
        },
        setup(e, s) {
            let {
                slots: a
            } = s;
            const t = ee(e, "modelValue"),
                {
                    positionClasses: r
                } = te(e),
                {
                    scopeId: o
                } = we(),
                {
                    themeClasses: n
                } = ae(e),
                {
                    colorClasses: d,
                    colorStyles: _,
                    variantClasses: f
                } = se(e),
                {
                    roundedClasses: c
                } = oe(e),
                v = Be(() => Number(e.timeout)),
                x = V(),
                p = V(),
                u = D(!1),
                R = D(0),
                A = V(),
                H = Ve(ne, void 0);
            ie(() => !!H, () => {
                const i = _e();
                Ne(() => {
                    A.value = i.mainStyles.value
                })
            }), O(t, P), O(() => e.timeout, P), Y(() => {
                t.value && P()
            });
            let B = -1;

            function P() {
                v.reset(), window.clearTimeout(B);
                const i = Number(e.timeout);
                if (!t.value || i === -1) return;
                const T = le(p.value);
                v.start(T), B = window.setTimeout(() => {
                    t.value = !1
                }, i)
            }

            function j() {
                v.reset(), window.clearTimeout(B)
            }

            function G() {
                u.value = !0, j()
            }

            function M() {
                u.value = !1, P()
            }

            function J(i) {
                R.value = i.touches[0].clientY
            }

            function K(i) {
                Math.abs(R.value - i.changedTouches[0].clientY) > 50 && (t.value = !1)
            }

            function X() {
                u.value && M()
            }
            const q = h(() => e.location.split(" ").reduce((i, T) => (i[`v-snackbar--${T}`] = !0, i), {}));
            return re(() => {
                const i = z.filterProps(e),
                    T = !!(a.default || a.text || e.text);
                return m(z, N({
                    ref: x,
                    class: ["v-snackbar", {
                        "v-snackbar--active": t.value,
                        "v-snackbar--multi-line": e.multiLine && !e.vertical,
                        "v-snackbar--timer": !!e.timer,
                        "v-snackbar--vertical": e.vertical
                    }, q.value, r.value, e.class],
                    style: [A.value, e.style]
                }, i, {
                    modelValue: t.value,
                    "onUpdate:modelValue": S => t.value = S,
                    contentProps: N({
                        class: ["v-snackbar__wrapper", n.value, d.value, c.value, f.value],
                        style: [_.value],
                        onPointerenter: G,
                        onPointerleave: M
                    }, i.contentProps),
                    persistent: !0,
                    noClickAnimation: !0,
                    scrim: !1,
                    scrollStrategy: "none",
                    _disableGlobalStack: !0,
                    onTouchstartPassive: J,
                    onTouchend: K,
                    onAfterLeave: X
                }, o), {
                    default: () => {
                        var S, U;
                        return [pe(!1, "v-snackbar"), e.timer && !u.value && m("div", {
                            key: "timer",
                            class: "v-snackbar__timer"
                        }, [m(W, {
                            ref: p,
                            color: typeof e.timer == "string" ? e.timer : "info",
                            max: e.timeout,
                            "model-value": v.time.value
                        }, null)]), T && m("div", {
                            key: "content",
                            class: "v-snackbar__content",
                            role: "status",
                            "aria-live": "polite"
                        }, [((S = a.text) == null ? void 0 : S.call(a)) ? ? e.text, (U = a.default) == null ? void 0 : U.call(a)]), a.actions && m(be, {
                            defaults: {
                                VBtn: {
                                    variant: "text",
                                    ripple: !1,
                                    slim: !0
                                }
                            }
                        }, {
                            default: () => [m("div", {
                                class: "v-snackbar__actions"
                            }, [a.actions({
                                isActive: t
                            })])]
                        })]
                    },
                    activator: a.activator
                })
            }), he({}, x)
        }
    }),
    Le = {
        class: "snackbar_content"
    },
    Re = {
        key: 0,
        style: {
            "font-weight": "600"
        },
        class: "title"
    },
    Ae = {
        class: "message"
    },
    Me = I({
        __name: "NotificationBlock",
        props: {
            multiLine: {
                type: Boolean
            },
            timeout: {},
            color: {},
            value: {
                type: Boolean
            },
            title: {},
            message: {},
            iconName: {},
            code: {}
        },
        emits: ["close"],
        setup(e, {
            emit: s
        }) {
            const {
                deleteNotification: a
            } = ye(), t = e, r = s, o = h(() => {
                if (!t.iconName) switch (t.color) {
                    case "orange":
                    case "warning":
                        return "mdi-alert-circle-outline";
                    case "red":
                    case "danger":
                        return "mdi-alert-outline";
                    default:
                        return "mdi-check"
                }
                return t.iconName
            }), n = V(!0);

            function d() {
                switch (t.color) {
                    case "orange":
                        return "yellowNotification";
                    case "red":
                        return "yellowNotification";
                    case "green":
                        return "greenNotification";
                    default:
                        return null
                }
            }

            function _() {
                n.value = !1, a(), r("close")
            }
            return t.timeout && t.timeout !== -1 && setTimeout(_, t.timeout), (f, c) => (y(), b("div", {
                class: "notification",
                "data-auto-test-el": d
            }, [m($e, N({
                modelValue: l(n),
                "onUpdate:modelValue": c[0] || (c[0] = v => F(n) ? n.value = v : null)
            }, t, {
                height: t != null && t.title ? 105 : 64,
                location: "right",
                "z-index": "3000"
            }), {
                default: $(() => [g("div", Le, [g("p", null, [m(E, {
                    large: "",
                    icon: l(o),
                    class: "icon"
                }, null, 8, ["icon"]), g("span", {
                    style: Pe({
                        display: f.title ? "block" : ""
                    })
                }, [f.title ? (y(), b("span", Re, k(f.title), 1)) : L("", !0), g("span", Ae, k(f.message), 1)], 4)]), m(E, {
                    class: "close ml-2",
                    dark: "",
                    icon: "mdi-close",
                    right: "",
                    onClick: _
                }, {
                    default: $(() => c[1] || (c[1] = [w("mdi-close")])),
                    _: 1
                })])]),
                _: 1
            }, 16, ["modelValue", "height"])]))
        }
    }),
    tt = C(Me, [
        ["__scopeId", "data-v-0d8b8510"]
    ]),
    Ue = {
        class: "mb-6 progressbar",
        "data-auto-test-el": "bonusProgress"
    },
    Ee = I({
        __name: "AppProgressbar",
        props: {
            value: {
                default: ""
            }
        },
        setup(e) {
            const s = e,
                a = h(() => isNaN(Number(s.value)) ? 0 : Number(s.value));
            return (t, r) => (y(), b("div", Ue, [m(W, N(s, {
                modelValue: l(a),
                "onUpdate:modelValue": r[0] || (r[0] = o => F(a) ? a.value = o : null),
                color: "primary"
            }), {
                default: $(() => [w(k(l(a)) + "%", 1)]),
                _: 1
            }, 16, ["modelValue"])]))
        }
    }),
    at = C(Ee, [
        ["__scopeId", "data-v-5140f75d"]
    ]),
    ze = {
        class: "radio"
    },
    Oe = I({
        __name: "AppRadio",
        props: {
            color: {
                default: ""
            },
            value: {
                default: 0
            }
        },
        emits: ["click"],
        setup(e, {
            emit: s
        }) {
            const a = e,
                t = s,
                r = {
                    click(o) {
                        t("click", o)
                    }
                };
            return (o, n) => (y(), b("div", ze, [m(Ie, N(a, {
                value: a.value,
                dark: ""
            }, Se(r)), null, 16, ["value"])]))
        }
    }),
    st = C(Oe, [
        ["__scopeId", "data-v-797208fb"]
    ]),
    We = {
        class: "timer timer--box",
        "data-auto-test-el": "timer"
    },
    Ye = {
        key: 0,
        class: "d-flex text-center"
    },
    Fe = {
        key: 0,
        class: "timer__item"
    },
    He = {
        key: 1,
        class: "timer__item"
    },
    je = {
        class: "timer__item"
    },
    Ge = {
        key: 1,
        class: "text-center"
    },
    Je = I({
        __name: "AppTimer",
        props: {
            deadline: {},
            speed: {}
        },
        emits: ["timer:up"],
        setup(e, {
            emit: s
        }) {
            const {
                t: a
            } = ke(), t = e, r = s, o = V(null), n = V(null), d = p => p < 10 ? `0${p}` : `${p}`, _ = h(() => Math.floor((o.value ? ? 0) / 1e3 % 60)), f = h(() => Math.floor((o.value ? ? 0) / 1e3 / 60 % 60)), c = h(() => Math.floor((o.value ? ? 0) / (1e3 * 60 * 60) % 24)), v = h(() => Math.floor((o.value ? ? 0) / (1e3 * 60 * 60 * 24))), x = () => {
                const p = typeof t.deadline == "string" ? Date.parse(t.deadline) : t.deadline * 1e3;
                o.value = p - Date.now(), o.value > 0 ? n.value = setTimeout(x, t.speed ? ? 1e3) : (n.value && clearTimeout(n.value), n.value = null, o.value = null, r("timer:up"))
            };
            return Y(() => {
                x()
            }), Ce(() => {
                n.value && clearTimeout(n.value)
            }), (p, u) => (y(), b("div", We, [l(o) !== null ? (y(), b("div", Ye, [l(v) ? (y(), b("div", Fe, [w(k(d(l(v))) + " ", 1), u[0] || (u[0] = g("span", {
                class: "px-1"
            }, ":", -1))])) : L("", !0), l(v) || l(c) > 0 ? (y(), b("div", He, [w(k(d(l(c))) + " ", 1), u[1] || (u[1] = g("span", {
                class: "px-1"
            }, ":", -1))])) : L("", !0), g("div", je, [w(k(d(l(f))) + " ", 1), u[2] || (u[2] = g("span", {
                class: "px-1"
            }, ":", -1)), w(" " + k(d(l(_))), 1)])])) : (y(), b("div", Ge, k(l(a)("profile.bonuses.timer.timesUp")), 1))]))
        }
    }),
    ot = C(Je, [
        ["__scopeId", "data-v-47afb145"]
    ]);
export {
    tt as _, at as a, st as b, ot as c
};