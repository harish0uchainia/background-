import s from "./BawUMdEg.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "65b043cd-8593-4fb6-84e0-3b23d5a9e864", e._sentryDebugIdIdentifier = "sentry-dbid-65b043cd-8593-4fb6-84e0-3b23d5a9e864")
    } catch {}
})();
const r = () => ({
    warnHtmlMessage: !1,
    legacy: !1,
    locale: "en",
    fallbackLocale: "en",
    messages: {
        en: s,
        bn: {},
        "hi-bn": {},
        fr: {},
        hi: {},
        id: {},
        kn: {},
        mr: {},
        ms: {},
        my: {},
        pt: {},
        sw: {},
        ta: {},
        te: {},
        th: {},
        tr: {},
        ur: {},
        uz: {},
        vi: {},
        es: {}
    }
});
export {
    r as
    default
};