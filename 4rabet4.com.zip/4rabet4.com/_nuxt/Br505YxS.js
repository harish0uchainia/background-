(function() {
    try {
        var t = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            r = new t.Error().stack;
        r && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[r] = "99a22571-d478-4fa0-843a-1baf78c804bf", t._sentryDebugIdIdentifier = "sentry-dbid-99a22571-d478-4fa0-843a-1baf78c804bf")
    } catch {}
})();
try {
    self["workbox:window:7.2.0"] && _()
} catch {}

function P(t, r) {
    return new Promise(function(n) {
        var i = new MessageChannel;
        i.port1.onmessage = function(c) {
            n(c.data)
        }, t.postMessage(r, [i.port2])
    })
}

function W(t) {
    var r = function(n, i) {
        if (typeof n != "object" || !n) return n;
        var c = n[Symbol.toPrimitive];
        if (c !== void 0) {
            var d = c.call(n, i);
            if (typeof d != "object") return d;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }
        return String(n)
    }(t, "string");
    return typeof r == "symbol" ? r : r + ""
}

function k(t, r) {
    for (var n = 0; n < r.length; n++) {
        var i = r[n];
        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, W(i.key), i)
    }
}

function E(t, r) {
    return E = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
        return n.__proto__ = i, n
    }, E(t, r)
}

function j(t, r) {
    (r == null || r > t.length) && (r = t.length);
    for (var n = 0, i = new Array(r); n < r; n++) i[n] = t[n];
    return i
}

function L(t, r) {
    var n = typeof Symbol < "u" && t[Symbol.iterator] || t["@@iterator"];
    if (n) return (n = n.call(t)).next.bind(n);
    if (Array.isArray(t) || (n = function(c, d) {
            if (c) {
                if (typeof c == "string") return j(c, d);
                var l = Object.prototype.toString.call(c).slice(8, -1);
                return l === "Object" && c.constructor && (l = c.constructor.name), l === "Map" || l === "Set" ? Array.from(c) : l === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(l) ? j(c, d) : void 0
            }
        }(t)) || r) {
        n && (t = n);
        var i = 0;
        return function() {
            return i >= t.length ? {
                done: !0
            } : {
                done: !1,
                value: t[i++]
            }
        }
    }
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}
try {
    self["workbox:core:7.2.0"] && _()
} catch {}
var w = function() {
    var t = this;
    this.promise = new Promise(function(r, n) {
        t.resolve = r, t.reject = n
    })
};

function b(t, r) {
    var n = location.href;
    return new URL(t, n).href === new URL(r, n).href
}
var g = function(t, r) {
    this.type = t, Object.assign(this, r)
};

function h(t, r, n) {
    return n ? r ? r(t) : t : (t && t.then || (t = Promise.resolve(t)), r ? t.then(r) : t)
}

function I() {}
var O = {
    type: "SKIP_WAITING"
};

function S(t, r) {
    return t && t.then ? t.then(I) : Promise.resolve()
}
var x = function(t) {
    function r(v, u) {
        var e, o;
        return u === void 0 && (u = {}), (e = t.call(this) || this).nn = {}, e.tn = 0, e.rn = new w, e.en = new w, e.on = new w, e.un = 0, e.an = new Set, e.cn = function() {
            var s = e.fn,
                a = s.installing;
            e.tn > 0 || !b(a.scriptURL, e.sn.toString()) || performance.now() > e.un + 6e4 ? (e.vn = a, s.removeEventListener("updatefound", e.cn)) : (e.hn = a, e.an.add(a), e.rn.resolve(a)), ++e.tn, a.addEventListener("statechange", e.ln)
        }, e.ln = function(s) {
            var a = e.fn,
                f = s.target,
                p = f.state,
                y = f === e.vn,
                m = {
                    sw: f,
                    isExternal: y,
                    originalEvent: s
                };
            !y && e.mn && (m.isUpdate = !0), e.dispatchEvent(new g(p, m)), p === "installed" ? e.wn = self.setTimeout(function() {
                p === "installed" && a.waiting === f && e.dispatchEvent(new g("waiting", m))
            }, 200) : p === "activating" && (clearTimeout(e.wn), y || e.en.resolve(f))
        }, e.yn = function(s) {
            var a = e.hn,
                f = a !== navigator.serviceWorker.controller;
            e.dispatchEvent(new g("controlling", {
                isExternal: f,
                originalEvent: s,
                sw: a,
                isUpdate: e.mn
            })), f || e.on.resolve(a)
        }, e.gn = (o = function(s) {
            var a = s.data,
                f = s.ports,
                p = s.source;
            return h(e.getSW(), function() {
                e.an.has(p) && e.dispatchEvent(new g("message", {
                    data: a,
                    originalEvent: s,
                    ports: f,
                    sw: p
                }))
            })
        }, function() {
            for (var s = [], a = 0; a < arguments.length; a++) s[a] = arguments[a];
            try {
                return Promise.resolve(o.apply(this, s))
            } catch (f) {
                return Promise.reject(f)
            }
        }), e.sn = v, e.nn = u, navigator.serviceWorker.addEventListener("message", e.gn), e
    }
    var n, i;
    i = t, (n = r).prototype = Object.create(i.prototype), n.prototype.constructor = n, E(n, i);
    var c, d, l = r.prototype;
    return l.register = function(v) {
        var u = (v === void 0 ? {} : v).immediate,
            e = u !== void 0 && u;
        try {
            var o = this;
            return h(function(s, a) {
                var f = s();
                return f && f.then ? f.then(a) : a(f)
            }(function() {
                if (!e && document.readyState !== "complete") return S(new Promise(function(s) {
                    return window.addEventListener("load", s)
                }))
            }, function() {
                return o.mn = !!navigator.serviceWorker.controller, o.dn = o.pn(), h(o.bn(), function(s) {
                    o.fn = s, o.dn && (o.hn = o.dn, o.en.resolve(o.dn), o.on.resolve(o.dn), o.dn.addEventListener("statechange", o.ln, {
                        once: !0
                    }));
                    var a = o.fn.waiting;
                    return a && b(a.scriptURL, o.sn.toString()) && (o.hn = a, Promise.resolve().then(function() {
                        o.dispatchEvent(new g("waiting", {
                            sw: a,
                            wasWaitingBeforeRegister: !0
                        }))
                    }).then(function() {})), o.hn && (o.rn.resolve(o.hn), o.an.add(o.hn)), o.fn.addEventListener("updatefound", o.cn), navigator.serviceWorker.addEventListener("controllerchange", o.yn), o.fn
                })
            }))
        } catch (s) {
            return Promise.reject(s)
        }
    }, l.update = function() {
        try {
            return this.fn ? h(S(this.fn.update())) : h()
        } catch (v) {
            return Promise.reject(v)
        }
    }, l.getSW = function() {
        return this.hn !== void 0 ? Promise.resolve(this.hn) : this.rn.promise
    }, l.messageSW = function(v) {
        try {
            return h(this.getSW(), function(u) {
                return P(u, v)
            })
        } catch (u) {
            return Promise.reject(u)
        }
    }, l.messageSkipWaiting = function() {
        this.fn && this.fn.waiting && P(this.fn.waiting, O)
    }, l.pn = function() {
        var v = navigator.serviceWorker.controller;
        return v && b(v.scriptURL, this.sn.toString()) ? v : void 0
    }, l.bn = function() {
        try {
            var v = this;
            return h(function(u, e) {
                try {
                    var o = u()
                } catch (s) {
                    return e(s)
                }
                return o && o.then ? o.then(void 0, e) : o
            }(function() {
                return h(navigator.serviceWorker.register(v.sn, v.nn), function(u) {
                    return v.un = performance.now(), u
                })
            }, function(u) {
                throw u
            }))
        } catch (u) {
            return Promise.reject(u)
        }
    }, c = r, (d = [{
        key: "active",
        get: function() {
            return this.en.promise
        }
    }, {
        key: "controlling",
        get: function() {
            return this.on.promise
        }
    }]) && k(c.prototype, d), Object.defineProperty(c, "prototype", {
        writable: !1
    }), c
}(function() {
    function t() {
        this.Pn = new Map
    }
    var r = t.prototype;
    return r.addEventListener = function(n, i) {
        this.jn(n).add(i)
    }, r.removeEventListener = function(n, i) {
        this.jn(n).delete(i)
    }, r.dispatchEvent = function(n) {
        n.target = this;
        for (var i, c = L(this.jn(n.type)); !(i = c()).done;)(0, i.value)(n)
    }, r.jn = function(n) {
        return this.Pn.has(n) || this.Pn.set(n, new Set), this.Pn.get(n)
    }, t
}());
export {
    x as Workbox, g as WorkboxEvent, P as messageSW
};