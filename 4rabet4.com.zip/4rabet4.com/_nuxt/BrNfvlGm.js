import {
    v as A,
    $ as p,
    j as w,
    f as I,
    l as f,
    _ as $
} from "./BbvgifQp.js";
import {
    V as m,
    a as h,
    b as U,
    c as T
} from "./BuDDDvke.js";
import {
    V as N
} from "./CL3SmZKg.js";
import {
    z as j,
    d as z,
    U as y,
    V as i,
    W as o,
    D as a,
    a8 as c,
    _ as g,
    $ as n,
    a2 as b,
    J as E,
    u as H,
    f as O
} from "./BBZLTf3A.js";
(function() {
    try {
        var s = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            l = new s.Error().stack;
        l && (s._sentryDebugIds = s._sentryDebugIds || {}, s._sentryDebugIds[l] = "bb19b4a3-cf42-4ce0-a6fc-9dcc4c4ba623", s._sentryDebugIdIdentifier = "sentry-dbid-bb19b4a3-cf42-4ce0-a6fc-9dcc4c4ba623")
    } catch {}
})();
const R = {
        key: 0,
        class: "close-btn d-flex justify-end"
    },
    S = {
        key: 0,
        class: "close-btn d-flex justify-end"
    },
    J = j({
        __name: "AppDialog",
        props: {
            contentClass: {},
            persistent: {
                type: Boolean
            },
            width: {},
            isUseCloseBtn: {
                type: Boolean
            },
            isUseCloseBtnAddition: {
                type: Boolean
            },
            isHideOverlay: {
                type: Boolean
            },
            isAddition: {
                type: Boolean
            }
        },
        emits: ["modal:close"],
        setup(s, {
            emit: l
        }) {
            const d = s,
                C = l,
                {
                    dialogData: _
                } = A(p()),
                {
                    changeDialogData: v
                } = p(),
                {
                    trackButtonClick: V
                } = w(),
                {
                    closeDialog: k
                } = I(),
                r = z(() => {
                    var e;
                    return !!((e = _.value) != null && e.name)
                }),
                B = {
                    "auth-dialog": "login_popup",
                    "resetpwd-dialog": "recover_popup",
                    "registration-dialog": "register_popup"
                },
                u = () => {
                    v(null), k(), C("modal:close");
                    const e = B[d.contentClass || ""];
                    e && V({
                        category: e,
                        action: "close"
                    })
                };
            return (e, t) => (i(), y(N, E({
                modelValue: H(r),
                "onUpdate:modelValue": t[0] || (t[0] = D => O(r) ? r.value = D : null)
            }, d, {
                "hide-overlay": e.isHideOverlay,
                attach: "",
                scrollable: ""
            }), {
                default: o(() => [a(m, null, {
                    default: o(() => [a(h, null, {
                        default: o(() => [e.isUseCloseBtn ? (i(), g("div", R, [a(f, {
                            size: "16",
                            onClick: u
                        }, {
                            default: o(() => t[1] || (t[1] = [b(" mdi-close")])),
                            _: 1
                        })])) : c("", !0), n(e.$slots, "title", {}, void 0, !0)]),
                        _: 3
                    }), a(U, null, {
                        default: o(() => [n(e.$slots, "body", {}, void 0, !0)]),
                        _: 3
                    }), a(T, null, {
                        default: o(() => [n(e.$slots, "actions", {}, void 0, !0)]),
                        _: 3
                    })]),
                    _: 3
                }), e.isAddition ? (i(), y(m, {
                    key: 0,
                    class: "addition"
                }, {
                    default: o(() => [e.isUseCloseBtnAddition ? (i(), g("div", S, [a(f, {
                        size: "16",
                        onClick: u
                    }, {
                        default: o(() => t[2] || (t[2] = [b("mdi-close")])),
                        _: 1
                    })])) : c("", !0), n(e.$slots, "addition", {}, void 0, !0)]),
                    _: 3
                })) : c("", !0)]),
                _: 3
            }, 16, ["modelValue", "hide-overlay"]))
        }
    }),
    x = $(J, [
        ["__scopeId", "data-v-60afa631"]
    ]);
export {
    x as A
};