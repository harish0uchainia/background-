import {
    u as G
} from "./Eh0EvCQt.js";
import {
    u as E,
    $ as k,
    v as z,
    w as A,
    g as $,
    h as B,
    a6 as O
} from "./BbvgifQp.js";
import {
    u as P
} from "./Cc4FcFuq.js";
import {
    d as R,
    B as T
} from "./BBZLTf3A.js";
(function() {
    try {
        var o = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            u = new o.Error().stack;
        u && (o._sentryDebugIds = o._sentryDebugIds || {}, o._sentryDebugIds[u] = "bac21e73-741e-4098-9b53-53c7d5e086c5", o._sentryDebugIdIdentifier = "sentry-dbid-bac21e73-741e-4098-9b53-53c7d5e086c5")
    } catch {}
})();

function q() {
    const {
        imageUrl: o
    } = G();

    function u(l, f) {
        return `${o.value}/${f}/${l}.svg`
    }

    function t(l) {
        const d = l.filter(g => g == null ? void 0 : g.length).join("/").split("/");
        return `${o.value}/${d[0]}/${d[1]}.${d[2]}`
    }

    function m(l) {
        return l.includes("mdi-")
    }
    return {
        getSvgIcon: u,
        getIconWithExt: t,
        isIcon: m
    }
}
const L = {
    brazil: "BR",
    bangladesh: "BD",
    philippines: "PH",
    india: "IN"
};

function x(o = "use") {
    const {
        config: u
    } = E(), t = {
        src: "https://accounts.google.com/gsi/client",
        id: "google-sso-script",
        async: !0
    }, {
        onRegistrationWithGoogle: m,
        setGoogleSsoAvailable: l
    } = k(), {
        userGeo: f
    } = z(A()), {
        isAuthenticated: d
    } = $(), {
        isDesktop: g
    } = P(), {
        locale: b
    } = B(), p = R(() => {
        var e;
        return d.value || O() ? !1 : (e = u.value) != null && e.APP_WITH_GOOGLE_SSO ? !0 : Object.values(L).includes(f.value)
    }), w = {
        client_id: "901678335424-ntkn3ouqvl360cm10a6p2t2rg963qaep.apps.googleusercontent.com",
        cancel_on_tap_outside: !1,
        ux_mode: "popup",
        callback: e => {
            m({
                credential: e.credential,
                isRegistration: o !== "use" && o === "signup",
                isLogin: o !== "use" && o === "signin"
            })
        },
        use_fedcm_for_prompt: !0,
        context: o
    }, _ = () => {
        var e, n, i, s, a, c;
        try {
            (i = (n = (e = window.google) == null ? void 0 : e.accounts) == null ? void 0 : n.id) != null && i.prompt && ((c = (a = (s = window.google) == null ? void 0 : s.accounts) == null ? void 0 : a.id) == null || c.prompt(r => {
                r.isSkippedMoment() && (h(), document.cookie = "g_state=;path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT")
            }))
        } catch (r) {
            console.error("window.google.accounts.id.prompt ", r)
        }
    }, h = ({
        width: e
    } = {}) => {
        var n, i, s, a, c, r, y, v, I;
        if (p.value) try {
            (s = (i = (n = window.google) == null ? void 0 : n.accounts) == null ? void 0 : i.id) != null && s.initialize && ((r = (c = (a = window.google) == null ? void 0 : a.accounts) == null ? void 0 : c.id) == null || r.initialize(w), (I = (v = (y = window.google) == null ? void 0 : y.accounts) == null ? void 0 : v.id) == null || I.renderButton(document.getElementById("google_auth_or_reg"), {
                type: "standard",
                shape: "pill",
                theme: "filled_blue",
                text: "continue_with",
                size: "large",
                logo_alignment: "left",
                locale: b.value || "en_US",
                width: e || (g.value ? 400 : 300),
                height: 47
            }))
        } catch (D) {
            console.error("reInit window.google.accounts.id.initialize", D)
        }
    }, S = () => {
        l(p.value), p.value && (window.onload = () => {
            var e, n, i, s, a, c;
            try {
                (i = (n = (e = window.google) == null ? void 0 : e.accounts) == null ? void 0 : n.id) != null && i.initialize && ((c = (a = (s = window.google) == null ? void 0 : s.accounts) == null ? void 0 : a.id) == null || c.initialize(w), _())
            } catch (r) {
                console.error("window.google.accounts.id.initialize", r)
            }
        })
    };
    return T(() => {
        if (p.value && !document.getElementById(t.id)) {
            const e = document.createElement("script");
            e.type = "text/javascript", e.src = t.src, e.id = t.id, e.async = t.async, document.head.append(e)
        }
    }), {
        googleSsoPromptDisplay: _,
        googleSsoReInit: h,
        googleSsoInit: S,
        googleSsoDisplay: p,
        googleSsoScript: t
    }
}
export {
    q as a, x as u
};