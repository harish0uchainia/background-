import {
    U as l,
    Y as s,
    ai as H,
    a4 as c,
    W as y,
    X as C,
    l as A,
    au as I,
    aA as x,
    ab as m,
    aj as J,
    ag as U,
    al as W,
    am as X,
    an as Z,
    a3 as $,
    ao as q,
    a_ as G,
    bt as K,
    bu as Q,
    ap as ee,
    as as ae,
    ac as te,
    ad as ne,
    aw as de,
    ax as ie,
    bv as le,
    bw as se,
    aZ as ce,
    az as re,
    a5 as ue,
    aB as oe,
    at as ve,
    a$ as me
} from "./BbvgifQp.js";
import {
    D as n,
    F as P,
    d as S,
    Y as ye,
    ar as be,
    J as ge
} from "./BBZLTf3A.js";
import {
    c as fe
} from "./Ka2RWjod.js";
import {
    V as h,
    d as ke
} from "./D9sqA5Xl.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            d = new e.Error().stack;
        d && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[d] = "765ce947-f77d-4c53-bc92-6b78fed4c33f", e._sentryDebugIdIdentifier = "sentry-dbid-765ce947-f77d-4c53-bc92-6b78fed4c33f")
    } catch {}
})();
const Ie = l()({
        name: "VCardActions",
        props: s(),
        setup(e, d) {
            let {
                slots: a
            } = d;
            return H({
                VBtn: {
                    slim: !0,
                    variant: "text"
                }
            }), c(() => {
                var t;
                return n("div", {
                    class: ["v-card-actions", e.class],
                    style: e.style
                }, [(t = a.default) == null ? void 0 : t.call(a)])
            }), {}
        }
    }),
    Ce = y({
        opacity: [Number, String],
        ...s(),
        ...C()
    }, "VCardSubtitle"),
    Ve = l()({
        name: "VCardSubtitle",
        props: Ce(),
        setup(e, d) {
            let {
                slots: a
            } = d;
            return c(() => n(e.tag, {
                class: ["v-card-subtitle", e.class],
                style: [{
                    "--v-card-subtitle-opacity": e.opacity
                }, e.style]
            }, a)), {}
        }
    }),
    pe = fe("v-card-title"),
    Ae = y({
        appendAvatar: String,
        appendIcon: m,
        prependAvatar: String,
        prependIcon: m,
        subtitle: [String, Number],
        title: [String, Number],
        ...s(),
        ...x()
    }, "VCardItem"),
    Pe = l()({
        name: "VCardItem",
        props: Ae(),
        setup(e, d) {
            let {
                slots: a
            } = d;
            return c(() => {
                var u;
                const t = !!(e.prependAvatar || e.prependIcon),
                    b = !!(t || a.prepend),
                    r = !!(e.appendAvatar || e.appendIcon),
                    g = !!(r || a.append),
                    f = !!(e.title != null || a.title),
                    k = !!(e.subtitle != null || a.subtitle);
                return n("div", {
                    class: ["v-card-item", e.class],
                    style: e.style
                }, [b && n("div", {
                    key: "prepend",
                    class: "v-card-item__prepend"
                }, [a.prepend ? n(I, {
                    key: "prepend-defaults",
                    disabled: !t,
                    defaults: {
                        VAvatar: {
                            density: e.density,
                            image: e.prependAvatar
                        },
                        VIcon: {
                            density: e.density,
                            icon: e.prependIcon
                        }
                    }
                }, a.prepend) : n(P, null, [e.prependAvatar && n(h, {
                    key: "prepend-avatar",
                    density: e.density,
                    image: e.prependAvatar
                }, null), e.prependIcon && n(A, {
                    key: "prepend-icon",
                    density: e.density,
                    icon: e.prependIcon
                }, null)])]), n("div", {
                    class: "v-card-item__content"
                }, [f && n(pe, {
                    key: "title"
                }, {
                    default: () => {
                        var i;
                        return [((i = a.title) == null ? void 0 : i.call(a)) ? ? e.title]
                    }
                }), k && n(Ve, {
                    key: "subtitle"
                }, {
                    default: () => {
                        var i;
                        return [((i = a.subtitle) == null ? void 0 : i.call(a)) ? ? e.subtitle]
                    }
                }), (u = a.default) == null ? void 0 : u.call(a)]), g && n("div", {
                    key: "append",
                    class: "v-card-item__append"
                }, [a.append ? n(I, {
                    key: "append-defaults",
                    disabled: !r,
                    defaults: {
                        VAvatar: {
                            density: e.density,
                            image: e.appendAvatar
                        },
                        VIcon: {
                            density: e.density,
                            icon: e.appendIcon
                        }
                    }
                }, a.append) : n(P, null, [e.appendIcon && n(A, {
                    key: "append-icon",
                    density: e.density,
                    icon: e.appendIcon
                }, null), e.appendAvatar && n(h, {
                    key: "append-avatar",
                    density: e.density,
                    image: e.appendAvatar
                }, null)])])])
            }), {}
        }
    }),
    Se = y({
        opacity: [Number, String],
        ...s(),
        ...C()
    }, "VCardText"),
    he = l()({
        name: "VCardText",
        props: Se(),
        setup(e, d) {
            let {
                slots: a
            } = d;
            return c(() => n(e.tag, {
                class: ["v-card-text", e.class],
                style: [{
                    "--v-card-text-opacity": e.opacity
                }, e.style]
            }, a)), {}
        }
    }),
    xe = y({
        appendAvatar: String,
        appendIcon: m,
        disabled: Boolean,
        flat: Boolean,
        hover: Boolean,
        image: String,
        link: {
            type: Boolean,
            default: void 0
        },
        prependAvatar: String,
        prependIcon: m,
        ripple: {
            type: [Boolean, Object],
            default: !0
        },
        subtitle: [String, Number],
        text: [String, Number],
        title: [String, Number],
        ...oe(),
        ...s(),
        ...x(),
        ...ue(),
        ...re(),
        ...ce(),
        ...se(),
        ...le(),
        ...ie(),
        ...de(),
        ...C(),
        ...ne(),
        ...te({
            variant: "elevated"
        })
    }, "VCard"),
    we = l()({
        name: "VCard",
        directives: {
            Ripple: J
        },
        props: xe(),
        setup(e, d) {
            let {
                attrs: a,
                slots: t
            } = d;
            const {
                themeClasses: b
            } = U(e), {
                borderClasses: r
            } = W(e), {
                colorClasses: g,
                colorStyles: f,
                variantClasses: k
            } = X(e), {
                densityClasses: u
            } = Z(e), {
                dimensionStyles: i
            } = $(e), {
                elevationClasses: D
            } = q(e), {
                loaderClasses: _
            } = G(e), {
                locationStyles: T
            } = K(e), {
                positionClasses: B
            } = Q(e), {
                roundedClasses: w
            } = ee(e), o = ae(e, a), L = S(() => e.link !== !1 && o.isLink.value), v = S(() => !e.disabled && e.link !== !1 && (e.link || o.isClickable.value));
            return c(() => {
                const N = L.value ? "a" : e.tag,
                    R = !!(t.title || e.title != null),
                    F = !!(t.subtitle || e.subtitle != null),
                    E = R || F,
                    j = !!(t.append || e.appendAvatar || e.appendIcon),
                    M = !!(t.prepend || e.prependAvatar || e.prependIcon),
                    O = !!(t.image || e.image),
                    Y = E || M || j,
                    z = !!(t.text || e.text != null);
                return ye(n(N, ge({
                    class: ["v-card", {
                        "v-card--disabled": e.disabled,
                        "v-card--flat": e.flat,
                        "v-card--hover": e.hover && !(e.disabled || e.flat),
                        "v-card--link": v.value
                    }, b.value, r.value, g.value, u.value, D.value, _.value, B.value, w.value, k.value, e.class],
                    style: [f.value, i.value, T.value, e.style],
                    onClick: v.value && o.navigate,
                    tabindex: e.disabled ? -1 : void 0
                }, o.linkProps), {
                    default: () => {
                        var V;
                        return [O && n("div", {
                            key: "image",
                            class: "v-card__image"
                        }, [t.image ? n(I, {
                            key: "image-defaults",
                            disabled: !e.image,
                            defaults: {
                                VImg: {
                                    cover: !0,
                                    src: e.image
                                }
                            }
                        }, t.image) : n(ke, {
                            key: "image-img",
                            cover: !0,
                            src: e.image
                        }, null)]), n(me, {
                            name: "v-card",
                            active: !!e.loading,
                            color: typeof e.loading == "boolean" ? void 0 : e.loading
                        }, {
                            default: t.loader
                        }), Y && n(Pe, {
                            key: "item",
                            prependAvatar: e.prependAvatar,
                            prependIcon: e.prependIcon,
                            title: e.title,
                            subtitle: e.subtitle,
                            appendAvatar: e.appendAvatar,
                            appendIcon: e.appendIcon
                        }, {
                            default: t.item,
                            prepend: t.prepend,
                            title: t.title,
                            subtitle: t.subtitle,
                            append: t.append
                        }), z && n(he, {
                            key: "text"
                        }, {
                            default: () => {
                                var p;
                                return [((p = t.text) == null ? void 0 : p.call(t)) ? ? e.text]
                            }
                        }), (V = t.default) == null ? void 0 : V.call(t), t.actions && n(Ie, null, {
                            default: t.actions
                        }), ve(v.value, "v-card")]
                    }
                }), [
                    [be("ripple"), v.value && e.ripple]
                ])
            }), {}
        }
    });
export {
    we as V, pe as a, he as b, Ie as c, Ve as d
};