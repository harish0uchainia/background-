import {
    ay as c,
    L as g,
    A as p,
    az as x
} from "./BBZLTf3A.js";
import {
    U as b,
    W as _
} from "./BbvgifQp.js";
(function() {
    try {
        var i = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            a = new i.Error().stack;
        a && (i._sentryDebugIds = i._sentryDebugIds || {}, i._sentryDebugIds[a] = "26e0a648-bc7e-4e48-97ac-bb79ea83bb5a", i._sentryDebugIdIdentifier = "sentry-dbid-26e0a648-bc7e-4e48-97ac-bb79ea83bb5a")
    } catch {}
})();
const w = _({
    disabled: Boolean,
    group: Boolean,
    hideOnLeave: Boolean,
    leaveAbsolute: Boolean,
    mode: String,
    origin: String
}, "transition");

function o(i, a, s) {
    return b()({
        name: i,
        props: w({
            mode: s,
            origin: a
        }),
        setup(n, l) {
            let {
                slots: r
            } = l;
            const t = {
                onBeforeEnter(e) {
                    n.origin && (e.style.transformOrigin = n.origin)
                },
                onLeave(e) {
                    if (n.leaveAbsolute) {
                        const {
                            offsetTop: d,
                            offsetLeft: f,
                            offsetWidth: y,
                            offsetHeight: u
                        } = e;
                        e._transitionInitialStyles = {
                            position: e.style.position,
                            top: e.style.top,
                            left: e.style.left,
                            width: e.style.width,
                            height: e.style.height
                        }, e.style.position = "absolute", e.style.top = `${d}px`, e.style.left = `${f}px`, e.style.width = `${y}px`, e.style.height = `${u}px`
                    }
                    n.hideOnLeave && e.style.setProperty("display", "none", "important")
                },
                onAfterLeave(e) {
                    if (n.leaveAbsolute && (e != null && e._transitionInitialStyles)) {
                        const {
                            position: d,
                            top: f,
                            left: y,
                            width: u,
                            height: v
                        } = e._transitionInitialStyles;
                        delete e._transitionInitialStyles, e.style.position = d || "", e.style.top = f || "", e.style.left = y || "", e.style.width = u || "", e.style.height = v || ""
                    }
                }
            };
            return () => {
                const e = n.group ? c : g;
                return p(e, {
                    name: n.disabled ? "" : i,
                    css: !n.disabled,
                    ...n.group ? void 0 : {
                        mode: n.mode
                    },
                    ...n.disabled ? {} : t
                }, r.default)
            }
        }
    })
}

function h(i, a) {
    let s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "in-out";
    return b()({
        name: i,
        props: {
            mode: {
                type: String,
                default: s
            },
            disabled: Boolean,
            group: Boolean
        },
        setup(n, l) {
            let {
                slots: r
            } = l;
            const t = n.group ? c : g;
            return () => p(t, {
                name: n.disabled ? "" : i,
                css: !n.disabled,
                ...n.disabled ? {} : a
            }, r.default)
        }
    })
}

function m() {
    let i = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
    const s = (arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1) ? "width" : "height",
        n = x(`offset-${s}`);
    return {
        onBeforeEnter(t) {
            t._parent = t.parentNode, t._initialStyle = {
                transition: t.style.transition,
                overflow: t.style.overflow,
                [s]: t.style[s]
            }
        },
        onEnter(t) {
            const e = t._initialStyle;
            if (!e) return;
            t.style.setProperty("transition", "none", "important"), t.style.overflow = "hidden";
            const d = `${t[n]}px`;
            t.style[s] = "0", t.offsetHeight, t.style.transition = e.transition, i && t._parent && t._parent.classList.add(i), requestAnimationFrame(() => {
                t.style[s] = d
            })
        },
        onAfterEnter: r,
        onEnterCancelled: r,
        onLeave(t) {
            t._initialStyle = {
                transition: "",
                overflow: t.style.overflow,
                [s]: t.style[s]
            }, t.style.overflow = "hidden", t.style[s] = `${t[n]}px`, t.offsetHeight, requestAnimationFrame(() => t.style[s] = "0")
        },
        onAfterLeave: l,
        onLeaveCancelled: l
    };

    function l(t) {
        i && t._parent && t._parent.classList.remove(i), r(t)
    }

    function r(t) {
        if (!t._initialStyle) return;
        const e = t._initialStyle[s];
        t.style.overflow = t._initialStyle.overflow, e != null && (t.style[s] = e), delete t._initialStyle
    }
}
o("fab-transition", "center center", "out-in");
o("dialog-bottom-transition");
o("dialog-top-transition");
const T = o("fade-transition");
o("scale-transition");
o("scroll-x-transition");
o("scroll-x-reverse-transition");
o("scroll-y-transition");
o("scroll-y-reverse-transition");
o("slide-x-transition");
o("slide-x-reverse-transition");
const A = o("slide-y-transition");
o("slide-y-reverse-transition");
const E = h("expand-transition", m()),
    I = h("expand-x-transition", m("", !0));
export {
    I as V, E as a, A as b, T as c
};