import {
    v as i,
    w as n,
    _ as u
} from "./BbvgifQp.js";
import {
    z as d,
    d as g,
    _ as f,
    V as _,
    a7 as r,
    u as a,
    a0 as p
} from "./BBZLTf3A.js";
import {
    u as m
} from "./Eh0EvCQt.js";
import {
    u as b
} from "./CRXlgDsv.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "55714d48-f46b-4133-90f2-81fa6dcd0d6d", e._sentryDebugIdIdentifier = "sentry-dbid-55714d48-f46b-4133-90f2-81fa6dcd0d6d")
    } catch {}
})();
const v = ["src", "alt", "title"],
    y = d({
        __name: "CategoryFilterIcon",
        props: {
            slug: {}
        },
        setup(e) {
            const t = e,
                {
                    imageUrl: s
                } = m(),
                {
                    section: l
                } = b(),
                {
                    userGeo: c
                } = i(n()),
                o = g(() => c.value === "BD" && l.value === "casino" && t.slug === "local" ? "jili" : t.slug);
            return (h, k) => (_(), f("div", {
                class: r(["cat-filter-icon", `cat-filter-icon_${a(o)}`])
            }, [p("img", {
                src: `${a(s)}/casino/${a(o)}.png`,
                class: r(["cat-filter-icon__img", `cat-filter-icon__img_${a(o)}`]),
                width: "24",
                height: "24",
                alt: a(o),
                title: a(o),
                loading: "lazy"
            }, null, 10, v)], 2))
        }
    }),
    S = u(y, [
        ["__scopeId", "data-v-93cb509f"]
    ]),
    B = {
        "virtual-soccer": "football",
        "virtual-tennis": "tennis",
        "virtual-basketball": "basketball",
        "virtual-dog-racing": "dog-racing",
        "virtual-horses": "horses-racing",
        "virtual-racing": "racing",
        "virtual-baseball": "baseball",
        "virtual-golf": "golf",
        popular: "royal-crown",
        "new-games": "diamond",
        slots: "slot-machine",
        baccarat: "baccarat",
        roulette: "roulette",
        blackjack: "card-game",
        table: "dice",
        board: "poker-table",
        lottery: "lottery",
        "video-poker": "video-poker",
        other: "other",
        bingo: "bingo",
        cases: "cases",
        crash: "crash-category",
        keno: "keno",
        vip: "vip-category",
        fast: "fast-category",
        local: "local-category",
        live: "live-category",
        evolution: "category-evolution",
        game_shows: "category-game_shows",
        virtual_sports: "virtual-sports",
        exclusives: "exclusives-category"
    };
export {
    B as S, S as _
};