import G from "./DNwLMpuy.js";
import {
    _ as q,
    s as $
} from "./DBHC5eiV.js";
import {
    z as j,
    b,
    d as v,
    w as K,
    _ as g,
    U as Q,
    a8 as S,
    u as o,
    V as u,
    a0 as r,
    D as X,
    F as Y,
    aa as Z,
    a7 as ee
} from "./BBZLTf3A.js";
import {
    t as te,
    f as se,
    g as oe,
    v as ne,
    q as I,
    c as ae,
    s as re,
    _ as ie
} from "./BbvgifQp.js";
import {
    u as le
} from "./D5xT9ef6.js";
import {
    u as ce
} from "./D_nsTU_t.js";
(function() {
    try {
        var a = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            d = new a.Error().stack;
        d && (a._sentryDebugIds = a._sentryDebugIds || {}, a._sentryDebugIds[d] = "fd38b464-a910-4075-9c18-38b1610b3f9d", a._sentryDebugIdIdentifier = "sentry-dbid-fd38b464-a910-4075-9c18-38b1610b3f9d")
    } catch {}
})();
const ue = {
        class: "l-content__cols"
    },
    de = {
        class: "l-content__col-left"
    },
    _e = {
        class: "l-content__slider"
    },
    me = {
        key: 0,
        class: "l-content__col-right"
    },
    fe = {
        class: "banner banner--border-r h-d_block h-none l-content__banner"
    },
    pe = ["href"],
    he = ["data-src"],
    be = j({
        __name: "CasinoSlider",
        setup(a) {
            const d = te(),
                {
                    openDialog: k
                } = se(),
                {
                    isAuthenticated: y
                } = oe(),
                {
                    profileForm: w
                } = le(),
                {
                    filteredBannerList: U,
                    isBannersLoaded: L
                } = ne(I()),
                {
                    setBannersLoaded: A
                } = I(),
                {
                    isMobileUa: C,
                    isPcUa: M
                } = ce(),
                {
                    changeUploadHost: z,
                    getSubdirUrlPart: P
                } = ae(),
                {
                    debounce: V
                } = re(),
                B = b(""),
                _ = b(""),
                N = b(!1),
                i = b([]),
                x = v(() => {
                    var e;
                    return (e = U.value) == null ? void 0 : e.big
                }),
                F = v(() => {
                    var e;
                    return (e = U.value) == null ? void 0 : e.small
                }),
                O = v(() => H()),
                T = {
                    "tv-games": "TV Games",
                    "live-dealers": "Live Dealers",
                    casino: "Casino",
                    "": "Main",
                    "/": "Main"
                },
                D = v(() => {
                    const e = P(0, d.path);
                    return T[e] || null
                });

            function J(e) {
                if (!y.value) return k("auth");
                window.location = e
            }
            const W = V(e => {
                i.value = $(e), A(!0)
            }, 500, {
                leading: !0
            });
            K(() => x.value, e => {
                e && e.length ? E(e) : i.value = []
            }, {
                immediate: !0
            });

            function E(e) {
                try {
                    const n = [],
                        l = D.value,
                        s = JSON.parse(JSON.stringify(e ? ? [])),
                        c = t => t === "all" || M.value && t === "desktopDevices" || C.value && t === "mobileDevices",
                        R = t => {
                            var m, f, p;
                            if (t === "all") return !0;
                            if (y.value) {
                                const h = ((p = (f = (m = w.value) == null ? void 0 : m.balance) == null ? void 0 : f.total_deposit) == null ? void 0 : p.amount) || 0;
                                return t === "authorizedUsersWithoutDeposit" && !+h || t === "authorizedUsersWithDeposit" && !!+h || !["authorizedUsersWithoutDeposit", "authorizedUsersWithDeposit"].includes(t) && t === "authorizedUsers"
                            } else return t === "unauthorizedUsers"
                        };
                    for (const t of s) {
                        const {
                            disposition: m,
                            platform: f,
                            is_for_signed_in: p,
                            image: h
                        } = t;
                        !c(f) || !R(p) || m.includes(l) && (B.value = z(h), n.push(t))
                    }
                    W(n)
                } catch (n) {
                    console.error("error BIG banners", n)
                }
            }

            function H() {
                try {
                    const e = D.value,
                        n = JSON.parse(JSON.stringify(F.value ? ? [])),
                        l = s => {
                            B.value = z(s.image), _.value = s.location;
                            const c = s.is_for_signed_in;
                            N.value = y.value ? c !== "unauthorizedUsers" : ["unauthorizedUsers", "all"].includes(c)
                        };
                    for (const s of n)
                        if (s.disposition.includes(e) && s.enabled) return l(s), !0
                } catch (e) {
                    console.error("error SMALL banners", e)
                }
            }
            return (e, n) => {
                const l = G,
                    s = q;
                return o(i) && o(i).length ? (u(), g("div", {
                    key: 0,
                    class: ee(["l-content__block", {
                        "is-not-home-page": o(D) !== "Main"
                    }])
                }, [r("div", ue, [r("div", de, [r("div", _e, [X(l, {
                    items: o(i) || []
                }, null, 8, ["items"])])]), o(O) ? (u(), g(Y, {
                    key: 0
                }, [o(N) ? (u(), g("div", me, [r("div", fe, [o(_) ? (u(), g("a", {
                    key: 0,
                    href: o(_),
                    onClick: n[0] || (n[0] = Z(c => J(o(_)), ["prevent"]))
                }, [r("div", null, [r("img", {
                    "data-src": o(B),
                    alt: "small banner",
                    title: "small banner",
                    loading: "lazy"
                }, null, 8, he)])], 8, pe)) : S("", !0)])])) : S("", !0)], 64)) : S("", !0)])], 2)) : o(L) ? S("", !0) : (u(), Q(s, {
                    key: 1
                }))
            }
        }
    }),
    Ue = ie(be, [
        ["__scopeId", "data-v-bb69732b"]
    ]);
export {
    Ue as _
};