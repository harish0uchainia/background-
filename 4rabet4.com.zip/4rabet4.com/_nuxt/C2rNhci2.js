import {
    S as t,
    c as I,
    z as _,
    t as E,
    E as l,
    _ as A
} from "./BbvgifQp.js";
import {
    z as x,
    d as v,
    b as L,
    B as M,
    R as B,
    C as T,
    U as R,
    V as C,
    X as g,
    u as i,
    a7 as w,
    W as O,
    $ as h
} from "./BBZLTf3A.js";
(function() {
    try {
        var s = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            e = new s.Error().stack;
        e && (s._sentryDebugIds = s._sentryDebugIds || {}, s._sentryDebugIds[e] = "286422c1-da5e-4036-901f-39f0cf93b138", s._sentryDebugIdIdentifier = "sentry-dbid-286422c1-da5e-4036-901f-39f0cf93b138")
    } catch {}
})();
const S = ["RW", "BF", "TZ", "ZM", "IN"];
var d, p, y;
const j = [{
        name: "Main",
        route: "/",
        sysname: "main",
        icon: "main"
    }, {
        name: "live",
        route: "/live",
        sysname: "live",
        icon: "sport-game-scores"
    }, {
        name: "sports",
        route: "/sports",
        sysname: "line",
        icon: "football-field"
    }, {
        name: "Casino",
        route: "/casino",
        sysname: "casino",
        icon: "seven"
    }, {
        name: "Live Dealers",
        route: "/live-dealers",
        sysname: "liveDealers",
        icon: "token"
    }, {
        name: "TV Games",
        route: "/tv-games",
        sysname: "tvGames",
        icon: "tv"
    }, {
        name: "Aviator",
        route: t.AVIATOR_MOBILE,
        slotId: ((d = t.AVIATOR_MOBILE) == null ? void 0 : d.replace("/casino/slot/", "")) || "aviator",
        sysname: "aviator",
        icon: "aviator",
        mob: !0
    }, {
        name: "JetX",
        route: t.JETX_MOBILE,
        slotId: ((p = t.JETX_MOBILE) == null ? void 0 : p.replace("/tv-games/slot/", "")) || "jetx",
        sysname: "jetx",
        icon: "jetx",
        mob: !0
    }, {
        name: "Aviatrix",
        route: t.AVIATRIX_MOBILE,
        slotId: ((y = t.AVIATRIX_MOBILE) == null ? void 0 : y.replace("/casino/slot/", "")) || "aviatrix",
        sysname: "aviatrix",
        icon: "aviatrix",
        mob: !0
    }, {
        name: "Cybersport",
        route: "/sports/e_sport",
        sysname: "cyberSport",
        icon: "football"
    }, {
        name: "Bonuses",
        route: "/bonuses",
        sysname: "bonuses",
        icon: "certificate"
    }],
    G = [{
        id: 1,
        name: "Main",
        route: "/",
        sysname: "main",
        icon: "main"
    }, {
        id: 2,
        name: "live",
        route: "/live",
        sysname: "live",
        icon: "sport-game-scores"
    }, {
        id: 3,
        name: "sports",
        route: "/sports",
        sysname: "line",
        icon: "football-field"
    }, {
        id: 4,
        name: "IPL",
        route: "/sports/cricket/india/indian-premier-league-1710528586840150016",
        sysname: "ipl",
        icon: "ipl"
    }, {
        id: 5,
        name: "Casino",
        route: "/casino",
        sysname: "casino",
        icon: "seven"
    }, {
        id: 6,
        name: "Live Dealers",
        route: "/live-dealers",
        sysname: "liveDealers",
        icon: "token"
    }, {
        id: 7,
        name: "TV Games",
        route: "/tv-games",
        sysname: "tvGames",
        icon: "tv"
    }, {
        id: 8,
        name: "Aviator",
        route: t.AVIATOR_MOBILE,
        slotId: "aviator",
        sysname: "aviator",
        icon: "aviator",
        mob: !0
    }, {
        id: 9,
        name: "JetX",
        route: t.JETX_MOBILE,
        slotId: "jetx-m",
        sysname: "jetx",
        icon: "jetx",
        mob: !0
    }, {
        id: 10,
        name: "Aviatrix",
        route: t.AVIATRIX_MOBILE,
        slotId: "aviatrix-m",
        sysname: "aviatrix",
        icon: "aviatrix",
        mob: !0
    }, {
        id: 11,
        name: "Cybersport",
        route: "/sports/e_sport",
        sysname: "cyberSport",
        icon: "football"
    }, {
        id: 12,
        name: "Bonuses",
        route: "/bonuses",
        sysname: "bonuses",
        icon: "certificate"
    }],
    J = [{
        name: "Main",
        route: "/",
        sysname: "main",
        icon: "main"
    }, {
        name: "live",
        route: "/live",
        sysname: "live",
        icon: "sport-game-scores"
    }, {
        name: "sports",
        route: "/sports",
        sysname: "line",
        icon: "football-field"
    }, {
        name: "IPL",
        route: "/live?bt-path=%2Flive%2F1",
        sysname: "football",
        icon: "football"
    }, {
        name: "Casino",
        route: "/casino",
        sysname: "casino",
        icon: "seven"
    }, {
        name: "Live Dealers",
        route: "/live-dealers",
        sysname: "liveDealers",
        icon: "token"
    }, {
        name: "TV Games",
        route: "/tv-games",
        sysname: "tvGames",
        icon: "tv"
    }, {
        name: "Aviator",
        route: t.AVIATOR_MOBILE,
        slotId: "aviator",
        sysname: "aviator",
        icon: "aviator",
        mob: !0
    }, {
        name: "JetX",
        route: t.JETX_MOBILE,
        slotId: "jetx-m",
        sysname: "jetx",
        icon: "jetx",
        mob: !0
    }, {
        name: "Aviatrix",
        route: t.AVIATRIX_MOBILE,
        slotId: "aviatrix-m",
        sysname: "aviatrix",
        icon: "aviatrix",
        mob: !0
    }, {
        name: "Cybersport",
        route: "/sports/e_sport",
        sysname: "cyberSport",
        icon: "football"
    }, {
        name: "Bonuses",
        route: "/bonuses",
        sysname: "bonuses",
        icon: "certificate"
    }],
    D = x({
        __name: "BetbyLink",
        props: {
            routePath: {},
            isDynamic: {
                type: Boolean,
                default: !0
            },
            activeClass: {
                default: ""
            },
            activeRoutes: {
                default: () => []
            }
        },
        setup(s) {
            const e = s,
                {
                    customPathWithLocale: r
                } = I(),
                {
                    $bt: o
                } = _(),
                m = E(),
                c = v(() => e.isDynamic && (o != null && o.isHere()) && m.meta.isBetbyRoute ? "div" : l),
                u = L(!1),
                b = v(() => r(e.routePath)),
                n = () => {
                    const a = c.value === l ? m.path : window.location.pathname;
                    u.value = e.activeRoutes.includes(a)
                },
                f = () => {
                    e.activeClass && e.activeRoutes.length && window.dispatchEvent(new Event("betby-route-update"))
                };
            return M(() => {
                e.activeClass && e.activeRoutes.length && (n(), window.addEventListener("betby-route-update", n))
            }), B(() => {
                e.activeClass && e.activeRoutes.length && window.dispatchEvent(new Event("betby-route-update"))
            }), T(() => {
                e.activeClass && e.activeRoutes.length && window.removeEventListener("betby-route-update", n)
            }), (a, V) => (C(), R(g(i(c)), {
                to: i(b),
                class: w([
                    [i(u) ? a.activeClass : ""], "link-to-bt"
                ]),
                onClick: f
            }, {
                default: O(() => [h(a.$slots, "default", {}, void 0, !0)]),
                _: 3
            }, 8, ["to", "class"]))
        }
    }),
    P = A(D, [
        ["__scopeId", "data-v-7248fe47"]
    ]);
export {
    S as A, G as M, P as _, j as a, J as b
};