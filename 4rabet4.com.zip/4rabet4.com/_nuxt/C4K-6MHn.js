(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            d = new e.Error().stack;
        d && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[d] = "bac15aa2-6bf8-464d-be9b-95768d32b908", e._sentryDebugIdIdentifier = "sentry-dbid-bac15aa2-6bf8-464d-be9b-95768d32b908")
    } catch {}
})();
const r = (e, d) => d !== "providers";
export {
    r as d
};