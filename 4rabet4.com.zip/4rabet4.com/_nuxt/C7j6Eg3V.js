import {
    z as f,
    o as m,
    a as b
} from "./BbvgifQp.js";
import {
    b as I
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "e0c800b6-7c31-4218-96ad-a6d59837ecc1", e._sentryDebugIdIdentifier = "sentry-dbid-e0c800b6-7c31-4218-96ad-a6d59837ecc1")
    } catch {}
})();
let u = null;

function C() {
    const {
        $privateLog: e
    } = f(), n = a => {
        ["clickOnStory", "showSlide", "showStory", "closeStory", "clickOnButton", "likeStory", "dislikeStory", "favoriteStory", "shareStory", "shareStoryWithPath", "feedLoad", "feedImpression", "startGame", "finishGame", "closeGame"].forEach(o => {
            a.on(o, i => {
                e(o, "[InAppStories] --> Event"), e(i, "[InAppStories] --> Payload")
            })
        })
    }, {
        isInAppStoriesReady: t
    } = m(), s = I(0);
    return {
        isInAppStoriesReady: t,
        renderStackedStoryCard: a => {
            const l = document.getElementById("story-card"),
                o = () => {
                    s.value = 0;
                    for (const i of a.stories) i.isOpened || (s.value += 1, s.value = Math.min(s.value, 6))
                };
            o(), a.on("update", i => {
                e("[InAppStories] --> InAppStories Updated"), u = i, o()
            }), a.on("destroy", () => {
                a.destroy()
            }), l == null || l.addEventListener("click", () => {
                e("[InAppStories] --> InAppStories Clicked"), a.showStory(u)
            })
        },
        addEventListeners: n,
        unreadTrendsCount: s
    }
}
let c = null,
    p = [];
const A = e => ({
        apiKey: b().public.env.IN_APP_STORIES_KEY,
        userId: e,
        tags: [],
        placeholders: {
            user: "Guest"
        },
        imagePlaceholders: {
            userAvatar: "image_url"
        },
        lang: "en"
    }),
    g = e => {
        var n;
        try {
            return ((n = window.IAS.StoryManager) == null ? void 0 : n.getInstance()) || new window.IAS.StoryManager(e)
        } catch (t) {
            throw new Error(`Error during initialization StoryManager: ${t instanceof Error?t.message:String(t)}`)
        }
    },
    k = e => {
        e.setCommonOptions({
            hasLike: !0,
            hasFavorite: !0,
            closeButtonPosition: "right"
        }).setStoriesListOptions({
            card: {
                title: {
                    color: "red",
                    font: "14px/16px InternalPrimaryFont",
                    padding: 8,
                    position: "cardOutsideBottom",
                    lineClamp: 3
                },
                gap: 10,
                height: 100,
                variant: "quad",
                border: {
                    radius: 20,
                    color: "blue",
                    width: 2,
                    gap: 3
                },
                boxShadow: null,
                opacity: 1,
                mask: {
                    color: "rgba(34, 34, 34, 0.3)"
                },
                opened: {
                    border: {
                        radius: null,
                        color: "red",
                        width: null,
                        gap: null
                    },
                    boxShadow: null,
                    opacity: null,
                    mask: {
                        color: "rgba(34, 34, 34, 0.1)"
                    }
                }
            },
            layout: {
                height: 0,
                backgroundColor: "transparent"
            },
            sidePadding: 20,
            topPadding: 20,
            bottomPadding: 20,
            bottomMargin: 0,
            navigation: {
                showControls: !1,
                controlsSize: 48,
                controlsBackgroundColor: "white",
                controlsColor: "black"
            }
        }).setStoryReaderOptions({
            scrollStyle: "flat",
            sharePanel: {
                targets: ["facebook", "twitter", "vk", "linkedin", "telegram"]
            }
        }).setStoryFavoriteReaderOptions({
            title: {
                content: "Favorite",
                color: "white",
                font: "14px/16px InternalPrimaryFont",
                backgroundColor: "#333333"
            },
            backgroundColor: "#333333"
        })
    },
    S = () => {
        try {
            const e = new window.IAS.AppearanceManager;
            return k(e), e
        } catch (e) {
            throw new Error(`Error during initialization StoryManager: ${e instanceof Error?e.message:String(e)}`)
        }
    },
    P = (e, n) => {
        try {
            const t = g(n),
                s = S();
            s.setCommonOptions({
                hasLike: !0,
                hasFavorite: !0
            }).setStoryReaderOptions({
                closeButtonPosition: "right",
                scrollStyle: "flat"
            });
            const r = {
                handleStartLoading: () => console.log("handleStartLoading"),
                handleStopLoading: a => console.log("handleStartLoading", a),
                handleStoryReaderClose: () => console.log("handleStoryReaderClose")
            };
            return new t.SharePage(e, s, r)
        } catch (t) {
            throw new Error(`Error during initialization StoryManager: ${t instanceof Error?t.message:String(t)}`)
        }
    },
    M = (e, n) => {
        try {
            const t = S();
            return t.setGameReaderOptions({
                loader: {
                    default: {
                        color: "white",
                        accentColor: "transparent"
                    }
                }
            }), !c && n && (c = g(n), c.setUserId(n.userId), c.storyLinkClickHandler = ({
                data: s
            }) => {
                const {
                    url: r
                } = s, a = () => c == null ? void 0 : c.closeStoryReader(), l = o => decodeURIComponent(o).split("&").reduce((d, h) => {
                    const [y, w] = h.split("=");
                    return y.trim().toLowerCase() === "action" ? w.trim() : d
                }, null);
                if (r.startsWith("app://"))
                    if (r.includes("smartico")) {
                        if (r.includes("smartico") && (r.includes("casino") || r.includes("sports") || r.includes("live-dealers") || r.includes("tv-games"))) {
                            const o = r.replace("app://", "").split("?")[0],
                                i = r.split("=")[1],
                                d = l(i);
                            window._smartico.action(d), a(), e.push(o)
                        } else if (r.includes("smartico")) {
                            const o = "app:///?_smartico_dp=",
                                i = r.startsWith(o) ? r.substring(o.length) : "dp:gf_missions";
                            window._smartico.dp(i), a()
                        }
                    } else {
                        const o = r.replace("app://", "");
                        a(), r.includes("casino-tour") ? window.location.assign(o) : e.push(o)
                    }
                else window.open(r, "_blank")
            }, p = new c.StackedStoryList(t, {
                feed: "default"
            })), p
        } catch (t) {
            throw new Error(`Error during initialization StoryManager: ${t instanceof Error?t.message:String(t)}`)
        }
    };
export {
    P as a, A as c, M as i, C as u
};