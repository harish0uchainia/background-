import {
    a as s
} from "./BbvgifQp.js";
import {
    d as e
} from "./BBZLTf3A.js";
(function() {
    try {
        var o = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            r = new o.Error().stack;
        r && (o._sentryDebugIds = o._sentryDebugIds || {}, o._sentryDebugIds[r] = "90ff31a4-b119-4063-a3d2-9310688b9550", o._sentryDebugIdIdentifier = "sentry-dbid-90ff31a4-b119-4063-a3d2-9310688b9550")
    } catch {}
})();

function m() {
    const o = s(),
        r = e(() => o.app.imagesUrl),
        n = e(() => o.app.videoUrl),
        i = e(() => o.app.imagesPromoUrl),
        t = e(() => o.app.videoPromoUrl),
        a = e(() => o.app.imagesPromoIplUrl),
        d = e(() => o.app.videoPromoIplUrl);
    return {
        imageUrl: r,
        videoUrl: n,
        imagePromoUrl: i,
        videoPromoUrl: t,
        imagePromoIplUrl: a,
        videoPromoIplUrl: d
    }
}
export {
    m as u
};