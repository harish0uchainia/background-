import {
    z as b,
    b as d,
    B as u,
    _ as i,
    I as s
} from "./BBZLTf3A.js";
(function() {
    try {
        var n = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            e = new n.Error().stack;
        e && (n._sentryDebugIds = n._sentryDebugIds || {}, n._sentryDebugIds[e] = "b78ba00c-79c0-40b1-b2b7-f7de4963937c", n._sentryDebugIdIdentifier = "sentry-dbid-b78ba00c-79c0-40b1-b2b7-f7de4963937c")
    } catch {}
})();
const y = Symbol.for("nuxt:client-only"),
    p = b({
        name: "ClientOnly",
        inheritAttrs: !1,
        props: ["fallback", "placeholder", "placeholderTag", "fallbackTag"],
        setup(n, {
            slots: e,
            attrs: l
        }) {
            const t = d(!1);
            return u(() => {
                t.value = !0
            }), s(y, !0), a => {
                var c;
                if (t.value) return (c = e.default) == null ? void 0 : c.call(e);
                const r = e.fallback || e.placeholder;
                if (r) return r();
                const o = a.fallback || a.placeholder || "",
                    f = a.fallbackTag || a.placeholderTag || "span";
                return i(f, l, o)
            }
        }
    });
export {
    p as _
};