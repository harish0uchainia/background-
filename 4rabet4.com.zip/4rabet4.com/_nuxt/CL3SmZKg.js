import {
    m as w,
    a as D,
    c as g
} from "./D9sqA5Xl.js";
import {
    f as x
} from "./CbxP4vag.js";
import {
    U as I,
    W as p,
    a7 as L,
    aQ as A,
    a4 as B,
    b1 as S,
    au as F
} from "./BbvgifQp.js";
import {
    u as R
} from "./B9YIqgoQ.js";
import {
    b as T,
    p as W,
    w as b,
    J as v,
    D as E,
    n as O
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            i = new e.Error().stack;
        i && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[i] = "be90ecfa-57df-45f6-af07-443f68112874", e._sentryDebugIdIdentifier = "sentry-dbid-be90ecfa-57df-45f6-af07-443f68112874")
    } catch {}
})();
const U = p({
        fullscreen: Boolean,
        retainFocus: {
            type: Boolean,
            default: !0
        },
        scrollable: Boolean,
        ...w({
            origin: "center center",
            scrollStrategy: "block",
            transition: {
                component: D
            },
            zIndex: 2400
        })
    }, "VDialog"),
    J = I()({
        name: "VDialog",
        props: U(),
        emits: {
            "update:modelValue": e => !0,
            afterEnter: () => !0,
            afterLeave: () => !0
        },
        setup(e, i) {
            let {
                emit: d,
                slots: u
            } = i;
            const f = L(e, "modelValue"),
                {
                    scopeId: h
                } = R(),
                t = T();

            function m(n) {
                var r, s;
                const o = n.relatedTarget,
                    l = n.target;
                if (o !== l && ((r = t.value) != null && r.contentEl) && ((s = t.value) != null && s.globalTop) && ![document, t.value.contentEl].includes(l) && !t.value.contentEl.contains(l)) {
                    const a = S(t.value.contentEl);
                    if (!a.length) return;
                    const c = a[0],
                        P = a[a.length - 1];
                    o === c ? P.focus() : c.focus()
                }
            }
            W(() => {
                document.removeEventListener("focusin", m)
            }), A && b(() => f.value && e.retainFocus, n => {
                n ? document.addEventListener("focusin", m) : document.removeEventListener("focusin", m)
            }, {
                immediate: !0
            });

            function y() {
                var n;
                d("afterEnter"), (n = t.value) != null && n.contentEl && !t.value.contentEl.contains(document.activeElement) && t.value.contentEl.focus({
                    preventScroll: !0
                })
            }

            function V() {
                d("afterLeave")
            }
            return b(f, async n => {
                var o;
                n || (await O(), (o = t.value.activatorEl) == null || o.focus({
                    preventScroll: !0
                }))
            }), B(() => {
                const n = g.filterProps(e),
                    o = v({
                        "aria-haspopup": "dialog"
                    }, e.activatorProps),
                    l = v({
                        tabindex: -1
                    }, e.contentProps);
                return E(g, v({
                    ref: t,
                    class: ["v-dialog", {
                        "v-dialog--fullscreen": e.fullscreen,
                        "v-dialog--scrollable": e.scrollable
                    }, e.class],
                    style: e.style
                }, n, {
                    modelValue: f.value,
                    "onUpdate:modelValue": r => f.value = r,
                    "aria-modal": "true",
                    activatorProps: o,
                    contentProps: l,
                    height: e.fullscreen ? void 0 : e.height,
                    width: e.fullscreen ? void 0 : e.width,
                    maxHeight: e.fullscreen ? void 0 : e.maxHeight,
                    maxWidth: e.fullscreen ? void 0 : e.maxWidth,
                    role: "dialog",
                    onAfterEnter: y,
                    onAfterLeave: V
                }, h), {
                    activator: u.activator,
                    default: function() {
                        for (var r = arguments.length, s = new Array(r), a = 0; a < r; a++) s[a] = arguments[a];
                        return E(F, {
                            root: "VDialog"
                        }, {
                            default: () => {
                                var c;
                                return [(c = u.default) == null ? void 0 : c.call(u, ...s)]
                            }
                        })
                    }
                })
            }), x({}, t)
        }
    });
export {
    J as V
};