const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["./CzJexDrZ.js", "./DF9zLyti.js", "./BbvgifQp.js", "./BBZLTf3A.js", "./swiper-vue.OzWMjU4A.css", "./entry.J6UAyoZA.css", "./VGrid.D0S0a0cH.css", "./SwitcherPhoneAndEmail.jR1rQGUy.css"]))) => i.map(i => d[i]);
import {
    z as Be,
    b as L,
    r as _t,
    d as S,
    u as c,
    B as tt,
    f as Je,
    w as ye,
    ao as ae,
    O as vn,
    t as Et,
    X as pn,
    A as mn,
    l as hn,
    n as ie,
    y as gn,
    I as yn,
    aq as bn,
    ab as ht,
    _ as ve,
    V as H,
    a7 as qe,
    D as Z,
    W as se,
    U as Ve,
    a8 as le,
    Q as _n,
    J as ct,
    a0 as ee,
    a1 as we,
    a6 as wn,
    $ as qt,
    p as Ht,
    Y as Sn,
    a2 as gt,
    aa as Cn,
    ae as On,
    F as Tn
} from "./BBZLTf3A.js";
import {
    a0 as Vn,
    h as nt,
    v as Re,
    k as En,
    $ as je,
    q as zt,
    w as Wt,
    j as Gt,
    a1 as St,
    x as Pn,
    _ as ze,
    V as xt,
    o as Kt,
    p as In,
    t as Yt,
    a as An,
    C as kn,
    c as Rn,
    b as Xt,
    s as jn,
    u as Bn
} from "./BbvgifQp.js";
import {
    A as Fn
} from "./BM8cjqjo.js";
import {
    u as $n,
    P as Dn,
    z as Nn,
    A as Un,
    V as Ln
} from "./Nc2j0qUX.js";
import {
    s as Mn
} from "./DCO7F8HW.js";
import {
    V as wt,
    a as Xe
} from "./DF9zLyti.js";
import {
    V as qn
} from "./CNgVgUb9.js";
import {
    u as Qt,
    a as Hn
} from "./BtdAVlWx.js";
import {
    _ as Jt
} from "./BeLlcxC7.js";
import {
    u as zn
} from "./Cc4FcFuq.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "111a103c-705f-47f1-8236-ff9b69e18dd6", e._sentryDebugIdIdentifier = "sentry-dbid-111a103c-705f-47f1-8236-ff9b69e18dd6")
    } catch {}
})();
/**
 * vee-validate v4.15.0
 * (c) 2024 Abdelrahman Awad
 * @license MIT
 */
function Zt(e) {
    return /^\[.+\]$/i.test(e)
}

function Wn(e) {
    return Zt(e) ? e.replace(/\[|\]/gi, "") : e
}
const Gn = {
    generateMessage: ({
        field: e
    }) => `${e} is not valid.`,
    bails: !0,
    validateOnBlur: !0,
    validateOnChange: !0,
    validateOnInput: !1,
    validateOnModelUpdate: !0
};
Object.assign({}, Gn);
/**
 * vee-validate v4.15.0
 * (c) 2024 Abdelrahman Awad
 * @license MIT
 */
const Ze = e => e !== null && !!e && typeof e == "object" && !Array.isArray(e);

function Pt(e) {
    return Number(e) >= 0
}

function xn(e) {
    return typeof e == "object" && e !== null
}

function Kn(e) {
    return e == null ? e === void 0 ? "[object Undefined]" : "[object Null]" : Object.prototype.toString.call(e)
}

function It(e) {
    if (!xn(e) || Kn(e) !== "[object Object]") return !1;
    if (Object.getPrototypeOf(e) === null) return !0;
    let n = e;
    for (; Object.getPrototypeOf(n) !== null;) n = Object.getPrototypeOf(n);
    return Object.getPrototypeOf(e) === n
}

function en(e, n) {
    return Object.keys(n).forEach(t => {
        if (It(n[t]) && It(e[t])) {
            e[t] || (e[t] = {}), en(e[t], n[t]);
            return
        }
        e[t] = n[t]
    }), e
}

function Yn(e, n = {
    abortEarly: !1
}) {
    return {
        __type: "VVTypedSchema",
        async parse(r) {
            var a;
            try {
                return {
                    value: await e.validate(r, Object.assign({}, n)),
                    errors: []
                }
            } catch (i) {
                const l = i;
                if (l.name !== "ValidationError") throw i;
                if (!(!((a = l.inner) === null || a === void 0) && a.length) && l.errors.length) return {
                    errors: [{
                        path: l.path,
                        errors: l.errors
                    }]
                };
                const f = l.inner.reduce((d, v) => {
                    const g = v.path || "";
                    return d[g] || (d[g] = {
                        errors: [],
                        path: g
                    }), d[g].errors.push(...v.errors), d
                }, {});
                return {
                    errors: Object.values(f)
                }
            }
        },
        cast(r) {
            try {
                return e.cast(r)
            } catch {
                const i = e.getDefault();
                return Ze(i) && Ze(r) ? en(i, r) : r
            }
        },
        describe(r) {
            try {
                if (!r) return At(e.spec);
                const a = Xn(r, e);
                return a ? At(a) : {
                    required: !1,
                    exists: !1
                }
            } catch {
                return {
                    required: !1,
                    exists: !1
                }
            }
        }
    }
}

function At(e) {
    return {
        required: !e.optional,
        exists: !0
    }
}

function Xn(e, n) {
    if (!kt(n)) return null;
    if (Zt(e)) {
        const a = n.fields[Wn(e)];
        return (a == null ? void 0 : a.spec) || null
    }
    const t = (e || "").split(/\.|\[(\d+)\]/).filter(Boolean);
    let r = n;
    for (let a = 0; a < t.length; a++) {
        const i = t[a];
        if (kt(r) && i in r.fields ? r = r.fields[i] : Qn(r) && Pt(i) ? r = r.spec.types[Number(i)] : Pt(i) && Jn(r) && (r = r.innerType), a === t.length - 1) return r.spec
    }
    return null
}

function Qn(e) {
    return Ze(e) && e.type === "tuple"
}

function kt(e) {
    return Ze(e) && e.type === "object"
}

function Jn(e) {
    return Ze(e) && e.type === "array"
}

function Zn() {
    return {
        yup: Vn,
        toTypedSchema: Yn
    }
}
/**
 * vee-validate v4.12.5
 * (c) 2024 Abdelrahman Awad
 * @license MIT
 */
function Se(e) {
    return typeof e == "function"
}

function tn(e) {
    return e == null
}
const He = e => e !== null && !!e && typeof e == "object" && !Array.isArray(e);

function Ct(e) {
    return Number(e) >= 0
}

function er(e) {
    return typeof e == "object" && e !== null
}

function tr(e) {
    return e == null ? e === void 0 ? "[object Undefined]" : "[object Null]" : Object.prototype.toString.call(e)
}

function Rt(e) {
    if (!er(e) || tr(e) !== "[object Object]") return !1;
    if (Object.getPrototypeOf(e) === null) return !0;
    let n = e;
    for (; Object.getPrototypeOf(n) !== null;) n = Object.getPrototypeOf(n);
    return Object.getPrototypeOf(e) === n
}

function et(e, n) {
    return Object.keys(n).forEach(t => {
        if (Rt(n[t]) && Rt(e[t])) {
            e[t] || (e[t] = {}), et(e[t], n[t]);
            return
        }
        e[t] = n[t]
    }), e
}

function at(e) {
    const n = e.split(".");
    if (!n.length) return "";
    let t = String(n[0]);
    for (let r = 1; r < n.length; r++) {
        if (Ct(n[r])) {
            t += `[${n[r]}]`;
            continue
        }
        t += `.${n[r]}`
    }
    return t
}
const nr = {};

function rr(e) {
    return nr[e]
}

function jt(e, n, t) {
    typeof t.value == "object" && (t.value = U(t.value)), !t.enumerable || t.get || t.set || !t.configurable || !t.writable || n === "__proto__" ? Object.defineProperty(e, n, t) : e[n] = t.value
}

function U(e) {
    if (typeof e != "object") return e;
    var n = 0,
        t, r, a, i = Object.prototype.toString.call(e);
    if (i === "[object Object]" ? a = Object.create(e.__proto__ || null) : i === "[object Array]" ? a = Array(e.length) : i === "[object Set]" ? (a = new Set, e.forEach(function(l) {
            a.add(U(l))
        })) : i === "[object Map]" ? (a = new Map, e.forEach(function(l, f) {
            a.set(U(f), U(l))
        })) : i === "[object Date]" ? a = new Date(+e) : i === "[object RegExp]" ? a = new RegExp(e.source, e.flags) : i === "[object DataView]" ? a = new e.constructor(U(e.buffer)) : i === "[object ArrayBuffer]" ? a = e.slice(0) : i.slice(-6) === "Array]" && (a = new e.constructor(e)), a) {
        for (r = Object.getOwnPropertySymbols(e); n < r.length; n++) jt(a, r[n], Object.getOwnPropertyDescriptor(e, r[n]));
        for (n = 0, r = Object.getOwnPropertyNames(e); n < r.length; n++) Object.hasOwnProperty.call(a, t = r[n]) && a[t] === e[t] || jt(a, t, Object.getOwnPropertyDescriptor(e, t))
    }
    return a || e
}
const sr = Symbol("vee-validate-form"),
    or = typeof window < "u";

function ar(e) {
    return Se(e) && !!e.__locatorRef
}

function ke(e) {
    return !!e && Se(e.parse) && e.__type === "VVTypedSchema"
}

function nn(e) {
    return !!e && Se(e.validate)
}

function ir(e) {
    return e === "checkbox" || e === "radio"
}

function lr(e) {
    return He(e) || Array.isArray(e)
}

function ur(e) {
    return Array.isArray(e) ? e.length === 0 : He(e) && Object.keys(e).length === 0
}

function dt(e) {
    return /^\[.+\]$/i.test(e)
}

function cr(e) {
    return rn(e) && e.multiple
}

function rn(e) {
    return e.tagName === "SELECT"
}

function sn(e) {
    return Ot(e) && e.target && "submit" in e.target
}

function Ot(e) {
    return e ? !!(typeof Event < "u" && Se(Event) && e instanceof Event || e && e.srcElement) : !1
}

function Qe(e, n) {
    if (e === n) return !0;
    if (e && n && typeof e == "object" && typeof n == "object") {
        if (e.constructor !== n.constructor) return !1;
        var t, r, a;
        if (Array.isArray(e)) {
            if (t = e.length, t != n.length) return !1;
            for (r = t; r-- !== 0;)
                if (!Qe(e[r], n[r])) return !1;
            return !0
        }
        if (e instanceof Map && n instanceof Map) {
            if (e.size !== n.size) return !1;
            for (r of e.entries())
                if (!n.has(r[0])) return !1;
            for (r of e.entries())
                if (!Qe(r[1], n.get(r[0]))) return !1;
            return !0
        }
        if (Bt(e) && Bt(n)) return !(e.size !== n.size || e.name !== n.name || e.lastModified !== n.lastModified || e.type !== n.type);
        if (e instanceof Set && n instanceof Set) {
            if (e.size !== n.size) return !1;
            for (r of e.entries())
                if (!n.has(r[0])) return !1;
            return !0
        }
        if (ArrayBuffer.isView(e) && ArrayBuffer.isView(n)) {
            if (t = e.length, t != n.length) return !1;
            for (r = t; r-- !== 0;)
                if (e[r] !== n[r]) return !1;
            return !0
        }
        if (e.constructor === RegExp) return e.source === n.source && e.flags === n.flags;
        if (e.valueOf !== Object.prototype.valueOf) return e.valueOf() === n.valueOf();
        if (e.toString !== Object.prototype.toString) return e.toString() === n.toString();
        for (a = Object.keys(e), t = a.length, r = t; r-- !== 0;) {
            var i = a[r];
            if (!Qe(e[i], n[i])) return !1
        }
        return !0
    }
    return e !== e && n !== n
}

function Bt(e) {
    return or ? e instanceof File : !1
}

function Tt(e) {
    return dt(e) ? e.replace(/\[|\]/gi, "") : e
}

function Ee(e, n, t) {
    return e ? dt(n) ? e[Tt(n)] : (n || "").split(/\.|\[(\d+)\]/).filter(Boolean).reduce((a, i) => lr(a) && i in a ? a[i] : t, e) : t
}

function Ae(e, n, t) {
    if (dt(n)) {
        e[Tt(n)] = t;
        return
    }
    const r = n.split(/\.|\[(\d+)\]/).filter(Boolean);
    let a = e;
    for (let i = 0; i < r.length; i++) {
        if (i === r.length - 1) {
            a[r[i]] = t;
            return
        }(!(r[i] in a) || tn(a[r[i]])) && (a[r[i]] = Ct(r[i + 1]) ? [] : {}), a = a[r[i]]
    }
}

function yt(e, n) {
    if (Array.isArray(e) && Ct(n)) {
        e.splice(Number(n), 1);
        return
    }
    He(e) && delete e[n]
}

function Ft(e, n) {
    if (dt(n)) {
        delete e[Tt(n)];
        return
    }
    const t = n.split(/\.|\[(\d+)\]/).filter(Boolean);
    let r = e;
    for (let i = 0; i < t.length; i++) {
        if (i === t.length - 1) {
            yt(r, t[i]);
            break
        }
        if (!(t[i] in r) || tn(r[t[i]])) break;
        r = r[t[i]]
    }
    const a = t.map((i, l) => Ee(e, t.slice(0, l).join(".")));
    for (let i = a.length - 1; i >= 0; i--)
        if (ur(a[i])) {
            if (i === 0) {
                yt(e, t[0]);
                continue
            }
            yt(a[i - 1], t[i - 1])
        }
}

function _e(e) {
    return Object.keys(e)
}

function $t(e, n = 0) {
    let t = null,
        r = [];
    return function(...a) {
        return t && clearTimeout(t), t = setTimeout(() => {
            const i = e(...a);
            r.forEach(l => l(i)), r = []
        }, n), new Promise(i => r.push(i))
    }
}

function dr(e, n) {
    let t;
    return async function(...a) {
        const i = e(...a);
        t = i;
        const l = await i;
        return i !== t ? l : (t = void 0, n(l, a))
    }
}

function Dt(e) {
    return Array.isArray(e) ? e : e ? [e] : []
}

function it(e, n) {
    const t = {};
    for (const r in e) n.includes(r) || (t[r] = e[r]);
    return t
}

function fr(e) {
    let n = null,
        t = [];
    return function(...r) {
        const a = ie(() => {
            if (n !== a) return;
            const i = e(...r);
            t.forEach(l => l(i)), t = [], n = null
        });
        return n = a, new Promise(i => t.push(i))
    }
}

function vr(e, n, t) {
    return n.slots.default ? typeof e == "string" || !e ? n.slots.default(t()) : {
        default: () => {
            var r, a;
            return (a = (r = n.slots).default) === null || a === void 0 ? void 0 : a.call(r, t())
        }
    } : n.slots.default
}

function bt(e) {
    if (on(e)) return e._value
}

function on(e) {
    return "_value" in e
}

function pr(e) {
    return e.type === "number" || e.type === "range" ? Number.isNaN(e.valueAsNumber) ? e.value : e.valueAsNumber : e.value
}

function Nt(e) {
    if (!Ot(e)) return e;
    const n = e.target;
    if (ir(n.type) && on(n)) return bt(n);
    if (n.type === "file" && n.files) {
        const t = Array.from(n.files);
        return n.multiple ? t : t[0]
    }
    if (cr(n)) return Array.from(n.options).filter(t => t.selected && !t.disabled).map(bt);
    if (rn(n)) {
        const t = Array.from(n.options).find(r => r.selected);
        return t ? bt(t) : n.value
    }
    return pr(n)
}

function mr(e) {
    const n = {};
    return Object.defineProperty(n, "_$$isNormalized", {
        value: !0,
        writable: !1,
        enumerable: !1,
        configurable: !1
    }), e ? He(e) && e._$$isNormalized ? e : He(e) ? Object.keys(e).reduce((t, r) => {
        const a = hr(e[r]);
        return e[r] !== !1 && (t[r] = Ut(a)), t
    }, n) : typeof e != "string" ? n : e.split("|").reduce((t, r) => {
        const a = gr(r);
        return a.name && (t[a.name] = Ut(a.params)), t
    }, n) : n
}

function hr(e) {
    return e === !0 ? [] : Array.isArray(e) || He(e) ? e : [e]
}

function Ut(e) {
    const n = t => typeof t == "string" && t[0] === "@" ? yr(t.slice(1)) : t;
    return Array.isArray(e) ? e.map(n) : e instanceof RegExp ? [e] : Object.keys(e).reduce((t, r) => (t[r] = n(e[r]), t), {})
}
const gr = e => {
    let n = [];
    const t = e.split(":")[0];
    return e.includes(":") && (n = e.split(":").slice(1).join(":").split(",")), {
        name: t,
        params: n
    }
};

function yr(e) {
    const n = t => Ee(t, e) || t[e];
    return n.__locatorRef = e, n
}
const br = {
    generateMessage: ({
        field: e
    }) => `${e} is not valid.`,
    bails: !0,
    validateOnBlur: !0,
    validateOnChange: !0,
    validateOnInput: !1,
    validateOnModelUpdate: !0
};
let _r = Object.assign({}, br);
const Ye = () => _r;
async function wr(e, n, t = {}) {
    const r = t == null ? void 0 : t.bails,
        a = {
            name: (t == null ? void 0 : t.name) || "{field}",
            rules: n,
            label: t == null ? void 0 : t.label,
            bails: r ? ? !0,
            formData: (t == null ? void 0 : t.values) || {}
        },
        l = (await Sr(a, e)).errors;
    return {
        errors: l,
        valid: !l.length
    }
}
async function Sr(e, n) {
    if (ke(e.rules) || nn(e.rules)) return Or(n, e.rules);
    if (Se(e.rules) || Array.isArray(e.rules)) {
        const l = {
                field: e.label || e.name,
                name: e.name,
                label: e.label,
                form: e.formData,
                value: n
            },
            f = Array.isArray(e.rules) ? e.rules : [e.rules],
            d = f.length,
            v = [];
        for (let g = 0; g < d; g++) {
            const A = f[g],
                O = await A(n, l);
            if (!(typeof O != "string" && !Array.isArray(O) && O)) {
                if (Array.isArray(O)) v.push(...O);
                else {
                    const k = typeof O == "string" ? O : ln(l);
                    v.push(k)
                }
                if (e.bails) return {
                    errors: v
                }
            }
        }
        return {
            errors: v
        }
    }
    const t = Object.assign(Object.assign({}, e), {
            rules: mr(e.rules)
        }),
        r = [],
        a = Object.keys(t.rules),
        i = a.length;
    for (let l = 0; l < i; l++) {
        const f = a[l],
            d = await Tr(t, n, {
                name: f,
                params: t.rules[f]
            });
        if (d.error && (r.push(d.error), e.bails)) return {
            errors: r
        }
    }
    return {
        errors: r
    }
}

function Cr(e) {
    return !!e && e.name === "ValidationError"
}

function an(e) {
    return {
        __type: "VVTypedSchema",
        async parse(t) {
            var r;
            try {
                return {
                    output: await e.validate(t, {
                        abortEarly: !1
                    }),
                    errors: []
                }
            } catch (a) {
                if (!Cr(a)) throw a;
                if (!(!((r = a.inner) === null || r === void 0) && r.length) && a.errors.length) return {
                    errors: [{
                        path: a.path,
                        errors: a.errors
                    }]
                };
                const i = a.inner.reduce((l, f) => {
                    const d = f.path || "";
                    return l[d] || (l[d] = {
                        errors: [],
                        path: d
                    }), l[d].errors.push(...f.errors), l
                }, {});
                return {
                    errors: Object.values(i)
                }
            }
        }
    }
}
async function Or(e, n) {
    const r = await (ke(n) ? n : an(n)).parse(e),
        a = [];
    for (const i of r.errors) i.errors.length && a.push(...i.errors);
    return {
        errors: a
    }
}
async function Tr(e, n, t) {
    const r = rr(t.name);
    if (!r) throw new Error(`No such validator '${t.name}' exists.`);
    const a = Vr(t.params, e.formData),
        i = {
            field: e.label || e.name,
            name: e.name,
            label: e.label,
            value: n,
            form: e.formData,
            rule: Object.assign(Object.assign({}, t), {
                params: a
            })
        },
        l = await r(n, a, i);
    return typeof l == "string" ? {
        error: l
    } : {
        error: l ? void 0 : ln(i)
    }
}

function ln(e) {
    const n = Ye().generateMessage;
    return n ? n(e) : "Field is invalid"
}

function Vr(e, n) {
    const t = r => ar(r) ? r(n) : r;
    return Array.isArray(e) ? e.map(t) : Object.keys(e).reduce((r, a) => (r[a] = t(e[a]), r), {})
}
async function Er(e, n) {
    const r = await (ke(e) ? e : an(e)).parse(U(n)),
        a = {},
        i = {};
    for (const l of r.errors) {
        const f = l.errors,
            d = (l.path || "").replace(/\["(\d+)"\]/g, (v, g) => `[${g}]`);
        a[d] = {
            valid: !f.length,
            errors: f
        }, f.length && (i[d] = f[0])
    }
    return {
        valid: !r.errors.length,
        results: a,
        errors: i,
        values: r.value
    }
}
async function Pr(e, n, t) {
    const a = _e(e).map(async v => {
        var g, A, O;
        const P = (g = t == null ? void 0 : t.names) === null || g === void 0 ? void 0 : g[v],
            k = await wr(Ee(n, v), e[v], {
                name: (P == null ? void 0 : P.name) || v,
                label: P == null ? void 0 : P.label,
                values: n,
                bails: (O = (A = t == null ? void 0 : t.bailsMap) === null || A === void 0 ? void 0 : A[v]) !== null && O !== void 0 ? O : !0
            });
        return Object.assign(Object.assign({}, k), {
            path: v
        })
    });
    let i = !0;
    const l = await Promise.all(a),
        f = {},
        d = {};
    for (const v of l) f[v.path] = {
        valid: v.valid,
        errors: v.errors
    }, v.valid || (i = !1, d[v.path] = v.errors[0]);
    return {
        valid: i,
        results: f,
        errors: d
    }
}
let Ir = 0;
const lt = ["bails", "fieldsCount", "id", "multiple", "type", "validate"];

function un(e) {
    const n = Object.assign({}, ae((e == null ? void 0 : e.initialValues) || {})),
        t = c(e == null ? void 0 : e.validationSchema);
    return t && ke(t) && Se(t.cast) ? U(t.cast(n) || {}) : U(n)
}

function cn(e) {
    var n;
    const t = Ir++;
    let r = 0;
    const a = L(!1),
        i = L(!1),
        l = L(0),
        f = [],
        d = _t(un(e)),
        v = L([]),
        g = L({}),
        A = L({}),
        O = fr(() => {
            A.value = v.value.reduce((o, s) => (o[at(ae(s.path))] = s, o), {})
        });

    function P(o, s) {
        const u = V(o);
        if (!u) {
            typeof o == "string" && (g.value[at(o)] = Dt(s));
            return
        }
        if (typeof o == "string") {
            const m = at(o);
            g.value[m] && delete g.value[m]
        }
        u.errors = Dt(s), u.valid = !u.errors.length
    }

    function k(o) {
        _e(o).forEach(s => {
            P(s, o[s])
        })
    }
    e != null && e.initialErrors && k(e.initialErrors);
    const B = S(() => {
            const o = v.value.reduce((s, u) => (u.errors.length && (s[u.path] = u.errors), s), {});
            return Object.assign(Object.assign({}, g.value), o)
        }),
        C = S(() => _e(B.value).reduce((o, s) => {
            const u = B.value[s];
            return u != null && u.length && (o[s] = u[0]), o
        }, {})),
        $ = S(() => v.value.reduce((o, s) => (o[s.path] = {
            name: s.path || "",
            label: s.label || ""
        }, o), {})),
        G = S(() => v.value.reduce((o, s) => {
            var u;
            return o[s.path] = (u = s.bails) !== null && u !== void 0 ? u : !0, o
        }, {})),
        z = Object.assign({}, (e == null ? void 0 : e.initialErrors) || {}),
        h = (n = e == null ? void 0 : e.keepValuesOnUnmount) !== null && n !== void 0 ? n : !1,
        {
            initialValues: R,
            originalInitialValues: j,
            setInitialValues: Y
        } = kr(v, d, e),
        te = Ar(v, d, j, C),
        J = S(() => v.value.reduce((o, s) => {
            const u = Ee(d, s.path);
            return Ae(o, s.path, u), o
        }, {})),
        x = e == null ? void 0 : e.validationSchema;

    function w(o, s) {
        var u, m;
        const _ = S(() => Ee(R.value, ae(o))),
            b = A.value[ae(o)],
            F = (s == null ? void 0 : s.type) === "checkbox" || (s == null ? void 0 : s.type) === "radio";
        if (b && F) {
            b.multiple = !0;
            const be = r++;
            return Array.isArray(b.id) ? b.id.push(be) : b.id = [b.id, be], b.fieldsCount++, b.__flags.pendingUnmount[be] = !1, b
        }
        const ne = S(() => Ee(d, ae(o))),
            K = ae(o),
            oe = y.findIndex(be => be === K);
        oe !== -1 && y.splice(oe, 1);
        const M = S(() => {
                var be, Ke, vt, Vt, pt, mt;
                return ke(x) ? (vt = (Ke = (be = x).describe) === null || Ke === void 0 ? void 0 : Ke.call(be, ae(o)).required) !== null && vt !== void 0 ? vt : !1 : ke(s == null ? void 0 : s.schema) && (mt = (pt = (Vt = s == null ? void 0 : s.schema).describe) === null || pt === void 0 ? void 0 : pt.call(Vt).required) !== null && mt !== void 0 ? mt : !1
            }),
            re = r++,
            fe = _t({
                id: re,
                path: o,
                touched: !1,
                pending: !1,
                valid: !0,
                validated: !!(!((u = z[K]) === null || u === void 0) && u.length),
                required: M,
                initialValue: _,
                errors: gn([]),
                bails: (m = s == null ? void 0 : s.bails) !== null && m !== void 0 ? m : !1,
                label: s == null ? void 0 : s.label,
                type: (s == null ? void 0 : s.type) || "default",
                value: ne,
                multiple: !1,
                __flags: {
                    pendingUnmount: {
                        [re]: !1
                    },
                    pendingReset: !1
                },
                fieldsCount: 1,
                validate: s == null ? void 0 : s.validate,
                dirty: S(() => !Qe(c(ne), c(_)))
            });
        return v.value.push(fe), A.value[K] = fe, O(), C.value[K] && !z[K] && ie(() => {
            Te(K, {
                mode: "silent"
            })
        }), Je(o) && ye(o, be => {
            O();
            const Ke = U(ne.value);
            A.value[be] = fe, ie(() => {
                Ae(d, be, Ke)
            })
        }), fe
    }
    const T = $t(p, 5),
        D = $t(p, 5),
        N = dr(async o => await (o === "silent" ? T() : D()), (o, [s]) => {
            const u = _e(ue.errorBag.value),
                _ = [...new Set([..._e(o.results), ...v.value.map(b => b.path), ...u])].sort().reduce((b, F) => {
                    var ne;
                    const K = F,
                        oe = V(K) || W(K),
                        M = ((ne = o.results[K]) === null || ne === void 0 ? void 0 : ne.errors) || [],
                        re = ae(oe == null ? void 0 : oe.path) || K,
                        fe = Rr({
                            errors: M,
                            valid: !M.length
                        }, b.results[re]);
                    return b.results[re] = fe, fe.valid || (b.errors[re] = fe.errors[0]), oe && g.value[re] && delete g.value[re], oe ? (oe.valid = fe.valid, s === "silent" || s === "validated-only" && !oe.validated || P(oe, fe.errors), b) : (P(re, M), b)
                }, {
                    valid: o.valid,
                    results: {},
                    errors: {}
                });
            return o.values && (_.values = o.values), _
        });

    function X(o) {
        v.value.forEach(o)
    }

    function V(o) {
        const s = typeof o == "string" ? at(o) : o;
        return typeof s == "string" ? A.value[s] : s
    }

    function W(o) {
        return v.value.filter(u => o.startsWith(u.path)).reduce((u, m) => u ? m.path.length > u.path.length ? m : u : m, void 0)
    }
    let y = [],
        I;

    function q(o) {
        return y.push(o), I || (I = ie(() => {
            [...y].sort().reverse().forEach(u => {
                Ft(d, u)
            }), y = [], I = null
        })), I
    }

    function Fe(o) {
        return function(u, m) {
            return function(b) {
                return b instanceof Event && (b.preventDefault(), b.stopPropagation()), X(F => F.touched = !0), a.value = !0, l.value++, Oe().then(F => {
                    const ne = U(d);
                    if (F.valid && typeof u == "function") {
                        const K = U(J.value);
                        let oe = o ? K : ne;
                        return F.values && (oe = F.values), u(oe, {
                            evt: b,
                            controlledValues: K,
                            setErrors: k,
                            setFieldError: P,
                            setTouched: Ie,
                            setFieldTouched: me,
                            setValues: Ce,
                            setFieldValue: pe,
                            resetForm: ce,
                            resetField: st
                        })
                    }!F.valid && typeof m == "function" && m({
                        values: ne,
                        evt: b,
                        errors: F.errors,
                        results: F.results
                    })
                }).then(F => (a.value = !1, F), F => {
                    throw a.value = !1, F
                })
            }
        }
    }
    const he = Fe(!1);
    he.withControlled = Fe(!0);

    function $e(o, s) {
        const u = v.value.findIndex(_ => _.path === o && (Array.isArray(_.id) ? _.id.includes(s) : _.id === s)),
            m = v.value[u];
        if (!(u === -1 || !m)) {
            if (ie(() => {
                    Te(o, {
                        mode: "silent",
                        warn: !1
                    })
                }), m.multiple && m.fieldsCount && m.fieldsCount--, Array.isArray(m.id)) {
                const _ = m.id.indexOf(s);
                _ >= 0 && m.id.splice(_, 1), delete m.__flags.pendingUnmount[s]
            }(!m.multiple || m.fieldsCount <= 0) && (v.value.splice(u, 1), ot(o), O(), delete A.value[o])
        }
    }

    function De(o) {
        _e(A.value).forEach(s => {
            s.startsWith(o) && delete A.value[s]
        }), v.value = v.value.filter(s => !s.path.startsWith(o)), ie(() => {
            O()
        })
    }
    const ue = {
        formId: t,
        values: d,
        controlledValues: J,
        errorBag: B,
        errors: C,
        schema: x,
        submitCount: l,
        meta: te,
        isSubmitting: a,
        isValidating: i,
        fieldArrays: f,
        keepValuesOnUnmount: h,
        validateSchema: c(x) ? N : void 0,
        validate: Oe,
        setFieldError: P,
        validateField: Te,
        setFieldValue: pe,
        setValues: Ce,
        setErrors: k,
        setFieldTouched: me,
        setTouched: Ie,
        resetForm: ce,
        resetField: st,
        handleSubmit: he,
        useFieldModel: de,
        defineInputBinds: Me,
        defineComponentBinds: xe,
        defineField: Q,
        stageInitialValue: ft,
        unsetInitialValue: ot,
        setFieldInitialValue: Le,
        createPathState: w,
        getPathState: V,
        unsetPathValue: q,
        removePathState: $e,
        initialValues: R,
        getAllPathStates: () => v.value,
        destroyPath: De,
        isFieldTouched: Ue,
        isFieldDirty: rt,
        isFieldValid: Ge
    };

    function pe(o, s, u = !0) {
        const m = U(s),
            _ = typeof o == "string" ? o : o.path;
        V(_) || w(_), Ae(d, _, m), u && Te(_)
    }

    function Pe(o, s = !0) {
        _e(d).forEach(u => {
            delete d[u]
        }), _e(o).forEach(u => {
            pe(u, o[u], !1)
        }), s && Oe()
    }

    function Ce(o, s = !0) {
        et(d, o), f.forEach(u => u && u.reset()), s && Oe()
    }

    function ge(o, s) {
        const u = V(ae(o)) || w(o);
        return S({
            get() {
                return u.value
            },
            set(m) {
                var _;
                const b = ae(o);
                pe(b, m, (_ = ae(s)) !== null && _ !== void 0 ? _ : !1)
            }
        })
    }

    function me(o, s) {
        const u = V(o);
        u && (u.touched = s)
    }

    function Ue(o) {
        const s = V(o);
        return s ? s.touched : v.value.filter(u => u.path.startsWith(o)).some(u => u.touched)
    }

    function rt(o) {
        const s = V(o);
        return s ? s.dirty : v.value.filter(u => u.path.startsWith(o)).some(u => u.dirty)
    }

    function Ge(o) {
        const s = V(o);
        return s ? s.valid : v.value.filter(u => u.path.startsWith(o)).every(u => u.valid)
    }

    function Ie(o) {
        if (typeof o == "boolean") {
            X(s => {
                s.touched = o
            });
            return
        }
        _e(o).forEach(s => {
            me(s, !!o[s])
        })
    }

    function st(o, s) {
        var u;
        const m = s && "value" in s ? s.value : Ee(R.value, o),
            _ = V(o);
        _ && (_.__flags.pendingReset = !0), Le(o, U(m), !0), pe(o, m, !1), me(o, (u = s == null ? void 0 : s.touched) !== null && u !== void 0 ? u : !1), P(o, (s == null ? void 0 : s.errors) || []), ie(() => {
            _ && (_.__flags.pendingReset = !1)
        })
    }

    function ce(o, s) {
        let u = U(o != null && o.values ? o.values : j.value);
        u = s != null && s.force ? u : et(j.value, u), u = ke(x) && Se(x.cast) ? x.cast(u) : u, Y(u), X(m => {
            var _;
            m.__flags.pendingReset = !0, m.validated = !1, m.touched = ((_ = o == null ? void 0 : o.touched) === null || _ === void 0 ? void 0 : _[m.path]) || !1, pe(m.path, Ee(u, m.path), !1), P(m.path, void 0)
        }), s != null && s.force ? Pe(u, !1) : Ce(u, !1), k((o == null ? void 0 : o.errors) || {}), l.value = (o == null ? void 0 : o.submitCount) || 0, ie(() => {
            Oe({
                mode: "silent"
            }), X(m => {
                m.__flags.pendingReset = !1
            })
        })
    }
    async function Oe(o) {
        const s = (o == null ? void 0 : o.mode) || "force";
        if (s === "force" && X(b => b.validated = !0), ue.validateSchema) return ue.validateSchema(s);
        i.value = !0;
        const u = await Promise.all(v.value.map(b => b.validate ? b.validate(o).then(F => ({
            key: b.path,
            valid: F.valid,
            errors: F.errors
        })) : Promise.resolve({
            key: b.path,
            valid: !0,
            errors: []
        })));
        i.value = !1;
        const m = {},
            _ = {};
        for (const b of u) m[b.key] = {
            valid: b.valid,
            errors: b.errors
        }, b.errors.length && (_[b.key] = b.errors[0]);
        return {
            valid: u.every(b => b.valid),
            results: m,
            errors: _
        }
    }
    async function Te(o, s) {
        var u;
        const m = V(o);
        if (m && (s == null ? void 0 : s.mode) !== "silent" && (m.validated = !0), x) {
            const {
                results: _
            } = await N((s == null ? void 0 : s.mode) || "validated-only");
            return _[o] || {
                errors: [],
                valid: !0
            }
        }
        return m != null && m.validate ? m.validate(s) : (!m && (u = s == null ? void 0 : s.warn), Promise.resolve({
            errors: [],
            valid: !0
        }))
    }

    function ot(o) {
        Ft(R.value, o)
    }

    function ft(o, s, u = !1) {
        Le(o, s), Ae(d, o, s), u && !(e != null && e.initialValues) && Ae(j.value, o, U(s))
    }

    function Le(o, s, u = !1) {
        Ae(R.value, o, U(s)), u && Ae(j.value, o, U(s))
    }
    async function p() {
        const o = c(x);
        if (!o) return {
            valid: !0,
            results: {},
            errors: {}
        };
        i.value = !0;
        const s = nn(o) || ke(o) ? await Er(o, d) : await Pr(o, d, {
            names: $.value,
            bailsMap: G.value
        });
        return i.value = !1, s
    }
    const E = he((o, {
        evt: s
    }) => {
        sn(s) && s.target.submit()
    });
    tt(() => {
        if (e != null && e.initialErrors && k(e.initialErrors), e != null && e.initialTouched && Ie(e.initialTouched), e != null && e.validateOnMount) {
            Oe();
            return
        }
        ue.validateSchema && ue.validateSchema("silent")
    }), Je(x) && ye(x, () => {
        var o;
        (o = ue.validateSchema) === null || o === void 0 || o.call(ue, "validated-only")
    }), yn(sr, ue);

    function Q(o, s) {
        const u = Se(s) || s == null ? void 0 : s.label,
            m = V(ae(o)) || w(o, {
                label: u
            }),
            _ = () => Se(s) ? s(it(m, lt)) : s || {};

        function b() {
            var M;
            m.touched = !0, ((M = _().validateOnBlur) !== null && M !== void 0 ? M : Ye().validateOnBlur) && Te(m.path)
        }

        function F() {
            var M;
            ((M = _().validateOnInput) !== null && M !== void 0 ? M : Ye().validateOnInput) && ie(() => {
                Te(m.path)
            })
        }

        function ne() {
            var M;
            ((M = _().validateOnChange) !== null && M !== void 0 ? M : Ye().validateOnChange) && ie(() => {
                Te(m.path)
            })
        }
        const K = S(() => {
            const M = {
                onChange: ne,
                onInput: F,
                onBlur: b
            };
            return Se(s) ? Object.assign(Object.assign({}, M), s(it(m, lt)).props || {}) : s != null && s.props ? Object.assign(Object.assign({}, M), s.props(it(m, lt))) : M
        });
        return [ge(o, () => {
            var M, re, fe;
            return (fe = (M = _().validateOnModelUpdate) !== null && M !== void 0 ? M : (re = Ye()) === null || re === void 0 ? void 0 : re.validateOnModelUpdate) !== null && fe !== void 0 ? fe : !0
        }), K]
    }

    function de(o) {
        return Array.isArray(o) ? o.map(s => ge(s, !0)) : ge(o)
    }

    function Me(o, s) {
        const [u, m] = Q(o, s);

        function _() {
            m.value.onBlur()
        }

        function b(ne) {
            const K = Nt(ne);
            pe(ae(o), K, !1), m.value.onInput()
        }

        function F(ne) {
            const K = Nt(ne);
            pe(ae(o), K, !1), m.value.onChange()
        }
        return S(() => Object.assign(Object.assign({}, m.value), {
            onBlur: _,
            onInput: b,
            onChange: F,
            value: u.value
        }))
    }

    function xe(o, s) {
        const [u, m] = Q(o, s), _ = V(ae(o));

        function b(F) {
            u.value = F
        }
        return S(() => {
            const F = Se(s) ? s(it(_, lt)) : s || {};
            return Object.assign({
                [F.model || "modelValue"]: u.value,
                [`onUpdate:${F.model||"modelValue"}`]: b
            }, m.value)
        })
    }
    return Object.assign(Object.assign({}, ue), {
        values: vn(d),
        handleReset: () => ce(),
        submitForm: E
    })
}

function Ar(e, n, t, r) {
    const a = {
            touched: "some",
            pending: "some",
            valid: "every"
        },
        i = S(() => !Qe(n, c(t)));

    function l() {
        const d = e.value;
        return _e(a).reduce((v, g) => {
            const A = a[g];
            return v[g] = d[A](O => O[g]), v
        }, {})
    }
    const f = _t(l());
    return hn(() => {
        const d = l();
        f.touched = d.touched, f.valid = d.valid, f.pending = d.pending
    }), S(() => Object.assign(Object.assign({
        initialValues: c(t)
    }, f), {
        valid: f.valid && !_e(r.value).length,
        dirty: i.value
    }))
}

function kr(e, n, t) {
    const r = un(t),
        a = L(r),
        i = L(U(r));

    function l(f, d = !1) {
        a.value = et(U(a.value) || {}, U(f)), i.value = et(U(i.value) || {}, U(f)), d && e.value.forEach(v => {
            if (v.touched) return;
            const A = Ee(a.value, v.path);
            Ae(n, v.path, U(A))
        })
    }
    return {
        initialValues: a,
        originalInitialValues: i,
        setInitialValues: l
    }
}

function Rr(e, n) {
    return n ? {
        valid: e.valid && n.valid,
        errors: [...e.errors, ...n.errors]
    } : e
}
const jr = Be({
        name: "Form",
        inheritAttrs: !1,
        props: {
            as: {
                type: null,
                default: "form"
            },
            validationSchema: {
                type: Object,
                default: void 0
            },
            initialValues: {
                type: Object,
                default: void 0
            },
            initialErrors: {
                type: Object,
                default: void 0
            },
            initialTouched: {
                type: Object,
                default: void 0
            },
            validateOnMount: {
                type: Boolean,
                default: !1
            },
            onSubmit: {
                type: Function,
                default: void 0
            },
            onInvalidSubmit: {
                type: Function,
                default: void 0
            },
            keepValues: {
                type: Boolean,
                default: !1
            }
        },
        setup(e, n) {
            const t = Et(e, "validationSchema"),
                r = Et(e, "keepValues"),
                {
                    errors: a,
                    errorBag: i,
                    values: l,
                    meta: f,
                    isSubmitting: d,
                    isValidating: v,
                    submitCount: g,
                    controlledValues: A,
                    validate: O,
                    validateField: P,
                    handleReset: k,
                    resetForm: B,
                    handleSubmit: C,
                    setErrors: $,
                    setFieldError: G,
                    setFieldValue: z,
                    setValues: h,
                    setFieldTouched: R,
                    setTouched: j,
                    resetField: Y
                } = cn({
                    validationSchema: t.value ? t : void 0,
                    initialValues: e.initialValues,
                    initialErrors: e.initialErrors,
                    initialTouched: e.initialTouched,
                    validateOnMount: e.validateOnMount,
                    keepValuesOnUnmount: r
                }),
                te = C((V, {
                    evt: W
                }) => {
                    sn(W) && W.target.submit()
                }, e.onInvalidSubmit),
                J = e.onSubmit ? C(e.onSubmit, e.onInvalidSubmit) : te;

            function x(V) {
                Ot(V) && V.preventDefault(), k(), typeof n.attrs.onReset == "function" && n.attrs.onReset()
            }

            function w(V, W) {
                return C(typeof V == "function" && !W ? V : W, e.onInvalidSubmit)(V)
            }

            function T() {
                return U(l)
            }

            function D() {
                return U(f.value)
            }

            function N() {
                return U(a.value)
            }

            function X() {
                return {
                    meta: f.value,
                    errors: a.value,
                    errorBag: i.value,
                    values: l,
                    isSubmitting: d.value,
                    isValidating: v.value,
                    submitCount: g.value,
                    controlledValues: A.value,
                    validate: O,
                    validateField: P,
                    handleSubmit: w,
                    handleReset: k,
                    submitForm: te,
                    setErrors: $,
                    setFieldError: G,
                    setFieldValue: z,
                    setValues: h,
                    setFieldTouched: R,
                    setTouched: j,
                    resetForm: B,
                    resetField: Y,
                    getValues: T,
                    getMeta: D,
                    getErrors: N
                }
            }
            return n.expose({
                    setFieldError: G,
                    setErrors: $,
                    setFieldValue: z,
                    setValues: h,
                    setFieldTouched: R,
                    setTouched: j,
                    resetForm: B,
                    validate: O,
                    validateField: P,
                    resetField: Y,
                    getValues: T,
                    getMeta: D,
                    getErrors: N,
                    values: l,
                    meta: f,
                    errors: a
                }),
                function() {
                    const W = e.as === "form" ? e.as : e.as ? pn(e.as) : null,
                        y = vr(W, n, X);
                    return W ? mn(W, Object.assign(Object.assign(Object.assign({}, W === "form" ? {
                        novalidate: !0
                    } : {}), n.attrs), {
                        onSubmit: J,
                        onReset: x
                    }), y) : y
                }
        }
    }),
    Br = jr,
    Fr = e => {
        (e.key === " " || e.code === "Space") && e.preventDefault()
    },
    $r = {
        key: 0,
        class: "phone-error"
    },
    Dr = {
        key: 1,
        class: "v-text-field"
    },
    Nr = {
        class: "v-input__details"
    },
    Ur = {
        class: "v-messages__message",
        role: "alert"
    },
    Lr = Be({
        __name: "PhoneAndEmailForms",
        props: {
            requiresTooltipDisabled: {
                type: Boolean
            },
            hideTabs: {
                type: Boolean
            },
            hidePassword: {
                type: Boolean
            },
            forceTabType: {},
            type: {}
        },
        emits: ["get-submit-handler", "get-reset-handler", "submit:disabled-btn", "check-email:loading", "change-tab"],
        setup(e, {
            emit: n
        }) {
            const t = _n(() => Pn(() =>
                    import ("./CzJexDrZ.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7]),
                    import.meta.url)),
                r = e,
                a = n,
                {
                    t: i
                } = nt(),
                {
                    yup: l,
                    toTypedSchema: f
                } = Zn(),
                d = bn(),
                v = ht("email-field"),
                g = ht("phone-field"),
                A = ht("password-field"),
                {
                    isHasUpdatedPassword: O
                } = Re(En()),
                P = S(() => {
                    if (r.requiresTooltipDisabled) return !1;
                    const p = localStorage.getItem("hasNewPasswordRules");
                    return r.type === "registration" && !!(p && p === "1")
                }),
                k = S(() => {
                    const p = localStorage.getItem("hasNewPasswordRules");
                    return r.type === "login" || p && p === "0"
                }),
                {
                    updateRegistrationForm: B,
                    updateAuthForm: C,
                    updateResetPwdForm: $,
                    onCheckEmail: G
                } = je(),
                {
                    debouncedValidateEmailOnClientOrServer: z,
                    isEmailLoading: h
                } = $n(G),
                {
                    smsCountriesIsAvailable: R
                } = zt(),
                {
                    userGeo: j
                } = Re(Wt()),
                {
                    trackButtonClick: Y
                } = Gt(),
                te = S(() => R),
                J = S(() => r.type === "reset-pwd"),
                x = S(() => J.value ? te.value : Dn),
                w = S(() => St.DEFAULT_PHONE_COUNTRY_CODES[j.value] || "IN"),
                T = L("email"),
                D = L(!1),
                N = L(!1),
                X = L(!1),
                V = L(!1),
                W = p => X.value = p,
                y = p => p !== void 0 && !V.value,
                I = l.string().required(i("validations.emailIsRequired")).test("is-valid-email", i("validations.invalidEmail"), async p => !!p && await z(p) || !1).typeError(i("validations.invalidEmail")).label("E-mail"),
                q = l.string().required(i("validations.phoneIsRequired")).test("is-valid-phone", i("labels.phoneValidation"), y).label("Phone"),
                Fe = l.string().min(6, i("validations.pwdRules")).required(i("validations.pwdRules")).typeError(i("validations.pwdRules")),
                We = l.string().required(i("validations.pwdRules")).test("password-with-custom-rules", () => X.value),
                he = S(() => P.value && O.value > 0 ? We : Fe),
                $e = S(() => V.value ? i("labels.phoneValidation") : Ie.value.errorMessages[0]),
                De = S(() => r.forceTabType && r.hideTabs && r.hidePassword ? T.value === "email" ? f(l.object({
                    email: I
                })) : f(l.object({
                    phone: q
                })) : r.forceTabType === "phone" && r.hideTabs ? f(l.object({
                    phone: q,
                    password: he.value
                })) : r.forceTabType === "email" && r.hideTabs ? f(l.object({
                    email: I,
                    password: he.value
                })) : r.hideTabs ? f(l.object({
                    email: I,
                    password: he.value,
                    phone: q
                })) : T.value === "email" ? f(l.object({
                    email: I,
                    password: he.value
                })) : f(l.object({
                    password: he.value,
                    phone: q
                }))),
                {
                    handleSubmit: ue,
                    resetForm: pe,
                    defineField: Pe
                } = cn({
                    validationSchema: De
                }),
                Ce = p => {
                    var E;
                    return {
                        props: {
                            errorMessages: p.errors,
                            messagesState: p,
                            hideDetails: !p.validated && p.value === void 0 || !((E = p.errors) != null && E.length)
                        }
                    }
                },
                [ge, me] = Pe("email", Ce),
                [Ue, rt] = Pe("password", Ce),
                [Ge, Ie] = Pe("phone", Ce),
                st = S(() => {
                    var p, E, Q;
                    return !((p = me.value) != null && p.hideDetails) || !((E = rt.value) != null && E.hideDetails) || !((Q = Ie.value) != null && Q.hideDetails)
                }),
                ce = (p, E) => {
                    const Q = {
                        key: p,
                        value: E
                    };
                    J.value ? $(Q) : r.type === "registration" ? B(Q) : C(Q)
                },
                Oe = p => {
                    if (T.value = p, r.type === "login") {
                        const E = {
                            email: "email",
                            phone: "phone"
                        };
                        E[p] && Y({
                            category: "login_popup",
                            action: "switch_tab",
                            label: E[p]
                        })
                    }
                    p === "phone" ? (a("check-email:loading", !1), ce("username", void 0)) : p === "email" && (ce("phone_user", void 0), ce("phone_iso", void 0), ce("phone_code", void 0), ce("username", ge.value)), a("change-tab", p), a("submit:disabled-btn", !1), Te()
                },
                Te = () => {
                    ie(() => {
                        var E, Q, de;
                        [
                            [(E = v.value) == null ? void 0 : E.$el, "enterEmail"],
                            [(Q = g.value) == null ? void 0 : Q.$el, "enterPhone"],
                            [(de = A.value) == null ? void 0 : de.$el, "enterPassword"]
                        ].forEach(([Me, xe]) => {
                            Me && Mn(Me, xe)
                        })
                    })
                };
            ye(() => st.value, p => {
                a("submit:disabled-btn", p)
            }), ye(h, p => {
                a("check-email:loading", p)
            }), tt(() => {
                r.forceTabType ? T.value !== r.forceTabType && Oe(r.forceTabType) : Oe(T.value), a("get-submit-handler", ue), a("get-reset-handler", pe), Te()
            });
            const ot = (p, E) => {
                    if (!p) return;
                    let Q = !0;
                    if ((E == null ? void 0 : E.countryCode) === "IN") {
                        const Me = ["6", "7", "8", "9"];
                        Q = (p == null ? void 0 : p.length) === 10 && Me.some(xe => p == null ? void 0 : p.startsWith(xe))
                    }
                    if (V.value = !!E.formatted && (!Q || !E.valid), V.value && a("submit:disabled-btn", !0), N.value = !!E.formatted, Ge.value === E.nationalNumber) return;
                    const de = p.startsWith("0") ? p : E.nationalNumber;
                    Ge.value = de, ce("phone_user", de)
                },
                ft = p => {
                    ce("phone_iso", p.iso2), ce("phone_code", `+${p.dialCode}`)
                },
                Le = p => {
                    Fr(p)
                };
            return (p, E) => {
                const Q = Fn;
                return H(), ve("div", {
                    class: qe(["container__forms", {
                        ["display-" + p.type]: p.type
                    }])
                }, [Z(c(Br), {
                    "validation-schema": c(De)
                }, {
                    default: se(() => [p.hideTabs ? le("", !0) : (H(), Ve(c(t), {
                        key: 0,
                        "selected-btn": c(T),
                        onChangeTab: Oe
                    }, null, 8, ["selected-btn"])), Z(wt, null, {
                        default: se(() => [c(T) === "email" || p.hideTabs && !p.forceTabType ? (H(), Ve(Xe, {
                            key: 0,
                            cols: "12",
                            class: "email-field"
                        }, {
                            default: se(() => [Z(qn, ct({
                                ref: "email-field",
                                id: "auth__login-" + c(d),
                                modelValue: c(ge),
                                "onUpdate:modelValue": E[0] || (E[0] = de => Je(ge) ? ge.value = de : null),
                                class: "auth__login"
                            }, c(me), {
                                "hide-details": c(J) ? !1 : "auto",
                                placeholder: c(J) ? "" : c(i)("labels.email"),
                                label: c(J) ? c(i)("labels.enterEmail") : "",
                                "append-inner-icon": c(J) ? "mdi-pencil-outline" : "",
                                color: "#3486e3",
                                type: "email",
                                variant: "outlined",
                                autocomplete: "off",
                                density: "compact",
                                onInput: E[1] || (E[1] = de => ce("username", c(ge))),
                                onKeydown: Le
                            }), null, 16, ["id", "modelValue", "hide-details", "placeholder", "label", "append-inner-icon"])]),
                            _: 1
                        })) : le("", !0), c(T) === "phone" || p.hideTabs && !p.forceTabType ? (H(), Ve(Xe, {
                            key: 1,
                            cols: "12",
                            class: qe(["phone-field", {
                                "pt-0": p.hideTabs,
                                "only-phone-displayed": p.hideTabs && p.forceTabType
                            }])
                        }, {
                            default: se(() => [ee("div", {
                                class: qe(["phone-field__label", {
                                    "opacity-100": c(N),
                                    withPt: p.hideTabs && p.forceTabType || !p.hideTabs,
                                    "v-messages__message": c(V)
                                }])
                            }, we(c(i)("labels.phoneNumber")), 3), Z(c(Nn), ct({
                                ref: "phone-field"
                            }, c(Ie), {
                                id: "profile_phone_input-" + c(d),
                                value: c(Ge),
                                "default-country": c(w),
                                "only-countries": c(x),
                                "all-countries": c(Un),
                                dark: "",
                                class: {
                                    "not-empty-field": c(N), "reset-pwd-height": c(J)
                                },
                                "valid-characters-only": "",
                                "auto-format": !1,
                                mode: "international",
                                "dropdown-options": {
                                    showDialCodeInSelection: !0,
                                    showDialCodeInList: !1,
                                    showFlags: !0
                                },
                                "input-options": {
                                    placeholder: c(i)("labels.phoneNumber"),
                                    showDialCode: !1,
                                    type: "tel"
                                },
                                onOnInput: ot,
                                onCountryChanged: ft
                            }), null, 16, ["id", "value", "default-country", "only-countries", "all-countries", "class", "input-options"]), c(J) ? (H(), ve("div", $r, we(c($e)), 1)) : !c(Ie).hideDetails || c(V) ? (H(), ve("div", Dr, [ee("div", Nr, [ee("div", Ur, we(c($e)), 1)])])) : le("", !0)]),
                            _: 1
                        }, 8, ["class"])) : le("", !0), p.hidePassword ? le("", !0) : (H(), Ve(Xe, {
                            key: 2,
                            cols: "12",
                            class: "password-field pt-0"
                        }, {
                            default: se(() => [Z(Q, ct({
                                ref: "password-field",
                                id: "auth__password-" + c(d),
                                modelValue: c(Ue),
                                "onUpdate:modelValue": E[2] || (E[2] = de => Je(Ue) ? Ue.value = de : null)
                            }, c(rt), {
                                class: "auth__password",
                                "requires-tooltip": c(P),
                                placeholder: c(i)("placeholders.password"),
                                type: c(D) ? "text" : "password",
                                variant: "outlined",
                                autocomplete: "off",
                                "skip-required-valid": c(k),
                                density: "compact",
                                "onClick:append": E[3] || (E[3] = de => D.value = !c(D)),
                                onInput: E[4] || (E[4] = de => ce("password", c(Ue))),
                                "onValidate:customRules": W,
                                onKeydown: Le
                            }), null, 16, ["id", "modelValue", "requires-tooltip", "placeholder", "type", "skip-required-valid"])]),
                            _: 1
                        }))]),
                        _: 1
                    })]),
                    _: 1
                }, 8, ["validation-schema"])], 2)
            }
        }
    }),
    Mr = ze(Lr, [
        ["__scopeId", "data-v-fa11d6df"]
    ]),
    qr = {
        class: "action__wrapper"
    },
    Hr = Be({
        __name: "GoogleLoginButton",
        props: {
            text: {},
            ssoType: {},
            ssoWidth: {}
        },
        emits: ["registration-submit"],
        setup(e, {
            emit: n
        }) {
            const t = e,
                {
                    googleSsoReInit: r,
                    googleSsoPromptDisplay: a
                } = Qt(t.ssoType),
                i = n;

            function l() {
                t.ssoType === "signup" && i("registration-submit", !1), a()
            }
            return tt(() => {
                r(t.ssoWidth ? {
                    width: t.ssoWidth
                } : void 0)
            }), (f, d) => (H(), ve("div", {
                id: "google_auth_or_reg",
                class: "register_google-btn",
                onClick: l
            }, [d[0] || (d[0] = wn('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 32 32" width="64" height="64" data-v-fd5d5f38><defs data-v-fd5d5f38><path id="A" d="M44.5 20H24v8.5h11.8C34.7 33.9 30.1 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 11.8 2 2 11.8 2 24s9.8 22 22 22c11 0 21-8 21-22 0-1.3-.2-2.7-.5-4z" data-v-fd5d5f38></path></defs><clipPath id="B" data-v-fd5d5f38><use xlink:href="#A" data-v-fd5d5f38></use></clipPath><g transform="matrix(.727273 0 0 .727273 -.954545 -1.45455)" data-v-fd5d5f38><path d="M0 37V11l17 13z" clip-path="url(#B)" fill="#fbbc05" data-v-fd5d5f38></path><path d="M0 11l17 13 7-6.1L48 14V0H0z" clip-path="url(#B)" fill="#ea4335" data-v-fd5d5f38></path><path d="M0 37l30-23 7.9 1L48 0v48H0z" clip-path="url(#B)" fill="#34a853" data-v-fd5d5f38></path><path d="M48 48L17 24l-4-3 35-10z" clip-path="url(#B)" fill="#4285f4" data-v-fd5d5f38></path></g></svg>', 1)), ee("div", qr, [ee("span", null, we(f.text), 1), Z(xt, {
                class: "action__loader",
                loading: !0
            })])]))
        }
    }),
    dn = ze(Hr, [
        ["__scopeId", "data-v-fd5d5f38"]
    ]),
    Ss = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: dn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    zr = {
        class: "flag mr-4"
    },
    Wr = ["src"],
    Gr = ["innerHTML"],
    Lt = Be({
        __name: "SelectCurrencyItem",
        props: {
            item: {}
        },
        emits: ["click"],
        setup(e) {
            const {
                getIconWithExt: n
            } = Hn();
            return (t, r) => (H(), ve("div", {
                class: "align-center d-flex select-with-currency-item",
                onClick: r[0] || (r[0] = a => t.$emit("click"))
            }, [ee("div", zr, [t.item.flag ? (H(), ve("img", {
                key: 0,
                src: c(n)(["svgflags", t.item.flag.toUpperCase(), "svg"]),
                width: "37",
                height: "37",
                alt: ""
            }, null, 8, Wr)) : le("", !0)]), ee("div", {
                innerHTML: t.item.symbol
            }, null, 8, Gr), r[1] || (r[1] = ee("div", {
                class: "px-2"
            }, "-", -1)), ee("div", null, we(t.item.iso_code), 1)]))
        }
    }),
    xr = {
        class: "select-with-currency"
    },
    Kr = Be({
        __name: "AppSelectWithCurrency",
        props: {
            updateBonuses: {
                type: Boolean
            }
        },
        setup(e) {
            const n = e,
                {
                    currencies: t
                } = Re(zt()),
                {
                    registerForm: r,
                    isNeedToClearPromo: a
                } = Re(je()),
                {
                    updateRegistrationForm: i
                } = je(),
                {
                    fetchWelcomeBonuses: l
                } = Kt(),
                {
                    appDefaultCurrency: f
                } = In(),
                d = Yt(),
                v = L(!1),
                g = {
                    origin: "overlap",
                    location: "bottom",
                    contentClass: "select-module-register",
                    closeOnContentClick: !0,
                    "data-auto-test-el": "listCurrency"
                },
                A = S(() => {
                    var $, G, z, h;
                    const C = (($ = r.value) == null ? void 0 : $.currency) || ((G = d.query) == null ? void 0 : G.val_cur) || f.value;
                    return typeof C == "string" ? C : (C == null ? void 0 : C.iso_code) || ((h = (z = t.value) == null ? void 0 : z[0]) == null ? void 0 : h.iso_code)
                }),
                O = S(() => {
                    var C;
                    return ((C = t.value) == null ? void 0 : C.map($ => ({
                        value: $
                    }))) || []
                }),
                P = S(() => O.value.find(C => C.value.iso_code === A.value) || O.value[0]);

            function k(C) {
                const $ = C == null ? void 0 : C.iso_code;
                a.value = r.value.isPromo, i({
                    key: "currency",
                    value: $
                }), n.updateBonuses && l($)
            }

            function B() {
                ie(() => {
                    var $;
                    const C = ($ = P.value) == null ? void 0 : $.value;
                    C && (C && k(C), v.value = !0)
                })
            }
            return ye(t, () => {
                !v.value && B()
            }, {
                once: !0
            }), tt(B), (C, $) => {
                const G = Jt;
                return H(), ve("div", xr, [c(t) ? (H(), Ve(G, ct({
                    key: 0
                }, C.$props, {
                    items: c(O),
                    value: c(P),
                    height: 42,
                    "is-slotable-item": "",
                    "is-slotable-selection": "",
                    "bg-color": "",
                    dark: "",
                    "return-object": "",
                    "menu-props": g,
                    "data-auto-test-el": "chooseCurency"
                }), {
                    item: se(({
                        item: z
                    }) => [Z(Lt, {
                        item: z.value,
                        class: qe({
                            active: z.value.iso_code === c(A)
                        }),
                        onClick: h => k(z.value)
                    }, null, 8, ["item", "class", "onClick"])]),
                    selection: se(({
                        item: z
                    }) => [Z(Lt, {
                        item: z.value,
                        class: "selection"
                    }, null, 8, ["item"])]),
                    _: 1
                }, 16, ["items", "value"])) : le("", !0)])
            }
        }
    }),
    Yr = {
        key: 0,
        class: "flag mr-4"
    },
    Xr = ["src"],
    Qr = ["innerHTML"],
    Jr = Be({
        __name: "SelectBonusesItem",
        props: {
            item: {}
        },
        emits: ["click"],
        setup(e) {
            const {
                app: n
            } = An(), t = S(() => n == null ? void 0 : n.fullDomain), {
                locale: r
            } = nt();

            function a(l) {
                if (!(t != null && t.value)) return;
                const f = `upload.${new URL(t==null?void 0:t.value).host}`;
                try {
                    const d = new URL(l);
                    return d.host.includes("upload") && (d.host = f), d.toString()
                } catch {
                    const d = new URL(`https://${f}`);
                    return d.pathname = l, d.toString()
                }
            }
            const i = l => {
                var f;
                return l != null && l.bonus_name ? (l == null ? void 0 : l.bonus_name[r.value]) || ((f = l == null ? void 0 : l.bonus_name) == null ? void 0 : f.en) : l.name
            };
            return (l, f) => typeof l.item != "number" ? (H(), ve("div", {
                key: 0,
                class: "align-center bonus-item d-flex",
                style: {
                    width: "100%"
                },
                onClick: f[0] || (f[0] = d => l.$emit("click"))
            }, [l.item.image ? (H(), ve("div", Yr, [ee("img", {
                src: a(l.item.image),
                alt: ""
            }, null, 8, Xr)])) : le("", !0), ee("span", {
                innerHTML: i(l.item)
            }, null, 8, Qr)])) : le("", !0)
        }
    }),
    Mt = ze(Jr, [
        ["__scopeId", "data-v-2a571cbf"]
    ]),
    Zr = {
        class: "mb-4 modal__form-title"
    },
    es = Be({
        __name: "AppSelectWithBonuses",
        setup(e) {
            const n = ["casino", "live-dealers", "tv-games"],
                t = ["BD", "PH"],
                {
                    getWelcomeBonuses: r,
                    selectedBonusListId: a
                } = Re(Kt()),
                {
                    registerForm: i
                } = Re(je()),
                {
                    userGeo: l
                } = Re(Wt()),
                {
                    updateRegistrationForm: f
                } = je(),
                {
                    cloneDeep: d
                } = jn(),
                {
                    t: v
                } = nt(),
                g = kn(),
                {
                    getSubdirUrlPart: A
                } = Rn(),
                O = Yt(),
                P = L(!1),
                k = {
                    origin: "overlap",
                    location: "bottom",
                    contentClass: "select-module-register",
                    closeOnContentClick: !0,
                    "data-auto-test-el": "bonusList"
                },
                B = S(() => r.value),
                C = S(() => {
                    var w;
                    return (w = i.value) == null ? void 0 : w.currency
                }),
                $ = S(() => {
                    var w;
                    return (w = i.value) == null ? void 0 : w.isPromo
                }),
                G = S(() => {
                    var w;
                    return (w = i.value) == null ? void 0 : w.bonus
                }),
                z = Xt("welcome_bonus"),
                h = S(() => {
                    if (!B.value) return [];
                    const w = d(B.value);
                    return !t.includes(l.value) && !z.value && w.push({
                        id: St.NO_BONUS_ID,
                        name: v("buttons.playWithoutBonus"),
                        image: "/storage/108353/no-bonus.png"
                    }), w.map(T => ({
                        value: { ...T
                        }
                    }))
                }),
                R = S(() => h.value.length > 1 ? v("dialogs.registration.bonus") : v("dialogs.registration.welcome_bonus")),
                j = S(() => {
                    var w, T, D;
                    return (D = (T = (w = h.value) == null ? void 0 : w[0]) == null ? void 0 : T.value) == null ? void 0 : D.id
                }),
                Y = S(() => {
                    var w, T;
                    return ((w = h.value) == null ? void 0 : w.find(D => D.value.id === G.value)) || ((T = h.value) == null ? void 0 : T[0])
                }),
                te = S(() => {
                    var T, D, N, X, V, W;
                    if ((T = O.query) != null && T.bonus_id) return (D = B.value) == null ? void 0 : D.find(y => y.id === Number(O.query.bonus_id) && y.is_welcome);
                    const w = (X = String((N = O.query) == null ? void 0 : N.bonus)) == null ? void 0 : X.toLowerCase();
                    return w === "casino" ? (V = B.value) == null ? void 0 : V.find(y => y.casino && !y.bets && y.is_welcome) : w === "sport" ? (W = B.value) == null ? void 0 : W.find(y => y.bets && !y.casino && y.is_welcome) : null
                });

            function J(w) {
                if ($.value) return;
                const T = w || j.value;
                P.value = !0, T !== G.value && f({
                    key: "bonus",
                    value: T
                })
            }

            function x() {
                var I, q, Fe, We, he, $e, De, ue, pe, Pe, Ce, ge;
                const w = g(`/${A(0,O.path)}`).split("/"),
                    T = w[w.length - 1],
                    D = ((q = (I = B.value) == null ? void 0 : I.find(me => me.casino)) == null ? void 0 : q.id) || G.value,
                    N = ((We = (Fe = B.value) == null ? void 0 : Fe.find(me => me.bets)) == null ? void 0 : We.id) || G.value,
                    X = n.includes(T),
                    V = w.includes("sports") || w.includes("live"),
                    W = P.value ? G.value : X ? D : V ? N : (De = ($e = (he = h.value) == null ? void 0 : he[0]) == null ? void 0 : $e.value) == null ? void 0 : De.id;
                if ((N || D) && !W) {
                    f({
                        key: "bonus",
                        value: (pe = (ue = B.value) == null ? void 0 : ue[0]) == null ? void 0 : pe.id
                    });
                    return
                }
                const y = (Ce = (Pe = B.value) == null ? void 0 : Pe.find(me => me.id === a.value)) == null ? void 0 : Ce.id;
                f({
                    key: "bonus",
                    value: ((ge = te.value) == null ? void 0 : ge.id) || y || W
                })
            }
            return ye(C, (w, T) => {
                w !== T && (P.value = !1, x())
            }), ye(B, (w, T) => {
                var D, N;
                w !== T && (f({
                    key: "bonus",
                    value: (N = (D = B.value) == null ? void 0 : D[0]) == null ? void 0 : N.id
                }), x())
            }), (w, T) => {
                const D = Jt;
                return H(), ve("div", {
                    class: qe(["mt-3 select-with-bonuses w-100", {
                        "select-with-bonuses__single": c(h).length < 2
                    }])
                }, [ee("p", Zr, we(c(R)), 1), c(B) ? (H(), Ve(D, {
                    key: 0,
                    items: c(h),
                    value: c(Y),
                    height: 42,
                    "return-object": "",
                    "menu-icon": c(h).length > 1 ? "mdi-chevron-down" : "",
                    "is-slotable-item": "",
                    "is-slotable-selection": "",
                    "menu-props": k,
                    readonly: c(h).length === 1,
                    "data-auto-test-el": "bonus"
                }, {
                    item: se(({
                        item: N
                    }) => [Z(Mt, {
                        item: N.value,
                        class: qe({
                            active: N.value.id === c(G)
                        }),
                        onClick: X => J(N.value.id)
                    }, null, 8, ["item", "class", "onClick"])]),
                    selection: se(({
                        item: N
                    }) => [Z(Mt, {
                        item: N.value,
                        class: "selection"
                    }, null, 8, ["item"])]),
                    _: 1
                }, 8, ["items", "value", "menu-icon", "readonly"])) : le("", !0)], 2)
            }
        }
    }),
    ts = ze(es, [
        ["__scopeId", "data-v-75eed49a"]
    ]),
    ns = {},
    rs = {
        class: "auth-module-content"
    };

function ss(e, n) {
    return H(), ve("div", rs, [qt(e.$slots, "default", {}, void 0, !0)])
}
const fn = ze(ns, [
        ["render", ss],
        ["__scopeId", "data-v-901e66fb"]
    ]),
    Cs = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: fn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Ne = "Cloudflare Turnstile",
    ut = {
        src: "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit",
        id: "turnstile-cloudflare"
    };

function os({
    widgetId: e
} = {}) {
    var z;
    const {
        config: n
    } = Bn(), {
        locale: t
    } = nt(), {
        cfCaptcha: r,
        setCfCaptchaOption: a
    } = je(), i = L((z = n.value) == null ? void 0 : z.APP_WITH_CAPTCHA), l = L(null), f = L(!1), d = S(() => r), v = S(() => {
        var h, R;
        return f.value ? !1 : ((h = d.value) == null ? void 0 : h.displayCaptcha) && !((R = d.value) != null && R.token)
    }), g = (h, R) => {
        a({
            key: h,
            value: R
        })
    }, A = h => {
        g("token", h), g("needReset", !1)
    }, O = () => St.TURNSTILE_SUPPORT_LANGUAGES.includes(t.value) ? t.value : "en", P = () => ({
        sitekey: l.value,
        size: "invisible",
        language: O(),
        callback: A
    });

    function k() {
        return new Promise((h, R) => {
            const j = document.querySelector(`head script[id="${ut.id}"]`);
            if (j) {
                h(j);
                return
            }
            const Y = document.createElement("script");
            Y.src = ut.src, Y.id = ut.id, Y.type = "text/javascript", Y.onload = () => {
                h(Y)
            }, Y.onerror = te => {
                R(te)
            }, document.head.appendChild(Y)
        })
    }
    async function B(h) {
        var R;
        try {
            if (!(window != null && window.turnstile)) {
                console.warn(`[${Ne}] - is not available or not installed`);
                const j = await k();
                console.info(`[${Ne}] - Force installed`, j)
            }(R = window.turnstile) == null || R.reset(h), g("token", null), g("needReset", !1)
        } catch (j) {
            console.error(`[${Ne}] - error`, j)
        }
    }
    async function C(h) {
        var R;
        try {
            if (!(window != null && window.turnstile)) {
                console.warn(`[${Ne}] - is not available or not installed`);
                const j = await k();
                console.info(`[${Ne}] - Force installed`, j)
            }(R = window.turnstile) == null || R.remove(h), g("token", null), g("elementId", null), g("needReset", !1)
        } catch (j) {
            console.error(`[${Ne}] - error`, j)
        }
    }

    function $() {
        i.value = !!d.value.siteKey, l.value = d.value.siteKey, i.value && l.value && ie(() => g("displayCaptcha", !0))
    }
    async function G(h) {
        var R;
        try {
            const j = (R = d.value) == null ? void 0 : R.elementId;
            j && await C(j), window != null && window.turnstile || await k(), await ie(() => {
                var te;
                document.querySelector(h) && ((te = window.turnstile) == null || te.render(h, P()), g("elementId", h))
            })
        } catch (j) {
            console.error(`[${Ne}] - Error during init:`, j), f.value = !0
        }
    }
    return i.value && $(), ye(() => {
        var h;
        return (h = d.value) == null ? void 0 : h.needReset
    }, h => {
        h && d.value.elementId && B(d.value.elementId)
    }), ye(() => {
        var h;
        return (h = d.value) == null ? void 0 : h.displayCaptcha
    }, h => {
        h && e ? G(e) : e && C(e)
    }), ye(() => d.value.siteKey, () => ie(() => $())), Ht(() => {
        g("token", null), g("elementId", null), g("needReset", !1)
    }), {
        useCaptcha: i,
        changeStoreCFOption: g,
        sfScriptData: ut,
        getCfCaptcha: d,
        isCaptchaDisabledBtn: v
    }
}
const as = {
        class: "actions"
    },
    is = {
        class: "checkbox-terms"
    },
    ls = {
        key: 0
    },
    us = {
        key: 0,
        id: "login-captcha"
    },
    cs = {
        class: "auth_or"
    },
    ds = Be({
        __name: "RegistrationFormView",
        props: {
            displayCurrency: {
                type: Boolean
            },
            displayBonuses: {
                type: Boolean
            },
            displayGoogleSso: {
                type: Boolean
            },
            type: {},
            typeRegistration: {},
            hideTabs: {
                type: Boolean
            },
            hidePassword: {
                type: Boolean
            },
            displayOnlyField: {}
        },
        emits: ["get:notification", "get:response-success", "get:response-error", "get:validation-error", "get:validation-success"],
        setup(e, {
            emit: n
        }) {
            const {
                t
            } = nt(), r = e, a = n, i = L(!1), l = L(!1), f = L(!1), d = L("email"), v = L(null), g = L(null), {
                isMobile: A
            } = zn(), {
                trackButtonClick: O
            } = Gt(), P = L([y => !!y || ""]), k = L(!0), {
                isGoogleSsoSuccess: B,
                tokenDataUser: C,
                googleSsoErrors: $
            } = Re(je()), {
                onAuthentication: G,
                onRegistration: z,
                updateRegistrationForm: h,
                onUpdateGoogleSsoSuccess: R,
                changeDialogData: j
            } = je(), {
                getCfCaptcha: Y,
                isCaptchaDisabledBtn: te,
                useCaptcha: J
            } = os({
                widgetId: "#login-captcha"
            }), x = S(() => r.type === "registration" ? "signup" : "signin"), {
                googleSsoDisplay: w
            } = Qt(x.value), T = Xt("typeReg"), D = () => {
                O({
                    category: "register_popup",
                    action: "terms"
                })
            };

            function N() {
                if (!v.value) return a("get:validation-error", {
                    formSubmitHandler: "formSubmitHandler missing"
                }), console.error("formSubmitHandler missing");
                v.value(async y => {
                    a("get:validation-success", y);
                    try {
                        const q = await (r.type === "login" ? G : z)();
                        a("get:response-success", q == null ? void 0 : q.data), j(null)
                    } catch (I) {
                        a("get:response-error", I), I instanceof Error ? console.error("Catch error in onAuthentication: ", I.message) : console.error("Catch error in onAuthentication: ", String(I))
                    } finally {
                        i.value = !1
                    }
                }, y => {
                    console.error("Validation errors:", y), i.value = !1, a("get:validation-error", y)
                })()
            }

            function X() {
                h({
                    key: "checkbox1",
                    value: k.value
                }), h({
                    key: "checkbox2",
                    value: k.value
                })
            }

            function V(y) {
                d.value = y
            }

            function W(y) {
                r.type === "registration" && (T.value = r.typeRegistration || "2"), i.value = !0, N(), console.info("action", y)
            }
            return ye(() => B.value, y => {
                y && a("get:response-success", C.value)
            }), ye(() => $.value, y => {
                y && a("get:response-error", $.value)
            }), tt(() => {
                X(), r.type === "registration" && (h({
                    key: "checkbox1",
                    value: !0
                }), h({
                    key: "checkbox2",
                    value: !0
                }), h({
                    key: "confirm_subscribers",
                    value: ["news"]
                }))
            }), Ht(() => {
                R(!1)
            }), (y, I) => (H(), Ve(fn, {
                class: "form-registration"
            }, {
                default: se(() => [Z(Mr, {
                    type: y.type,
                    "selected-btn": c(d),
                    "hide-tabs": y.hideTabs,
                    "hide-password": y.hidePassword,
                    "force-tab-type": y.displayOnlyField,
                    "requires-tooltip-disabled": y.typeRegistration === "4",
                    onChangeTab: V,
                    onGetSubmitHandler: I[0] || (I[0] = q => v.value = q),
                    onGetResetHandler: I[1] || (I[1] = q => g.value = q),
                    "onSubmit:disabledBtn": I[2] || (I[2] = q => l.value = q),
                    "onCheckEmail:loading": I[3] || (I[3] = q => f.value = q)
                }, null, 8, ["type", "selected-btn", "hide-tabs", "hide-password", "force-tab-type", "requires-tooltip-disabled"]), y.displayCurrency ? (H(), Ve(wt, {
                    key: 0,
                    class: "currency-field"
                }, {
                    default: se(() => [Z(Xe, {
                        class: "pb-0 pt-3"
                    }, {
                        default: se(() => [Z(Kr, {
                            id: "reg_select_list",
                            class: "register__currency"
                        })]),
                        _: 1
                    })]),
                    _: 1
                })) : le("", !0), y.displayBonuses ? (H(), Ve(wt, {
                    key: 1,
                    class: "bonuses-field"
                }, {
                    default: se(() => [Z(Xe, {
                        class: "pb-0 pt-3"
                    }, {
                        default: se(() => [Z(ts, {
                            id: "reg_select_list-bonus",
                            class: "register__currency"
                        })]),
                        _: 1
                    })]),
                    _: 1
                })) : le("", !0), ee("div", as, [Z(Ln, {
                    modelValue: c(k),
                    "onUpdate:modelValue": I[4] || (I[4] = q => Je(k) ? k.value = q : null),
                    class: "checkbox",
                    rules: c(P),
                    "hide-details": "",
                    onInput: X
                }, {
                    label: se(() => [ee("div", is, [gt(we(c(t)("dialogs.registration.agreement0")) + " ", 1), ee("a", {
                        href: "/terms-and-conditions",
                        target: "_blank",
                        class: "text-color-white",
                        onClick: Cn(D, ["stop"])
                    }, we(c(t)("dialogs.registration.terms_of_user_agreement")), 1), c(A) ? (H(), ve("br", ls)) : le("", !0), gt(" " + we(c(t)("dialogs.registration.over18")), 1)])]),
                    _: 1
                }, 8, ["modelValue", "rules"]), c(J) ? Sn((H(), ve("div", us, null, 512)), [
                    [On, c(Y).displayCaptcha]
                ]) : le("", !0), y.$slots.buttonSubmit ? qt(y.$slots, "buttonSubmit", {
                    key: 1,
                    loadingSubmit: c(i) || c(f),
                    disabled: c(l) || c(te) || !c(k) || c(f),
                    submitHandler: () => W("sign_in")
                }, void 0, !0) : (H(), Ve(xt, {
                    key: 2,
                    id: "login-sign-in-btn",
                    class: "font-weight-bold social-btn",
                    color: "primary",
                    height: "47",
                    block: "",
                    disabled: c(l) || c(te) || !c(k) || c(f),
                    loading: c(i) || c(f),
                    onClick: I[5] || (I[5] = q => W("sign_in"))
                }, {
                    default: se(() => [gt(we(c(t)("buttons.signIn")), 1)]),
                    _: 1
                }, 8, ["disabled", "loading"])), c(w) && y.displayGoogleSso ? (H(), ve(Tn, {
                    key: 3
                }, [ee("div", cs, [ee("span", null, we(c(t)("dialogs.registration.or")), 1)]), Z(dn, {
                    "sso-type": c(x),
                    text: c(t)("dialogs.registration.login_with_google")
                }, null, 8, ["sso-type", "text"])], 64)) : le("", !0)])]),
                _: 3
            }))
        }
    }),
    Os = ze(ds, [
        ["__scopeId", "data-v-5ddf7021"]
    ]);
export {
    ts as A, Cs as C, dn as G, Mr as P, Os as _, Kr as a, Ss as b, Fr as p, os as u
};