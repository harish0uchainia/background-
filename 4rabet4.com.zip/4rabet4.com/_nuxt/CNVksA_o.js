import {
    z as t
} from "./BbvgifQp.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "6039cf89-70f2-40a4-aba9-44c72c1085f2", e._sentryDebugIdIdentifier = "sentry-dbid-6039cf89-70f2-40a4-aba9-44c72c1085f2")
    } catch {}
})();
const r = () => t().$device;
export {
    r as u
};