import {
    G as b,
    t as R,
    v as j,
    c as E
} from "./BbvgifQp.js";
import {
    u as L
} from "./D_nsTU_t.js";
import {
    u as O
} from "./D5xT9ef6.js";
import {
    d as s
} from "./BBZLTf3A.js";
(function() {
    try {
        var o = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            a = new o.Error().stack;
        a && (o._sentryDebugIds = o._sentryDebugIds || {}, o._sentryDebugIds[a] = "97b3b6f6-281b-4bfb-a143-af1630575e68", o._sentryDebugIdIdentifier = "sentry-dbid-97b3b6f6-281b-4bfb-a143-af1630575e68")
    } catch {}
})();

function M() {
    const {
        getSectionCategories: o,
        getSlotsByCategory: a,
        getSlotsBySection: n,
        clearSubSlot: m,
        setExternalProviderId: g,
        sectionsList: c
    } = b(), u = R(), {
        subSlots: S,
        slots: y
    } = j(b()), {
        isPcUa: h,
        isMobileUa: C
    } = L(), {
        getSubdirUrlPart: f
    } = E(), {
        isUserVip: I,
        userGeo: w
    } = O(), r = s(() => {
        const e = f(0);
        return e === "live-dealers" ? "live-casino" : e
    }), P = s(() => {
        const e = u.path.split("/").filter(t => t.trim() !== "");
        return e.length >= 2 ? e.slice(-2).join("/") : u.path
    }), _ = s(() => f(1)), d = s(() => {
        const e = o(r.value);
        return !I.value && Array.isArray(e.value) ? e.value.filter(t => t.slug !== "vip") : Array.isArray(e.value) ? e.value : []
    }), B = ["baccarat", "baccarat", "blackjack", "crash", "fast", "favourites-slots", "live", "local", "new-games", "other", "popular", "recommended", "roulette", "slots", "table", "exclusives", "tutorials", "game_shows", "virtual_sports", "evolution", "board", "providers", "allGames", "vip"], D = s(() => d.value.length > 0), v = s(() => ({
        section: r.value,
        desktop: h.value,
        mobile: C.value
    })), G = s(() => y.value[r.value] || []);

    function A(e) {
        const t = ["vip", "local"];
        return r.value === "live-casino" && t.includes(e) ? `casinoCategories.${e}-tables` : r.value === "casino" && e === "local" && w.value === "BD" ? "JILI Games" : `casinoCategories.${e}`
    }

    function U() {
        D.value || n(v.value)
    }

    function k({
        currentSection: e,
        desktop: t,
        mobile: i
    }) {
        const x = c.filter(l => l !== e).map(l => n({
            section: l,
            desktop: t,
            mobile: i
        }));
        return Promise.all(x)
    }

    function F({
        desktop: e,
        mobile: t
    }) {
        const i = c.map(p => n({
            section: p,
            desktop: e,
            mobile: t
        }));
        return Promise.all(i)
    }

    function T(e) {
        return a(e)
    }
    return {
        section: r,
        currentCategory: _,
        sectionCategories: d,
        getSlotsByCategory: T,
        updatedImages: B,
        loadSlotsForOtherSections: k,
        loadSlotsForAllSections: F,
        paramsToFetchBySection: v,
        slots: G,
        subSlots: S,
        fetchCurrentSectionSlots: U,
        lastTwoSections: P,
        setExternalProviderId: g,
        clearSubSlot: m,
        getTranslationCategoryKey: A
    }
}
export {
    M as u
};