import {
    B as H,
    n as L,
    b as P,
    O as R,
    w as J,
    C as U,
    a as B,
    g as K,
    o as Q,
    y as X,
    d as V,
    ao as O,
    u as Y
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "d45c4df6-ab79-4ea4-9984-12f3158f1040", e._sentryDebugIdIdentifier = "sentry-dbid-d45c4df6-ab79-4ea4-9984-12f3158f1040")
    } catch {}
})();

function Z(e) {
    return K() ? (Q(e), !0) : !1
}
const x = typeof window < "u" && typeof document < "u";
typeof WorkerGlobalScope < "u" && globalThis instanceof WorkerGlobalScope;
const ee = Object.prototype.toString,
    te = e => ee.call(e) === "[object Object]",
    ne = () => {};

function re(e, n) {
    function t(...u) {
        return new Promise((s, p) => {
            Promise.resolve(e(() => n.apply(this, u), {
                fn: n,
                thisArg: this,
                args: u
            })).then(s).catch(p)
        })
    }
    return t
}
const $ = e => e();

function oe(e = $) {
    const n = P(!0);

    function t() {
        n.value = !1
    }

    function u() {
        n.value = !0
    }
    const s = (...p) => {
        n.value && e(...p)
    };
    return {
        isActive: R(n),
        pause: t,
        resume: u,
        eventFilter: s
    }
}

function q(e) {
    return B()
}

function I(e) {
    return Array.isArray(e) ? e : [e]
}

function ie(e, n, t = {}) {
    const {
        eventFilter: u = $,
        ...s
    } = t;
    return J(e, re(u, n), s)
}

function ae(e, n, t = {}) {
    const {
        eventFilter: u,
        ...s
    } = t, {
        eventFilter: p,
        pause: E,
        resume: i,
        isActive: a
    } = oe(u);
    return {
        stop: ie(e, n, { ...s,
            eventFilter: p
        }),
        pause: E,
        resume: i,
        isActive: a
    }
}

function G(e, n = !0, t) {
    q() ? H(e, t) : n ? e() : L(e)
}

function ue(e, n) {
    q() && U(e, n)
}

function se(e, n, t) {
    return J(e, n, { ...t,
        immediate: !0
    })
}
const _ = x ? window : void 0,
    le = x ? window.document : void 0;

function ce(e) {
    var n;
    const t = O(e);
    return (n = t == null ? void 0 : t.$el) != null ? n : t
}

function T(...e) {
    const n = [],
        t = () => {
            n.forEach(i => i()), n.length = 0
        },
        u = (i, a, l, y) => (i.addEventListener(a, l, y), () => i.removeEventListener(a, l, y)),
        s = V(() => {
            const i = I(O(e[0])).filter(a => a != null);
            return i.every(a => typeof a != "string") ? i : void 0
        }),
        p = se(() => {
            var i, a;
            return [(a = (i = s.value) == null ? void 0 : i.map(l => ce(l))) != null ? a : [_].filter(l => l != null), I(O(s.value ? e[1] : e[0])), I(Y(s.value ? e[2] : e[1])), O(s.value ? e[3] : e[2])]
        }, ([i, a, l, y]) => {
            if (t(), !(i != null && i.length) || !(a != null && a.length) || !(l != null && l.length)) return;
            const c = te(y) ? { ...y
            } : y;
            n.push(...i.flatMap(D => a.flatMap(v => l.map(b => u(D, v, b, c)))))
        }, {
            flush: "post"
        }),
        E = () => {
            p(), t()
        };
    return Z(t), E
}
const j = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
    M = "__vueuse_ssr_handlers__",
    fe = de();

function de() {
    return M in j || (j[M] = j[M] || {}), j[M]
}

function pe(e, n) {
    return fe[e] || n
}

function ye(e) {
    return e == null ? "any" : e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof Date ? "date" : typeof e == "boolean" ? "boolean" : typeof e == "string" ? "string" : typeof e == "object" ? "object" : Number.isNaN(e) ? "any" : "number"
}
const me = {
        boolean: {
            read: e => e === "true",
            write: e => String(e)
        },
        object: {
            read: e => JSON.parse(e),
            write: e => JSON.stringify(e)
        },
        number: {
            read: e => Number.parseFloat(e),
            write: e => String(e)
        },
        any: {
            read: e => e,
            write: e => String(e)
        },
        string: {
            read: e => e,
            write: e => String(e)
        },
        map: {
            read: e => new Map(JSON.parse(e)),
            write: e => JSON.stringify(Array.from(e.entries()))
        },
        set: {
            read: e => new Set(JSON.parse(e)),
            write: e => JSON.stringify(Array.from(e))
        },
        date: {
            read: e => new Date(e),
            write: e => e.toISOString()
        }
    },
    z = "vueuse-storage";

function ge(e, n, t, u = {}) {
    var s;
    const {
        flush: p = "pre",
        deep: E = !0,
        listenToStorageChanges: i = !0,
        writeDefaults: a = !0,
        mergeDefaults: l = !1,
        shallow: y,
        window: c = _,
        eventFilter: D,
        onError: v = r => {
            console.error(r)
        },
        initOnMounted: b
    } = u, w = (y ? X : P)(typeof n == "function" ? n() : n), m = V(() => O(e));
    if (!t) try {
        t = pe("getDefaultStorage", () => {
            var r;
            return (r = _) == null ? void 0 : r.localStorage
        })()
    } catch (r) {
        v(r)
    }
    if (!t) return w;
    const h = O(n),
        S = ye(h),
        A = (s = u.serializer) != null ? s : me[S],
        {
            pause: W,
            resume: C
        } = ae(w, () => o(w.value), {
            flush: p,
            deep: E,
            eventFilter: D
        });
    J(m, () => f(), {
        flush: p
    }), c && i && G(() => {
        t instanceof Storage ? T(c, "storage", f, {
            passive: !0
        }) : T(c, z, k), b && f()
    }), b || f();

    function F(r, d) {
        if (c) {
            const g = {
                key: m.value,
                oldValue: r,
                newValue: d,
                storageArea: t
            };
            c.dispatchEvent(t instanceof Storage ? new StorageEvent("storage", g) : new CustomEvent(z, {
                detail: g
            }))
        }
    }

    function o(r) {
        try {
            const d = t.getItem(m.value);
            if (r == null) F(d, null), t.removeItem(m.value);
            else {
                const g = A.write(r);
                d !== g && (t.setItem(m.value, g), F(d, g))
            }
        } catch (d) {
            v(d)
        }
    }

    function N(r) {
        const d = r ? r.newValue : t.getItem(m.value);
        if (d == null) return a && h != null && t.setItem(m.value, A.write(h)), h;
        if (!r && l) {
            const g = A.read(d);
            return typeof l == "function" ? l(g, h) : S === "object" && !Array.isArray(g) ? { ...h,
                ...g
            } : g
        } else return typeof d != "string" ? d : A.read(d)
    }

    function f(r) {
        if (!(r && r.storageArea !== t)) {
            if (r && r.key == null) {
                w.value = h;
                return
            }
            if (!(r && r.key !== m.value)) {
                W();
                try {
                    (r == null ? void 0 : r.newValue) !== A.write(w.value) && (w.value = N(r))
                } catch (d) {
                    v(d)
                } finally {
                    r ? L(C) : C()
                }
            }
        }
    }

    function k(r) {
        f(r.detail)
    }
    return w
}

function he(e, n, t = {}) {
    const {
        window: u = _
    } = t;
    return ge(e, n, u == null ? void 0 : u.localStorage, t)
}

function be(e, n = ne, t = {}) {
    const {
        immediate: u = !0,
        manual: s = !1,
        type: p = "text/javascript",
        async: E = !0,
        crossOrigin: i,
        referrerPolicy: a,
        noModule: l,
        defer: y,
        document: c = le,
        attrs: D = {}
    } = t, v = P(null);
    let b = null;
    const w = S => new Promise((A, W) => {
            const C = f => (v.value = f, A(f), f);
            if (!c) {
                A(!1);
                return
            }
            let F = !1,
                o = c.querySelector(`script[src="${O(e)}"]`);
            o ? o.hasAttribute("data-loaded") && C(o) : (o = c.createElement("script"), o.type = p, o.async = E, o.src = O(e), y && (o.defer = y), i && (o.crossOrigin = i), l && (o.noModule = l), a && (o.referrerPolicy = a), Object.entries(D).forEach(([f, k]) => o == null ? void 0 : o.setAttribute(f, k)), F = !0);
            const N = {
                passive: !0
            };
            T(o, "error", f => W(f), N), T(o, "abort", f => W(f), N), T(o, "load", () => {
                o.setAttribute("data-loaded", "true"), n(o), C(o)
            }, N), F && (o = c.head.appendChild(o)), S || C(o)
        }),
        m = (S = !0) => (b || (b = w(S)), b),
        h = () => {
            if (!c) return;
            b = null, v.value && (v.value = null);
            const S = c.querySelector(`script[src="${O(e)}"]`);
            S && c.head.removeChild(S)
        };
    return u && !s && G(m), s || ue(h), {
        scriptTag: v,
        load: m,
        unload: h
    }
}
export {
    me as S, ge as a, be as b, he as u
};