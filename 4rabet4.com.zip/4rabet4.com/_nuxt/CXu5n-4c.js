import {
    _ as g
} from "./DVkCUlFY.js";
import {
    h as y,
    k as b,
    o as r,
    v as I,
    V as B,
    _ as h
} from "./BbvgifQp.js";
import {
    z as w,
    _ as v,
    a8 as x,
    u as o,
    V as P,
    a0 as a,
    D as c,
    a1 as i,
    W as k,
    a2 as V
} from "./BBZLTf3A.js";
import {
    u as D
} from "./Eh0EvCQt.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "e604d5dd-e97e-4f78-a286-0fd35f479ddf", e._sentryDebugIdIdentifier = "sentry-dbid-e604d5dd-e97e-4f78-a286-0fd35f479ddf")
    } catch {}
})();
const N = {
        key: 0,
        class: "bonus-instruction__dialog"
    },
    S = {
        class: "title"
    },
    C = {
        class: "text"
    },
    $ = w({
        __name: "BonusInstraction",
        setup(e) {
            const {
                imageUrl: t
            } = D(), {
                t: n
            } = y(), u = b(), {
                bonusPopupSeen: d,
                getPlayerBonusesList: l
            } = r(), {
                bonusesPopupNotSeenIds: f,
                showBonusPopup: _
            } = I(r()), p = async () => {
                try {
                    await Promise.all(f.value.map(s => d(s))), await u.getPlayerBalance(), await l()
                } catch (s) {
                    throw console.error("Ошибка при обновлении просмотренных бонуснов:", s), s
                }
            };
            return (s, E) => {
                const m = g;
                return o(_) ? (P(), v("div", N, [a("div", S, [c(m, {
                    src: `${o(t)}/svg-sprite/bonus-instruction.svg`,
                    alt: "bonus instruction"
                }, null, 8, ["src"])]), a("div", C, [a("div", null, i(o(n)("dialogs.bonusInstruction.text")), 1)]), c(B, {
                    color: "primary",
                    onClick: p
                }, {
                    default: k(() => [V(i(o(n)("buttons.okButton")), 1)]),
                    _: 1
                })])) : x("", !0)
            }
        }
    }),
    U = h($, [
        ["__scopeId", "data-v-1834c574"]
    ]);
export {
    U as
    default
};