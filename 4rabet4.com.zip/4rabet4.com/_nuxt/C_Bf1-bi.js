var x = Object.defineProperty;
var C = (s, r, i) => r in s ? x(s, r, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: i
}) : s[r] = i;
var w = (s, r, i) => C(s, typeof r != "symbol" ? r + "" : r, i);
import {
    z as N,
    v as S,
    f as P,
    bB as q
} from "./BbvgifQp.js";
import {
    u as v
} from "./WQ5Cu1Fz.js";
import {
    u as I,
    a as M
} from "./BGjWZMuE.js";
import {
    b as B
} from "./BBZLTf3A.js";
(function() {
    try {
        var s = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            r = new s.Error().stack;
        r && (s._sentryDebugIds = s._sentryDebugIds || {}, s._sentryDebugIds[r] = "222edee1-5506-4f51-9a0c-602810163d69", s._sentryDebugIdIdentifier = "sentry-dbid-222edee1-5506-4f51-9a0c-602810163d69")
    } catch {}
})();
class A extends Error {
    constructor({
        message: i,
        code: c,
        showNotification: T = !0,
        errorTextCode: _
    }) {
        super(i);
        w(this, "_name");
        w(this, "_showNotification");
        w(this, "_code");
        w(this, "_errorTextCode");
        this._name = new.target.name, this._showNotification = T, this._code = c, this._errorTextCode = _
    }
    get name() {
        return this._name
    }
    get showNotification() {
        return this._showNotification
    }
    get code() {
        return this._code
    }
    get errorTextCode() {
        return this._errorTextCode
    }
}

function K() {
    const {
        $API: s
    } = N(), r = B(!1), {
        depositMethods: i,
        selectedDepositMethod: c,
        sumToDeposit: T
    } = S(v()), {
        openDialog: _
    } = P(), {
        setSumToDeposit: b,
        fetchDepositHistory: E
    } = v(), {
        trackDepositStatistics: k
    } = I(), {
        defineBannerTrigger: u
    } = M(), {
        showNotification: $
    } = q();
    return {
        createDepositTransaction: async n => {
            var a, t, p, l, f, d, m, h, y, g, D;
            r.value = !0;
            try {
                u({
                    status: "pending",
                    request: "create"
                });
                const e = await s.ApiPayments.depositCreateTransaction(n);
                if (((a = e.data) == null ? void 0 : a.status) === "fail") throw _("depositFailed", null, !0), new Error((t = e.data) == null ? void 0 : t.message);
                return b(+n.amount), k({
                    event: "try_dep_create",
                    amount: typeof n.amount == "number" ? `${n.amount}` : n.amount,
                    tokenMethod: (p = c.value) == null ? void 0 : p.token,
                    tokenTransaction: (l = e.data) == null ? void 0 : l.token,
                    errorTag: (f = e == null ? void 0 : e.data) == null ? void 0 : f.code
                }), u({
                    status: "success",
                    request: "create"
                }), e.data
            } catch (e) {
                if (u({
                        status: "fail",
                        request: "create"
                    }), k({
                        event: "try_dep_create",
                        amount: typeof n.amount == "number" ? `${n.amount}` : n.amount,
                        tokenMethod: (d = c.value) == null ? void 0 : d.token,
                        tokenTransaction: null,
                        errorTag: e == null ? void 0 : e.errorTextCode
                    }), e instanceof Error && console.error(`[createDepositTransaction]: ${e.message}`, e), e instanceof A) throw e;
                const o = e;
                throw new A({
                    message: ((h = (m = o == null ? void 0 : o.response) == null ? void 0 : m.data) == null ? void 0 : h.message) ? ? "Unknown error occurred",
                    code: (y = o == null ? void 0 : o.response) == null ? void 0 : y.status,
                    showNotification: !0,
                    errorTextCode: (D = (g = o == null ? void 0 : o.response) == null ? void 0 : g.data) == null ? void 0 : D.code
                })
            } finally {
                r.value = !1
            }
        },
        applyDepositTransaction: async ({
            device: n,
            data: a
        }) => {
            var t, p, l, f, d, m, h, y, g, D;
            r.value = !0;
            try {
                u({
                    status: "pending",
                    request: "apply"
                });
                const e = await s.ApiPayments.depositApplyTransaction(a, {
                    "User-Device": n
                });
                if (((t = e.data) == null ? void 0 : t.status) === "fail") throw _("depositFailed", null, !0), new Error((p = e.data) == null ? void 0 : p.message);
                return k({
                    event: "try_dep_apply",
                    tokenMethod: (l = c.value) == null ? void 0 : l.token,
                    amount: `${T.value}`,
                    tokenTransaction: a == null ? void 0 : a.token,
                    errorTag: (f = e.data) == null ? void 0 : f.code
                }), u({
                    status: "success",
                    request: "apply"
                }), e
            } catch (e) {
                u({
                    status: "fail",
                    request: "apply"
                }), k({
                    event: "try_dep_apply",
                    amount: `${T.value}`,
                    tokenMethod: (d = c.value) == null ? void 0 : d.token,
                    tokenTransaction: null
                }), e instanceof Error && console.error(`[applyDepositTransaction]: ${e.message}`, e);
                const o = e;
                throw (h = (m = o == null ? void 0 : o.response) == null ? void 0 : m.data) != null && h.message && $({
                    code: ((y = o == null ? void 0 : o.response) == null ? void 0 : y.status) ? ? 500,
                    type: "error",
                    color: "red",
                    message: (D = (g = o == null ? void 0 : o.response) == null ? void 0 : g.data) == null ? void 0 : D.message
                }), e
            } finally {
                r.value = !1
            }
        },
        refreshStatusDeposit: async n => {
            try {
                await s.ApiPayments.fetchDepositPullOne(n), console.info("success result")
            } catch (a) {
                throw a instanceof Error && console.error(`[refreshStatusDeposit]: ${a.message}`, a), a
            }
        },
        fetchDepositAccumulator: async n => {
            var a;
            try {
                const t = await s.ApiPayments.fetchDepositGetAccumulator(n);
                if (!(t != null && t.data) || ((a = t == null ? void 0 : t.data) == null ? void 0 : a.status) !== "ok") throw new Error(`[fetchDepositAccumulator] Failed to fetch accumulator,
 status: ${t.status}`);
                return t.data
            } catch (t) {
                throw t instanceof Error && console.error(`[fetchDepositAccumulator]: ${t.message}`, t), t
            }
        },
        fetchDepositHistory: E,
        depositMethods: i,
        loaderSubmitDeposit: r
    }
}
export {
    K as u
};