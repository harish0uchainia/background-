import {
    v as a,
    k as d
} from "./BbvgifQp.js";
import {
    d as f
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            o = new e.Error().stack;
        o && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[o] = "2516f8a0-de0d-4be6-bbaf-698deba96969", e._sentryDebugIdIdentifier = "sentry-dbid-2516f8a0-de0d-4be6-bbaf-698deba96969")
    } catch {}
})();

function u() {
    const e = a(d()),
        o = f(() => {
            var r;
            return (r = e.profileForm.value) == null ? void 0 : r.balance
        }),
        n = f(() => {
            var r, t;
            return (t = (r = e.profileForm.value) == null ? void 0 : r.info) == null ? void 0 : t.currency
        });
    return {
        balance: o,
        currency: n
    }
}
export {
    u
};