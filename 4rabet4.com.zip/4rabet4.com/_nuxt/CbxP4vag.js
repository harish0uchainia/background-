import {
    ay as b,
    L as w,
    A as v,
    J as y
} from "./BBZLTf3A.js";
import {
    W as x
} from "./BbvgifQp.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            s = new e.Error().stack;
        s && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[s] = "a9f8a9a8-13bf-47eb-9500-f9509d4eb833", e._sentryDebugIdIdentifier = "sentry-dbid-a9f8a9a8-13bf-47eb-9500-f9509d4eb833")
    } catch {}
})();
class p {
    constructor(s) {
        let {
            x: i,
            y: r,
            width: n,
            height: t
        } = s;
        this.x = i, this.y = r, this.width = n, this.height = t
    }
    get top() {
        return this.y
    }
    get bottom() {
        return this.y + this.height
    }
    get left() {
        return this.x
    }
    get right() {
        return this.x + this.width
    }
}

function W(e, s) {
    return {
        x: {
            before: Math.max(0, s.left - e.left),
            after: Math.max(0, e.right - s.right)
        },
        y: {
            before: Math.max(0, s.top - e.top),
            after: Math.max(0, e.bottom - s.bottom)
        }
    }
}

function P(e) {
    return Array.isArray(e) ? new p({
        x: e[0],
        y: e[1],
        width: 0,
        height: 0
    }) : e.getBoundingClientRect()
}

function _(e) {
    const s = e.getBoundingClientRect(),
        i = getComputedStyle(e),
        r = i.transform;
    if (r) {
        let n, t, o, f, a;
        if (r.startsWith("matrix3d(")) n = r.slice(9, -1).split(/, /), t = +n[0], o = +n[5], f = +n[12], a = +n[13];
        else if (r.startsWith("matrix(")) n = r.slice(7, -1).split(/, /), t = +n[0], o = +n[3], f = +n[4], a = +n[5];
        else return new p(s);
        const c = i.transformOrigin,
            l = s.x - f - (1 - t) * parseFloat(c),
            u = s.y - a - (1 - o) * parseFloat(c.slice(c.indexOf(" ") + 1)),
            h = t ? s.width / t : e.offsetWidth + 1,
            d = o ? s.height / o : e.offsetHeight + 1;
        return new p({
            x: l,
            y: u,
            width: h,
            height: d
        })
    } else return new p(s)
}

function D(e, s, i) {
    if (typeof e.animate > "u") return {
        finished: Promise.resolve()
    };
    let r;
    try {
        r = e.animate(s, i)
    } catch {
        return {
            finished: Promise.resolve()
        }
    }
    return typeof r.finished > "u" && (r.finished = new Promise(n => {
        r.onfinish = () => {
            n(r)
        }
    })), r
}
const j = "cubic-bezier(0.4, 0, 0.2, 1)",
    B = "cubic-bezier(0.0, 0, 0.2, 1)",
    M = "cubic-bezier(0.4, 0, 1, 1)",
    T = x({
        transition: {
            type: [Boolean, String, Object],
            default: "fade-transition",
            validator: e => e !== !0
        }
    }, "transition"),
    E = (e, s) => {
        let {
            slots: i
        } = s;
        const {
            transition: r,
            disabled: n,
            group: t,
            ...o
        } = e, {
            component: f = t ? b : w,
            ...a
        } = typeof r == "object" ? r : {};
        return v(f, y(typeof r == "string" ? {
            name: n ? "" : r
        } : a, typeof r == "string" ? {} : Object.fromEntries(Object.entries({
            disabled: n,
            group: t
        }).filter(c => {
            let [l, u] = c;
            return u !== void 0
        })), o), i)
    },
    g = Symbol("Forwarded refs");

function m(e, s) {
    let i = e;
    for (; i;) {
        const r = Reflect.getOwnPropertyDescriptor(i, s);
        if (r) return r;
        i = Object.getPrototypeOf(i)
    }
}

function I(e) {
    for (var s = arguments.length, i = new Array(s > 1 ? s - 1 : 0), r = 1; r < s; r++) i[r - 1] = arguments[r];
    return e[g] = i, new Proxy(e, {
        get(n, t) {
            if (Reflect.has(n, t)) return Reflect.get(n, t);
            if (!(typeof t == "symbol" || t.startsWith("$") || t.startsWith("__"))) {
                for (const o of i)
                    if (o.value && Reflect.has(o.value, t)) {
                        const f = Reflect.get(o.value, t);
                        return typeof f == "function" ? f.bind(o.value) : f
                    }
            }
        },
        has(n, t) {
            if (Reflect.has(n, t)) return !0;
            if (typeof t == "symbol" || t.startsWith("$") || t.startsWith("__")) return !1;
            for (const o of i)
                if (o.value && Reflect.has(o.value, t)) return !0;
            return !1
        },
        set(n, t, o) {
            if (Reflect.has(n, t)) return Reflect.set(n, t, o);
            if (typeof t == "symbol" || t.startsWith("$") || t.startsWith("__")) return !1;
            for (const f of i)
                if (f.value && Reflect.has(f.value, t)) return Reflect.set(f.value, t, o);
            return !1
        },
        getOwnPropertyDescriptor(n, t) {
            var f;
            const o = Reflect.getOwnPropertyDescriptor(n, t);
            if (o) return o;
            if (!(typeof t == "symbol" || t.startsWith("$") || t.startsWith("__"))) {
                for (const a of i) {
                    if (!a.value) continue;
                    const c = m(a.value, t) ? ? ("_" in a.value ? m((f = a.value._) == null ? void 0 : f.setupState, t) : void 0);
                    if (c) return c
                }
                for (const a of i) {
                    const c = a.value && a.value[g];
                    if (!c) continue;
                    const l = c.slice();
                    for (; l.length;) {
                        const u = l.shift(),
                            h = m(u.value, t);
                        if (h) return h;
                        const d = u.value && u.value[g];
                        d && l.push(...d)
                    }
                }
            }
        }
    })
}
export {
    p as B, E as M, D as a, M as b, W as c, B as d, I as f, P as g, T as m, _ as n, j as s
};