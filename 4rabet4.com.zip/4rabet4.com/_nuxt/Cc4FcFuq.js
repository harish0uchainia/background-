import {
    L as r,
    M as u,
    T as b,
    D as i
} from "./1xKHoBf3.js";
import {
    A as c
} from "./BbvgifQp.js";
import {
    d as t
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            s = new e.Error().stack;
        s && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[s] = "e85c7908-5706-48e4-b36a-1b47ba6a8ee4", e._sentryDebugIdIdentifier = "sentry-dbid-e85c7908-5706-48e4-b36a-1b47ba6a8ee4")
    } catch {}
})();

function w() {
    const e = c(),
        s = t(() => e.width.value !== 0 && e.width.value < i),
        o = t(() => e.width.value >= i),
        a = t(() => e.width.value <= b),
        n = t(() => e.width.value < u),
        d = t(() => e.width.value >= r);
    return {
        isMobile: s,
        isDesktop: o,
        isTablet: a,
        isMobileXS: n,
        isLaptops: d
    }
}
export {
    w as u
};