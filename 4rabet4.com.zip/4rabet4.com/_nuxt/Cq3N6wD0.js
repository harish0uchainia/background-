import {
    A as Pe
} from "./BrNfvlGm.js";
import {
    z as Q,
    k as De,
    b as r,
    d as b,
    w as ie,
    U as N,
    V as g,
    W as i,
    u as e,
    D as a,
    a0 as y,
    a1 as C,
    Y as W,
    at as Se,
    f as ge,
    _ as V,
    a7 as K,
    n as ne,
    i as Te,
    B as fe,
    ae as Z,
    a8 as G,
    $ as O,
    a2 as X,
    J as ve,
    aa as Ve,
    F as $e,
    a9 as Ie,
    ai as Ae,
    af as Ee,
    ag as Fe
} from "./BBZLTf3A.js";
import {
    u as He,
    P as Le,
    a as Me,
    A as Ge,
    G as Ne
} from "./CMnmInvQ.js";
import Ue from "./D3cdnUJq.js";
import {
    $ as q,
    h as ee,
    V as le,
    l as ze,
    _ as te,
    v as J,
    t as _e,
    u as be,
    w as ye,
    j as he,
    d as Oe,
    M as qe,
    o as je,
    z as We,
    b as Ye
} from "./BbvgifQp.js";
import {
    a as M,
    V as Y
} from "./DF9zLyti.js";
import {
    u as Ke
} from "./DWq0O7ht.js";
import {
    u as ue
} from "./Cc4FcFuq.js";
import {
    u as Je
} from "./BcxiMhqF.js";
import {
    u as Xe
} from "./BQ66EBJG.js";
import {
    L as Ze
} from "./quAyFRoR.js";
import {
    V as Qe
} from "./BYAyGWVz.js";
import {
    V as pe
} from "./Nc2j0qUX.js";
import {
    V as et
} from "./B99ngSfl.js";
import tt from "./BkMYWUSc.js";
import {
    u as ot
} from "./CBbqpxnU.js";
import {
    d as st
} from "./D9sqA5Xl.js";
import {
    u as at
} from "./BtdAVlWx.js";
import {
    u as rt
} from "./Dr6OcbWf.js";
import {
    V as it
} from "./B4fA6PS_.js";
import "./BuDDDvke.js";
import "./Ka2RWjod.js";
import "./CL3SmZKg.js";
import "./CbxP4vag.js";
import "./B9YIqgoQ.js";
import "./BM8cjqjo.js";
import "./DHxCvf5R.js";
import "./DCO7F8HW.js";
import "./CNgVgUb9.js";
import "./BulKdswA.js";
import "./BEPDeFGu.js";
import "./CyEI51nD.js";
import "./BeLlcxC7.js";
import "./DDGpYvNX.js";
import "./iTYf75jB.js";
import "./BQ7ou4ZQ.js"; /* empty css        */
import "./1xKHoBf3.js";
import "./CNVksA_o.js";
import "./CbNZPVTM.js";
import "./Eh0EvCQt.js";
import "./Q3GHUzCg.js";
(function() {
    try {
        var f = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            D = new f.Error().stack;
        D && (f._sentryDebugIds = f._sentryDebugIds || {}, f._sentryDebugIds[D] = "fabc5a10-73f5-43c3-a04e-7e61d75f9a1e", f._sentryDebugIdIdentifier = "sentry-dbid-fabc5a10-73f5-43c3-a04e-7e61d75f9a1e")
    } catch {}
})();
const nt = {
        class: "cursor-pointer inner-text ml-2 white--text"
    },
    lt = ["placeholder", "disabled"],
    ut = {
        key: 1,
        class: "inner-text white--text"
    },
    ct = Q({
        __name: "AppPromoInput",
        setup(f) {
            const {
                checkPromo: D,
                updateRegistrationForm: n
            } = q(), {
                registerForm: A,
                isNeedToClearPromo: m
            } = De(q()), {
                t: d
            } = ee(), v = r(!1), p = r(""), R = r(null), S = r(null), h = r(null), E = r(null), k = r(null), w = r(!1), P = b(() => {
                var t;
                return (t = A.value) == null ? void 0 : t.isPromo
            }), o = b(() => P.value ? d("buttons.cancel") : d("buttons.apply")), x = r([t => /[a-zA-Z!?0-9 ]*/g.test(t) ? String(t).trim().length > 12 ? d("validations.promoCodeMaxLength12char") : !0 : ""]);

            function B() {
                v.value = !0, ne(() => {
                    S.value && S.value.focus()
                })
            }

            function $(t) {
                t && (R.value = null)
            }

            function U(t) {
                h.value = t
            }
            async function F() {
                if (w.value = !0, h.value) {
                    w.value = !1;
                    return
                }
                return E.value = null, k.value = null, P.value ? z() : await I(), w.value = !1, w.value
            }
            async function I() {
                if (R.value = null, p.value) {
                    const c = await D();
                    c && c.description && (E.value = 0, k.value = c.description)
                } else R.value = d("errors.registration.emptyPromo")
            }

            function j() {
                n({
                    key: "promo",
                    value: p.value
                }), $(p.value)
            }

            function z() {
                n({
                    key: "isPromo",
                    value: !1
                }), n({
                    key: "promo",
                    value: ""
                }), p.value = ""
            }

            function H() {
                z(), v.value = !1, m.value = !1
            }
            return ie(m, t => {
                t && H()
            }), (t, c) => {
                const T = Ue;
                return g(), N(Y, {
                    class: K([{
                        "d-inline-flex pt-3 w-full": !e(v)
                    }, "mt-4 py-2"]),
                    "no-gutters": ""
                }, {
                    default: i(() => [e(v) ? (g(), N(M, {
                        key: 1,
                        class: "align-center d-flex promo-code-wrapper rounded-lg"
                    }, {
                        default: i(() => [W(y("input", {
                            ref_key: "promoRef",
                            ref: S,
                            "onUpdate:modelValue": c[0] || (c[0] = oe => ge(p) ? p.value = oe : null),
                            type: "text",
                            class: "input pl-1 register__promo v-input__slot",
                            placeholder: e(d)("placeholders.promoCodeThirdType"),
                            maxlength: "12",
                            disabled: e(P),
                            "data-auto-test-el": "addPromocode",
                            onInput: c[1] || (c[1] = () => j()),
                            "onUpdate:error": U
                        }, null, 40, lt), [
                            [Se, e(p)]
                        ]), a(le, {
                            id: "registration-promo-apply-btn",
                            "inner-content-id": "registration-promo-apply-btn-text",
                            color: "primary",
                            disabled: !e(p) || e(x)[0](e(p)) !== !0 || e(w),
                            class: "font-weight-bold promo-code-wrapper_promo-apply text-body-2 text-uppercase",
                            rounded: "lg",
                            variant: "flat",
                            "min-width": 76,
                            "max-width": 110,
                            "data-auto-test-el": "apply",
                            onClick: c[2] || (c[2] = () => F())
                        }, {
                            default: i(() => [y("div", {
                                class: K(["register__promo-content-btn", {
                                    "promo-code-wrapper--loading": e(w)
                                }])
                            }, [e(w) ? (g(), N(T, {
                                key: 0
                            })) : (g(), V("span", ut, C(e(o)), 1))], 2)]),
                            _: 1
                        }, 8, ["disabled"])]),
                        _: 1
                    })) : (g(), N(M, {
                        key: 0,
                        class: "d-flex align-center",
                        onClick: B,
                        "data-auto-test-el": "iHavePromocode"
                    }, {
                        default: i(() => [a(le, {
                            icon: "",
                            class: "primary promo-code-wrapper_button",
                            size: 24
                        }, {
                            default: i(() => [a(ze, {
                                icon: "mdi-plus",
                                size: "20"
                            })]),
                            _: 1
                        }), y("span", nt, C(e(d)("dialogs.registration.havePromoCode")), 1)]),
                        _: 1
                    }))]),
                    _: 1
                }, 8, ["class"])
            }
        }
    }),
    dt = te(ct, [
        ["__scopeId", "data-v-54cfd960"]
    ]),
    mt = {
        key: 0,
        class: "register_agreement--first"
    },
    pt = {
        class: "text-center"
    },
    gt = {
        key: 0
    },
    ft = {
        key: 1,
        class: "align-baseline d-flex flex-column"
    },
    vt = Q({
        __name: "EmailTab",
        props: {
            hideCurrency: {
                type: Boolean,
                default: !1
            },
            hideTabs: {
                type: Boolean,
                default: !1
            },
            hideEmail: {
                type: Boolean,
                default: !1
            },
            errorCheckBox: {
                type: Boolean,
                default: !0
            },
            listeners: {
                type: Function
            }
        },
        emits: ["registration-submit"],
        setup(f, {
            emit: D
        }) {
            const {
                onRegistration: n,
                changeDialogData: A,
                updateRegistrationForm: m
            } = q(), {
                registerForm: d
            } = J(q()), {
                t: v
            } = ee(), p = _e(), {
                config: R
            } = be(), {
                userGeo: S
            } = J(ye()), {
                trackRegistration: h
            } = Xe(), {
                classForIphone: E
            } = Je(), {
                trackButtonClick: k
            } = he(), {
                getCfCaptcha: w,
                isCaptchaDisabledBtn: P,
                useCaptcha: o
            } = He({
                widgetId: "#registration-captcha"
            }), {
                setPasswordRules: u
            } = Ke(), x = D, B = r(null), $ = r(null), U = r("email"), F = r(!1), I = r(!1), j = b(() => {
                var s;
                return !!((s = d.value) != null && s.isPromo)
            }), z = b(() => {
                var s;
                return (s = d.value) == null ? void 0 : s.checkbox1
            }), H = r(!0), t = r(!1), c = r(!1), {
                isMobile: T
            } = ue(), oe = Te(Ze, !1), ke = Oe(), L = r(!ke.host.includes(qe("LEKvYiX5AiLjeD", "string"))), se = b(() => c.value ? L.value : !0), ce = r(!0), ae = r([s => !!s || ""]), we = r([{
                model: L,
                rules: ae.value,
                label: v("dialogs.registration.agreement1")
            }, {
                model: H,
                rules: ae.value,
                label: v("dialogs.registration.agreement2")
            }, {
                model: ce,
                label: v("dialogs.registration.subCheckBox")
            }]);

            function re() {
                m({
                    key: "checkbox1",
                    value: L.value
                }), m({
                    key: "checkbox2",
                    value: H.value
                }), m({
                    key: "confirm_subscribers",
                    value: ce.value ? ["news"] : []
                })
            }
            const Be = () => {
                    k({
                        category: "register_popup",
                        action: "terms"
                    })
                },
                Ce = b(() => {
                    var s;
                    return S.value === "BD" && ((s = R.value) != null && s.ENABLE_FORM_5) ? "email" : f.hideEmail ? "phone" : ""
                });

            function Re(s) {
                U.value = s
            }

            function de() {
                if (t.value = !0, c.value = !0, x("registration-submit", se.value), !B.value || !se.value) return t.value = !1, f.listeners("get:validation-error", {
                    formSubmitHandler: "formSubmitHandler missing"
                }), console.error("formSubmitHandler missing");
                B.value(async s => {
                    if (t.value = !0, f.listeners("get:validation-success", s), z.value && H.value) try {
                        const l = await n();
                        f.listeners("get:response-success", {
                            response: l == null ? void 0 : l.data,
                            formData: d.value
                        }), k({
                            category: "register_popup",
                            action: "registr_success"
                        }), h(), A(null)
                    } catch (l) {
                        console.error(l), f.listeners("get:response-error", l)
                    } finally {
                        t.value = !1
                    }
                }, s => {
                    t.value = !1, console.error("Validation errors:", s), f.listeners("get:validation-error", s)
                })()
            }
            return fe(() => {
                var s, l;
                re(), m({
                    key: "confirm_subscribers",
                    value: ["news"]
                }), (s = p.query) != null && s.has_new_password_rules ? localStorage.setItem("hasNewPasswordRules", (l = p.query) == null ? void 0 : l.has_new_password_rules.toString()) : u()
            }), (s, l) => (g(), V("div", {
                class: K(["email", e(E)])
            }, [a(Qe, {
                id: "registerForm",
                ref: "form",
                "lazy-validation": ""
            }, {
                default: i(() => [a(Le, {
                    class: "pb-0 pt-3",
                    type: "registration",
                    "hide-tabs": s.hideTabs,
                    forceTabType: e(Ce),
                    onChangeTab: Re,
                    onGetSubmitHandler: l[0] || (l[0] = _ => B.value = _),
                    onGetResetHandler: l[1] || (l[1] = _ => $.value = _),
                    "onSubmit:disabledBtn": l[2] || (l[2] = _ => F.value = _),
                    "onCheckEmail:loading": l[3] || (l[3] = _ => I.value = _)
                }, null, 8, ["hide-tabs", "forceTabType"]), W(a(Y, null, {
                    default: i(() => [a(M, {
                        class: "pb-0 pt-3"
                    }, {
                        default: i(() => [a(Me, {
                            id: "reg_select_list",
                            class: "register__currency",
                            "update-bonuses": ""
                        })]),
                        _: 1
                    })]),
                    _: 1
                }, 512), [
                    [Z, !s.hideCurrency]
                ]), a(dt), W(a(Y, {
                    class: "mt-3",
                    "no-gutters": ""
                }, {
                    default: i(() => [a(Ge, {
                        class: "register__bonuses"
                    })]),
                    _: 1
                }, 512), [
                    [Z, !e(j)]
                ]), a(Y, null, {
                    default: i(() => [e(o) ? W((g(), N(M, {
                        key: 0,
                        cols: "12",
                        "data-auto-test-el": "captcha"
                    }, {
                        default: i(() => l[5] || (l[5] = [y("div", {
                            id: "registration-captcha",
                            class: "mt-0"
                        }, null, -1)])),
                        _: 1
                    }, 512)), [
                        [Z, e(w).displayCaptcha]
                    ]) : G("", !0), a(M, {
                        cols: "12",
                        class: "justify-center pa-0"
                    }, {
                        default: i(() => [e(oe) ? (g(), V("div", ft, [(g(!0), V($e, null, Ie(e(we), (_, me) => (g(), V("div", {
                            key: me,
                            class: K(me === 0 ? "register_agreement--first" : "register_agreement--second")
                        }, [a(pe, {
                            modelValue: _.model,
                            "onUpdate:modelValue": xe => _.model = xe,
                            rules: _.rules,
                            label: _.label,
                            class: "checkbox",
                            onInput: re
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "rules", "label"])], 2))), 128))])) : (g(), V("div", mt, [a(pe, {
                            modelValue: e(L),
                            "onUpdate:modelValue": l[4] || (l[4] = _ => ge(L) ? L.value = _ : null),
                            error: !s.errorCheckBox && !e(L),
                            rules: e(ae),
                            class: "checkbox",
                            onInput: re
                        }, {
                            label: i(() => [y("div", pt, [X(C(e(v)("dialogs.registration.agreement0")) + " ", 1), a(et, {
                                location: "bottom"
                            }, {
                                activator: i(({
                                    props: _
                                }) => [y("a", ve({
                                    href: "/terms-and-conditions",
                                    target: "_blank",
                                    class: "text-color-white"
                                }, _, {
                                    onClick: Ve(Be, ["stop"])
                                }), C(e(v)("dialogs.registration.terms_of_user_agreement")), 17)]),
                                default: i(() => [l[6] || (l[6] = X(" Opens in new window "))]),
                                _: 1
                            }), e(T) ? (g(), V("br", gt)) : G("", !0), X(" " + C(e(v)("dialogs.registration.over18")), 1)])]),
                            _: 1
                        }, 8, ["modelValue", "error", "rules"])]))]),
                        _: 1
                    }), s.$slots.customButtonSubmit ? O(s.$slots, "customButtonSubmit", {
                        key: 1,
                        loading: e(t) || e(I),
                        disabled: e(F) || e(P) || !e(L) || e(I),
                        submitHandler: de,
                        dataAutoTestEl: "signUp"
                    }, void 0, !0) : (g(), N(M, {
                        key: 2,
                        cols: "12",
                        class: "pb-2 pt-0"
                    }, {
                        default: i(() => [a(le, {
                            id: "reg_signup_btn",
                            class: "social-btn",
                            color: "primary",
                            height: "47",
                            block: "",
                            loading: e(t) || e(I),
                            disabled: e(F) || e(P) || !e(se) || e(I),
                            "data-auto-test-el": "signUp",
                            onClick: de
                        }, {
                            default: i(() => [X(C(e(v)("buttons.signUp")), 1)]),
                            _: 1
                        }, 8, ["loading", "disabled"])]),
                        _: 1
                    }))]),
                    _: 3
                })]),
                _: 3
            }, 512)], 2))
        }
    }),
    _t = te(vt, [
        ["__scopeId", "data-v-3935708b"]
    ]),
    bt = {
        class: "gift gift--margin"
    },
    yt = {
        class: "gift__container"
    },
    ht = {
        class: "gift__img-box"
    },
    kt = {
        class: "gift__title mb-0"
    },
    wt = Q({
        __name: "RegistrationGiftDialog",
        setup(f) {
            const {
                t: D
            } = ee(), {
                registerForm: n,
                isSuccessRegistration: A
            } = J(q()), {
                imagePromoUrl: m
            } = ot(), {
                getWelcomeBonuses: d
            } = J(je()), {
                isMobile: v
            } = ue(), p = r(null), R = b(() => {
                var o, u, x, B, $;
                return typeof((o = n.value) == null ? void 0 : o.bonus) == "number" ? (u = n.value) == null ? void 0 : u.bonus : ((B = (x = n.value) == null ? void 0 : x.bonus) == null ? void 0 : B.id) || (($ = n.value) == null ? void 0 : $.bonus)
            }), S = b(() => A.value || !v.value && (R == null ? void 0 : R.value) !== 1 && !k.value && w.value), h = b(() => {
                var o;
                return (o = n.value) == null ? void 0 : o.currency
            }), E = b(() => {
                var o;
                return typeof h.value == "string" ? h.value : (o = h.value) == null ? void 0 : o.iso_code
            }), k = b(() => {
                var o;
                return !!((o = n.value) != null && o.isPromo)
            }), w = b(() => {
                var o;
                return !!((o = d.value) != null && o.length)
            }), P = b(() => {
                var u, x;
                const o = (u = d.value) == null ? void 0 : u.find(B => B.id === R.value);
                return o && (o != null && o.max_bonus) ? +(((x = o == null ? void 0 : o.max_bonus) == null ? void 0 : x.amount) || 0) / 100 : 0
            });
            return (o, u) => W((g(), V("div", bt, [y("div", yt, [y("div", ht, [a(st, {
                src: `${e(m)}/gift.png`,
                alt: "",
                cover: "",
                width: "65px",
                class: "gift__img lazyloaded"
            }, null, 8, ["src"])]), y("p", kt, C(e(P) || e(p)) + " " + C(e(E)) + " " + C(e(D)("labels.secondPart")), 1)])], 512)), [
                [Z, e(S)]
            ])
        }
    }),
    Bt = te(wt, [
        ["__scopeId", "data-v-a4bc51b5"]
    ]),
    Ct = {
        class: "register",
        "data-auto-test-el": "fullRegistrationModel"
    },
    Rt = {
        key: 1,
        class: "modal__form-title text-center title"
    },
    xt = {
        class: "register_or"
    },
    Pt = {
        class: "d-flex justify-center"
    },
    Dt = {
        class: "hint pr-1"
    },
    St = Q({
        __name: "RegistrationDialog",
        props: {
            listeners: {
                type: Function
            },
            freezeTypeRegistration: {},
            hideBanner: {
                type: Boolean
            },
            widthDialog: {}
        },
        emits: ["display:auth-modal"],
        setup(f, {
            emit: D
        }) {
            const n = f,
                {
                    config: A
                } = be(),
                {
                    t: m
                } = ee(),
                {
                    $googleId: d
                } = We(),
                v = D,
                {
                    googleSsoDisplay: p
                } = at("signup"),
                {
                    statisticsOpenedRegistrationDialog: R
                } = q(),
                {
                    isMobile: S
                } = ue(),
                {
                    userGeo: h
                } = J(ye()),
                {
                    trackButtonClick: E
                } = he(),
                k = _e(),
                w = b(() => {
                    var t;
                    return (t = A.value) == null ? void 0 : t.NEW_THIRD_REGISTRATION_DIALOG
                }),
                P = r(!n.hideBanner),
                o = b(() => ({
                    "content-class": "registration-dialog",
                    persistent: !0,
                    isUseCloseBtn: !0,
                    width: n.hideBanner && n.widthDialog ? n.widthDialog : 906,
                    "is-addition": P.value
                })),
                u = r(n.freezeTypeRegistration || "2"),
                x = r(!1),
                B = r(!0);

            function $(t) {
                B.value = !!t
            }
            const U = b(() => {
                var t;
                return h.value === "BD" && ((t = A.value) == null ? void 0 : t.ENABLE_FORM_5)
            });

            function F({
                value: t
            }) {
                P.value = t
            }

            function I() {
                const t = Ye("typeReg");
                if (n.freezeTypeRegistration) t.value = n.freezeTypeRegistration;
                else if (k.query.show_reg_1 || !U.value && h.value === "BD") u.value = "1", t.value = "1";
                else if (k.query.show_reg_2) t.value = "2", u.value = "2";
                else if (k.query.show_reg_3 && w.value) u.value = "3", t.value = "3";
                else if (U.value && (k.query.show_reg_5 || h.value === "BD")) u.value = "5", t.value = "5";
                else if (k.query.show_reg_6) t.value = "6", u.value = "6";
                else {
                    const c = t.value;
                    c ? u.value = c.toString() : (["IN", "MM", "BR"].includes(h.value) || !c) && (u.value = "2", t.value = "2")
                }
            }

            function j(t) {
                x.value = t
            }

            function z() {
                v("display:auth-modal"), E({
                    category: "register_popup",
                    action: "sign_in"
                })
            }

            function H(t) {
                t && R({
                    googleId: t
                })
            }
            return ie(() => n.hideBanner, t => F({
                value: !t
            })), ie(() => d, t => {
                ne(() => H(t))
            }, {
                deep: !0
            }), fe(() => {
                I(), d != null && d.value && ne(() => {
                    H(d.value)
                }), n.hideBanner || rt([F], !0)
            }), (t, c) => (g(), V("div", Ct, [a(Pe, ve(e(o), {
                "is-hide-overlay": !1,
                "is-loader-shown": e(x)
            }), {
                title: i(() => [t.$slots.customHeader ? O(t.$slots, "customHeader", {
                    key: 0
                }, void 0, !0) : e(S) ? (g(), V("h3", Rt, C(e(m)("buttons.signUp")), 1)) : G("", !0)]),
                body: i(() => [t.$slots.customBodyHeader ? O(t.$slots, "customBodyHeader", {
                    key: 0
                }, void 0, !0) : G("", !0), a(it, {
                    fluid: "",
                    class: "pa-0"
                }, {
                    default: i(() => [a(Bt), a(_t, {
                        "google-sso-display": e(p),
                        "hide-tabs": e(u).includes("2") || e(u).includes("3") || e(u).includes("5") || e(u).includes("6"),
                        "hide-email": e(u).includes("6"),
                        listeners: n.listeners,
                        "hide-currency": e(u).includes("3"),
                        "error-check-box": e(B),
                        onRegistrationSubmit: c[0] || (c[0] = T => $(T)),
                        onRegistrationRun: j
                    }, Ae({
                        _: 2
                    }, [t.$slots.customButtonSubmit ? {
                        name: "customButtonSubmit",
                        fn: i(T => [O(t.$slots, "customButtonSubmit", Ee(Fe(T)), void 0, !0)]),
                        key: "0"
                    } : void 0]), 1032, ["google-sso-display", "hide-tabs", "hide-email", "listeners", "hide-currency", "error-check-box"]), a(Y, null, {
                        default: i(() => [t.$slots.customActionsHeader ? O(t.$slots, "customActionsHeader", {
                            key: 0
                        }, void 0, !0) : G("", !0), e(p) ? (g(), N(M, {
                            key: 1,
                            cols: "12"
                        }, {
                            default: i(() => [y("div", xt, [y("span", null, C(e(m)("dialogs.registration.or")), 1)]), a(Ne, {
                                "sso-type": "signup",
                                "data-auto-test-el": "googleLoginButton",
                                text: e(m)("dialogs.registration.sign_up_with_google"),
                                onRegistrationSubmit: c[1] || (c[1] = T => $(T))
                            }, null, 8, ["text"])]),
                            _: 1
                        })) : G("", !0), a(M, {
                            cols: "12",
                            class: K([{
                                "pt-0": !e(S)
                            }, "mt-4"])
                        }, {
                            default: i(() => [y("div", Pt, [y("div", Dt, C(e(m)("labels.alreadyRegistered")), 1), y("div", {
                                id: "reg_signin_btn",
                                class: "link",
                                tabindex: "4",
                                "data-auto-test-el": "moveToAuth",
                                onClick: z
                            }, C(e(m)("buttons.signIn")), 1)])]),
                            _: 1
                        }, 8, ["class"])]),
                        _: 3
                    })]),
                    _: 3
                }), t.$slots.customBodyFooter ? O(t.$slots, "customBodyFooter", {
                    key: 1
                }, void 0, !0) : G("", !0)]),
                addition: i(() => [a(tt, {
                    title: e(m)("buttons.signUp"),
                    summary: e(m)("labels.regBanner")
                }, null, 8, ["title", "summary"])]),
                _: 3
            }, 16, ["is-loader-shown"])]))
        }
    }),
    yo = te(St, [
        ["__scopeId", "data-v-6aabc748"]
    ]);
export {
    yo as
    default
};