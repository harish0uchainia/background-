import {
    _ as Ke
} from "./CyEI51nD.js";
import {
    C as Qe,
    n as ye,
    A as Je,
    V as fe,
    _ as be,
    v as K,
    G as Q,
    t as Xe,
    h as Ye,
    z as Ze,
    f as et,
    bz as tt,
    g as ot,
    o as nt,
    p as st,
    u as at
} from "./BbvgifQp.js";
import {
    z as Se,
    b as m,
    B as ke,
    C as xe,
    _ as B,
    V as b,
    D as A,
    W as ge,
    o as lt,
    aG as rt,
    u as n,
    d as de,
    w as x,
    n as it,
    p as ct,
    U as pe,
    a8 as R,
    a0 as ut,
    F as he,
    a2 as mt,
    a1 as vt,
    a7 as _e
} from "./BBZLTf3A.js";
import ft from "./D3cdnUJq.js";
import {
    u as gt
} from "./D5xT9ef6.js";
import {
    u as dt
} from "./Cc4FcFuq.js";
import {
    u as pt
} from "./CRXlgDsv.js";
import {
    u as ht
} from "./BMZwzS6C.js";
(function() {
    try {
        var a = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            v = new a.Error().stack;
        v && (a._sentryDebugIds = a._sentryDebugIds || {}, a._sentryDebugIds[v] = "71b04fb2-8761-4bbf-a1e3-4786142efbe2", a._sentryDebugIdIdentifier = "sentry-dbid-71b04fb2-8761-4bbf-a1e3-4786142efbe2")
    } catch {}
})();
const _t = {
        class: "d-flex fullscreen-wrapper justify-end"
    },
    wt = Se({
        __name: "FullscreenButtons",
        props: {
            gameContainer: {}
        },
        setup(a) {
            const v = a,
                i = Qe(),
                d = ye(),
                {
                    mdAndUp: w
                } = Je(),
                c = m(!1),
                u = m(0),
                h = () => {
                    const l = v.gameContainer,
                        y = l.requestFullscreen || l.mozRequestFullScreen || l.webkitRequestFullscreen || l.msRequestFullscreen;
                    y && y.call(l)
                },
                f = () => {
                    const l = document,
                        y = l.exitFullscreen || l.mozCancelFullScreen || l.webkitExitFullscreen || l.msExitFullscreen;
                    y && y.call(l)
                },
                O = () => {
                    v.gameContainer && (c.value ? f() : h(), u.value = window.innerHeight, c.value = !c.value)
                },
                U = () => {
                    c.value && u.value >= window.innerHeight && (c.value = !1, u.value = window.innerHeight)
                },
                _ = () => {
                    d.push(i("/"))
                };
            return ke(() => {
                w.value && (u.value = window.innerHeight, window.addEventListener("resize", U), window.addEventListener("dblclick", f))
            }), xe(() => {
                window.removeEventListener("resize", U), window.removeEventListener("dblclick", f)
            }), (l, y) => {
                const g = Ke;
                return b(), B("div", _t, [A(fe, {
                    icon: "",
                    plain: "",
                    class: "mr-2",
                    onClick: O
                }, {
                    default: ge(() => [A(g, {
                        size: 32,
                        height: 32,
                        "symbol-id": "fullscreen"
                    })]),
                    _: 1
                }), A(fe, {
                    icon: "",
                    plain: "",
                    onClick: _
                }, {
                    default: ge(() => [A(g, {
                        size: 32,
                        height: 32,
                        "symbol-id": "close-window"
                    })]),
                    _: 1
                })])
            }
        }
    }),
    yt = be(wt, [
        ["__scopeId", "data-v-6517637a"]
    ]);

function we(a, v) {
    return new Promise((i, d) => {
        ((w, c, u) => {
            const h = w.createElement(c);
            w.getElementById(u.toString()) || (h.id = u.toString(), h.src = a, document.body.appendChild(h), h.onload = i, h.onerror = d, h.async = !0)
        })(document, "script", v)
    })
}

function bt() {
    const {
        runningGameData: a,
        isTvBetSlot: v
    } = K(Q());
    return {
        runningGameData: a,
        isTvBetSlot: v
    }
}

function St({
    el: a,
    cb: v,
    event: i
}) {
    function d(f) {
        f.preventDefault(), f.stopPropagation(), f.stopImmediatePropagation(), v(f)
    }

    function w() {
        window.removeEventListener(i, d, !0)
    }

    function c() {
        window.addEventListener(i, d, !0)
    }

    function u() {
        if (a.value) {
            a.value.style.pointerEvents = "none";
            for (const f of a.value.children) f.style.pointerEvents = "none";
            c()
        }
    }

    function h() {
        if (w(), a.value) {
            a.value.style.pointerEvents = "auto";
            for (const f of a.value.children) f.style.pointerEvents = "auto"
        }
    }
    return lt(() => {
        w()
    }), {
        initEventLocker: u,
        removeGlobalEventLocker: w,
        addGlobalEventLocker: c,
        killEventLocker: h
    }
}
const kt = ["src", "allow"],
    xt = ["srcdoc", "allow"],
    Bt = ["src", "allow"],
    Et = {
        key: 1,
        class: "iframe-wrapper mb-5 mx-5 px-5 py-5"
    },
    Gt = Se({
        __name: "SlotsGamePage",
        setup(a) {
            rt(e => ({
                "1a3fb500": n(Be),
                "3f43f208": n(Ee)
            }));
            const v = ye(),
                i = Xe(),
                d = Ye(),
                {
                    $localePath: w
                } = Ze(),
                {
                    dialogName: c,
                    openDialog: u
                } = et(),
                {
                    checkBonusOnGameStart: h
                } = tt(),
                {
                    isMobile: f,
                    isDesktop: O
                } = dt(),
                {
                    fetchCurrentSectionSlots: U
                } = pt(),
                _ = m(""),
                l = m(null),
                y = m(null),
                g = m(""),
                I = m(""),
                Be = m("44px"),
                Ee = m("57px"),
                E = m(!1),
                J = m(!1),
                X = m(!1),
                C = m(!1),
                Ge = [24168, 15478],
                Le = [135, 163],
                {
                    fetchUrlPromoGame: Ce,
                    slotUrl: T,
                    letPlayGame: Y,
                    externalProviderId: Z,
                    setPlayGame: D,
                    setSlotUrl: ee,
                    setIsTvBetSlot: te,
                    saveRunningGameData: De,
                    getGameData: Pe,
                    getTokenSlot: oe,
                    initTvBet: ne
                } = ht(),
                {
                    runningGameData: z,
                    isTvBetSlot: Fe
                } = bt(),
                {
                    setErrorStartGame: Re
                } = Q(),
                {
                    errorStartGame: Ue
                } = K(Q()),
                {
                    isAuthenticated: S
                } = ot(),
                {
                    userUUID: se
                } = gt(),
                {
                    currentBonusId: ae
                } = K(nt()),
                W = m(null),
                j = de(() => i.query.gsp),
                {
                    isGoogleBot: Ie,
                    hashLink: Te,
                    appDefaultCurrency: ze
                } = st(),
                le = m(null),
                {
                    config: Ne
                } = at(),
                $e = de(() => {
                    var e;
                    return E.value && Ge.includes(+(((e = z.value) == null ? void 0 : e.id) || 0)) ? "pf" : "pa"
                }),
                P = e => o => {
                    !o && !S.value && e()
                },
                He = e => o => {
                    o && e()
                },
                N = e => {
                    u(e, {
                        gsp: !0
                    })
                },
                {
                    initEventLocker: qe,
                    removeGlobalEventLocker: $,
                    addGlobalEventLocker: H,
                    killEventLocker: Ae
                } = St({
                    el: le,
                    event: "click",
                    cb(e) {
                        var p;
                        const o = e.target,
                            r = ["auth_btn", "reg_btn"],
                            s = (p = o.closest("[data-ignore-event-locker]")) == null ? void 0 : p.id;
                        if (!S.value && r.includes(s)) {
                            N(s === "auth_btn" ? "auth" : "registration"), $(), q();
                            const G = x(() => c.value, P(() => {
                                H(), G()
                            }));
                            return
                        }
                        u("yesNoDialog", {
                            message: d.t("dialogs.gameSlotPromo.message"),
                            yesText: d.t("dialogs.gameSlotPromo.signIn"),
                            yes() {
                                N("auth"), $(), q();
                                const k = x(() => c.value, P(() => {
                                    H(), k()
                                }))
                            },
                            noText: d.t("dialogs.gameSlotPromo.signUp"),
                            no() {
                                N("registration"), $(), q();
                                const k = x(() => c.value, P(() => {
                                    H(), k()
                                }))
                            }
                        }), $();
                        const t = x(() => c.value, P(() => {
                            H(), t()
                        }))
                    }
                });

            function F(e = "") {
                if (e.startsWith("softswiss:")) {
                    const o = atob(e.slice(10));
                    _.value = i.fullPath, l.value = o
                } else if (e.startsWith("softgaming:")) {
                    const o = e.slice(11);
                    let r = atob(o);
                    r = r + `
    <style>
      * { margin: 0; padding: 0; box-sizing: border-box; }
      html, body { width: 100%; height: 100%; }
    </style>`;
                    const t = new Blob([r], {
                            type: "text/html"
                        }),
                        p = URL.createObjectURL(t);
                    y.value = p
                } else _.value = e
            }

            function q() {
                const e = x(() => S.value, He(() => {
                    Ae(), _.value = "", l.value = null, e()
                }))
            }

            function Oe() {
                var o;
                if (S.value || (o = i.query) != null && o.login) return;
                N("registration"), q();
                const e = x(() => c.value, P(() => {
                    S.value || qe(), e()
                }))
            }
            async function We({
                currency: e,
                balance: o,
                isAviator: r = !1
            }) {
                Oe();
                let s;
                r ? s = {
                    url: `https://demo.spribe.io/launch/aviator?currency=${e}&lang=${d.locale.value}`
                } : s = await Ce({
                    id: g.value,
                    lang: d.locale.value,
                    balance: o,
                    currency: e
                }), D(!0), F(s == null ? void 0 : s.url)
            }

            function re(e) {
                _.value || F(e)
            }
            async function ie() {
                var o, r, s;
                const e = {
                    demo: !!((o = i.query) != null && o.demo)
                };
                try {
                    const t = await Pe(g.value, e).catch(p => {
                        if (Ue.value) {
                            u("slotBonusBlock"), Re(!1);
                            return
                        }
                        throw v.push(w("/")), console.error("Failed to get game", p == null ? void 0 : p.toString()), p
                    });
                    if (!t) return;
                    if (z.value || h(), ((r = t == null ? void 0 : t.options) == null ? void 0 : r.allow_fullscreen) === 1 && (C.value = !0), (t == null ? void 0 : t.provider) === "tvbet") {
                        te(!0), E.value = !0;
                        const p = document.getElementsByTagName("script");
                        let k = !1;
                        for (const L of p) k = L.src.includes("/assets/frame.js");
                        const G = new URL(t == null ? void 0 : t.url).origin;
                        k ? (we(`${G}/assets/frame.js`, "tvbet-game"), ne(t == null ? void 0 : t.token, t == null ? void 0 : t.url, t == null ? void 0 : t.external_id)) : we(`${G}/assets/frame.js`, "tvbet-game").then(() => {
                            ne(t == null ? void 0 : t.token, t == null ? void 0 : t.url, t == null ? void 0 : t.external_id)
                        }).catch(L => {
                            console.error(L, "tvbet load error")
                        })
                    } else if (!(t != null && t.is_wager_playable) && !((s = T.value) != null && s.length) && ae.value) {
                        if (F(t == null ? void 0 : t.url), Ne.value.SLOT_BONUS_BLOCK) {
                            if (!z.value || !Y.value) return u("slotBonusBlock");
                            D(!0), re(t == null ? void 0 : t.url);
                            return
                        }
                        return u("wagerNoPossible")
                    } else D(!0), F(t == null ? void 0 : t.url), re(t == null ? void 0 : t.url)
                } catch (t) {
                    console.error("getGameUrl", t), I.value || (I.value = "Cannot get game url")
                }
            }

            function M() {
                var o, r, s;
                const {
                    demo: e
                } = i.query;
                if (!S.value && !Te.value && !Ie.value && !e && !j.value) {
                    const t = (o = g.value) != null && o.includes("aviator") ? "registration" : "auth";
                    u(t)
                } else(se.value || e) && (T.value && T.value.length > 0 && !i.path.includes("tv-games") && !Fe.value ? (C.value = ((s = (r = z.value) == null ? void 0 : r.options) == null ? void 0 : s.allow_fullscreen) === 1, F(T.value)) : oe().then(() => {
                    ie()
                }))
            }

            function je() {
                var e;
                J.value = (e = i.params.id) == null ? void 0 : e.includes("aviator"), g.value = i.params.id
            }

            function ce() {
                const e = window.innerHeight * .01;
                document.documentElement.style.setProperty("--vh", `${e}px`)
            }

            function ue() {
                ce()
            }
            x(() => c.value, (e, o) => {
                j.value || e !== o && !S.value && e === null && v.push(w("/"))
            }), x(() => se.value, (e, o) => {
                e !== o && Number(e) && !X.value ? oe().then(() => {
                    ie()
                }) : e !== o && M()
            }), x(() => ae.value, (e, o) => {
                e !== o && (_.value = "", ee(""), M())
            }), je();

            function me(e = !0) {
                const o = document.querySelector(".default-template"),
                    r = document.documentElement,
                    s = o == null ? void 0 : o.classList.contains("default-template_is-not-auth");
                !f.value || !o || (e && !s ? o.classList.add("pt-0") : e || o.classList.remove("pt-0"), r.classList[e ? "add" : "remove"]("overflow-hidden"))
            }
            return ke(async () => {
                U(), X.value = !0, await it(), window.addEventListener("resize", ue);
                const {
                    demo: e,
                    show_reg: o,
                    show_reg_1: r,
                    show_reg_2: s,
                    show_reg_3: t,
                    show_reg_5: p,
                    show_reg_6: k,
                    val_cur: G,
                    balance: L
                } = i.query, Me = (o || r || s || t || p || k) && G, ve = g.value === "18613" || g.value === "18612" || g.value === "48204" || g.value === "aviator" || g.value && g.value.includes("aviator") || !1;
                if (Me && j.value && !S.value && L) return We({
                    currency: G,
                    balance: L,
                    isAviator: ve
                });
                if (ce(), !S.value && ve && e) {
                    const V = d.locale.value,
                        Ve = `currency=${ze.value}&lang=${V==null?void 0:V.toUpperCase()}`;
                    D(!0), _.value = `https://demo.spribe.io/launch/aviator?${Ve}`;
                    return
                }
                M(), me(!0)
            }), ct(() => {
                window.removeEventListener("resize", ue)
            }), xe(() => {
                _.value = "", g.value = "", l.value = null, E.value = !1, J.value = !1, D(!1), te(!1), ee(""), De(null);
                for (const e of document.scripts) e.src.includes("/assets/frame.js") && e.remove();
                me(!1)
            }), (e, o) => {
                const r = yt,
                    s = ft;
                return b(), B("div", {
                    ref_key: "gameSlotRoot",
                    ref: le
                }, [n(O) && n(W) ? (b(), pe(r, {
                    key: 0,
                    "game-container": n(W)
                }, null, 8, ["game-container"])) : R("", !0), ut("div", {
                    ref_key: "gameContainer",
                    ref: W,
                    class: _e(["iframe-wrapper", {
                        tvbet: n(E),
                        "height-unset": n(Z) && Le.includes(n(Z))
                    }])
                }, [!n(E) && (n(_) || n(y) || n(l)) && n(Y) ? (b(), B(he, {
                    key: 0
                }, [n(y) ? (b(), B("iframe", {
                    key: 0,
                    src: n(y),
                    height: "100%",
                    class: "iframe-game",
                    title: "soft-gaming",
                    allow: n(C) ? "fullscreen" : ""
                }, null, 8, kt)) : R("", !0), n(l) ? (b(), B("iframe", {
                    key: 1,
                    srcdoc: n(l),
                    height: "100%",
                    class: "iframe-game",
                    title: "soft-swiss",
                    allow: n(C) ? "fullscreen" : ""
                }, null, 8, xt)) : (b(), B("iframe", {
                    key: 2,
                    src: n(_),
                    height: "100%",
                    class: "iframe-game",
                    title: "tv-games",
                    allow: n(C) ? "fullscreen" : ""
                }, null, 8, Bt))], 64)) : R("", !0), !n(E) && !n(_) ? (b(), B("h2", Et, [n(I) ? (b(), B(he, {
                    key: 0
                }, [mt(vt(n(I)), 1)], 64)) : (b(), pe(s, {
                    key: 1
                }))])) : R("", !0), n(E) ? (b(), B("div", {
                    key: 2,
                    id: "tv-bet",
                    class: _e(n($e))
                }, null, 2)) : R("", !0)], 2)], 512)
            }
        }
    }),
    zt = be(Gt, [
        ["__scopeId", "data-v-3c2a3a3a"]
    ]);
export {
    zt as _
};