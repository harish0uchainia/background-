import {
    _ as o
} from "./BbvgifQp.js";
import {
    _ as i,
    V as l,
    a0 as n,
    a7 as g
} from "./BBZLTf3A.js";
(function() {
    try {
        var t = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            s = new t.Error().stack;
        s && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[s] = "fdf62705-44eb-4d4a-b857-f5914bfdd2d6", t._sentryDebugIdIdentifier = "sentry-dbid-fdf62705-44eb-4d4a-b857-f5914bfdd2d6")
    } catch {}
})();
const c = "" + new URL("bank.omFFurDF.svg",
        import.meta.url).href,
    d = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: c
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    _ = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20512%20512'%20fill='%23859cba'%20%3e%3cpath%20d='M467.812%20431.851l-36.629-61.056a181.363%20181.363%200%200%201-25.856-93.312V224c0-67.52-45.056-124.629-106.667-143.04V42.667C298.66%2019.136%20279.524%200%20255.993%200s-42.667%2019.136-42.667%2042.667V80.96C151.716%2099.371%20106.66%20156.48%20106.66%20224v53.483c0%2032.853-8.939%2065.109-25.835%2093.291L44.196%20431.83a10.653%2010.653%200%200%200-.128%2010.752c1.899%203.349%205.419%205.419%209.259%205.419H458.66c3.84%200%207.381-2.069%209.28-5.397%201.899-3.329%201.835-7.468-.128-10.753zM188.815%20469.333C200.847%20494.464%20226.319%20512%20255.993%20512s55.147-17.536%2067.179-42.667H188.815z'/%3e%3c/svg%3e",
    v = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: _
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    u = "data:image/svg+xml,%3csvg%20width='12'%20height='13'%20viewBox='0%200%2012%2013'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M1%2011.0888L11%201.08881M1%201.08881L11%2011.0888'%20stroke='%237198BF'%20stroke-width='2'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e",
    f = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: u
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    m = "data:image/svg+xml,%3csvg%20width='12'%20height='12'%20viewBox='0%200%209%209'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M9%204.5C9%206.98528%206.98528%209%204.5%209C2.01472%209%200%206.98528%200%204.5C0%202.01472%202.01472%200%204.5%200C6.98528%200%209%202.01472%209%204.5Z'%20fill='%23141922'/%3e%3cpath%20opacity='0.9'%20d='M9%204.5C9%206.98528%206.98528%209%204.5%209C2.01472%209%200%206.98528%200%204.5C0%202.01472%202.01472%200%204.5%200C6.98528%200%209%202.01472%209%204.5Z'%20fill='white'/%3e%3cpath%20fill-rule='evenodd'%20clip-rule='evenodd'%20d='M4.41432%205.89703C4.27784%206.0237%204.06056%206.03487%203.90984%205.92296L2.14218%204.61047C1.97882%204.48917%201.95233%204.26793%202.08302%204.11631C2.21371%203.96469%202.45208%203.94011%202.61544%204.06141L4.11836%205.17733L6.35336%203.10297C6.50128%202.96568%206.74112%202.96568%206.88905%203.10297C7.03698%203.24027%207.03698%203.46287%206.88905%203.60017L4.41432%205.89703Z'%20fill='%23038508'/%3e%3c/svg%3e",
    h = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: m
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    b = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20512%20512'%20fill='%23859cba'%20%3e%3cpath%20d='M248.158%20343.22c-14.639%200-26.491%2012.2-26.491%2026.84%200%2014.291%2011.503%2026.84%2026.491%2026.84s26.84-12.548%2026.84-26.84c0-14.64-12.199-26.84-26.84-26.84zm4.532-203.218c-47.057%200-68.668%2027.885-68.668%2046.708%200%2013.595%2011.502%2019.869%2020.914%2019.869%2018.822%200%2011.154-26.84%2046.708-26.84%2017.429%200%2031.372%207.669%2031.372%2023.703%200%2018.824-19.52%2029.629-31.023%2039.389-10.108%208.714-23.354%2023.006-23.354%2052.983%200%2018.125%204.879%2023.354%2019.171%2023.354%2017.08%200%2020.565-7.668%2020.565-14.291%200-18.126.35-28.583%2019.521-43.571%209.411-7.32%2039.04-31.023%2039.04-63.789s-29.629-57.515-74.246-57.515z'%20/%3e%3cpath%20d='M256%200C114.516%200%200%20114.497%200%20256v236c0%2011.046%208.954%2020%2020%2020h236c141.483%200%20256-114.497%20256-256C512%20114.516%20397.503%200%20256%200zm0%20472H40V256c0-119.377%2096.607-216%20216-216%20119.377%200%20216%2096.607%20216%20216%200%20119.377-96.607%20216-216%20216z'%20/%3e%3c/svg%3e",
    p = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: b
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    a = "" + new URL("sprite.CfzK5AaZ.svg",
        import.meta.url).href,
    y = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: a
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    w = Object.assign({
        "/layers/nuxt-shared-service/assets/img/svg-sprite/bank.svg": d,
        "/layers/nuxt-shared-service/assets/img/svg-sprite/bell.svg": v,
        "/layers/nuxt-shared-service/assets/img/svg-sprite/close.svg": f,
        "/layers/nuxt-shared-service/assets/img/svg-sprite/confirmed.svg": h,
        "/layers/nuxt-shared-service/assets/img/svg-sprite/question_icon.svg": p,
        "/layers/nuxt-shared-service/assets/img/svg-sprite/sprite.svg": y
    }),
    x = /^\/node_modules\/\.c12\/[^/]+|^\.\.\/nuxt-shared-service|^\/layers\/nuxt-shared-service/,
    S = Object.fromEntries(Object.entries(w).map(([t, s]) => [t.replace(x, ""), s])),
    C = {
        name: "VSvgSprite",
        props: {
            size: {
                type: Number,
                default: 24
            },
            tag: {
                type: String,
                default: "svg"
            },
            height: {
                type: Number,
                default: 0
            },
            symbolId: {
                type: String,
                required: !0
            },
            tagUseClassName: {
                type: String,
                default: ""
            }
        },
        methods: {
            getSvgSprite() {
                return a
            },
            getImage(t) {
                const s = S[`/assets/img/svg-sprite/${t}`];
                return s ? s.default : t
            }
        }
    },
    z = ["height", "width", "src", "alt"],
    j = ["height", "width"],
    M = ["href"];

function O(t, s, e, k, I, r) {
    return e.tag === "img" ? (l(), i("img", {
        key: 0,
        class: "svg-sprite__img",
        height: e.height || e.size,
        width: e.size,
        src: r.getImage(e.symbolId),
        alt: e.symbolId
    }, null, 8, z)) : (l(), i("svg", {
        key: 1,
        height: e.height || e.size,
        width: e.size,
        class: "svg-sprite__svg"
    }, [n("use", {
        class: g(e.tagUseClassName),
        href: `${r.getSvgSprite()}#${e.symbolId}`
    }, null, 10, M)], 8, j))
}
const V = o(C, [
    ["render", O]
]);
export {
    V as _, a as s
};