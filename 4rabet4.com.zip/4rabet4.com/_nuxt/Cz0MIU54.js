import {
    a as i,
    m as R,
    d as w
} from "./CNgVgUb9.js";
import {
    a as _,
    b as h,
    c as A
} from "./iTYf75jB.js";
import {
    U as D,
    W as S,
    a8 as k,
    a7 as B,
    a4 as C,
    a9 as E,
    ab as f,
    aa as F,
    u as T
} from "./BbvgifQp.js";
import {
    d as p,
    D as l,
    J as c,
    F as U
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            a = new e.Error().stack;
        a && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[a] = "8f96fc1a-485b-46fa-a5bf-b0399a2def7e", e._sentryDebugIdIdentifier = "sentry-dbid-8f96fc1a-485b-46fa-a5bf-b0399a2def7e")
    } catch {}
})();
const M = S({
        height: {
            type: [Number, String],
            default: "auto"
        },
        ...R(),
        ...F(h(), ["multiple"]),
        trueIcon: {
            type: f,
            default: "$radioOn"
        },
        falseIcon: {
            type: f,
            default: "$radioOff"
        },
        type: {
            type: String,
            default: "radio"
        }
    }, "VRadioGroup"),
    W = D()({
        name: "VRadioGroup",
        inheritAttrs: !1,
        props: M(),
        emits: {
            "update:modelValue": e => !0
        },
        setup(e, a) {
            let {
                attrs: n,
                slots: t
            } = a;
            const m = k(),
                d = p(() => e.id || `radio-group-${m}`),
                o = B(e, "modelValue");
            return C(() => {
                const [b, y] = E(n), V = i.filterProps(e), g = _.filterProps(e), r = t.label ? t.label({
                    label: e.label,
                    props: {
                        for: d.value
                    }
                }) : e.label;
                return l(i, c({
                    class: ["v-radio-group", e.class],
                    style: e.style
                }, b, V, {
                    modelValue: o.value,
                    "onUpdate:modelValue": s => o.value = s,
                    id: d.value
                }), { ...t,
                    default: s => {
                        let {
                            id: u,
                            messagesId: I,
                            isDisabled: v,
                            isReadonly: P
                        } = s;
                        return l(U, null, [r && l(w, {
                            id: u.value
                        }, {
                            default: () => [r]
                        }), l(A, c(g, {
                            id: u.value,
                            "aria-describedby": I.value,
                            defaultsTarget: "VRadio",
                            trueIcon: e.trueIcon,
                            falseIcon: e.falseIcon,
                            type: e.type,
                            disabled: v.value,
                            readonly: P.value,
                            "aria-labelledby": r ? u.value : void 0,
                            multiple: !1
                        }, y, {
                            modelValue: o.value,
                            "onUpdate:modelValue": G => o.value = G
                        }), t)])
                    }
                })
            }), {}
        }
    });

function H() {
    const {
        config: e
    } = T();
    return {
        showTopBar: p(() => !!e.value.SHOW_GAME_IN_IFRAME)
    }
}
export {
    W as V, H as u
};