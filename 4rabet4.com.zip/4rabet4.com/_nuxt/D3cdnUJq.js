import {
    z as d,
    _ as t,
    V as s,
    a0 as o,
    F as i,
    a9 as l,
    a7 as c
} from "./BBZLTf3A.js";
import {
    _ as f
} from "./BbvgifQp.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "80a15f3d-f11e-4bbf-9d9b-f906411799c2", e._sentryDebugIdIdentifier = "sentry-dbid-80a15f3d-f11e-4bbf-9d9b-f906411799c2")
    } catch {}
})();
const _ = {
        class: "lds-spinner"
    },
    p = d({
        __name: "LoaderSpinner",
        props: {
            inButton: {},
            isGlobal: {}
        },
        setup(e) {
            const n = e;
            return (a, u) => (s(), t("div", {
                class: c(["loader text-center", {
                    "loader_in-button": n.inButton,
                    loader_global: n.isGlobal
                }])
            }, [o("div", _, [(s(), t(i, null, l(12, r => o("div", {
                key: r
            })), 64))])], 2))
        }
    }),
    y = f(p, [
        ["__scopeId", "data-v-89890ea4"]
    ]);
export {
    y as
    default
};