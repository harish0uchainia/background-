import {
    z as $,
    u as j,
    v as i,
    k as q,
    G as H,
    w as J
} from "./BbvgifQp.js";
import {
    d as o
} from "./BBZLTf3A.js";
(function() {
    try {
        var u = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            r = new u.Error().stack;
        r && (u._sentryDebugIds = u._sentryDebugIds || {}, u._sentryDebugIds[r] = "f83ac0c3-908d-4231-8e45-e78c7e5dfe87", u._sentryDebugIdIdentifier = "sentry-dbid-f83ac0c3-908d-4231-8e45-e78c7e5dfe87")
    } catch {}
})();

function W() {
    const u = $();
    j();
    const r = i(q()),
        l = i(H()),
        c = i(J()),
        m = o(() => {
            var e;
            return (e = u.$isAuthenticated) == null ? void 0 : e.value
        }),
        t = o(() => r.profileForm.value),
        p = o(() => t.value),
        _ = o(() => {
            var e, s;
            return ((s = (e = t == null ? void 0 : t.value) == null ? void 0 : e.meta) == null ? void 0 : s.selected_bonus_id) ? ? null
        }),
        y = o(() => {
            var s;
            const e = t.value;
            return ((s = e == null ? void 0 : e.info) == null ? void 0 : s.uuid) != null
        }),
        g = o(() => l.selectedSlot.value),
        F = o(() => {
            var e, s;
            return (s = (e = r.profileForm.value) == null ? void 0 : e.meta) == null ? void 0 : s.is_fake
        }),
        a = o(() => c.userGeo.value),
        I = o(() => {
            var e, s;
            return (s = (e = t.value) == null ? void 0 : e.info) == null ? void 0 : s.country
        }),
        b = o(() => {
            var e, s;
            return (s = (e = t.value) == null ? void 0 : e.info) == null ? void 0 : s.city
        }),
        D = o(() => {
            var e, s;
            return (s = (e = t.value) == null ? void 0 : e.info) == null ? void 0 : s.first_name
        }),
        h = o(() => {
            var e, s;
            return (s = (e = t.value) == null ? void 0 : e.info) == null ? void 0 : s.last_name
        }),
        S = o(() => {
            var e, s;
            return (s = (e = t.value) == null ? void 0 : e.info) == null ? void 0 : s.email
        }),
        C = o(() => {
            var e, s, n;
            return (n = (s = (e = t.value) == null ? void 0 : e.info) == null ? void 0 : s.phone) == null ? void 0 : n.code
        }),
        U = o(() => {
            var e, s, n;
            return (n = (s = (e = t.value) == null ? void 0 : e.info) == null ? void 0 : s.phone) == null ? void 0 : n.phone
        }),
        w = o(() => {
            var e, s;
            return (s = (e = t.value) == null ? void 0 : e.info) == null ? void 0 : s.gender
        }),
        B = o(() => {
            var e, s;
            return (s = (e = r.profileForm.value) == null ? void 0 : e.meta) == null ? void 0 : s.is_vip
        }),
        k = o(() => {
            var e, s;
            return (s = (e = r.profileForm.value) == null ? void 0 : e.info) == null ? void 0 : s.birth
        }),
        A = o(() => {
            var e, s;
            return (s = (e = r.profileForm.value) == null ? void 0 : e.info) == null ? void 0 : s.uuid
        }),
        d = o(() => r.userCurrency.value),
        G = o(() => {
            var e, s;
            return (s = (e = r.profileForm.value) == null ? void 0 : e.meta) == null ? void 0 : s.mirror_id
        }),
        f = o(() => r.registerForm.value),
        L = o(() => r.isLoadedLogout.value),
        P = o(() => {
            var e;
            return (e = f.value) == null ? void 0 : e.currency
        }),
        N = o(() => {
            var e;
            return (e = t.value) == null ? void 0 : e.info.uuid
        }),
        R = o(() => {
            var e, s, n;
            return (n = (s = (e = t.value) == null ? void 0 : e.balance) == null ? void 0 : s.total_deposit) == null ? void 0 : n.amount
        }),
        V = o(() => {
            var e, s;
            return (s = (e = t.value) == null ? void 0 : e.meta) == null ? void 0 : s.selected_bonus_id
        }),
        x = o(() => {
            var e, s;
            return (s = (e = t.value) == null ? void 0 : e.meta) == null ? void 0 : s.registered_via_google
        }),
        E = o(() => {
            var e, s, n, v;
            return ["pending_recommended", "self_verified", "canceled", "pending_recommended", "self_verified", "fail_recommended"].includes((s = (e = t.value) == null ? void 0 : e.meta) == null ? void 0 : s.verification_status) ? !1 : !!((v = (n = t.value) == null ? void 0 : n.meta) != null && v.verification_status)
        }),
        O = o(() => {
            var e, s;
            return ["pending_recommended", "self_verified"].includes((s = (e = t.value) == null ? void 0 : e.meta) == null ? void 0 : s.verification_status)
        }),
        T = o(() => t.value && t.value.meta && t.value.meta.casino_access || !1),
        z = o(() => d.value || c.defaultCurrency.value),
        M = o(() => a.value ? ["IN", "BD"].includes(a.value) : !1);
    return {
        userCurrency: d,
        userCountry: I,
        userProfileForm: p,
        userCity: b,
        userFirstName: D,
        userLastName: h,
        userEmail: S,
        userTelCountryCode: C,
        userPhone: U,
        userGender: w,
        displayVerifyInfoBlock: E,
        displayVerifyRecommendedInfoBlock: O,
        isUserRegisteredViaGoogle: x,
        userRegistrationForm: f,
        currencyRegistrationForm: P,
        userUUID: A,
        isAuthenticated: m,
        isUserDataLoaded: y,
        isUserFake: F,
        selectedBonusId: _,
        userMirrorId: G,
        canAccessCasinoForUserPages: T,
        userProfileId: N,
        userDepositAmount: R,
        userBonusSelected: V,
        userDefaultCurrency: z,
        isUserLoadedLogout: L,
        selectedSlot: g,
        isUserVip: B,
        userGeo: a,
        showOnlyForINOrBD: M,
        userBirth: k,
        profileForm: t
    }
}
export {
    W as u
};