import {
    D as h,
    J as H,
    L as me,
    b as W,
    d as T,
    w as V,
    o as q,
    n as ie,
    l as we,
    e as De,
    i as He,
    y as D,
    B as ft,
    r as We,
    O as vt,
    I as dt,
    c as gt,
    t as qe,
    p as pe,
    aB as mt,
    Y as ye,
    ae as $e,
    ar as je,
    F as Ye,
    av as yt
} from "./BBZLTf3A.js";
import {
    a as Q,
    g as Ue,
    n as Xe,
    b as ht,
    d as bt,
    s as he,
    B as ue,
    c as Oe,
    m as Ge,
    M as Z
} from "./CbxP4vag.js";
import {
    aX as Ke,
    b5 as Je,
    U as ee,
    W as p,
    aQ as j,
    aR as Ee,
    b6 as St,
    b7 as Ae,
    b8 as fe,
    b9 as ve,
    ba as Te,
    bb as Be,
    aI as z,
    aO as _e,
    bc as wt,
    aE as le,
    bd as Re,
    aT as Et,
    A as xt,
    ad as Qe,
    a5 as Ze,
    Y as se,
    a7 as Pt,
    ag as et,
    a2 as kt,
    aK as tt,
    a3 as nt,
    be as Ct,
    a4 as ce,
    bf as Ot,
    ap as at,
    b4 as At,
    ax as ot,
    al as Tt,
    am as Bt,
    an as _t,
    aq as Rt,
    at as Ft,
    l as Vt,
    au as Lt,
    ac as It,
    X as Mt,
    av as Nt,
    aA as zt,
    aB as Dt,
    ab as Ht
} from "./BbvgifQp.js";
import {
    m as Wt,
    u as qt
} from "./Q3GHUzCg.js";
import {
    u as pt
} from "./B9YIqgoQ.js";
import {
    C as $t,
    I as jt
} from "./BEPDeFGu.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "1ab0045e-0f86-46b3-84f4-87824232bc32", e._sentryDebugIdIdentifier = "sentry-dbid-1ab0045e-0f86-46b3-84f4-87824232bc32")
    } catch {}
})();
const ne = new WeakMap;

function Yt(e, n) {
    Object.keys(n).forEach(t => {
        if (Ke(t)) {
            const a = Je(t),
                r = ne.get(e);
            if (n[t] == null) r == null || r.forEach(l => {
                const [s, o] = l;
                s === a && (e.removeEventListener(a, o), r.delete(l))
            });
            else if (!r || ![...r].some(l => l[0] === a && l[1] === n[t])) {
                e.addEventListener(a, n[t]);
                const l = r || new Set;
                l.add([a, n[t]]), ne.has(e) || ne.set(e, l)
            }
        } else n[t] == null ? e.removeAttribute(t) : e.setAttribute(t, n[t])
    })
}

function Ut(e, n) {
    Object.keys(n).forEach(t => {
        if (Ke(t)) {
            const a = Je(t),
                r = ne.get(e);
            r == null || r.forEach(l => {
                const [s, o] = l;
                s === a && (e.removeEventListener(a, o), r.delete(l))
            })
        } else e.removeAttribute(t)
    })
}

function Xt(e) {
    let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
    for (; e;) {
        if (n ? Gt(e) : xe(e)) return e;
        e = e.parentElement
    }
    return document.scrollingElement
}

function oe(e, n) {
    const t = [];
    if (n && e && !n.contains(e)) return t;
    for (; e && (xe(e) && t.push(e), e !== n);) e = e.parentElement;
    return t
}

function xe(e) {
    if (!e || e.nodeType !== Node.ELEMENT_NODE) return !1;
    const n = window.getComputedStyle(e);
    return n.overflowY === "scroll" || n.overflowY === "auto" && e.scrollHeight > e.clientHeight
}

function Gt(e) {
    if (!e || e.nodeType !== Node.ELEMENT_NODE) return !1;
    const n = window.getComputedStyle(e);
    return ["scroll", "auto"].includes(n.overflowY)
}

function Kt(e) {
    for (; e;) {
        if (window.getComputedStyle(e).position === "fixed") return !0;
        e = e.offsetParent
    }
    return !1
}
const Jt = p({
        target: [Object, Array]
    }, "v-dialog-transition"),
    Fn = ee()({
        name: "VDialogTransition",
        props: Jt(),
        setup(e, n) {
            let {
                slots: t
            } = n;
            const a = {
                onBeforeEnter(r) {
                    r.style.pointerEvents = "none", r.style.visibility = "hidden"
                },
                async onEnter(r, l) {
                    var w;
                    await new Promise(g => requestAnimationFrame(g)), await new Promise(g => requestAnimationFrame(g)), r.style.visibility = "";
                    const {
                        x: s,
                        y: o,
                        sx: u,
                        sy: f,
                        speed: i
                    } = Ve(e.target, r), b = Q(r, [{
                        transform: `translate(${s}px, ${o}px) scale(${u}, ${f})`,
                        opacity: 0
                    }, {}], {
                        duration: 225 * i,
                        easing: bt
                    });
                    (w = Fe(r)) == null || w.forEach(g => {
                        Q(g, [{
                            opacity: 0
                        }, {
                            opacity: 0,
                            offset: .33
                        }, {}], {
                            duration: 225 * 2 * i,
                            easing: he
                        })
                    }), b.finished.then(() => l())
                },
                onAfterEnter(r) {
                    r.style.removeProperty("pointer-events")
                },
                onBeforeLeave(r) {
                    r.style.pointerEvents = "none"
                },
                async onLeave(r, l) {
                    var w;
                    await new Promise(g => requestAnimationFrame(g));
                    const {
                        x: s,
                        y: o,
                        sx: u,
                        sy: f,
                        speed: i
                    } = Ve(e.target, r);
                    Q(r, [{}, {
                        transform: `translate(${s}px, ${o}px) scale(${u}, ${f})`,
                        opacity: 0
                    }], {
                        duration: 125 * i,
                        easing: ht
                    }).finished.then(() => l()), (w = Fe(r)) == null || w.forEach(g => {
                        Q(g, [{}, {
                            opacity: 0,
                            offset: .2
                        }, {
                            opacity: 0
                        }], {
                            duration: 125 * 2 * i,
                            easing: he
                        })
                    })
                },
                onAfterLeave(r) {
                    r.style.removeProperty("pointer-events")
                }
            };
            return () => e.target ? h(me, H({
                name: "dialog-transition"
            }, a, {
                css: !1
            }), t) : h(me, {
                name: "dialog-transition"
            }, t)
        }
    });

function Fe(e) {
    var t;
    const n = (t = e.querySelector(":scope > .v-card, :scope > .v-sheet, :scope > .v-list")) == null ? void 0 : t.children;
    return n && [...n]
}

function Ve(e, n) {
    const t = Ue(e),
        a = Xe(n),
        [r, l] = getComputedStyle(n).transformOrigin.split(" ").map(O => parseFloat(O)),
        [s, o] = getComputedStyle(n).getPropertyValue("--v-overlay-anchor-origin").split(" ");
    let u = t.left + t.width / 2;
    s === "left" || o === "left" ? u -= t.width / 2 : (s === "right" || o === "right") && (u += t.width / 2);
    let f = t.top + t.height / 2;
    s === "top" || o === "top" ? f -= t.height / 2 : (s === "bottom" || o === "bottom") && (f += t.height / 2);
    const i = t.width / a.width,
        b = t.height / a.height,
        w = Math.max(1, i, b),
        g = i / w || 0,
        y = b / w || 0,
        m = a.width * a.height / (window.innerWidth * window.innerHeight),
        C = m > .12 ? Math.min(1.5, (m - .12) * 10 + 1) : 1;
    return {
        x: u - (r + a.left),
        y: f - (l + a.top),
        sx: g,
        sy: y,
        speed: C
    }
}

function de(e, n) {
    return {
        x: e.x + n.x,
        y: e.y + n.y
    }
}

function Qt(e, n) {
    return {
        x: e.x - n.x,
        y: e.y - n.y
    }
}

function Le(e, n) {
    if (e.side === "top" || e.side === "bottom") {
        const {
            side: t,
            align: a
        } = e, r = a === "left" ? 0 : a === "center" ? n.width / 2 : a === "right" ? n.width : a, l = t === "top" ? 0 : t === "bottom" ? n.height : t;
        return de({
            x: r,
            y: l
        }, n)
    } else if (e.side === "left" || e.side === "right") {
        const {
            side: t,
            align: a
        } = e, r = t === "left" ? 0 : t === "right" ? n.width : t, l = a === "top" ? 0 : a === "center" ? n.height / 2 : a === "bottom" ? n.height : a;
        return de({
            x: r,
            y: l
        }, n)
    }
    return de({
        x: n.width / 2,
        y: n.height / 2
    }, n)
}
const rt = {
        static: tn,
        connected: an
    },
    Zt = p({
        locationStrategy: {
            type: [String, Function],
            default: "static",
            validator: e => typeof e == "function" || e in rt
        },
        location: {
            type: String,
            default: "bottom"
        },
        origin: {
            type: String,
            default: "auto"
        },
        offset: [Number, String, Array]
    }, "VOverlay-location-strategies");

function en(e, n) {
    const t = W({}),
        a = W();
    j && Ee(() => !!(n.isActive.value && e.locationStrategy), l => {
        var s, o;
        V(() => e.locationStrategy, l), q(() => {
            window.removeEventListener("resize", r), a.value = void 0
        }), window.addEventListener("resize", r, {
            passive: !0
        }), typeof e.locationStrategy == "function" ? a.value = (s = e.locationStrategy(n, e, t)) == null ? void 0 : s.updateLocation : a.value = (o = rt[e.locationStrategy](n, e, t)) == null ? void 0 : o.updateLocation
    });

    function r(l) {
        var s;
        (s = a.value) == null || s.call(a, l)
    }
    return {
        contentStyles: t,
        updateLocation: a
    }
}

function tn() {}

function nn(e, n) {
    const t = Xe(e);
    return n ? t.x += parseFloat(e.style.right || 0) : t.x -= parseFloat(e.style.left || 0), t.y -= parseFloat(e.style.top || 0), t
}

function an(e, n, t) {
    (Array.isArray(e.target.value) || Kt(e.target.value)) && Object.assign(t.value, {
        position: "fixed",
        top: 0,
        [e.isRtl.value ? "right" : "left"]: 0
    });
    const {
        preferredAnchor: r,
        preferredOrigin: l
    } = St(() => {
        const y = Ae(n.location, e.isRtl.value),
            m = n.origin === "overlap" ? y : n.origin === "auto" ? fe(y) : Ae(n.origin, e.isRtl.value);
        return y.side === m.side && y.align === ve(m).align ? {
            preferredAnchor: Te(y),
            preferredOrigin: Te(m)
        } : {
            preferredAnchor: y,
            preferredOrigin: m
        }
    }), [s, o, u, f] = ["minWidth", "minHeight", "maxWidth", "maxHeight"].map(y => T(() => {
        const m = parseFloat(n[y]);
        return isNaN(m) ? 1 / 0 : m
    })), i = T(() => {
        if (Array.isArray(n.offset)) return n.offset;
        if (typeof n.offset == "string") {
            const y = n.offset.split(" ").map(parseFloat);
            return y.length < 2 && y.push(0), y
        }
        return typeof n.offset == "number" ? [n.offset, 0] : [0, 0]
    });
    let b = !1;
    const w = new ResizeObserver(() => {
        b && g()
    });
    V([e.target, e.contentEl], (y, m) => {
        let [C, O] = y, [P, x] = m;
        P && !Array.isArray(P) && w.unobserve(P), C && !Array.isArray(C) && w.observe(C), x && w.unobserve(x), O && w.observe(O)
    }, {
        immediate: !0
    }), q(() => {
        w.disconnect()
    });

    function g() {
        if (b = !1, requestAnimationFrame(() => b = !0), !e.target.value || !e.contentEl.value) return;
        const y = Ue(e.target.value),
            m = nn(e.contentEl.value, e.isRtl.value),
            C = oe(e.contentEl.value),
            O = 12;
        C.length || (C.push(document.documentElement), e.contentEl.value.style.top && e.contentEl.value.style.left || (m.x -= parseFloat(document.documentElement.style.getPropertyValue("--v-body-scroll-x") || 0), m.y -= parseFloat(document.documentElement.style.getPropertyValue("--v-body-scroll-y") || 0)));
        const P = C.reduce((k, v) => {
            const d = v.getBoundingClientRect(),
                S = new ue({
                    x: v === document.documentElement ? 0 : d.x,
                    y: v === document.documentElement ? 0 : d.y,
                    width: v.clientWidth,
                    height: v.clientHeight
                });
            return k ? new ue({
                x: Math.max(k.left, S.left),
                y: Math.max(k.top, S.top),
                width: Math.min(k.right, S.right) - Math.max(k.left, S.left),
                height: Math.min(k.bottom, S.bottom) - Math.max(k.top, S.top)
            }) : S
        }, void 0);
        P.x += O, P.y += O, P.width -= O * 2, P.height -= O * 2;
        let x = {
            anchor: r.value,
            origin: l.value
        };

        function A(k) {
            const v = new ue(m),
                d = Le(k.anchor, y),
                S = Le(k.origin, v);
            let {
                x: I,
                y: M
            } = Qt(d, S);
            switch (k.anchor.side) {
                case "top":
                    M -= i.value[0];
                    break;
                case "bottom":
                    M += i.value[0];
                    break;
                case "left":
                    I -= i.value[0];
                    break;
                case "right":
                    I += i.value[0];
                    break
            }
            switch (k.anchor.align) {
                case "top":
                    M -= i.value[1];
                    break;
                case "bottom":
                    M += i.value[1];
                    break;
                case "left":
                    I -= i.value[1];
                    break;
                case "right":
                    I += i.value[1];
                    break
            }
            return v.x += I, v.y += M, v.width = Math.min(v.width, u.value), v.height = Math.min(v.height, f.value), {
                overflows: Oe(v, P),
                x: I,
                y: M
            }
        }
        let _ = 0,
            L = 0;
        const B = {
                x: 0,
                y: 0
            },
            c = {
                x: !1,
                y: !1
            };
        let R = -1;
        for (; !(R++ > 10);) {
            const {
                x: k,
                y: v,
                overflows: d
            } = A(x);
            _ += k, L += v, m.x += k, m.y += v; {
                const S = Be(x.anchor),
                    I = d.x.before || d.x.after,
                    M = d.y.before || d.y.after;
                let Y = !1;
                if (["x", "y"].forEach(F => {
                        if (F === "x" && I && !c.x || F === "y" && M && !c.y) {
                            const $ = {
                                    anchor: { ...x.anchor
                                    },
                                    origin: { ...x.origin
                                    }
                                },
                                U = F === "x" ? S === "y" ? ve : fe : S === "y" ? fe : ve;
                            $.anchor = U($.anchor), $.origin = U($.origin);
                            const {
                                overflows: X
                            } = A($);
                            (X[F].before <= d[F].before && X[F].after <= d[F].after || X[F].before + X[F].after < (d[F].before + d[F].after) / 2) && (x = $, Y = c[F] = !0)
                        }
                    }), Y) continue
            }
            d.x.before && (_ += d.x.before, m.x += d.x.before), d.x.after && (_ -= d.x.after, m.x -= d.x.after), d.y.before && (L += d.y.before, m.y += d.y.before), d.y.after && (L -= d.y.after, m.y -= d.y.after); {
                const S = Oe(m, P);
                B.x = P.width - S.x.before - S.x.after, B.y = P.height - S.y.before - S.y.after, _ += S.x.before, m.x += S.x.before, L += S.y.before, m.y += S.y.before
            }
            break
        }
        const G = Be(x.anchor);
        return Object.assign(t.value, {
            "--v-overlay-anchor-origin": `${x.anchor.side} ${x.anchor.align}`,
            transformOrigin: `${x.origin.side} ${x.origin.align}`,
            top: z(ge(L)),
            left: e.isRtl.value ? void 0 : z(ge(_)),
            right: e.isRtl.value ? z(ge(-_)) : void 0,
            minWidth: z(G === "y" ? Math.min(s.value, y.width) : s.value),
            maxWidth: z(Ie(_e(B.x, s.value === 1 / 0 ? 0 : s.value, u.value))),
            maxHeight: z(Ie(_e(B.y, o.value === 1 / 0 ? 0 : o.value, f.value)))
        }), {
            available: B,
            contentBox: m
        }
    }
    return V(() => [r.value, l.value, n.offset, n.minWidth, n.minHeight, n.maxWidth, n.maxHeight], () => g()), ie(() => {
        const y = g();
        if (!y) return;
        const {
            available: m,
            contentBox: C
        } = y;
        C.height > m.y && requestAnimationFrame(() => {
            g(), requestAnimationFrame(() => {
                g()
            })
        })
    }), {
        updateLocation: g
    }
}

function ge(e) {
    return Math.round(e * devicePixelRatio) / devicePixelRatio
}

function Ie(e) {
    return Math.ceil(e * devicePixelRatio) / devicePixelRatio
}
let be = !0;
const re = [];

function on(e) {
    !be || re.length ? (re.push(e), Se()) : (be = !1, e(), Se())
}
let Me = -1;

function Se() {
    cancelAnimationFrame(Me), Me = requestAnimationFrame(() => {
        const e = re.shift();
        e && e(), re.length ? Se() : be = !0
    })
}
const ae = {
        none: null,
        close: sn,
        block: cn,
        reposition: un
    },
    rn = p({
        scrollStrategy: {
            type: [String, Function],
            default: "block",
            validator: e => typeof e == "function" || e in ae
        }
    }, "VOverlay-scroll-strategies");

function ln(e, n) {
    if (!j) return;
    let t;
    we(async () => {
        t == null || t.stop(), n.isActive.value && e.scrollStrategy && (t = De(), await new Promise(a => setTimeout(a)), t.active && t.run(() => {
            var a;
            typeof e.scrollStrategy == "function" ? e.scrollStrategy(n, e, t) : (a = ae[e.scrollStrategy]) == null || a.call(ae, n, e, t)
        }))
    }), q(() => {
        t == null || t.stop()
    })
}

function sn(e) {
    function n(t) {
        e.isActive.value = !1
    }
    it(e.targetEl.value ? ? e.contentEl.value, n)
}

function cn(e, n) {
    var s;
    const t = (s = e.root.value) == null ? void 0 : s.offsetParent,
        a = [...new Set([...oe(e.targetEl.value, n.contained ? t : void 0), ...oe(e.contentEl.value, n.contained ? t : void 0)])].filter(o => !o.classList.contains("v-overlay-scroll-blocked")),
        r = window.innerWidth - document.documentElement.offsetWidth,
        l = (o => xe(o) && o)(t || document.documentElement);
    l && e.root.value.classList.add("v-overlay--scroll-blocked"), a.forEach((o, u) => {
        o.style.setProperty("--v-body-scroll-x", z(-o.scrollLeft)), o.style.setProperty("--v-body-scroll-y", z(-o.scrollTop)), o !== document.documentElement && o.style.setProperty("--v-scrollbar-offset", z(r)), o.classList.add("v-overlay-scroll-blocked")
    }), q(() => {
        a.forEach((o, u) => {
            const f = parseFloat(o.style.getPropertyValue("--v-body-scroll-x")),
                i = parseFloat(o.style.getPropertyValue("--v-body-scroll-y")),
                b = o.style.scrollBehavior;
            o.style.scrollBehavior = "auto", o.style.removeProperty("--v-body-scroll-x"), o.style.removeProperty("--v-body-scroll-y"), o.style.removeProperty("--v-scrollbar-offset"), o.classList.remove("v-overlay-scroll-blocked"), o.scrollLeft = -f, o.scrollTop = -i, o.style.scrollBehavior = b
        }), l && e.root.value.classList.remove("v-overlay--scroll-blocked")
    })
}

function un(e, n, t) {
    let a = !1,
        r = -1,
        l = -1;

    function s(o) {
        on(() => {
            var i, b;
            const u = performance.now();
            (b = (i = e.updateLocation).value) == null || b.call(i, o), a = (performance.now() - u) / (1e3 / 60) > 2
        })
    }
    l = (typeof requestIdleCallback > "u" ? o => o() : requestIdleCallback)(() => {
        t.run(() => {
            it(e.targetEl.value ? ? e.contentEl.value, o => {
                a ? (cancelAnimationFrame(r), r = requestAnimationFrame(() => {
                    r = requestAnimationFrame(() => {
                        s(o)
                    })
                })) : s(o)
            })
        })
    }), q(() => {
        typeof cancelIdleCallback < "u" && cancelIdleCallback(l), cancelAnimationFrame(r)
    })
}

function it(e, n) {
    const t = [document, ...oe(e)];
    t.forEach(a => {
        a.addEventListener("scroll", n, {
            passive: !0
        })
    }), q(() => {
        t.forEach(a => {
            a.removeEventListener("scroll", n)
        })
    })
}
const fn = Symbol.for("vuetify:v-menu"),
    vn = p({
        closeDelay: [Number, String],
        openDelay: [Number, String]
    }, "delay");

function dn(e, n) {
    let t = () => {};

    function a(s) {
        t == null || t();
        const o = Number(s ? e.openDelay : e.closeDelay);
        return new Promise(u => {
            t = wt(o, () => {
                n == null || n(s), u(s)
            })
        })
    }

    function r() {
        return a(!0)
    }

    function l() {
        return a(!1)
    }
    return {
        clearDelay: t,
        runOpenDelay: r,
        runCloseDelay: l
    }
}
const gn = p({
    target: [String, Object],
    activator: [String, Object],
    activatorProps: {
        type: Object,
        default: () => ({})
    },
    openOnClick: {
        type: Boolean,
        default: void 0
    },
    openOnHover: Boolean,
    openOnFocus: {
        type: Boolean,
        default: void 0
    },
    closeOnContentClick: Boolean,
    ...vn()
}, "VOverlay-activator");

function mn(e, n) {
    let {
        isActive: t,
        isTop: a,
        contentEl: r
    } = n;
    const l = le("useActivator"),
        s = W();
    let o = !1,
        u = !1,
        f = !0;
    const i = T(() => e.openOnFocus || e.openOnFocus == null && e.openOnHover),
        b = T(() => e.openOnClick || e.openOnClick == null && !e.openOnHover && !i.value),
        {
            runOpenDelay: w,
            runCloseDelay: g
        } = dn(e, c => {
            c === (e.openOnHover && o || i.value && u) && !(e.openOnHover && t.value && !a.value) && (t.value !== c && (f = !0), t.value = c)
        }),
        y = W(),
        m = {
            onClick: c => {
                c.stopPropagation(), s.value = c.currentTarget || c.target, t.value || (y.value = [c.clientX, c.clientY]), t.value = !t.value
            },
            onMouseenter: c => {
                var R;
                (R = c.sourceCapabilities) != null && R.firesTouchEvents || (o = !0, s.value = c.currentTarget || c.target, w())
            },
            onMouseleave: c => {
                o = !1, g()
            },
            onFocus: c => {
                Et(c.target, ":focus-visible") !== !1 && (u = !0, c.stopPropagation(), s.value = c.currentTarget || c.target, w())
            },
            onBlur: c => {
                u = !1, c.stopPropagation(), g()
            }
        },
        C = T(() => {
            const c = {};
            return b.value && (c.onClick = m.onClick), e.openOnHover && (c.onMouseenter = m.onMouseenter, c.onMouseleave = m.onMouseleave), i.value && (c.onFocus = m.onFocus, c.onBlur = m.onBlur), c
        }),
        O = T(() => {
            const c = {};
            if (e.openOnHover && (c.onMouseenter = () => {
                    o = !0, w()
                }, c.onMouseleave = () => {
                    o = !1, g()
                }), i.value && (c.onFocusin = () => {
                    u = !0, w()
                }, c.onFocusout = () => {
                    u = !1, g()
                }), e.closeOnContentClick) {
                const R = He(fn, null);
                c.onClick = () => {
                    t.value = !1, R == null || R.closeParents()
                }
            }
            return c
        }),
        P = T(() => {
            const c = {};
            return e.openOnHover && (c.onMouseenter = () => {
                f && (o = !0, f = !1, w())
            }, c.onMouseleave = () => {
                o = !1, g()
            }), c
        });
    V(a, c => {
        var R;
        c && (e.openOnHover && !o && (!i.value || !u) || i.value && !u && (!e.openOnHover || !o)) && !((R = r.value) != null && R.contains(document.activeElement)) && (t.value = !1)
    }), V(t, c => {
        c || setTimeout(() => {
            y.value = void 0
        })
    }, {
        flush: "post"
    });
    const x = Re();
    we(() => {
        x.value && ie(() => {
            s.value = x.el
        })
    });
    const A = Re(),
        _ = T(() => e.target === "cursor" && y.value ? y.value : A.value ? A.el : lt(e.target, l) || s.value),
        L = T(() => Array.isArray(_.value) ? void 0 : _.value);
    let B;
    return V(() => !!e.activator, c => {
        c && j ? (B = De(), B.run(() => {
            yn(e, l, {
                activatorEl: s,
                activatorEvents: C
            })
        })) : B && B.stop()
    }, {
        flush: "post",
        immediate: !0
    }), q(() => {
        B == null || B.stop()
    }), {
        activatorEl: s,
        activatorRef: x,
        target: _,
        targetEl: L,
        targetRef: A,
        activatorEvents: C,
        contentEvents: O,
        scrimEvents: P
    }
}

function yn(e, n, t) {
    let {
        activatorEl: a,
        activatorEvents: r
    } = t;
    V(() => e.activator, (u, f) => {
        if (f && u !== f) {
            const i = o(f);
            i && s(i)
        }
        u && ie(() => l())
    }, {
        immediate: !0
    }), V(() => e.activatorProps, () => {
        l()
    }), q(() => {
        s()
    });

    function l() {
        let u = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : o(),
            f = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : e.activatorProps;
        u && Yt(u, H(r.value, f))
    }

    function s() {
        let u = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : o(),
            f = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : e.activatorProps;
        u && Ut(u, H(r.value, f))
    }

    function o() {
        let u = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : e.activator;
        const f = lt(u, n);
        return a.value = (f == null ? void 0 : f.nodeType) === Node.ELEMENT_NODE ? f : void 0, a.value
    }
}

function lt(e, n) {
    var a, r;
    if (!e) return;
    let t;
    if (e === "parent") {
        let l = (r = (a = n == null ? void 0 : n.proxy) == null ? void 0 : a.$el) == null ? void 0 : r.parentNode;
        for (; l != null && l.hasAttribute("data-no-activator");) l = l.parentNode;
        t = l
    } else typeof e == "string" ? t = document.querySelector(e) : "$el" in e ? t = e.$el : t = e;
    return t
}

function hn() {
    if (!j) return D(!1);
    const {
        ssr: e
    } = xt();
    if (e) {
        const n = D(!1);
        return ft(() => {
            n.value = !0
        }), n
    } else return D(!0)
}
const Ne = Symbol.for("vuetify:stack"),
    J = We([]);

function bn(e, n, t) {
    const a = le("useStack"),
        r = !t,
        l = He(Ne, void 0),
        s = We({
            activeChildren: new Set
        });
    dt(Ne, s);
    const o = D(+n.value);
    Ee(e, () => {
        var b;
        const i = (b = J.at(-1)) == null ? void 0 : b[1];
        o.value = i ? i + 10 : +n.value, r && J.push([a.uid, o.value]), l == null || l.activeChildren.add(a.uid), q(() => {
            if (r) {
                const w = gt(J).findIndex(g => g[0] === a.uid);
                J.splice(w, 1)
            }
            l == null || l.activeChildren.delete(a.uid)
        })
    });
    const u = D(!0);
    r && we(() => {
        var b;
        const i = ((b = J.at(-1)) == null ? void 0 : b[0]) === a.uid;
        setTimeout(() => u.value = i)
    });
    const f = T(() => !s.activeChildren.size);
    return {
        globalTop: vt(u),
        localTop: f,
        stackStyles: T(() => ({
            zIndex: o.value
        }))
    }
}

function Sn(e) {
    return {
        teleportTarget: T(() => {
            const t = e();
            if (t === !0 || !j) return;
            const a = t === !1 ? document.body : typeof t == "string" ? document.querySelector(t) : t;
            if (a == null) return;
            let r = [...a.children].find(l => l.matches(".v-overlay-container"));
            return r || (r = document.createElement("div"), r.className = "v-overlay-container", a.appendChild(r)), r
        })
    }
}

function wn(e) {
    const {
        modelValue: n,
        color: t,
        ...a
    } = e;
    return h(me, {
        name: "fade-transition",
        appear: !0
    }, {
        default: () => [e.modelValue && h("div", H({
            class: ["v-overlay__scrim", e.color.backgroundColorClasses.value],
            style: e.color.backgroundColorStyles.value
        }, a), null)]
    })
}
const En = p({
        absolute: Boolean,
        attach: [Boolean, String, Object],
        closeOnBack: {
            type: Boolean,
            default: !0
        },
        contained: Boolean,
        contentClass: null,
        contentProps: null,
        disabled: Boolean,
        opacity: [Number, String],
        noClickAnimation: Boolean,
        modelValue: Boolean,
        persistent: Boolean,
        scrim: {
            type: [Boolean, String],
            default: !0
        },
        zIndex: {
            type: [Number, String],
            default: 2e3
        },
        ...gn(),
        ...se(),
        ...Ze(),
        ...Wt(),
        ...Zt(),
        ...rn(),
        ...Qe(),
        ...Ge()
    }, "VOverlay"),
    Vn = ee()({
        name: "VOverlay",
        directives: {
            ClickOutside: $t
        },
        inheritAttrs: !1,
        props: {
            _disableGlobalStack: Boolean,
            ...En()
        },
        emits: {
            "click:outside": e => !0,
            "update:modelValue": e => !0,
            afterEnter: () => !0,
            afterLeave: () => !0
        },
        setup(e, n) {
            let {
                slots: t,
                attrs: a,
                emit: r
            } = n;
            const l = le("VOverlay"),
                s = W(),
                o = W(),
                u = W(),
                f = Pt(e, "modelValue"),
                i = T({
                    get: () => f.value,
                    set: E => {
                        E && e.disabled || (f.value = E)
                    }
                }),
                {
                    themeClasses: b
                } = et(e),
                {
                    rtlClasses: w,
                    isRtl: g
                } = kt(),
                {
                    hasContent: y,
                    onAfterLeave: m
                } = qt(e, i),
                C = tt(T(() => typeof e.scrim == "string" ? e.scrim : null)),
                {
                    globalTop: O,
                    localTop: P,
                    stackStyles: x
                } = bn(i, qe(e, "zIndex"), e._disableGlobalStack),
                {
                    activatorEl: A,
                    activatorRef: _,
                    target: L,
                    targetEl: B,
                    targetRef: c,
                    activatorEvents: R,
                    contentEvents: G,
                    scrimEvents: k
                } = mn(e, {
                    isActive: i,
                    isTop: P,
                    contentEl: u
                }),
                {
                    teleportTarget: v
                } = Sn(() => {
                    var K, ke, Ce;
                    const E = e.attach || e.contained;
                    if (E) return E;
                    const N = ((K = A == null ? void 0 : A.value) == null ? void 0 : K.getRootNode()) || ((Ce = (ke = l.proxy) == null ? void 0 : ke.$el) == null ? void 0 : Ce.getRootNode());
                    return N instanceof ShadowRoot ? N : !1
                }),
                {
                    dimensionStyles: d
                } = nt(e),
                S = hn(),
                {
                    scopeId: I
                } = pt();
            V(() => e.disabled, E => {
                E && (i.value = !1)
            });
            const {
                contentStyles: M,
                updateLocation: Y
            } = en(e, {
                isRtl: g,
                contentEl: u,
                target: L,
                isActive: i
            });
            ln(e, {
                root: s,
                contentEl: u,
                targetEl: B,
                isActive: i,
                updateLocation: Y
            });

            function F(E) {
                r("click:outside", E), e.persistent ? te() : i.value = !1
            }

            function $(E) {
                return i.value && O.value && (!e.scrim || E.target === o.value || E instanceof MouseEvent && E.shadowTarget === o.value)
            }
            j && V(i, E => {
                E ? window.addEventListener("keydown", U) : window.removeEventListener("keydown", U)
            }, {
                immediate: !0
            }), pe(() => {
                j && window.removeEventListener("keydown", U)
            });

            function U(E) {
                var N, K;
                E.key === "Escape" && O.value && (e.persistent ? te() : (i.value = !1, (N = u.value) != null && N.contains(document.activeElement) && ((K = A.value) == null || K.focus())))
            }
            const X = Ct();
            Ee(() => e.closeOnBack, () => {
                Ot(X, E => {
                    O.value && i.value ? (E(!1), e.persistent ? te() : i.value = !1) : E()
                })
            });
            const Pe = W();
            V(() => i.value && (e.absolute || e.contained) && v.value == null, E => {
                if (E) {
                    const N = Xt(s.value);
                    N && N !== document.scrollingElement && (Pe.value = N.scrollTop)
                }
            });

            function te() {
                e.noClickAnimation || u.value && Q(u.value, [{
                    transformOrigin: "center"
                }, {
                    transform: "scale(1.03)"
                }, {
                    transformOrigin: "center"
                }], {
                    duration: 150,
                    easing: he
                })
            }

            function ct() {
                r("afterEnter")
            }

            function ut() {
                m(), r("afterLeave")
            }
            return ce(() => {
                var E;
                return h(Ye, null, [(E = t.activator) == null ? void 0 : E.call(t, {
                    isActive: i.value,
                    targetRef: c,
                    props: H({
                        ref: _
                    }, R.value, e.activatorProps)
                }), S.value && y.value && h(mt, {
                    disabled: !v.value,
                    to: v.value
                }, {
                    default: () => [h("div", H({
                        class: ["v-overlay", {
                            "v-overlay--absolute": e.absolute || e.contained,
                            "v-overlay--active": i.value,
                            "v-overlay--contained": e.contained
                        }, b.value, w.value, e.class],
                        style: [x.value, {
                            "--v-overlay-opacity": e.opacity,
                            top: z(Pe.value)
                        }, e.style],
                        ref: s
                    }, I, a), [h(wn, H({
                        color: C,
                        modelValue: i.value && !!e.scrim,
                        ref: o
                    }, k.value), null), h(Z, {
                        appear: !0,
                        persisted: !0,
                        transition: e.transition,
                        target: L.value,
                        onAfterEnter: ct,
                        onAfterLeave: ut
                    }, {
                        default: () => {
                            var N;
                            return [ye(h("div", H({
                                ref: u,
                                class: ["v-overlay__content", e.contentClass],
                                style: [d.value, M.value]
                            }, G.value, e.contentProps), [(N = t.default) == null ? void 0 : N.call(t, {
                                isActive: i
                            })]), [
                                [$e, i.value],
                                [je("click-outside"), {
                                    handler: F,
                                    closeConditional: $,
                                    include: () => [A.value]
                                }]
                            ])]
                        }
                    })])]
                })])
            }), {
                activatorEl: A,
                scrimEl: o,
                target: L,
                animateClick: te,
                contentEl: u,
                globalTop: O,
                localTop: P,
                updateLocation: Y
            }
        }
    });

function xn(e) {
    return {
        aspectStyles: T(() => {
            const n = Number(e.aspectRatio);
            return n ? {
                paddingBottom: String(1 / n * 100) + "%"
            } : void 0
        })
    }
}
const st = p({
        aspectRatio: [String, Number],
        contentClass: null,
        inline: Boolean,
        ...se(),
        ...Ze()
    }, "VResponsive"),
    ze = ee()({
        name: "VResponsive",
        props: st(),
        setup(e, n) {
            let {
                slots: t
            } = n;
            const {
                aspectStyles: a
            } = xn(e), {
                dimensionStyles: r
            } = nt(e);
            return ce(() => {
                var l;
                return h("div", {
                    class: ["v-responsive", {
                        "v-responsive--inline": e.inline
                    }, e.class],
                    style: [r.value, e.style]
                }, [h("div", {
                    class: "v-responsive__sizer",
                    style: a.value
                }, null), (l = t.additional) == null ? void 0 : l.call(t), t.default && h("div", {
                    class: ["v-responsive__content", e.contentClass]
                }, [t.default()])])
            }), {}
        }
    }),
    Pn = p({
        absolute: Boolean,
        alt: String,
        cover: Boolean,
        color: String,
        draggable: {
            type: [Boolean, String],
            default: void 0
        },
        eager: Boolean,
        gradient: String,
        lazySrc: String,
        options: {
            type: Object,
            default: () => ({
                root: void 0,
                rootMargin: void 0,
                threshold: void 0
            })
        },
        sizes: String,
        src: {
            type: [String, Object],
            default: ""
        },
        crossorigin: String,
        referrerpolicy: String,
        srcset: String,
        position: String,
        ...st(),
        ...se(),
        ...ot(),
        ...Ge()
    }, "VImg"),
    kn = ee()({
        name: "VImg",
        directives: {
            intersect: jt
        },
        props: Pn(),
        emits: {
            loadstart: e => !0,
            load: e => !0,
            error: e => !0
        },
        setup(e, n) {
            let {
                emit: t,
                slots: a
            } = n;
            const {
                backgroundColorClasses: r,
                backgroundColorStyles: l
            } = tt(qe(e, "color")), {
                roundedClasses: s
            } = at(e), o = le("VImg"), u = D(""), f = W(), i = D(e.eager ? "loading" : "idle"), b = D(), w = D(), g = T(() => e.src && typeof e.src == "object" ? {
                src: e.src.src,
                srcset: e.srcset || e.src.srcset,
                lazySrc: e.lazySrc || e.src.lazySrc,
                aspect: Number(e.aspectRatio || e.src.aspect || 0)
            } : {
                src: e.src,
                srcset: e.srcset,
                lazySrc: e.lazySrc,
                aspect: Number(e.aspectRatio || 0)
            }), y = T(() => g.value.aspect || b.value / w.value || 0);
            V(() => e.src, () => {
                m(i.value !== "idle")
            }), V(y, (v, d) => {
                !v && d && f.value && A(f.value)
            }), yt(() => m());

            function m(v) {
                if (!(e.eager && v) && !(At && !v && !e.eager)) {
                    if (i.value = "loading", g.value.lazySrc) {
                        const d = new Image;
                        d.src = g.value.lazySrc, A(d, null)
                    }
                    g.value.src && ie(() => {
                        var d;
                        t("loadstart", ((d = f.value) == null ? void 0 : d.currentSrc) || g.value.src), setTimeout(() => {
                            var S;
                            if (!o.isUnmounted)
                                if ((S = f.value) != null && S.complete) {
                                    if (f.value.naturalWidth || O(), i.value === "error") return;
                                    y.value || A(f.value, null), i.value === "loading" && C()
                                } else y.value || A(f.value), P()
                        })
                    })
                }
            }

            function C() {
                var v;
                o.isUnmounted || (P(), A(f.value), i.value = "loaded", t("load", ((v = f.value) == null ? void 0 : v.currentSrc) || g.value.src))
            }

            function O() {
                var v;
                o.isUnmounted || (i.value = "error", t("error", ((v = f.value) == null ? void 0 : v.currentSrc) || g.value.src))
            }

            function P() {
                const v = f.value;
                v && (u.value = v.currentSrc || v.src)
            }
            let x = -1;
            pe(() => {
                clearTimeout(x)
            });

            function A(v) {
                let d = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 100;
                const S = () => {
                    if (clearTimeout(x), o.isUnmounted) return;
                    const {
                        naturalHeight: I,
                        naturalWidth: M
                    } = v;
                    I || M ? (b.value = M, w.value = I) : !v.complete && i.value === "loading" && d != null ? x = window.setTimeout(S, d) : (v.currentSrc.endsWith(".svg") || v.currentSrc.startsWith("data:image/svg+xml")) && (b.value = 1, w.value = 1)
                };
                S()
            }
            const _ = T(() => ({
                    "v-img__img--cover": e.cover,
                    "v-img__img--contain": !e.cover
                })),
                L = () => {
                    var S;
                    if (!g.value.src || i.value === "idle") return null;
                    const v = h("img", {
                            class: ["v-img__img", _.value],
                            style: {
                                objectPosition: e.position
                            },
                            crossorigin: e.crossorigin,
                            src: g.value.src,
                            srcset: g.value.srcset,
                            alt: e.alt,
                            referrerpolicy: e.referrerpolicy,
                            draggable: e.draggable,
                            sizes: e.sizes,
                            ref: f,
                            onLoad: C,
                            onError: O
                        }, null),
                        d = (S = a.sources) == null ? void 0 : S.call(a);
                    return h(Z, {
                        transition: e.transition,
                        appear: !0
                    }, {
                        default: () => [ye(d ? h("picture", {
                            class: "v-img__picture"
                        }, [d, v]) : v, [
                            [$e, i.value === "loaded"]
                        ])]
                    })
                },
                B = () => h(Z, {
                    transition: e.transition
                }, {
                    default: () => [g.value.lazySrc && i.value !== "loaded" && h("img", {
                        class: ["v-img__img", "v-img__img--preload", _.value],
                        style: {
                            objectPosition: e.position
                        },
                        crossorigin: e.crossorigin,
                        src: g.value.lazySrc,
                        alt: e.alt,
                        referrerpolicy: e.referrerpolicy,
                        draggable: e.draggable
                    }, null)]
                }),
                c = () => a.placeholder ? h(Z, {
                    transition: e.transition,
                    appear: !0
                }, {
                    default: () => [(i.value === "loading" || i.value === "error" && !a.error) && h("div", {
                        class: "v-img__placeholder"
                    }, [a.placeholder()])]
                }) : null,
                R = () => a.error ? h(Z, {
                    transition: e.transition,
                    appear: !0
                }, {
                    default: () => [i.value === "error" && h("div", {
                        class: "v-img__error"
                    }, [a.error()])]
                }) : null,
                G = () => e.gradient ? h("div", {
                    class: "v-img__gradient",
                    style: {
                        backgroundImage: `linear-gradient(${e.gradient})`
                    }
                }, null) : null,
                k = D(!1); {
                const v = V(y, d => {
                    d && (requestAnimationFrame(() => {
                        requestAnimationFrame(() => {
                            k.value = !0
                        })
                    }), v())
                })
            }
            return ce(() => {
                const v = ze.filterProps(e);
                return ye(h(ze, H({
                    class: ["v-img", {
                        "v-img--absolute": e.absolute,
                        "v-img--booting": !k.value
                    }, r.value, s.value, e.class],
                    style: [{
                        width: z(e.width === "auto" ? b.value : e.width)
                    }, l.value, e.style]
                }, v, {
                    aspectRatio: y.value,
                    "aria-label": e.alt,
                    role: e.alt ? "img" : void 0
                }), {
                    additional: () => h(Ye, null, [h(L, null, null), h(B, null, null), h(G, null, null), h(c, null, null), h(R, null, null)]),
                    default: a.default
                }), [
                    [je("intersect"), {
                        handler: m,
                        options: e.options
                    }, null, {
                        once: !0
                    }]
                ])
            }), {
                currentSrc: u,
                image: f,
                state: i,
                naturalWidth: b,
                naturalHeight: w
            }
        }
    }),
    Cn = p({
        start: Boolean,
        end: Boolean,
        icon: Ht,
        image: String,
        text: String,
        ...Dt(),
        ...se(),
        ...zt(),
        ...ot(),
        ...Nt(),
        ...Mt(),
        ...Qe(),
        ...It({
            variant: "flat"
        })
    }, "VAvatar"),
    Ln = ee()({
        name: "VAvatar",
        props: Cn(),
        setup(e, n) {
            let {
                slots: t
            } = n;
            const {
                themeClasses: a
            } = et(e), {
                borderClasses: r
            } = Tt(e), {
                colorClasses: l,
                colorStyles: s,
                variantClasses: o
            } = Bt(e), {
                densityClasses: u
            } = _t(e), {
                roundedClasses: f
            } = at(e), {
                sizeClasses: i,
                sizeStyles: b
            } = Rt(e);
            return ce(() => h(e.tag, {
                class: ["v-avatar", {
                    "v-avatar--start": e.start,
                    "v-avatar--end": e.end
                }, a.value, r.value, l.value, u.value, f.value, i.value, o.value, e.class],
                style: [s.value, b.value, e.style]
            }, {
                default: () => [t.default ? h(Lt, {
                    key: "content-defaults",
                    defaults: {
                        VImg: {
                            cover: !0,
                            src: e.image
                        },
                        VIcon: {
                            icon: e.icon
                        }
                    }
                }, {
                    default: () => [t.default()]
                }) : e.image ? h(kn, {
                    key: "image",
                    src: e.image,
                    alt: "",
                    cover: !0
                }, null) : e.icon ? h(Vt, {
                    key: "icon",
                    icon: e.icon
                }, null) : e.text, Ft(!1, "v-avatar")]
            })), {}
        }
    });
export {
    Ln as V, Fn as a, fn as b, Vn as c, kn as d, vn as e, Pn as f, Xt as g, En as m, dn as u
};