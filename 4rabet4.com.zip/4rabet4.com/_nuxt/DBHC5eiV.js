import {
    u as c
} from "./Cc4FcFuq.js";
import {
    z as d,
    d as i,
    _ as f,
    V as u,
    an as p,
    u as r,
    a7 as g
} from "./BBZLTf3A.js";
import {
    _
} from "./BbvgifQp.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "06fe8f17-a599-4fa5-986c-91f8df206ea1", e._sentryDebugIdIdentifier = "sentry-dbid-06fe8f17-a599-4fa5-986c-91f8df206ea1")
    } catch {}
})();
const h = d({
        __name: "BannersSkeleton",
        props: {
            type: {
                default: "big"
            }
        },
        setup(e) {
            const t = e,
                {
                    isTablet: n
                } = c(),
                s = i(() => n.value ? 50 : 90),
                o = i(() => ["banners-skeleton", {
                    "banners-skeleton__big": t.type === "big"
                }, {
                    "banners-skeleton__upper": t.type === "upper"
                }]),
                a = i(() => ({
                    "--skeleton-height": `${s.value}px`
                }));
            return (b, B) => (u(), f("div", {
                class: g(r(o)),
                style: p(r(a))
            }, null, 6))
        }
    }),
    v = _(h, [
        ["__scopeId", "data-v-a379159a"]
    ]),
    m = e => {
        if (!(e != null && e.length)) return [];
        const t = [...e].sort((s, o) => s.id - o.id),
            n = Math.floor(Math.random() * t.length);
        return t.slice(n).concat(t.slice(0, n))
    },
    l = (e = []) => [...e].sort((t, n) => t.weight === n.weight ? t.id - n.id : t.weight - n.weight),
    I = (e = []) => e.length ? e.every(n => n.type === "big") && new Set(e.map(s => s.weight)).size === 1 ? m(e) : l(e) : [];
export {
    v as _, I as s
};