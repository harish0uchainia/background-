(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            s = new e.Error().stack;
        s && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[s] = "0719c80a-9c3b-4005-b09d-fe51b59fbdce", e._sentryDebugIdIdentifier = "sentry-dbid-0719c80a-9c3b-4005-b09d-fe51b59fbdce")
    } catch {}
})();
const a = {
    "bonuses-page": {
        Bonuses: "bonuses",
        Active: "activeBonuses",
        History: "historyBonuses",
        All: "all",
        Casino: "casino",
        Sports: "sports"
    },
    "main-page-top-sections": {
        JetX: "jetxSections",
        sports: "sportsSections",
        "live-casino": "LiveCasionSections",
        evolution: "evolutionSections",
        casino: "casinoSections",
        aviator: "aviatorSections",
        vip: "vipClubSections",
        cricket: "cricketSections"
    },
    "main-page-sections-titles": {
        live: "liveCasinoTitle",
        sport: "sportsTitle",
        crash: "сrashGamesTitle",
        slots: "slotsTitle",
        casino: "casinoTitle",
        exclusives: "4rabetExclusivesTitle"
    },
    "main-page-sections-more": {
        live: "moreLiveDealers",
        sport: "moreLiveEvents",
        crash: "moreCrashGames",
        slots: "seeAllSlots",
        casino: "moreCasinoGames",
        exclusives: "seeAll4rabetExclusives"
    },
    "main-page-sections-sliders": {
        live: "sliderLiveDealers",
        crash: "sliderCrashGames",
        sport: "sliderSports",
        slots: "sliderSlots",
        casino: "sliderCasinoGames",
        exclusives: "slider4rabetExclusives"
    },
    "main-page-sections-sports": {
        cricket: "sportsCricekt",
        football: "sportsFootball",
        sport: "sports",
        ecricket: "sportsECricket",
        basketball: "sportsBasketball",
        tennis: "sportsTennis",
        fifa: "sportsFifa",
        "table-tennis": "sportsTableTennis",
        volleyball: "sportsVolleyball",
        "ice-hockey": "sportsIceHockey",
        baseball: "sportsBaseBall",
        mma: "sportsMMA",
        handball: "sportsHandball"
    },
    "casino-page": {
        popular: "popular",
        exclusives: "exclusive",
        "new-games": "newGames",
        slots: "slots",
        baccarat: "baccarat",
        roulette: "roulette",
        blackjack: "blackjack",
        other: "other",
        table: "table",
        crash: "crash",
        local: "local",
        fast: "fast",
        vip: "vip",
        virtual_sports: "virtualSports",
        "video-poker-new": "videoPokerNew",
        board: "board"
    },
    "three-pages-titles": {
        popular: "titlePopular",
        exclusives: "titleExclusives",
        "new-games": "titleNewGames",
        slots: "titleSlots",
        baccarat: "titleBaccarat",
        roulette: "titleRoulette",
        blackjack: "titleBlackjack",
        table: "titleTable",
        crash: "titleCrash",
        other: "titleOther",
        vip: "titleVip",
        virtual_sports: "titleVirtualSports",
        "video-poker-new": "titleVideoPokerNew",
        board: "titleBoard"
    }
};

function o(e, s) {
    return s ? a[s][e] : a[e]
}

function i(e, s) {
    let t = null;
    e instanceof HTMLDivElement ? t = e.querySelector("input") : t = e, t == null || t.setAttribute("data-auto-test-el", s)
}
export {
    o as g, i as s
};