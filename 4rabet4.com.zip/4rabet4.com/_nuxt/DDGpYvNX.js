import {
    b as xt,
    V as Ue,
    c as Bt
} from "./CNgVgUb9.js";
import {
    d as b,
    D as r,
    J as q,
    t as B,
    Y as Se,
    ar as Je,
    ae as Qe,
    F as le,
    i as Ce,
    y as X,
    I as Ve,
    c as F,
    b as E,
    p as Ze,
    av as et,
    w as ue,
    l as ze,
    o as tt,
    n as at,
    B as Tt,
    a2 as Lt
} from "./BBZLTf3A.js";
import {
    M as _t,
    f as Ot,
    m as Dt
} from "./CbxP4vag.js";
import {
    U as Y,
    W as j,
    a7 as re,
    a4 as ee,
    aa as we,
    ab as W,
    ac as Ie,
    ad as be,
    X as de,
    ae as Ft,
    Y as te,
    af as nt,
    ag as pe,
    ah as Mt,
    ai as lt,
    aj as it,
    ak as st,
    al as Le,
    am as ot,
    an as _e,
    ao as Oe,
    ap as De,
    aq as Rt,
    ar as Et,
    as as ut,
    at as rt,
    l as se,
    au as oe,
    av as jt,
    aw as ct,
    ax as Fe,
    ay as Nt,
    az as Me,
    aA as Re,
    aB as Ee,
    aC as ce,
    aD as je,
    aE as dt,
    a8 as Gt,
    aF as $t,
    a3 as Ne,
    aG as Ht,
    a5 as Ge,
    aH as vt,
    aI as fe,
    aJ as ne,
    aK as Ut,
    aL as zt,
    aM as ft,
    A as Kt,
    aN as qt,
    aO as Pe,
    aP as Wt,
    aQ as xe,
    aR as Xt,
    aS as Ke,
    aT as qe,
    aU as Yt
} from "./BbvgifQp.js";
import {
    V as ge,
    g as Jt,
    a as Qt
} from "./D9sqA5Xl.js";
import {
    a as We,
    m as Zt,
    V as ea
} from "./iTYf75jB.js";
import {
    V as ta,
    a as aa
} from "./BulKdswA.js";
import {
    m as na,
    V as Xe,
    u as la
} from "./BQ7ou4ZQ.js";
import {
    c as ia
} from "./Ka2RWjod.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            i = new e.Error().stack;
        i && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[i] = "1c529dfa-405a-4d6e-a83d-e4f0f2c6e2af", e._sentryDebugIdIdentifier = "sentry-dbid-1c529dfa-405a-4d6e-a83d-e4f0f2c6e2af")
    } catch {}
})();
const sa = j({
        indeterminate: Boolean,
        indeterminateIcon: {
            type: W,
            default: "$checkboxIndeterminate"
        },
        ...Zt({
            falseIcon: "$checkboxOff",
            trueIcon: "$checkboxOn"
        })
    }, "VCheckboxBtn"),
    oa = Y()({
        name: "VCheckboxBtn",
        props: sa(),
        emits: {
            "update:modelValue": e => !0,
            "update:indeterminate": e => !0
        },
        setup(e, i) {
            let {
                slots: t
            } = i;
            const a = re(e, "indeterminate"),
                n = re(e, "modelValue");

            function l(c) {
                a.value && (a.value = !1)
            }
            const s = b(() => a.value ? e.indeterminateIcon : e.falseIcon),
                o = b(() => a.value ? e.indeterminateIcon : e.trueIcon);
            return ee(() => {
                const c = we(We.filterProps(e), ["modelValue"]);
                return r(We, q(c, {
                    modelValue: n.value,
                    "onUpdate:modelValue": [y => n.value = y, l],
                    class: ["v-checkbox-btn", e.class],
                    style: e.style,
                    type: "checkbox",
                    falseIcon: s.value,
                    trueIcon: o.value,
                    "aria-checked": a.value ? "mixed" : void 0
                }), t)
            }), {}
        }
    }),
    mt = Symbol.for("vuetify:v-chip-group"),
    ua = j({
        column: Boolean,
        filter: Boolean,
        valueComparator: {
            type: Function,
            default: nt
        },
        ...na(),
        ...te(),
        ...Ft({
            selectedClass: "v-chip--selected"
        }),
        ...de(),
        ...be(),
        ...Ie({
            variant: "tonal"
        })
    }, "VChipGroup");
Y()({
    name: "VChipGroup",
    props: ua(),
    emits: {
        "update:modelValue": e => !0
    },
    setup(e, i) {
        let {
            slots: t
        } = i;
        const {
            themeClasses: a
        } = pe(e), {
            isSelected: n,
            select: l,
            next: s,
            prev: o,
            selected: c
        } = Mt(e, mt);
        return lt({
            VChip: {
                color: B(e, "color"),
                disabled: B(e, "disabled"),
                filter: B(e, "filter"),
                variant: B(e, "variant")
            }
        }), ee(() => {
            const y = Xe.filterProps(e);
            return r(Xe, q(y, {
                class: ["v-chip-group", {
                    "v-chip-group--column": e.column
                }, a.value, e.class],
                style: e.style
            }), {
                default: () => {
                    var C;
                    return [(C = t.default) == null ? void 0 : C.call(t, {
                        isSelected: n,
                        select: l,
                        next: s,
                        prev: o,
                        selected: c.value
                    })]
                }
            })
        }), {}
    }
});
const ra = j({
        activeClass: String,
        appendAvatar: String,
        appendIcon: W,
        closable: Boolean,
        closeIcon: {
            type: W,
            default: "$delete"
        },
        closeLabel: {
            type: String,
            default: "$vuetify.close"
        },
        draggable: Boolean,
        filter: Boolean,
        filterIcon: {
            type: W,
            default: "$complete"
        },
        label: Boolean,
        link: {
            type: Boolean,
            default: void 0
        },
        pill: Boolean,
        prependAvatar: String,
        prependIcon: W,
        ripple: {
            type: [Boolean, Object],
            default: !0
        },
        text: String,
        modelValue: {
            type: Boolean,
            default: !0
        },
        onClick: ce(),
        onClickOnce: ce(),
        ...Ee(),
        ...te(),
        ...Re(),
        ...Me(),
        ...Nt(),
        ...Fe(),
        ...ct(),
        ...jt(),
        ...de({
            tag: "span"
        }),
        ...be(),
        ...Ie({
            variant: "tonal"
        })
    }, "VChip"),
    ca = Y()({
        name: "VChip",
        directives: {
            Ripple: it
        },
        props: ra(),
        emits: {
            "click:close": e => !0,
            "update:modelValue": e => !0,
            "group:selected": e => !0,
            click: e => !0
        },
        setup(e, i) {
            let {
                attrs: t,
                emit: a,
                slots: n
            } = i;
            const {
                t: l
            } = st(), {
                borderClasses: s
            } = Le(e), {
                colorClasses: o,
                colorStyles: c,
                variantClasses: y
            } = ot(e), {
                densityClasses: C
            } = _e(e), {
                elevationClasses: V
            } = Oe(e), {
                roundedClasses: h
            } = De(e), {
                sizeClasses: k
            } = Rt(e), {
                themeClasses: u
            } = pe(e), f = re(e, "modelValue"), d = Et(e, mt, !1), p = ut(e, t), I = b(() => e.link !== !1 && p.isLink.value), x = b(() => !e.disabled && e.link !== !1 && (!!d || e.link || p.isClickable.value)), _ = b(() => ({
                "aria-label": l(e.closeLabel),
                onClick(w) {
                    w.preventDefault(), w.stopPropagation(), f.value = !1, a("click:close", w)
                }
            }));

            function N(w) {
                var $;
                a("click", w), x.value && (($ = p.navigate) == null || $.call(p, w), d == null || d.toggle())
            }

            function O(w) {
                (w.key === "Enter" || w.key === " ") && (w.preventDefault(), N(w))
            }
            return () => {
                var ae;
                const w = p.isLink.value ? "a" : e.tag,
                    $ = !!(e.appendIcon || e.appendAvatar),
                    J = !!($ || n.append),
                    H = !!(n.close || e.closable),
                    Q = !!(n.filter || e.filter) && d,
                    D = !!(e.prependIcon || e.prependAvatar),
                    P = !!(D || n.prepend),
                    U = !d || d.isSelected.value;
                return f.value && Se(r(w, q({
                    class: ["v-chip", {
                        "v-chip--disabled": e.disabled,
                        "v-chip--label": e.label,
                        "v-chip--link": x.value,
                        "v-chip--filter": Q,
                        "v-chip--pill": e.pill,
                        [`${e.activeClass}`]: e.activeClass && ((ae = p.isActive) == null ? void 0 : ae.value)
                    }, u.value, s.value, U ? o.value : void 0, C.value, V.value, h.value, k.value, y.value, d == null ? void 0 : d.selectedClass.value, e.class],
                    style: [U ? c.value : void 0, e.style],
                    disabled: e.disabled || void 0,
                    draggable: e.draggable,
                    tabindex: x.value ? 0 : void 0,
                    onClick: N,
                    onKeydown: x.value && !I.value && O
                }, p.linkProps), {
                    default: () => {
                        var z;
                        return [rt(x.value, "v-chip"), Q && r(ta, {
                            key: "filter"
                        }, {
                            default: () => [Se(r("div", {
                                class: "v-chip__filter"
                            }, [n.filter ? r(oe, {
                                key: "filter-defaults",
                                disabled: !e.filterIcon,
                                defaults: {
                                    VIcon: {
                                        icon: e.filterIcon
                                    }
                                }
                            }, n.filter) : r(se, {
                                key: "filter-icon",
                                icon: e.filterIcon
                            }, null)]), [
                                [Qe, d.isSelected.value]
                            ])]
                        }), P && r("div", {
                            key: "prepend",
                            class: "v-chip__prepend"
                        }, [n.prepend ? r(oe, {
                            key: "prepend-defaults",
                            disabled: !D,
                            defaults: {
                                VAvatar: {
                                    image: e.prependAvatar,
                                    start: !0
                                },
                                VIcon: {
                                    icon: e.prependIcon,
                                    start: !0
                                }
                            }
                        }, n.prepend) : r(le, null, [e.prependIcon && r(se, {
                            key: "prepend-icon",
                            icon: e.prependIcon,
                            start: !0
                        }, null), e.prependAvatar && r(ge, {
                            key: "prepend-avatar",
                            image: e.prependAvatar,
                            start: !0
                        }, null)])]), r("div", {
                            class: "v-chip__content",
                            "data-no-activator": ""
                        }, [((z = n.default) == null ? void 0 : z.call(n, {
                            isSelected: d == null ? void 0 : d.isSelected.value,
                            selectedClass: d == null ? void 0 : d.selectedClass.value,
                            select: d == null ? void 0 : d.select,
                            toggle: d == null ? void 0 : d.toggle,
                            value: d == null ? void 0 : d.value.value,
                            disabled: e.disabled
                        })) ? ? e.text]), J && r("div", {
                            key: "append",
                            class: "v-chip__append"
                        }, [n.append ? r(oe, {
                            key: "append-defaults",
                            disabled: !$,
                            defaults: {
                                VAvatar: {
                                    end: !0,
                                    image: e.appendAvatar
                                },
                                VIcon: {
                                    end: !0,
                                    icon: e.appendIcon
                                }
                            }
                        }, n.append) : r(le, null, [e.appendIcon && r(se, {
                            key: "append-icon",
                            end: !0,
                            icon: e.appendIcon
                        }, null), e.appendAvatar && r(ge, {
                            key: "append-avatar",
                            end: !0,
                            image: e.appendAvatar
                        }, null)])]), H && r("button", q({
                            key: "close",
                            class: "v-chip__close",
                            type: "button",
                            "data-testid": "close-chip"
                        }, _.value), [n.close ? r(oe, {
                            key: "close-defaults",
                            defaults: {
                                VIcon: {
                                    icon: e.closeIcon,
                                    size: "x-small"
                                }
                            }
                        }, n.close) : r(se, {
                            key: "close-icon",
                            icon: e.closeIcon,
                            size: "x-small"
                        }, null)])]
                    }
                }), [
                    [Je("ripple"), x.value && e.ripple, null]
                ])
            }
        }
    }),
    Be = Symbol.for("vuetify:list");

function yt() {
    const e = Ce(Be, {
            hasPrepend: X(!1),
            updateHasPrepend: () => null
        }),
        i = {
            hasPrepend: X(!1),
            updateHasPrepend: t => {
                t && (i.hasPrepend.value = t)
            }
        };
    return Ve(Be, i), e
}

function gt() {
    return Ce(Be, null)
}
const $e = e => {
        const i = {
            activate: t => {
                let {
                    id: a,
                    value: n,
                    activated: l
                } = t;
                return a = F(a), e && !n && l.size === 1 && l.has(a) || (n ? l.add(a) : l.delete(a)), l
            },
            in: (t, a, n) => {
                let l = new Set;
                if (t != null)
                    for (const s of je(t)) l = i.activate({
                        id: s,
                        value: !0,
                        activated: new Set(l),
                        children: a,
                        parents: n
                    });
                return l
            },
            out: t => Array.from(t)
        };
        return i
    },
    ht = e => {
        const i = $e(e);
        return {
            activate: a => {
                let {
                    activated: n,
                    id: l,
                    ...s
                } = a;
                l = F(l);
                const o = n.has(l) ? new Set([l]) : new Set;
                return i.activate({ ...s,
                    id: l,
                    activated: o
                })
            },
            in: (a, n, l) => {
                let s = new Set;
                if (a != null) {
                    const o = je(a);
                    o.length && (s = i.in(o.slice(0, 1), n, l))
                }
                return s
            },
            out: (a, n, l) => i.out(a, n, l)
        }
    },
    da = e => {
        const i = $e(e);
        return {
            activate: a => {
                let {
                    id: n,
                    activated: l,
                    children: s,
                    ...o
                } = a;
                return n = F(n), s.has(n) ? l : i.activate({
                    id: n,
                    activated: l,
                    children: s,
                    ...o
                })
            },
            in: i.in,
            out: i.out
        }
    },
    va = e => {
        const i = ht(e);
        return {
            activate: a => {
                let {
                    id: n,
                    activated: l,
                    children: s,
                    ...o
                } = a;
                return n = F(n), s.has(n) ? l : i.activate({
                    id: n,
                    activated: l,
                    children: s,
                    ...o
                })
            },
            in: i.in,
            out: i.out
        }
    },
    fa = {
        open: e => {
            let {
                id: i,
                value: t,
                opened: a,
                parents: n
            } = e;
            if (t) {
                const l = new Set;
                l.add(i);
                let s = n.get(i);
                for (; s != null;) l.add(s), s = n.get(s);
                return l
            } else return a.delete(i), a
        },
        select: () => null
    },
    bt = {
        open: e => {
            let {
                id: i,
                value: t,
                opened: a,
                parents: n
            } = e;
            if (t) {
                let l = n.get(i);
                for (a.add(i); l != null && l !== i;) a.add(l), l = n.get(l);
                return a
            } else a.delete(i);
            return a
        },
        select: () => null
    },
    ma = {
        open: bt.open,
        select: e => {
            let {
                id: i,
                value: t,
                opened: a,
                parents: n
            } = e;
            if (!t) return a;
            const l = [];
            let s = n.get(i);
            for (; s != null;) l.push(s), s = n.get(s);
            return new Set(l)
        }
    },
    He = e => {
        const i = {
            select: t => {
                let {
                    id: a,
                    value: n,
                    selected: l
                } = t;
                if (a = F(a), e && !n) {
                    const s = Array.from(l.entries()).reduce((o, c) => {
                        let [y, C] = c;
                        return C === "on" && o.push(y), o
                    }, []);
                    if (s.length === 1 && s[0] === a) return l
                }
                return l.set(a, n ? "on" : "off"), l
            },
            in: (t, a, n) => {
                let l = new Map;
                for (const s of t || []) l = i.select({
                    id: s,
                    value: !0,
                    selected: new Map(l),
                    children: a,
                    parents: n
                });
                return l
            },
            out: t => {
                const a = [];
                for (const [n, l] of t.entries()) l === "on" && a.push(n);
                return a
            }
        };
        return i
    },
    pt = e => {
        const i = He(e);
        return {
            select: a => {
                let {
                    selected: n,
                    id: l,
                    ...s
                } = a;
                l = F(l);
                const o = n.has(l) ? new Map([
                    [l, n.get(l)]
                ]) : new Map;
                return i.select({ ...s,
                    id: l,
                    selected: o
                })
            },
            in: (a, n, l) => {
                let s = new Map;
                return a != null && a.length && (s = i.in(a.slice(0, 1), n, l)), s
            },
            out: (a, n, l) => i.out(a, n, l)
        }
    },
    ya = e => {
        const i = He(e);
        return {
            select: a => {
                let {
                    id: n,
                    selected: l,
                    children: s,
                    ...o
                } = a;
                return n = F(n), s.has(n) ? l : i.select({
                    id: n,
                    selected: l,
                    children: s,
                    ...o
                })
            },
            in: i.in,
            out: i.out
        }
    },
    ga = e => {
        const i = pt(e);
        return {
            select: a => {
                let {
                    id: n,
                    selected: l,
                    children: s,
                    ...o
                } = a;
                return n = F(n), s.has(n) ? l : i.select({
                    id: n,
                    selected: l,
                    children: s,
                    ...o
                })
            },
            in: i.in,
            out: i.out
        }
    },
    ha = e => {
        const i = {
            select: t => {
                let {
                    id: a,
                    value: n,
                    selected: l,
                    children: s,
                    parents: o
                } = t;
                a = F(a);
                const c = new Map(l),
                    y = [a];
                for (; y.length;) {
                    const V = y.shift();
                    l.set(F(V), n ? "on" : "off"), s.has(V) && y.push(...s.get(V))
                }
                let C = F(o.get(a));
                for (; C;) {
                    const V = s.get(C),
                        h = V.every(u => l.get(F(u)) === "on"),
                        k = V.every(u => !l.has(F(u)) || l.get(F(u)) === "off");
                    l.set(C, h ? "on" : k ? "off" : "indeterminate"), C = F(o.get(C))
                }
                return e && !n && Array.from(l.entries()).reduce((h, k) => {
                    let [u, f] = k;
                    return f === "on" && h.push(u), h
                }, []).length === 0 ? c : l
            },
            in: (t, a, n) => {
                let l = new Map;
                for (const s of t || []) l = i.select({
                    id: s,
                    value: !0,
                    selected: new Map(l),
                    children: a,
                    parents: n
                });
                return l
            },
            out: (t, a) => {
                const n = [];
                for (const [l, s] of t.entries()) s === "on" && !a.has(l) && n.push(l);
                return n
            }
        };
        return i
    },
    he = Symbol.for("vuetify:nested"),
    St = {
        id: X(),
        root: {
            register: () => null,
            unregister: () => null,
            parents: E(new Map),
            children: E(new Map),
            open: () => null,
            openOnSelect: () => null,
            activate: () => null,
            select: () => null,
            activatable: E(!1),
            selectable: E(!1),
            opened: E(new Set),
            activated: E(new Set),
            selected: E(new Map),
            selectedValues: E([]),
            getPath: () => []
        }
    },
    ba = j({
        activatable: Boolean,
        selectable: Boolean,
        activeStrategy: [String, Function, Object],
        selectStrategy: [String, Function, Object],
        openStrategy: [String, Object],
        opened: null,
        activated: null,
        selected: null,
        mandatory: Boolean
    }, "nested"),
    pa = e => {
        let i = !1;
        const t = E(new Map),
            a = E(new Map),
            n = re(e, "opened", e.opened, u => new Set(u), u => [...u.values()]),
            l = b(() => {
                if (typeof e.activeStrategy == "object") return e.activeStrategy;
                if (typeof e.activeStrategy == "function") return e.activeStrategy(e.mandatory);
                switch (e.activeStrategy) {
                    case "leaf":
                        return da(e.mandatory);
                    case "single-leaf":
                        return va(e.mandatory);
                    case "independent":
                        return $e(e.mandatory);
                    case "single-independent":
                    default:
                        return ht(e.mandatory)
                }
            }),
            s = b(() => {
                if (typeof e.selectStrategy == "object") return e.selectStrategy;
                if (typeof e.selectStrategy == "function") return e.selectStrategy(e.mandatory);
                switch (e.selectStrategy) {
                    case "single-leaf":
                        return ga(e.mandatory);
                    case "leaf":
                        return ya(e.mandatory);
                    case "independent":
                        return He(e.mandatory);
                    case "single-independent":
                        return pt(e.mandatory);
                    case "classic":
                    default:
                        return ha(e.mandatory)
                }
            }),
            o = b(() => {
                if (typeof e.openStrategy == "object") return e.openStrategy;
                switch (e.openStrategy) {
                    case "list":
                        return ma;
                    case "single":
                        return fa;
                    case "multiple":
                    default:
                        return bt
                }
            }),
            c = re(e, "activated", e.activated, u => l.value.in(u, t.value, a.value), u => l.value.out(u, t.value, a.value)),
            y = re(e, "selected", e.selected, u => s.value.in(u, t.value, a.value), u => s.value.out(u, t.value, a.value));
        Ze(() => {
            i = !0
        });

        function C(u) {
            const f = [];
            let d = u;
            for (; d != null;) f.unshift(d), d = a.value.get(d);
            return f
        }
        const V = dt("nested"),
            h = new Set,
            k = {
                id: X(),
                root: {
                    opened: n,
                    activatable: B(e, "activatable"),
                    selectable: B(e, "selectable"),
                    activated: c,
                    selected: y,
                    selectedValues: b(() => {
                        const u = [];
                        for (const [f, d] of y.value.entries()) d === "on" && u.push(f);
                        return u
                    }),
                    register: (u, f, d) => {
                        if (h.has(u)) {
                            C(u).map(String).join(" -> "), C(f).concat(u).map(String).join(" -> ");
                            return
                        } else h.add(u);
                        f && u !== f && a.value.set(u, f), d && t.value.set(u, []), f != null && t.value.set(f, [...t.value.get(f) || [], u])
                    },
                    unregister: u => {
                        if (i) return;
                        h.delete(u), t.value.delete(u);
                        const f = a.value.get(u);
                        if (f) {
                            const d = t.value.get(f) ? ? [];
                            t.value.set(f, d.filter(p => p !== u))
                        }
                        a.value.delete(u)
                    },
                    open: (u, f, d) => {
                        V.emit("click:open", {
                            id: u,
                            value: f,
                            path: C(u),
                            event: d
                        });
                        const p = o.value.open({
                            id: u,
                            value: f,
                            opened: new Set(n.value),
                            children: t.value,
                            parents: a.value,
                            event: d
                        });
                        p && (n.value = p)
                    },
                    openOnSelect: (u, f, d) => {
                        const p = o.value.select({
                            id: u,
                            value: f,
                            selected: new Map(y.value),
                            opened: new Set(n.value),
                            children: t.value,
                            parents: a.value,
                            event: d
                        });
                        p && (n.value = p)
                    },
                    select: (u, f, d) => {
                        V.emit("click:select", {
                            id: u,
                            value: f,
                            path: C(u),
                            event: d
                        });
                        const p = s.value.select({
                            id: u,
                            value: f,
                            selected: new Map(y.value),
                            children: t.value,
                            parents: a.value,
                            event: d
                        });
                        p && (y.value = p), k.root.openOnSelect(u, f, d)
                    },
                    activate: (u, f, d) => {
                        if (!e.activatable) return k.root.select(u, !0, d);
                        V.emit("click:activate", {
                            id: u,
                            value: f,
                            path: C(u),
                            event: d
                        });
                        const p = l.value.activate({
                            id: u,
                            value: f,
                            activated: new Set(c.value),
                            children: t.value,
                            parents: a.value,
                            event: d
                        });
                        p && (c.value = p)
                    },
                    children: t,
                    parents: a,
                    getPath: C
                }
            };
        return Ve(he, k), k.root
    },
    kt = (e, i) => {
        const t = Ce(he, St),
            a = Symbol(Gt()),
            n = b(() => e.value !== void 0 ? e.value : a),
            l = { ...t,
                id: n,
                open: (s, o) => t.root.open(n.value, s, o),
                openOnSelect: (s, o) => t.root.openOnSelect(n.value, s, o),
                isOpen: b(() => t.root.opened.value.has(n.value)),
                parent: b(() => t.root.parents.value.get(n.value)),
                activate: (s, o) => t.root.activate(n.value, s, o),
                isActivated: b(() => t.root.activated.value.has(F(n.value))),
                select: (s, o) => t.root.select(n.value, s, o),
                isSelected: b(() => t.root.selected.value.get(F(n.value)) === "on"),
                isIndeterminate: b(() => t.root.selected.value.get(F(n.value)) === "indeterminate"),
                isLeaf: b(() => !t.root.children.value.get(n.value)),
                isGroupActivator: t.isGroupActivator
            };
        return et(() => {
            !t.isGroupActivator && t.root.register(n.value, t.id.value, i)
        }), Ze(() => {
            !t.isGroupActivator && t.root.unregister(n.value)
        }), i && Ve(he, l), l
    },
    Sa = () => {
        const e = Ce(he, St);
        Ve(he, { ...e,
            isGroupActivator: !0
        })
    },
    ka = $t({
        name: "VListGroupActivator",
        setup(e, i) {
            let {
                slots: t
            } = i;
            return Sa(), () => {
                var a;
                return (a = t.default) == null ? void 0 : a.call(t)
            }
        }
    }),
    Ca = j({
        activeColor: String,
        baseColor: String,
        color: String,
        collapseIcon: {
            type: W,
            default: "$collapse"
        },
        expandIcon: {
            type: W,
            default: "$expand"
        },
        prependIcon: W,
        appendIcon: W,
        fluid: Boolean,
        subgroup: Boolean,
        title: String,
        value: null,
        ...te(),
        ...de()
    }, "VListGroup"),
    Ye = Y()({
        name: "VListGroup",
        props: Ca(),
        setup(e, i) {
            let {
                slots: t
            } = i;
            const {
                isOpen: a,
                open: n,
                id: l
            } = kt(B(e, "value"), !0), s = b(() => `v-list-group--id-${String(l.value)}`), o = gt(), {
                isBooted: c
            } = la();

            function y(k) {
                k.stopPropagation(), n(!a.value, k)
            }
            const C = b(() => ({
                    onClick: y,
                    class: "v-list-group__header",
                    id: s.value
                })),
                V = b(() => a.value ? e.collapseIcon : e.expandIcon),
                h = b(() => ({
                    VListItem: {
                        active: a.value,
                        activeColor: e.activeColor,
                        baseColor: e.baseColor,
                        color: e.color,
                        prependIcon: e.prependIcon || e.subgroup && V.value,
                        appendIcon: e.appendIcon || !e.subgroup && V.value,
                        title: e.title,
                        value: e.value
                    }
                }));
            return ee(() => r(e.tag, {
                class: ["v-list-group", {
                    "v-list-group--prepend": o == null ? void 0 : o.hasPrepend.value,
                    "v-list-group--fluid": e.fluid,
                    "v-list-group--subgroup": e.subgroup,
                    "v-list-group--open": a.value
                }, e.class],
                style: e.style
            }, {
                default: () => [t.activator && r(oe, {
                    defaults: h.value
                }, {
                    default: () => [r(ka, null, {
                        default: () => [t.activator({
                            props: C.value,
                            isOpen: a.value
                        })]
                    })]
                }), r(_t, {
                    transition: {
                        component: aa
                    },
                    disabled: !c.value
                }, {
                    default: () => {
                        var k;
                        return [Se(r("div", {
                            class: "v-list-group__items",
                            role: "group",
                            "aria-labelledby": s.value
                        }, [(k = t.default) == null ? void 0 : k.call(t)]), [
                            [Qe, a.value]
                        ])]
                    }
                })]
            })), {
                isOpen: a
            }
        }
    }),
    Va = j({
        opacity: [Number, String],
        ...te(),
        ...de()
    }, "VListItemSubtitle"),
    wa = Y()({
        name: "VListItemSubtitle",
        props: Va(),
        setup(e, i) {
            let {
                slots: t
            } = i;
            return ee(() => r(e.tag, {
                class: ["v-list-item-subtitle", e.class],
                style: [{
                    "--v-list-item-subtitle-opacity": e.opacity
                }, e.style]
            }, t)), {}
        }
    }),
    Ia = ia("v-list-item-title"),
    Pa = j({
        active: {
            type: Boolean,
            default: void 0
        },
        activeClass: String,
        activeColor: String,
        appendAvatar: String,
        appendIcon: W,
        baseColor: String,
        disabled: Boolean,
        lines: [Boolean, String],
        link: {
            type: Boolean,
            default: void 0
        },
        nav: Boolean,
        prependAvatar: String,
        prependIcon: W,
        ripple: {
            type: [Boolean, Object],
            default: !0
        },
        slim: Boolean,
        subtitle: [String, Number],
        title: [String, Number],
        value: null,
        onClick: ce(),
        onClickOnce: ce(),
        ...Ee(),
        ...te(),
        ...Re(),
        ...Ge(),
        ...Me(),
        ...Fe(),
        ...ct(),
        ...de(),
        ...be(),
        ...Ie({
            variant: "text"
        })
    }, "VListItem"),
    ke = Y()({
        name: "VListItem",
        directives: {
            Ripple: it
        },
        props: Pa(),
        emits: {
            click: e => !0
        },
        setup(e, i) {
            let {
                attrs: t,
                slots: a,
                emit: n
            } = i;
            const l = ut(e, t),
                s = b(() => e.value === void 0 ? l.href.value : e.value),
                {
                    activate: o,
                    isActivated: c,
                    select: y,
                    isOpen: C,
                    isSelected: V,
                    isIndeterminate: h,
                    isGroupActivator: k,
                    root: u,
                    parent: f,
                    openOnSelect: d,
                    id: p
                } = kt(s, !1),
                I = gt(),
                x = b(() => {
                    var g;
                    return e.active !== !1 && (e.active || ((g = l.isActive) == null ? void 0 : g.value) || (u.activatable.value ? c.value : V.value))
                }),
                _ = b(() => e.link !== !1 && l.isLink.value),
                N = b(() => !!I && (u.selectable.value || u.activatable.value || e.value != null)),
                O = b(() => !e.disabled && e.link !== !1 && (e.link || l.isClickable.value || N.value)),
                w = b(() => e.rounded || e.nav),
                $ = b(() => e.color ? ? e.activeColor),
                J = b(() => ({
                    color: x.value ? $.value ? ? e.baseColor : e.baseColor,
                    variant: e.variant
                }));
            ue(() => {
                var g;
                return (g = l.isActive) == null ? void 0 : g.value
            }, g => {
                g && H()
            }), et(() => {
                var g;
                (g = l.isActive) != null && g.value && H()
            });

            function H() {
                f.value != null && u.open(f.value, !0), d(!0)
            }
            const {
                themeClasses: Q
            } = pe(e), {
                borderClasses: D
            } = Le(e), {
                colorClasses: P,
                colorStyles: U,
                variantClasses: ae
            } = ot(J), {
                densityClasses: z
            } = _e(e), {
                dimensionStyles: me
            } = Ne(e), {
                elevationClasses: ve
            } = Oe(e), {
                roundedClasses: m
            } = De(w), v = b(() => e.lines ? `v-list-item--${e.lines}-line` : void 0), S = b(() => ({
                isActive: x.value,
                select: y,
                isOpen: C.value,
                isSelected: V.value,
                isIndeterminate: h.value
            }));

            function T(g) {
                var A;
                n("click", g), O.value && ((A = l.navigate) == null || A.call(l, g), !k && (u.activatable.value ? o(!c.value, g) : (u.selectable.value || e.value != null) && y(!V.value, g)))
            }

            function L(g) {
                (g.key === "Enter" || g.key === " ") && (g.preventDefault(), g.target.dispatchEvent(new MouseEvent("click", g)))
            }
            return ee(() => {
                const g = _.value ? "a" : e.tag,
                    A = a.title || e.title != null,
                    M = a.subtitle || e.subtitle != null,
                    Z = !!(e.appendAvatar || e.appendIcon),
                    G = !!(Z || a.append),
                    ie = !!(e.prependAvatar || e.prependIcon),
                    R = !!(ie || a.prepend);
                return I == null || I.updateHasPrepend(R), e.activeColor && Ht("active-color", ["color", "base-color"]), Se(r(g, q({
                    class: ["v-list-item", {
                        "v-list-item--active": x.value,
                        "v-list-item--disabled": e.disabled,
                        "v-list-item--link": O.value,
                        "v-list-item--nav": e.nav,
                        "v-list-item--prepend": !R && (I == null ? void 0 : I.hasPrepend.value),
                        "v-list-item--slim": e.slim,
                        [`${e.activeClass}`]: e.activeClass && x.value
                    }, Q.value, D.value, P.value, z.value, ve.value, v.value, m.value, ae.value, e.class],
                    style: [U.value, me.value, e.style],
                    tabindex: O.value ? I ? -2 : 0 : void 0,
                    "aria-selected": N.value ? u.activatable.value ? c.value : u.selectable.value ? V.value : x.value : void 0,
                    onClick: T,
                    onKeydown: O.value && !_.value && L
                }, l.linkProps), {
                    default: () => {
                        var ye;
                        return [rt(O.value || x.value, "v-list-item"), R && r("div", {
                            key: "prepend",
                            class: "v-list-item__prepend"
                        }, [a.prepend ? r(oe, {
                            key: "prepend-defaults",
                            disabled: !ie,
                            defaults: {
                                VAvatar: {
                                    density: e.density,
                                    image: e.prependAvatar
                                },
                                VIcon: {
                                    density: e.density,
                                    icon: e.prependIcon
                                },
                                VListItemAction: {
                                    start: !0
                                }
                            }
                        }, {
                            default: () => {
                                var K;
                                return [(K = a.prepend) == null ? void 0 : K.call(a, S.value)]
                            }
                        }) : r(le, null, [e.prependAvatar && r(ge, {
                            key: "prepend-avatar",
                            density: e.density,
                            image: e.prependAvatar
                        }, null), e.prependIcon && r(se, {
                            key: "prepend-icon",
                            density: e.density,
                            icon: e.prependIcon
                        }, null)]), r("div", {
                            class: "v-list-item__spacer"
                        }, null)]), r("div", {
                            class: "v-list-item__content",
                            "data-no-activator": ""
                        }, [A && r(Ia, {
                            key: "title"
                        }, {
                            default: () => {
                                var K;
                                return [((K = a.title) == null ? void 0 : K.call(a, {
                                    title: e.title
                                })) ? ? e.title]
                            }
                        }), M && r(wa, {
                            key: "subtitle"
                        }, {
                            default: () => {
                                var K;
                                return [((K = a.subtitle) == null ? void 0 : K.call(a, {
                                    subtitle: e.subtitle
                                })) ? ? e.subtitle]
                            }
                        }), (ye = a.default) == null ? void 0 : ye.call(a, S.value)]), G && r("div", {
                            key: "append",
                            class: "v-list-item__append"
                        }, [a.append ? r(oe, {
                            key: "append-defaults",
                            disabled: !Z,
                            defaults: {
                                VAvatar: {
                                    density: e.density,
                                    image: e.appendAvatar
                                },
                                VIcon: {
                                    density: e.density,
                                    icon: e.appendIcon
                                },
                                VListItemAction: {
                                    end: !0
                                }
                            }
                        }, {
                            default: () => {
                                var K;
                                return [(K = a.append) == null ? void 0 : K.call(a, S.value)]
                            }
                        }) : r(le, null, [e.appendIcon && r(se, {
                            key: "append-icon",
                            density: e.density,
                            icon: e.appendIcon
                        }, null), e.appendAvatar && r(ge, {
                            key: "append-avatar",
                            density: e.density,
                            image: e.appendAvatar
                        }, null)]), r("div", {
                            class: "v-list-item__spacer"
                        }, null)])]
                    }
                }), [
                    [Je("ripple"), O.value && e.ripple]
                ])
            }), {
                activate: o,
                isActivated: c,
                isGroupActivator: k,
                isSelected: V,
                list: I,
                select: y,
                root: u,
                id: p
            }
        }
    }),
    Aa = j({
        color: String,
        inset: Boolean,
        sticky: Boolean,
        title: String,
        ...te(),
        ...de()
    }, "VListSubheader"),
    xa = Y()({
        name: "VListSubheader",
        props: Aa(),
        setup(e, i) {
            let {
                slots: t
            } = i;
            const {
                textColorClasses: a,
                textColorStyles: n
            } = vt(B(e, "color"));
            return ee(() => {
                const l = !!(t.default || e.title);
                return r(e.tag, {
                    class: ["v-list-subheader", {
                        "v-list-subheader--inset": e.inset,
                        "v-list-subheader--sticky": e.sticky
                    }, a.value, e.class],
                    style: [{
                        textColorStyles: n
                    }, e.style]
                }, {
                    default: () => {
                        var s;
                        return [l && r("div", {
                            class: "v-list-subheader__text"
                        }, [((s = t.default) == null ? void 0 : s.call(t)) ? ? e.title])]
                    }
                })
            }), {}
        }
    }),
    Ba = j({
        color: String,
        inset: Boolean,
        length: [Number, String],
        opacity: [Number, String],
        thickness: [Number, String],
        vertical: Boolean,
        ...te(),
        ...be()
    }, "VDivider"),
    Ta = Y()({
        name: "VDivider",
        props: Ba(),
        setup(e, i) {
            let {
                attrs: t,
                slots: a
            } = i;
            const {
                themeClasses: n
            } = pe(e), {
                textColorClasses: l,
                textColorStyles: s
            } = vt(B(e, "color")), o = b(() => {
                const c = {};
                return e.length && (c[e.vertical ? "height" : "width"] = fe(e.length)), e.thickness && (c[e.vertical ? "borderRightWidth" : "borderTopWidth"] = fe(e.thickness)), c
            });
            return ee(() => {
                const c = r("hr", {
                    class: [{
                        "v-divider": !0,
                        "v-divider--inset": e.inset,
                        "v-divider--vertical": e.vertical
                    }, n.value, l.value, e.class],
                    style: [o.value, s.value, {
                        "--v-border-opacity": e.opacity
                    }, e.style],
                    "aria-orientation": !t.role || t.role === "separator" ? e.vertical ? "vertical" : "horizontal" : void 0,
                    role: `${t.role||"separator"}`
                }, null);
                return a.default ? r("div", {
                    class: ["v-divider__wrapper", {
                        "v-divider__wrapper--vertical": e.vertical,
                        "v-divider__wrapper--inset": e.inset
                    }]
                }, [c, r("div", {
                    class: "v-divider__content"
                }, [a.default()]), c]) : c
            }), {}
        }
    }),
    La = j({
        items: Array,
        returnObject: Boolean
    }, "VListChildren"),
    Ct = Y()({
        name: "VListChildren",
        props: La(),
        setup(e, i) {
            let {
                slots: t
            } = i;
            return yt(), () => {
                var a, n;
                return ((a = t.default) == null ? void 0 : a.call(t)) ? ? ((n = e.items) == null ? void 0 : n.map(l => {
                    var h, k;
                    let {
                        children: s,
                        props: o,
                        type: c,
                        raw: y
                    } = l;
                    if (c === "divider") return ((h = t.divider) == null ? void 0 : h.call(t, {
                        props: o
                    })) ? ? r(Ta, o, null);
                    if (c === "subheader") return ((k = t.subheader) == null ? void 0 : k.call(t, {
                        props: o
                    })) ? ? r(xa, o, null);
                    const C = {
                            subtitle: t.subtitle ? u => {
                                var f;
                                return (f = t.subtitle) == null ? void 0 : f.call(t, { ...u,
                                    item: y
                                })
                            } : void 0,
                            prepend: t.prepend ? u => {
                                var f;
                                return (f = t.prepend) == null ? void 0 : f.call(t, { ...u,
                                    item: y
                                })
                            } : void 0,
                            append: t.append ? u => {
                                var f;
                                return (f = t.append) == null ? void 0 : f.call(t, { ...u,
                                    item: y
                                })
                            } : void 0,
                            title: t.title ? u => {
                                var f;
                                return (f = t.title) == null ? void 0 : f.call(t, { ...u,
                                    item: y
                                })
                            } : void 0
                        },
                        V = Ye.filterProps(o);
                    return s ? r(Ye, q({
                        value: o == null ? void 0 : o.value
                    }, V), {
                        activator: u => {
                            let {
                                props: f
                            } = u;
                            const d = { ...o,
                                ...f,
                                value: e.returnObject ? y : o.value
                            };
                            return t.header ? t.header({
                                props: d
                            }) : r(ke, d, C)
                        },
                        default: () => r(Ct, {
                            items: s,
                            returnObject: e.returnObject
                        }, t)
                    }) : t.item ? t.item({
                        props: o
                    }) : r(ke, q(o, {
                        value: e.returnObject ? y : o.value
                    }), C)
                }))
            }
        }
    }),
    Vt = j({
        items: {
            type: Array,
            default: () => []
        },
        itemTitle: {
            type: [String, Array, Function],
            default: "title"
        },
        itemValue: {
            type: [String, Array, Function],
            default: "value"
        },
        itemChildren: {
            type: [Boolean, String, Array, Function],
            default: "children"
        },
        itemProps: {
            type: [Boolean, String, Array, Function],
            default: "props"
        },
        returnObject: Boolean,
        valueComparator: {
            type: Function,
            default: nt
        }
    }, "list-items");

function Te(e, i) {
    const t = ne(i, e.itemTitle, i),
        a = ne(i, e.itemValue, t),
        n = ne(i, e.itemChildren),
        l = e.itemProps === !0 ? typeof i == "object" && i != null && !Array.isArray(i) ? "children" in i ? we(i, ["children"]) : i : void 0 : ne(i, e.itemProps),
        s = {
            title: t,
            value: a,
            ...l
        };
    return {
        title: String(s.title ? ? ""),
        value: s.value,
        props: s,
        children: Array.isArray(n) ? wt(e, n) : void 0,
        raw: i
    }
}

function wt(e, i) {
    const t = [];
    for (const a of i) t.push(Te(e, a));
    return t
}

function _a(e) {
    const i = b(() => wt(e, e.items)),
        t = b(() => i.value.some(l => l.value === null));

    function a(l) {
        return t.value || (l = l.filter(s => s !== null)), l.map(s => e.returnObject && typeof s == "string" ? Te(e, s) : i.value.find(o => e.valueComparator(s, o.value)) || Te(e, s))
    }

    function n(l) {
        return e.returnObject ? l.map(s => {
            let {
                raw: o
            } = s;
            return o
        }) : l.map(s => {
            let {
                value: o
            } = s;
            return o
        })
    }
    return {
        items: i,
        transformIn: a,
        transformOut: n
    }
}

function Oa(e) {
    return typeof e == "string" || typeof e == "number" || typeof e == "boolean"
}

function Da(e, i) {
    const t = ne(i, e.itemType, "item"),
        a = Oa(i) ? i : ne(i, e.itemTitle),
        n = ne(i, e.itemValue, void 0),
        l = ne(i, e.itemChildren),
        s = e.itemProps === !0 ? we(i, ["children"]) : ne(i, e.itemProps),
        o = {
            title: a,
            value: n,
            ...s
        };
    return {
        type: t,
        title: o.title,
        value: o.value,
        props: o,
        children: t === "item" && l ? It(e, l) : void 0,
        raw: i
    }
}

function It(e, i) {
    const t = [];
    for (const a of i) t.push(Da(e, a));
    return t
}

function Fa(e) {
    return {
        items: b(() => It(e, e.items))
    }
}
const Ma = j({
        baseColor: String,
        activeColor: String,
        activeClass: String,
        bgColor: String,
        disabled: Boolean,
        expandIcon: W,
        collapseIcon: W,
        lines: {
            type: [Boolean, String],
            default: "one"
        },
        slim: Boolean,
        nav: Boolean,
        "onClick:open": ce(),
        "onClick:select": ce(),
        "onUpdate:opened": ce(),
        ...ba({
            selectStrategy: "single-leaf",
            openStrategy: "list"
        }),
        ...Ee(),
        ...te(),
        ...Re(),
        ...Ge(),
        ...Me(),
        itemType: {
            type: String,
            default: "type"
        },
        ...Vt(),
        ...Fe(),
        ...de(),
        ...be(),
        ...Ie({
            variant: "text"
        })
    }, "VList"),
    Ra = Y()({
        name: "VList",
        props: Ma(),
        emits: {
            "update:selected": e => !0,
            "update:activated": e => !0,
            "update:opened": e => !0,
            "click:open": e => !0,
            "click:activate": e => !0,
            "click:select": e => !0
        },
        setup(e, i) {
            let {
                slots: t
            } = i;
            const {
                items: a
            } = Fa(e), {
                themeClasses: n
            } = pe(e), {
                backgroundColorClasses: l,
                backgroundColorStyles: s
            } = Ut(B(e, "bgColor")), {
                borderClasses: o
            } = Le(e), {
                densityClasses: c
            } = _e(e), {
                dimensionStyles: y
            } = Ne(e), {
                elevationClasses: C
            } = Oe(e), {
                roundedClasses: V
            } = De(e), {
                children: h,
                open: k,
                parents: u,
                select: f,
                getPath: d
            } = pa(e), p = b(() => e.lines ? `v-list--${e.lines}-line` : void 0), I = B(e, "activeColor"), x = B(e, "baseColor"), _ = B(e, "color");
            yt(), lt({
                VListGroup: {
                    activeColor: I,
                    baseColor: x,
                    color: _,
                    expandIcon: B(e, "expandIcon"),
                    collapseIcon: B(e, "collapseIcon")
                },
                VListItem: {
                    activeClass: B(e, "activeClass"),
                    activeColor: I,
                    baseColor: x,
                    color: _,
                    density: B(e, "density"),
                    disabled: B(e, "disabled"),
                    lines: B(e, "lines"),
                    nav: B(e, "nav"),
                    slim: B(e, "slim"),
                    variant: B(e, "variant")
                }
            });
            const N = X(!1),
                O = E();

            function w(P) {
                N.value = !0
            }

            function $(P) {
                N.value = !1
            }

            function J(P) {
                var U;
                !N.value && !(P.relatedTarget && ((U = O.value) != null && U.contains(P.relatedTarget))) && D()
            }

            function H(P) {
                const U = P.target;
                if (!(!O.value || ["INPUT", "TEXTAREA"].includes(U.tagName))) {
                    if (P.key === "ArrowDown") D("next");
                    else if (P.key === "ArrowUp") D("prev");
                    else if (P.key === "Home") D("first");
                    else if (P.key === "End") D("last");
                    else return;
                    P.preventDefault()
                }
            }

            function Q(P) {
                N.value = !0
            }

            function D(P) {
                if (O.value) return zt(O.value, P)
            }
            return ee(() => r(e.tag, {
                ref: O,
                class: ["v-list", {
                    "v-list--disabled": e.disabled,
                    "v-list--nav": e.nav,
                    "v-list--slim": e.slim
                }, n.value, l.value, o.value, c.value, C.value, p.value, V.value, e.class],
                style: [s.value, y.value, e.style],
                tabindex: e.disabled || N.value ? -1 : 0,
                role: "listbox",
                "aria-activedescendant": void 0,
                onFocusin: w,
                onFocusout: $,
                onFocus: J,
                onKeydown: H,
                onMousedown: Q
            }, {
                default: () => [r(Ct, {
                    items: a.value,
                    returnObject: e.returnObject
                }, t)]
            })), {
                open: k,
                select: f,
                focus: D,
                children: h,
                parents: u,
                getPath: d
            }
        }
    }),
    Ea = j({
        renderless: Boolean,
        ...te()
    }, "VVirtualScrollItem"),
    ja = Y()({
        name: "VVirtualScrollItem",
        inheritAttrs: !1,
        props: Ea(),
        emits: {
            "update:height": e => !0
        },
        setup(e, i) {
            let {
                attrs: t,
                emit: a,
                slots: n
            } = i;
            const {
                resizeRef: l,
                contentRect: s
            } = ft(void 0, "border");
            ue(() => {
                var o;
                return (o = s.value) == null ? void 0 : o.height
            }, o => {
                o != null && a("update:height", o)
            }), ee(() => {
                var o, c;
                return e.renderless ? r(le, null, [(o = n.default) == null ? void 0 : o.call(n, {
                    itemRef: l
                })]) : r("div", q({
                    ref: l,
                    class: ["v-virtual-scroll__item", e.class],
                    style: e.style
                }, t), [(c = n.default) == null ? void 0 : c.call(n)])
            })
        }
    }),
    Na = -1,
    Ga = 1,
    Ae = 100,
    $a = j({
        itemHeight: {
            type: [Number, String],
            default: null
        },
        height: [Number, String]
    }, "virtual");

function Ha(e, i) {
    const t = Kt(),
        a = X(0);
    ze(() => {
        a.value = parseFloat(e.itemHeight || 0)
    });
    const n = X(0),
        l = X(Math.ceil((parseInt(e.height) || t.height.value) / (a.value || 16)) || 1),
        s = X(0),
        o = X(0),
        c = E(),
        y = E();
    let C = 0;
    const {
        resizeRef: V,
        contentRect: h
    } = ft();
    ze(() => {
        V.value = c.value
    });
    const k = b(() => {
            var v;
            return c.value === document.documentElement ? t.height.value : ((v = h.value) == null ? void 0 : v.height) || parseInt(e.height) || 0
        }),
        u = b(() => !!(c.value && y.value && k.value && a.value));
    let f = Array.from({
            length: i.value.length
        }),
        d = Array.from({
            length: i.value.length
        });
    const p = X(0);
    let I = -1;

    function x(v) {
        return f[v] || a.value
    }
    const _ = qt(() => {
            const v = performance.now();
            d[0] = 0;
            const S = i.value.length;
            for (let T = 1; T <= S - 1; T++) d[T] = (d[T - 1] || 0) + x(T - 1);
            p.value = Math.max(p.value, performance.now() - v)
        }, p),
        N = ue(u, v => {
            v && (N(), C = y.value.offsetTop, _.immediate(), z(), ~I && at(() => {
                xe && window.requestAnimationFrame(() => {
                    ve(I), I = -1
                })
            }))
        });
    tt(() => {
        _.clear()
    });

    function O(v, S) {
        const T = f[v],
            L = a.value;
        a.value = L ? Math.min(a.value, S) : S, (T !== S || L !== a.value) && (f[v] = S, _())
    }

    function w(v) {
        return v = Pe(v, 0, i.value.length - 1), d[v] || 0
    }

    function $(v) {
        return Ua(d, v)
    }
    let J = 0,
        H = 0,
        Q = 0;
    ue(k, (v, S) => {
        S && (z(), v < S && requestAnimationFrame(() => {
            H = 0, z()
        }))
    });
    let D = -1;

    function P() {
        if (!c.value || !y.value) return;
        const v = c.value.scrollTop,
            S = performance.now();
        S - Q > 500 ? (H = Math.sign(v - J), C = y.value.offsetTop) : H = v - J, J = v, Q = S, window.clearTimeout(D), D = window.setTimeout(U, 500), z()
    }

    function U() {
        !c.value || !y.value || (H = 0, Q = 0, window.clearTimeout(D), z())
    }
    let ae = -1;

    function z() {
        cancelAnimationFrame(ae), ae = requestAnimationFrame(me)
    }

    function me() {
        if (!c.value || !k.value) return;
        const v = J - C,
            S = Math.sign(H),
            T = Math.max(0, v - Ae),
            L = Pe($(T), 0, i.value.length),
            g = v + k.value + Ae,
            A = Pe($(g) + 1, L + 1, i.value.length);
        if ((S !== Na || L < n.value) && (S !== Ga || A > l.value)) {
            const M = w(n.value) - w(L),
                Z = w(A) - w(l.value);
            Math.max(M, Z) > Ae ? (n.value = L, l.value = A) : (L <= 0 && (n.value = L), A >= i.value.length && (l.value = A))
        }
        s.value = w(n.value), o.value = w(i.value.length) - w(l.value)
    }

    function ve(v) {
        const S = w(v);
        !c.value || v && !S ? I = v : c.value.scrollTop = S
    }
    const m = b(() => i.value.slice(n.value, l.value).map((v, S) => ({
        raw: v,
        index: S + n.value,
        key: Wt(v) && "value" in v ? v.value : S + n.value
    })));
    return ue(i, () => {
        f = Array.from({
            length: i.value.length
        }), d = Array.from({
            length: i.value.length
        }), _.immediate(), z()
    }, {
        deep: !0
    }), {
        calculateVisibleItems: z,
        containerRef: c,
        markerRef: y,
        computedItems: m,
        paddingTop: s,
        paddingBottom: o,
        scrollToIndex: ve,
        handleScroll: P,
        handleScrollend: U,
        handleItemResize: O
    }
}

function Ua(e, i) {
    let t = e.length - 1,
        a = 0,
        n = 0,
        l = null,
        s = -1;
    if (e[t] < i) return t;
    for (; a <= t;)
        if (n = a + t >> 1, l = e[n], l > i) t = n - 1;
        else if (l < i) s = n, a = n + 1;
    else return l === i ? n : a;
    return s
}
const za = j({
        items: {
            type: Array,
            default: () => []
        },
        renderless: Boolean,
        ...$a(),
        ...te(),
        ...Ge()
    }, "VVirtualScroll"),
    Ka = Y()({
        name: "VVirtualScroll",
        props: za(),
        setup(e, i) {
            let {
                slots: t
            } = i;
            const a = dt("VVirtualScroll"),
                {
                    dimensionStyles: n
                } = Ne(e),
                {
                    calculateVisibleItems: l,
                    containerRef: s,
                    markerRef: o,
                    handleScroll: c,
                    handleScrollend: y,
                    handleItemResize: C,
                    scrollToIndex: V,
                    paddingTop: h,
                    paddingBottom: k,
                    computedItems: u
                } = Ha(e, B(e, "items"));
            return Xt(() => e.renderless, () => {
                function f() {
                    var I, x;
                    const p = (arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1) ? "addEventListener" : "removeEventListener";
                    s.value === document.documentElement ? (document[p]("scroll", c, {
                        passive: !0
                    }), document[p]("scrollend", y)) : ((I = s.value) == null || I[p]("scroll", c, {
                        passive: !0
                    }), (x = s.value) == null || x[p]("scrollend", y))
                }
                Tt(() => {
                    s.value = Jt(a.vnode.el, !0), f(!0)
                }), tt(f)
            }), ee(() => {
                const f = u.value.map(d => r(ja, {
                    key: d.key,
                    renderless: e.renderless,
                    "onUpdate:height": p => C(d.index, p)
                }, {
                    default: p => {
                        var I;
                        return (I = t.default) == null ? void 0 : I.call(t, {
                            item: d.raw,
                            index: d.index,
                            ...p
                        })
                    }
                }));
                return e.renderless ? r(le, null, [r("div", {
                    ref: o,
                    class: "v-virtual-scroll__spacer",
                    style: {
                        paddingTop: fe(h.value)
                    }
                }, null), f, r("div", {
                    class: "v-virtual-scroll__spacer",
                    style: {
                        paddingBottom: fe(k.value)
                    }
                }, null)]) : r("div", {
                    ref: s,
                    class: ["v-virtual-scroll", e.class],
                    onScrollPassive: c,
                    onScrollend: y,
                    style: [n.value, e.style]
                }, [r("div", {
                    ref: o,
                    class: "v-virtual-scroll__container",
                    style: {
                        paddingTop: fe(h.value),
                        paddingBottom: fe(k.value)
                    }
                }, [f])])
            }), {
                calculateVisibleItems: l,
                scrollToIndex: V
            }
        }
    });

function qa(e, i) {
    const t = X(!1);
    let a;

    function n(o) {
        cancelAnimationFrame(a), t.value = !0, a = requestAnimationFrame(() => {
            a = requestAnimationFrame(() => {
                t.value = !1
            })
        })
    }
    async function l() {
        await new Promise(o => requestAnimationFrame(o)), await new Promise(o => requestAnimationFrame(o)), await new Promise(o => requestAnimationFrame(o)), await new Promise(o => {
            if (t.value) {
                const c = ue(t, () => {
                    c(), o()
                })
            } else o()
        })
    }
    async function s(o) {
        var C, V;
        if (o.key === "Tab" && ((C = i.value) == null || C.focus()), !["PageDown", "PageUp", "Home", "End"].includes(o.key)) return;
        const c = (V = e.value) == null ? void 0 : V.$el;
        if (!c) return;
        (o.key === "Home" || o.key === "End") && c.scrollTo({
            top: o.key === "Home" ? 0 : c.scrollHeight,
            behavior: "smooth"
        }), await l();
        const y = c.querySelectorAll(":scope > :not(.v-virtual-scroll__spacer)");
        if (o.key === "PageDown" || o.key === "Home") {
            const h = c.getBoundingClientRect().top;
            for (const k of y)
                if (k.getBoundingClientRect().top >= h) {
                    k.focus();
                    break
                }
        } else {
            const h = c.getBoundingClientRect().bottom;
            for (const k of [...y].reverse())
                if (k.getBoundingClientRect().bottom <= h) {
                    k.focus();
                    break
                }
        }
    }
    return {
        onScrollPassive: n,
        onKeydown: s
    }
}
const Wa = j({
        chips: Boolean,
        closableChips: Boolean,
        closeText: {
            type: String,
            default: "$vuetify.close"
        },
        openText: {
            type: String,
            default: "$vuetify.open"
        },
        eager: Boolean,
        hideNoData: Boolean,
        hideSelected: Boolean,
        listProps: {
            type: Object
        },
        menu: Boolean,
        menuIcon: {
            type: W,
            default: "$dropdown"
        },
        menuProps: {
            type: Object
        },
        multiple: Boolean,
        noDataText: {
            type: String,
            default: "$vuetify.noDataText"
        },
        openOnClear: Boolean,
        itemColor: String,
        ...Vt({
            itemChildren: !1
        })
    }, "Select"),
    Xa = j({ ...Wa(),
        ...we(Bt({
            modelValue: null,
            role: "combobox"
        }), ["validationValue", "dirty", "appendInnerIcon"]),
        ...Dt({
            transition: {
                component: Qt
            }
        })
    }, "VSelect"),
    sn = Y()({
        name: "VSelect",
        props: Xa(),
        emits: {
            "update:focused": e => !0,
            "update:modelValue": e => !0,
            "update:menu": e => !0
        },
        setup(e, i) {
            let {
                slots: t
            } = i;
            const {
                t: a
            } = st(), n = E(), l = E(), s = E(), o = re(e, "menu"), c = b({
                get: () => o.value,
                set: m => {
                    var v;
                    o.value && !m && ((v = l.value) != null && v.ΨopenChildren.size) || (o.value = m)
                }
            }), {
                items: y,
                transformIn: C,
                transformOut: V
            } = _a(e), h = re(e, "modelValue", [], m => C(m === null ? [null] : je(m)), m => {
                const v = V(m);
                return e.multiple ? v : v[0] ? ? null
            }), k = b(() => typeof e.counterValue == "function" ? e.counterValue(h.value) : typeof e.counterValue == "number" ? e.counterValue : h.value.length), u = xt(e), f = b(() => h.value.map(m => m.value)), d = X(!1), p = b(() => c.value ? e.closeText : e.openText);
            let I = "",
                x;
            const _ = b(() => e.hideSelected ? y.value.filter(m => !h.value.some(v => e.valueComparator(v, m))) : y.value),
                N = b(() => e.hideNoData && !_.value.length || u.isReadonly.value || u.isDisabled.value),
                O = b(() => {
                    var m;
                    return { ...e.menuProps,
                        activatorProps: { ...((m = e.menuProps) == null ? void 0 : m.activatorProps) || {},
                            "aria-haspopup": "listbox"
                        }
                    }
                }),
                w = E(),
                $ = qa(w, n);

            function J(m) {
                e.openOnClear && (c.value = !0)
            }

            function H() {
                N.value || (c.value = !c.value)
            }

            function Q(m) {
                Ke(m) && D(m)
            }

            function D(m) {
                var L, g;
                if (!m.key || u.isReadonly.value) return;
                ["Enter", " ", "ArrowDown", "ArrowUp", "Home", "End"].includes(m.key) && m.preventDefault(), ["Enter", "ArrowDown", " "].includes(m.key) && (c.value = !0), ["Escape", "Tab"].includes(m.key) && (c.value = !1), m.key === "Home" ? (L = w.value) == null || L.focus("first") : m.key === "End" && ((g = w.value) == null || g.focus("last"));
                const v = 1e3;
                if (!Ke(m)) return;
                const S = performance.now();
                S - x > v && (I = ""), I += m.key.toLowerCase(), x = S;
                const T = y.value.find(A => A.title.toLowerCase().startsWith(I));
                if (T !== void 0) {
                    h.value = [T];
                    const A = _.value.indexOf(T);
                    xe && window.requestAnimationFrame(() => {
                        var M;
                        A >= 0 && ((M = s.value) == null || M.scrollToIndex(A))
                    })
                }
            }

            function P(m) {
                let v = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
                if (!m.props.disabled)
                    if (e.multiple) {
                        const S = h.value.findIndex(L => e.valueComparator(L.value, m.value)),
                            T = v ? ? !~S;
                        if (~S) {
                            const L = T ? [...h.value, m] : [...h.value];
                            L.splice(S, 1), h.value = L
                        } else T && (h.value = [...h.value, m])
                    } else {
                        const S = v !== !1;
                        h.value = S ? [m] : [], at(() => {
                            c.value = !1
                        })
                    }
            }

            function U(m) {
                var v;
                (v = w.value) != null && v.$el.contains(m.relatedTarget) || (c.value = !1)
            }

            function ae() {
                var m;
                e.eager && ((m = s.value) == null || m.calculateVisibleItems())
            }

            function z() {
                var m;
                d.value && ((m = n.value) == null || m.focus())
            }

            function me(m) {
                d.value = !0
            }

            function ve(m) {
                if (m == null) h.value = [];
                else if (qe(n.value, ":autofill") || qe(n.value, ":-webkit-autofill")) {
                    const v = y.value.find(S => S.title === m);
                    v && P(v)
                } else n.value && (n.value.value = "")
            }
            return ue(c, () => {
                if (!e.hideSelected && c.value && h.value.length) {
                    const m = _.value.findIndex(v => h.value.some(S => e.valueComparator(S.value, v.value)));
                    xe && window.requestAnimationFrame(() => {
                        var v;
                        m >= 0 && ((v = s.value) == null || v.scrollToIndex(m))
                    })
                }
            }), ue(() => e.items, (m, v) => {
                c.value || d.value && !v.length && m.length && (c.value = !0)
            }), ee(() => {
                const m = !!(e.chips || t.chip),
                    v = !!(!e.hideNoData || _.value.length || t["prepend-item"] || t["append-item"] || t["no-data"]),
                    S = h.value.length > 0,
                    T = Ue.filterProps(e),
                    L = S || !d.value && e.label && !e.persistentPlaceholder ? void 0 : e.placeholder;
                return r(Ue, q({
                    ref: n
                }, T, {
                    modelValue: h.value.map(g => g.props.value).join(", "),
                    "onUpdate:modelValue": ve,
                    focused: d.value,
                    "onUpdate:focused": g => d.value = g,
                    validationValue: h.externalValue,
                    counterValue: k.value,
                    dirty: S,
                    class: ["v-select", {
                        "v-select--active-menu": c.value,
                        "v-select--chips": !!e.chips,
                        [`v-select--${e.multiple?"multiple":"single"}`]: !0,
                        "v-select--selected": h.value.length,
                        "v-select--selection-slot": !!t.selection
                    }, e.class],
                    style: e.style,
                    inputmode: "none",
                    placeholder: L,
                    "onClick:clear": J,
                    "onMousedown:control": H,
                    onBlur: U,
                    onKeydown: D,
                    "aria-label": a(p.value),
                    title: a(p.value)
                }), { ...t,
                    default: () => r(le, null, [r(ea, q({
                        ref: l,
                        modelValue: c.value,
                        "onUpdate:modelValue": g => c.value = g,
                        activator: "parent",
                        contentClass: "v-select__content",
                        disabled: N.value,
                        eager: e.eager,
                        maxHeight: 310,
                        openOnClick: !1,
                        closeOnContentClick: !1,
                        transition: e.transition,
                        onAfterEnter: ae,
                        onAfterLeave: z
                    }, O.value), {
                        default: () => [v && r(Ra, q({
                            ref: w,
                            selected: f.value,
                            selectStrategy: e.multiple ? "independent" : "single-independent",
                            onMousedown: g => g.preventDefault(),
                            onKeydown: Q,
                            onFocusin: me,
                            tabindex: "-1",
                            "aria-live": "polite",
                            color: e.itemColor ? ? e.color
                        }, $, e.listProps), {
                            default: () => {
                                var g, A, M;
                                return [(g = t["prepend-item"]) == null ? void 0 : g.call(t), !_.value.length && !e.hideNoData && (((A = t["no-data"]) == null ? void 0 : A.call(t)) ? ? r(ke, {
                                    key: "no-data",
                                    title: a(e.noDataText)
                                }, null)), r(Ka, {
                                    ref: s,
                                    renderless: !0,
                                    items: _.value
                                }, {
                                    default: Z => {
                                        var K;
                                        let {
                                            item: G,
                                            index: ie,
                                            itemRef: R
                                        } = Z;
                                        const ye = q(G.props, {
                                            ref: R,
                                            key: G.value,
                                            onClick: () => P(G, null)
                                        });
                                        return ((K = t.item) == null ? void 0 : K.call(t, {
                                            item: G,
                                            index: ie,
                                            props: ye
                                        })) ? ? r(ke, q(ye, {
                                            role: "option"
                                        }), {
                                            prepend: Pt => {
                                                let {
                                                    isSelected: At
                                                } = Pt;
                                                return r(le, null, [e.multiple && !e.hideSelected ? r(oa, {
                                                    key: G.value,
                                                    modelValue: At,
                                                    ripple: !1,
                                                    tabindex: "-1"
                                                }, null) : void 0, G.props.prependAvatar && r(ge, {
                                                    image: G.props.prependAvatar
                                                }, null), G.props.prependIcon && r(se, {
                                                    icon: G.props.prependIcon
                                                }, null)])
                                            }
                                        })
                                    }
                                }), (M = t["append-item"]) == null ? void 0 : M.call(t)]
                            }
                        })]
                    }), h.value.map((g, A) => {
                        function M(R) {
                            R.stopPropagation(), R.preventDefault(), P(g, !1)
                        }
                        const Z = {
                                "onClick:close": M,
                                onKeydown(R) {
                                    R.key !== "Enter" && R.key !== " " || (R.preventDefault(), R.stopPropagation(), M(R))
                                },
                                onMousedown(R) {
                                    R.preventDefault(), R.stopPropagation()
                                },
                                modelValue: !0,
                                "onUpdate:modelValue": void 0
                            },
                            G = m ? !!t.chip : !!t.selection,
                            ie = G ? Yt(m ? t.chip({
                                item: g,
                                index: A,
                                props: Z
                            }) : t.selection({
                                item: g,
                                index: A
                            })) : void 0;
                        if (!(G && !ie)) return r("div", {
                            key: g.value,
                            class: "v-select__selection"
                        }, [m ? t.chip ? r(oe, {
                            key: "chip-defaults",
                            defaults: {
                                VChip: {
                                    closable: e.closableChips,
                                    size: "small",
                                    text: g.title
                                }
                            }
                        }, {
                            default: () => [ie]
                        }) : r(ca, q({
                            key: "chip",
                            closable: e.closableChips,
                            size: "small",
                            text: g.title,
                            disabled: g.props.disabled
                        }, Z), null) : ie ? ? r("span", {
                            class: "v-select__selection-text"
                        }, [g.title, e.multiple && A < h.value.length - 1 && r("span", {
                            class: "v-select__selection-comma"
                        }, [Lt(",")])])])
                    })]),
                    "append-inner": function() {
                        var Z;
                        for (var g = arguments.length, A = new Array(g), M = 0; M < g; M++) A[M] = arguments[M];
                        return r(le, null, [(Z = t["append-inner"]) == null ? void 0 : Z.call(t, ...A), e.menuIcon ? r(se, {
                            class: "v-select__menu-icon",
                            icon: e.menuIcon
                        }, null) : void 0])
                    }
                })
            }), Ot({
                isFocused: d,
                menu: c,
                select: P
            }, n)
        }
    });
export {
    oa as V, sn as a, Ta as b, Ra as c, ke as d, ca as e, sa as m
};