import {
    F as b,
    h as f,
    L as g,
    cp as o,
    _ as p
} from "./BbvgifQp.js";
import {
    z as h,
    _ as k,
    V as y,
    a0 as s,
    D as r,
    W as c,
    a2 as d,
    a1 as i,
    u as _
} from "./BBZLTf3A.js";
(function() {
    try {
        var t = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            e = new t.Error().stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "4fdca7cb-1aa5-44b0-8bdb-f31f579a774d", t._sentryDebugIdIdentifier = "sentry-dbid-4fdca7cb-1aa5-44b0-8bdb-f31f579a774d")
    } catch {}
})();
const m = {
        class: "header__btn-wrapper"
    },
    I = {
        class: "header__btn"
    },
    C = {
        class: "header__btn"
    },
    D = h({
        __name: "HeaderAuthActions",
        setup(t) {
            const {
                displayDialog: e
            } = b(), {
                t: a
            } = f();

            function l() {
                e("auth"), o({
                    category: "header",
                    action: "registration"
                })
            }

            function u() {
                e("registration"), o({
                    category: "header",
                    action: "registration"
                })
            }
            return (v, w) => {
                const n = g;
                return y(), k("div", m, [s("div", I, [r(n, {
                    id: "auth_btn",
                    block: "",
                    color: "primary",
                    "btn-data-auto-test-el": "signIn",
                    "data-ignore-event-locker": "",
                    onClick: l
                }, {
                    default: c(() => [d(i(_(a)("buttons.signIn")), 1)]),
                    _: 1
                })]), s("div", C, [r(n, {
                    id: "reg_btn",
                    "inner-content-id": "reg_btn-text",
                    block: "",
                    color: "green",
                    "btn-data-auto-test-el": "signUp",
                    "data-ignore-event-locker": "",
                    onClick: u
                }, {
                    default: c(() => [d(i(_(a)("buttons.register")), 1)]),
                    _: 1
                })])])
            }
        }
    }),
    B = p(D, [
        ["__scopeId", "data-v-041d5fcb"]
    ]);
export {
    B as
    default
};