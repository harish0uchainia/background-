/* empty css        */
import {
    U as m,
    W as C,
    X as S,
    Y as k,
    Z as c
} from "./BbvgifQp.js";
import {
    d as w,
    A as N,
    E as u
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "a939e007-142d-4cea-92a2-7223ec018806", e._sentryDebugIdIdentifier = "sentry-dbid-a939e007-142d-4cea-92a2-7223ec018806")
    } catch {}
})();
const j = c.reduce((e, n) => (e[n] = {
        type: [Boolean, String, Number],
        default: !1
    }, e), {}),
    V = c.reduce((e, n) => {
        const t = "offset" + u(n);
        return e[t] = {
            type: [String, Number],
            default: null
        }, e
    }, {}),
    v = c.reduce((e, n) => {
        const t = "order" + u(n);
        return e[t] = {
            type: [String, Number],
            default: null
        }, e
    }, {}),
    y = {
        col: Object.keys(j),
        offset: Object.keys(V),
        order: Object.keys(v)
    };

function _(e, n, t) {
    let s = e;
    if (!(t == null || t === !1)) {
        if (n) {
            const a = n.replace(e, "");
            s += `-${a}`
        }
        return e === "col" && (s = "v-" + s), e === "col" && (t === "" || t === !0) || (s += `-${t}`), s.toLowerCase()
    }
}
const O = ["auto", "start", "end", "center", "baseline", "stretch"],
    G = C({
        cols: {
            type: [Boolean, String, Number],
            default: !1
        },
        ...j,
        offset: {
            type: [String, Number],
            default: null
        },
        ...V,
        order: {
            type: [String, Number],
            default: null
        },
        ...v,
        alignSelf: {
            type: String,
            default: null,
            validator: e => O.includes(e)
        },
        ...k(),
        ...S()
    }, "VCol"),
    x = m()({
        name: "VCol",
        props: G(),
        setup(e, n) {
            let {
                slots: t
            } = n;
            const s = w(() => {
                const a = [];
                let l;
                for (l in y) y[l].forEach(o => {
                    const i = e[o],
                        g = _(l, o, i);
                    g && a.push(g)
                });
                const r = a.some(o => o.startsWith("v-col-"));
                return a.push({
                    "v-col": !r || !e.cols,
                    [`v-col-${e.cols}`]: e.cols,
                    [`offset-${e.offset}`]: e.offset,
                    [`order-${e.order}`]: e.order,
                    [`align-self-${e.alignSelf}`]: e.alignSelf
                }), a
            });
            return () => {
                var a;
                return N(e.tag, {
                    class: [s.value, e.class],
                    style: e.style
                }, (a = t.default) == null ? void 0 : a.call(t))
            }
        }
    }),
    f = ["start", "end", "center"],
    L = ["space-between", "space-around", "space-evenly"];

function d(e, n) {
    return c.reduce((t, s) => {
        const a = e + u(s);
        return t[a] = n(), t
    }, {})
}
const U = [...f, "baseline", "stretch"],
    h = e => U.includes(e),
    $ = d("align", () => ({
        type: String,
        default: null,
        validator: h
    })),
    R = [...f, ...L],
    E = e => R.includes(e),
    P = d("justify", () => ({
        type: String,
        default: null,
        validator: E
    })),
    T = [...f, ...L, "stretch"],
    A = e => T.includes(e),
    I = d("alignContent", () => ({
        type: String,
        default: null,
        validator: A
    })),
    b = {
        align: Object.keys($),
        justify: Object.keys(P),
        alignContent: Object.keys(I)
    },
    B = {
        align: "align",
        justify: "justify",
        alignContent: "align-content"
    };

function D(e, n, t) {
    let s = B[e];
    if (t != null) {
        if (n) {
            const a = n.replace(e, "");
            s += `-${a}`
        }
        return s += `-${t}`, s.toLowerCase()
    }
}
const M = C({
        dense: Boolean,
        noGutters: Boolean,
        align: {
            type: String,
            default: null,
            validator: h
        },
        ...$,
        justify: {
            type: String,
            default: null,
            validator: E
        },
        ...P,
        alignContent: {
            type: String,
            default: null,
            validator: A
        },
        ...I,
        ...k(),
        ...S()
    }, "VRow"),
    W = m()({
        name: "VRow",
        props: M(),
        setup(e, n) {
            let {
                slots: t
            } = n;
            const s = w(() => {
                const a = [];
                let l;
                for (l in b) b[l].forEach(r => {
                    const o = e[r],
                        i = D(l, r, o);
                    i && a.push(i)
                });
                return a.push({
                    "v-row--no-gutters": e.noGutters,
                    "v-row--dense": e.dense,
                    [`align-${e.align}`]: e.align,
                    [`justify-${e.justify}`]: e.justify,
                    [`align-content-${e.alignContent}`]: e.alignContent
                }), a
            });
            return () => {
                var a;
                return N(e.tag, {
                    class: ["v-row", s.value, e.class],
                    style: e.style
                }, (a = t.default) == null ? void 0 : a.call(t))
            }
        }
    });
export {
    W as V, x as a
};