import {
    v,
    k as b,
    _ as I
} from "./BbvgifQp.js";
import {
    z as w,
    ac as m,
    aA as V,
    ab as x,
    d as f,
    ad as B,
    B as h,
    _ as k,
    V as E,
    a7 as R,
    D as C,
    J as M,
    W as p,
    $ as l
} from "./BBZLTf3A.js";
import {
    s as P
} from "./DCO7F8HW.js";
import {
    V as T
} from "./CNgVgUb9.js";
(function() {
    try {
        var a = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            s = new a.Error().stack;
        s && (a._sentryDebugIds = a._sentryDebugIds || {}, a._sentryDebugIds[s] = "a0feeccd-52cb-434a-bf7a-572e55821866", a._sentryDebugIdIdentifier = "sentry-dbid-a0feeccd-52cb-434a-bf7a-572e55821866")
    } catch {}
})();
const A = w({
        __name: "AppInputWrapper",
        props: m({
            appendIcon: {},
            appendInnerIcon: {},
            backgroundColor: {},
            customClassName: {},
            autocompleteOff: {},
            autocomplete: {},
            name: {},
            color: {},
            clearable: {
                type: Boolean
            },
            disabled: {
                type: Boolean
            },
            hideDetails: {
                type: [Boolean, String]
            },
            errorMessages: {},
            errorMessage: {},
            height: {},
            label: {},
            placeholder: {},
            variant: {},
            density: {},
            prependIcon: {},
            maxErrors: {},
            prependInnerIcon: {},
            readonly: {
                type: Boolean
            },
            rules: {},
            dynamicRegexChange: {
                type: Boolean
            },
            regex: {},
            tabindex: {},
            type: {},
            value: {},
            dataAutoTestEl: {},
            persistentPlaceholder: {
                type: Boolean
            },
            innerInputId: {},
            inputMode: {}
        }, {
            modelValue: {},
            modelModifiers: {}
        }),
        emits: m(["input", "blur", "focus", "keypress"], ["update:modelValue"]),
        setup(a, {
            emit: s
        }) {
            const r = V(a, ["value", "dataAutoTestEl"]),
                d = s,
                u = x("input-wrapper"),
                {
                    isHasUpdatedPassword: c
                } = v(b()),
                y = f(() => c.value),
                n = B(a, "modelValue"),
                i = f(() => new RegExp(r.regex, "g")),
                g = o => {
                    if (typeof n.value == "string" && o.key && !o.key.match(i.value) && r.dynamicRegexChange && y.value > 0) {
                        const e = n.value.match(i.value);
                        n.value = e ? e.join("") : ""
                    }
                };
            return h(() => {
                a.dataAutoTestEl && u.value && P(u.value, a.dataAutoTestEl)
            }), (o, e) => (E(), k("div", {
                class: R([o.customClassName, "input"])
            }, [C(T, M({
                ref: "input-wrapper",
                id: o.innerInputId,
                modelValue: n.value,
                "onUpdate:modelValue": e[0] || (e[0] = t => n.value = t)
            }, r, {
                "error-count": 4,
                "max-errors": o.maxErrors,
                inputmode: o.inputMode,
                "persistent-placeholder": o.persistentPlaceholder,
                onKeyup: g,
                onInput: e[1] || (e[1] = t => d("input", t)),
                onBlur: e[2] || (e[2] = t => d("blur", t)),
                onFocus: e[3] || (e[3] = t => d("focus", t)),
                onKeypress: e[4] || (e[4] = t => d("keypress", t))
            }), {
                append: p(() => [l(o.$slots, "append", {}, void 0, !0)]),
                prepend: p(() => [l(o.$slots, "prepend", {}, void 0, !0)]),
                "prepend-inner": p(() => [l(o.$slots, "prepend-inner", {}, void 0, !0)]),
                "append-inner": p(() => [l(o.$slots, "append-inner", {}, void 0, !0)]),
                _: 3
            }, 16, ["id", "modelValue", "max-errors", "inputmode", "persistent-placeholder"])], 2))
        }
    }),
    F = I(A, [
        ["__scopeId", "data-v-979715ae"]
    ]);
export {
    F as _
};