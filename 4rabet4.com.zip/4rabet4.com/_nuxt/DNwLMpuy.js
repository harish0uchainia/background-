import {
    h as N,
    g as T,
    c as z,
    j as $,
    f as R,
    a as V,
    by as j,
    _ as k
} from "./BbvgifQp.js";
import {
    u as w
} from "./Cc4FcFuq.js";
import {
    z as y,
    k as x,
    d as m,
    _ as v,
    a8 as C,
    u as n,
    V as l,
    a0 as b,
    U as d,
    W as _,
    an as E,
    aj as F,
    aD as H,
    al as U,
    Y as W,
    F as K,
    a9 as Y,
    am as q,
    D as G,
    a7 as J,
    ae as Q
} from "./BBZLTf3A.js";
import {
    _ as X
} from "./CIAn7tHz.js";
import "./1xKHoBf3.js";
(function() {
    try {
        var a = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            r = new a.Error().stack;
        r && (a._sentryDebugIds = a._sentryDebugIds || {}, a._sentryDebugIds[r] = "b61681e2-5294-44bc-bd4e-f90c94e8a5ef", a._sentryDebugIdIdentifier = "sentry-dbid-b61681e2-5294-44bc-bd4e-f90c94e8a5ef")
    } catch {}
})();

function g() {
    const a = navigator.userAgent || navigator.vendor || window.opera || "";
    return /android/i.test(a) ? "Android" : /iPad|iPhone|iPod/.test(a) && !window.MSStream ? "iOS" : "unknown"
}
const Z = ["rel", "href"],
    ee = ["src", "alt", "title"],
    te = y({
        __name: "CasinoSliderItemLink",
        props: {
            item: {},
            height: {}
        },
        setup(a) {
            const r = a,
                {
                    t: i
                } = N(),
                {
                    item: s
                } = x(r),
                c = V(),
                {
                    isAuthenticated: p
                } = T(),
                {
                    isMobile: u
                } = w(),
                {
                    changeUploadHost: f
                } = z(),
                {
                    trackButtonClick: D
                } = $(),
                {
                    openDialog: S
                } = R(),
                I = () => {
                    if (u && g() === "iOS") return c.app.appleBtn;
                    if (u && g() === "Android") return j
                },
                A = m(() => g() === "iOS"),
                B = m(() => {
                    var t, e;
                    return ((t = s.value) == null ? void 0 : t.image) && f((e = s.value) == null ? void 0 : e.image)
                }),
                O = m(() => {
                    var e, o;
                    return ((e = s.value) == null ? void 0 : e.mobile_apk_install) && I() || ((o = s.value) == null ? void 0 : o.location)
                });

            function L(t) {
                D({
                    category: "carousel",
                    action: t.name,
                    label: t.id
                })
            }

            function M(t) {
                var h;
                const e = t.currentTarget,
                    o = window.location.href === e.href;
                !e || !e.href || u.value && ((h = s.value) != null && h.mobile_apk_install) || e.href.includes("/live") && !o || e.href.includes("/sports") && !o || p.value || (t.preventDefault(), S(e.href.includes("casino/slot/") ? "auth" : "registration"))
            }

            function P(t, e) {
                M(t), L(e)
            }
            return (t, e) => n(s) ? (l(), v("a", {
                key: 0,
                class: "banner-item-link",
                rel: n(A) ? "nofollow" : "",
                href: n(O),
                onClick: e[0] || (e[0] = o => P(o, n(s)))
            }, [b("img", {
                src: n(B),
                alt: n(s).name,
                title: n(i)("pageTitles.bannerTitle"),
                loading: "lazy"
            }, null, 8, ee)], 8, Z)) : C("", !0)
        }
    }),
    ne = k(te, [
        ["__scopeId", "data-v-cca41085"]
    ]),
    ae = y({
        __name: "CasinoSliderSwiper",
        props: {
            bannerData: {
                default: null
            },
            height: {
                default: 0
            },
            displayDots: {
                type: Boolean,
                default: !0
            },
            items: {
                default: () => []
            }
        },
        setup(a) {
            const {
                isMobile: r
            } = w();
            return (i, s) => {
                const c = ne,
                    p = X;
                return l(), d(p, {
                    "fallback-tag": "div",
                    fallback: "Loading banner..."
                }, {
                    default: _(() => [b("div", {
                        class: "banner-wrapper",
                        style: E({
                            height: i.height ? i.height + "px" : ""
                        }),
                        "data-auto-test-el": "bannerMainContainer"
                    }, [i.items.length > 1 ? (l(), d(n(F), {
                        key: 0,
                        class: "swiper",
                        loop: !1,
                        "free-mode": !1,
                        mousewheel: !1,
                        "grab-cursor": !1,
                        "slides-per-view": 1,
                        "space-between": 10,
                        pagination: {
                            hideOnClick: !0,
                            el: ".swiper-pagination",
                            clickable: !0,
                            type: "bullets"
                        },
                        autoplay: {
                            delay: 1e4,
                            disableOnInteraction: !1
                        },
                        modules: [n(H), n(U)],
                        "update-on-window-resize": "",
                        "hidden-class": ""
                    }, {
                        default: _(() => [(l(!0), v(K, null, Y(i.items, (u, f) => (l(), d(n(q), {
                            key: "slide-" + f
                        }, {
                            default: _(() => [G(c, {
                                item: u
                            }, null, 8, ["item"])]),
                            _: 2
                        }, 1024))), 128)), W(b("div", {
                            class: J(["swiper-pagination", {
                                "swiper-pagination_right": n(r)
                            }]),
                            "data-auto-test-el": "bannerMainContainerButtons"
                        }, null, 2), [
                            [Q, i.displayDots]
                        ])]),
                        _: 1
                    }, 8, ["modules"])) : i.items.length === 1 ? (l(), d(c, {
                        key: 1,
                        item: i.items[0]
                    }, null, 8, ["item"])) : C("", !0)], 4)]),
                    _: 1
                })
            }
        }
    }),
    ue = k(ae, [
        ["__scopeId", "data-v-9be138ac"]
    ]);
export {
    ue as
    default
};