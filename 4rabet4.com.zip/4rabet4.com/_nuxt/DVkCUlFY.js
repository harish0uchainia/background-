import {
    Q as u,
    R as z,
    z as A
} from "./BbvgifQp.js";
import {
    d as n,
    z as k,
    Z as I,
    b,
    B,
    _ as x,
    $ as E,
    V as N,
    J as S,
    u as g,
    af as P
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            a = new e.Error().stack;
        a && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[a] = "01980d59-c5a4-4e2c-a47a-17d9491a8788", e._sentryDebugIdIdentifier = "sentry-dbid-01980d59-c5a4-4e2c-a47a-17d9491a8788")
    } catch {}
})();

function j(e) {
    var a;
    (a = performance == null ? void 0 : performance.mark) == null || a.call(performance, "mark_feature_usage", {
        detail: {
            feature: e
        }
    })
}
const w = {
        src: {
            type: String,
            required: !1
        },
        format: {
            type: String,
            required: !1
        },
        quality: {
            type: [Number, String],
            required: !1
        },
        background: {
            type: String,
            required: !1
        },
        fit: {
            type: String,
            required: !1
        },
        modifiers: {
            type: Object,
            required: !1
        },
        preset: {
            type: String,
            required: !1
        },
        provider: {
            type: String,
            required: !1
        },
        sizes: {
            type: [Object, String],
            required: !1
        },
        densities: {
            type: String,
            required: !1
        },
        preload: {
            type: [Boolean, Object],
            required: !1
        },
        width: {
            type: [String, Number],
            required: !1
        },
        height: {
            type: [String, Number],
            required: !1
        },
        alt: {
            type: String,
            required: !1
        },
        referrerpolicy: {
            type: String,
            required: !1
        },
        usemap: {
            type: String,
            required: !1
        },
        longdesc: {
            type: String,
            required: !1
        },
        ismap: {
            type: Boolean,
            required: !1
        },
        loading: {
            type: String,
            required: !1,
            validator: e => ["lazy", "eager"].includes(e)
        },
        crossorigin: {
            type: [Boolean, String],
            required: !1,
            validator: e => ["anonymous", "use-credentials", "", !0, !1].includes(e)
        },
        decoding: {
            type: String,
            required: !1,
            validator: e => ["async", "auto", "sync"].includes(e)
        },
        nonce: {
            type: [String],
            required: !1
        }
    },
    D = e => {
        const a = n(() => ({
                provider: e.provider,
                preset: e.preset
            })),
            t = n(() => ({
                width: u(e.width),
                height: u(e.height),
                alt: e.alt,
                referrerpolicy: e.referrerpolicy,
                usemap: e.usemap,
                longdesc: e.longdesc,
                ismap: e.ismap,
                crossorigin: e.crossorigin === !0 ? "anonymous" : e.crossorigin || void 0,
                loading: e.loading,
                decoding: e.decoding,
                nonce: e.nonce
            })),
            f = z(),
            i = n(() => ({ ...e.modifiers,
                width: u(e.width),
                height: u(e.height),
                format: e.format,
                quality: e.quality || f.options.quality,
                background: e.background,
                fit: e.fit
            }));
        return {
            options: a,
            attrs: t,
            modifiers: i
        }
    },
    H = { ...w,
        legacyFormat: {
            type: String,
            default: null
        },
        imgAttrs: {
            type: Object,
            default: null
        }
    },
    O = { ...w,
        placeholder: {
            type: [Boolean, String, Number, Array],
            required: !1
        },
        placeholderClass: {
            type: String,
            required: !1
        },
        custom: {
            type: Boolean,
            required: !1
        }
    },
    $ = ["src"],
    J = k({
        __name: "NuxtImg",
        props: O,
        emits: ["load", "error"],
        setup(e, {
            emit: a
        }) {
            const t = e,
                f = I(),
                i = a,
                v = !1,
                m = z(),
                o = D(t),
                d = b(!1),
                l = b(),
                c = n(() => m.getSizes(t.src, { ...o.options.value,
                    sizes: t.sizes,
                    densities: t.densities,
                    modifiers: { ...o.modifiers.value,
                        width: u(t.width),
                        height: u(t.height)
                    }
                })),
                h = n(() => {
                    const r = { ...o.attrs.value,
                        "data-nuxt-img": ""
                    };
                    return (!t.placeholder || d.value) && (r.sizes = c.value.sizes, r.srcset = c.value.srcset), r
                }),
                y = n(() => {
                    let r = t.placeholder;
                    if (r === "" && (r = !0), !r || d.value) return !1;
                    if (typeof r == "string") return r;
                    const s = Array.isArray(r) ? r : typeof r == "number" ? [r, r] : [10, 10];
                    return m(t.src, { ...o.modifiers.value,
                        width: s[0],
                        height: s[1],
                        quality: s[2] || 50,
                        blur: s[3] || 3
                    }, o.options.value)
                }),
                p = n(() => t.sizes ? c.value.src : m(t.src, o.modifiers.value, o.options.value)),
                q = n(() => y.value ? y.value : p.value),
                _ = A().isHydrating;
            return B(() => {
                if (y.value || t.custom) {
                    const r = new Image;
                    p.value && (r.src = p.value), t.sizes && (r.sizes = c.value.sizes || "", r.srcset = c.value.srcset), r.onload = s => {
                        d.value = !0, i("load", s)
                    }, r.onerror = s => {
                        i("error", s)
                    }, j("nuxt-image");
                    return
                }
                l.value && (l.value.complete && _ && (l.value.getAttribute("data-error") ? i("error", new Event("error")) : i("load", new Event("load"))), l.value.onload = r => {
                    i("load", r)
                }, l.value.onerror = r => {
                    i("error", r)
                })
            }), (r, s) => r.custom ? E(r.$slots, "default", P(S({
                key: 1
            }, { ...g(v) ? {
                    onerror: "this.setAttribute('data-error', 1)"
                } : {},
                imgAttrs: { ...h.value,
                    ...g(f)
                },
                isLoaded: d.value,
                src: q.value
            }))) : (N(), x("img", S({
                key: 0,
                ref_key: "imgEl",
                ref: l,
                class: t.placeholder && !d.value ? t.placeholderClass : void 0
            }, { ...g(v) ? {
                    onerror: "this.setAttribute('data-error', 1)"
                } : {},
                ...h.value,
                ...g(f)
            }, {
                src: q.value
            }), null, 16, $))
        }
    });
export {
    J as _, w as b, j as m, H as p, D as u
};