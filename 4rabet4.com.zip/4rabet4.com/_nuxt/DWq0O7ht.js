import {
    v as r,
    q as d,
    k as l,
    w as i
} from "./BbvgifQp.js";
import {
    d as w
} from "./BBZLTf3A.js";
(function() {
    try {
        var s = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            e = new s.Error().stack;
        e && (s._sentryDebugIds = s._sentryDebugIds || {}, s._sentryDebugIds[e] = "ca061117-adcc-4037-b391-a13ceaf28c4b", s._sentryDebugIdIdentifier = "sentry-dbid-ca061117-adcc-4037-b391-a13ceaf28c4b")
    } catch {}
})();

function p() {
    const {
        abtestPasswordCountries: s
    } = r(d()), {
        setNewPasswordLogic: e
    } = l(), {
        userGeo: o
    } = r(i()), n = w(() => o.value);
    return {
        setPasswordRules: () => {
            const u = n.value || "",
                c = (s.value || []).includes(u) && Math.random() > .5 ? 1 : 0,
                t = localStorage.getItem("hasNewPasswordRules"),
                a = t !== null ? +t : c;
            localStorage.setItem("hasNewPasswordRules", a.toString()), t && e(a)
        }
    }
}
export {
    p as u
};