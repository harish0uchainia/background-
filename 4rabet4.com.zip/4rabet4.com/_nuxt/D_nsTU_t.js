import {
    u as a
} from "./CNVksA_o.js";
import {
    d as t
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "4e9a7b26-f798-4c3e-8be8-abceac9a8dc5", e._sentryDebugIdIdentifier = "sentry-dbid-4e9a7b26-f798-4c3e-8be8-abceac9a8dc5")
    } catch {}
})();

function r() {
    const e = a(),
        n = t(() => e.isMobile),
        o = t(() => e.isDesktop),
        s = t(() => typeof window > "u" ? !1 : window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === !0);
    return {
        isMobileUa: n,
        isPcUa: o,
        isPWA: s
    }
}
export {
    r as u
};