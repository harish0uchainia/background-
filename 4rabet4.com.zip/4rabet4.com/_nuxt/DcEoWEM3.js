import {
    i as C,
    D as l,
    Y as h,
    ae as L,
    d as v,
    ar as j,
    I as z,
    t
} from "./BBZLTf3A.js";
import {
    a as Y
} from "./BulKdswA.js";
import {
    U as b,
    W as m,
    a4 as y,
    Y as V,
    aj as $,
    aK as T,
    a3 as F,
    au as w,
    l as K,
    a5 as N,
    ab as E,
    ar as O,
    ao as U,
    ap as W,
    X as D,
    ax as X,
    ay as q,
    az as H,
    ah as J,
    ag as M,
    ai as Q,
    ad as Z,
    aY as ee,
    ae
} from "./BbvgifQp.js";
import {
    u as ne,
    m as le
} from "./Q3GHUzCg.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            o = new e.Error().stack;
        o && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[o] = "abb46902-fb8f-4ce4-87f0-28735c34bfa4", e._sentryDebugIdIdentifier = "sentry-dbid-abb46902-fb8f-4ce4-87f0-28735c34bfa4")
    } catch {}
})();
const p = Symbol.for("vuetify:v-expansion-panel"),
    _ = m({ ...V(),
        ...le()
    }, "VExpansionPanelText"),
    k = b()({
        name: "VExpansionPanelText",
        props: _(),
        setup(e, o) {
            let {
                slots: n
            } = o;
            const a = C(p);
            if (!a) throw new Error("[Vuetify] v-expansion-panel-text needs to be placed inside v-expansion-panel");
            const {
                hasContent: i,
                onAfterLeave: u
            } = ne(e, a.isSelected);
            return y(() => l(Y, {
                onAfterLeave: u
            }, {
                default: () => {
                    var d;
                    return [h(l("div", {
                        class: ["v-expansion-panel-text", e.class],
                        style: e.style
                    }, [n.default && i.value && l("div", {
                        class: "v-expansion-panel-text__wrapper"
                    }, [(d = n.default) == null ? void 0 : d.call(n)])]), [
                        [L, a.isSelected.value]
                    ])]
                }
            })), {}
        }
    }),
    A = m({
        color: String,
        expandIcon: {
            type: E,
            default: "$expand"
        },
        collapseIcon: {
            type: E,
            default: "$collapse"
        },
        hideActions: Boolean,
        focusable: Boolean,
        static: Boolean,
        ripple: {
            type: [Boolean, Object],
            default: !1
        },
        readonly: Boolean,
        ...V(),
        ...N()
    }, "VExpansionPanelTitle"),
    S = b()({
        name: "VExpansionPanelTitle",
        directives: {
            Ripple: $
        },
        props: A(),
        setup(e, o) {
            let {
                slots: n
            } = o;
            const a = C(p);
            if (!a) throw new Error("[Vuetify] v-expansion-panel-title needs to be placed inside v-expansion-panel");
            const {
                backgroundColorClasses: i,
                backgroundColorStyles: u
            } = T(e, "color"), {
                dimensionStyles: d
            } = F(e), r = v(() => ({
                collapseIcon: e.collapseIcon,
                disabled: a.disabled.value,
                expanded: a.isSelected.value,
                expandIcon: e.expandIcon,
                readonly: e.readonly
            })), P = v(() => a.isSelected.value ? e.collapseIcon : e.expandIcon);
            return y(() => {
                var x;
                return h(l("button", {
                    class: ["v-expansion-panel-title", {
                        "v-expansion-panel-title--active": a.isSelected.value,
                        "v-expansion-panel-title--focusable": e.focusable,
                        "v-expansion-panel-title--static": e.static
                    }, i.value, e.class],
                    style: [u.value, d.value, e.style],
                    type: "button",
                    tabindex: a.disabled.value ? -1 : void 0,
                    disabled: a.disabled.value,
                    "aria-expanded": a.isSelected.value,
                    onClick: e.readonly ? void 0 : a.toggle
                }, [l("span", {
                    class: "v-expansion-panel-title__overlay"
                }, null), (x = n.default) == null ? void 0 : x.call(n, r.value), !e.hideActions && l(w, {
                    defaults: {
                        VIcon: {
                            icon: P.value
                        }
                    }
                }, {
                    default: () => {
                        var f;
                        return [l("span", {
                            class: "v-expansion-panel-title__icon"
                        }, [((f = n.actions) == null ? void 0 : f.call(n, r.value)) ? ? l(K, null, null)])]
                    }
                })]), [
                    [j("ripple"), e.ripple]
                ])
            }), {}
        }
    }),
    B = m({
        title: String,
        text: String,
        bgColor: String,
        ...H(),
        ...q(),
        ...X(),
        ...D(),
        ...A(),
        ..._()
    }, "VExpansionPanel"),
    ue = b()({
        name: "VExpansionPanel",
        props: B(),
        emits: {
            "group:selected": e => !0
        },
        setup(e, o) {
            let {
                slots: n
            } = o;
            const a = O(e, p),
                {
                    backgroundColorClasses: i,
                    backgroundColorStyles: u
                } = T(e, "bgColor"),
                {
                    elevationClasses: d
                } = U(e),
                {
                    roundedClasses: r
                } = W(e),
                P = v(() => (a == null ? void 0 : a.disabled.value) || e.disabled),
                x = v(() => a.group.items.value.reduce((c, s, g) => (a.group.selected.value.includes(s.id) && c.push(g), c), [])),
                f = v(() => {
                    const c = a.group.items.value.findIndex(s => s.id === a.id);
                    return !a.isSelected.value && x.value.some(s => s - c === 1)
                }),
                R = v(() => {
                    const c = a.group.items.value.findIndex(s => s.id === a.id);
                    return !a.isSelected.value && x.value.some(s => s - c === -1)
                });
            return z(p, a), y(() => {
                const c = !!(n.text || e.text),
                    s = !!(n.title || e.title),
                    g = S.filterProps(e),
                    G = k.filterProps(e);
                return l(e.tag, {
                    class: ["v-expansion-panel", {
                        "v-expansion-panel--active": a.isSelected.value,
                        "v-expansion-panel--before-active": f.value,
                        "v-expansion-panel--after-active": R.value,
                        "v-expansion-panel--disabled": P.value
                    }, r.value, i.value, e.class],
                    style: [u.value, e.style]
                }, {
                    default: () => [l("div", {
                        class: ["v-expansion-panel__shadow", ...d.value]
                    }, null), l(w, {
                        defaults: {
                            VExpansionPanelTitle: { ...g
                            },
                            VExpansionPanelText: { ...G
                            }
                        }
                    }, {
                        default: () => {
                            var I;
                            return [s && l(S, {
                                key: "title"
                            }, {
                                default: () => [n.title ? n.title() : e.title]
                            }), c && l(k, {
                                key: "text"
                            }, {
                                default: () => [n.text ? n.text() : e.text]
                            }), (I = n.default) == null ? void 0 : I.call(n)]
                        }
                    })]
                })
            }), {
                groupItem: a
            }
        }
    }),
    te = ["default", "accordion", "inset", "popout"],
    se = m({
        flat: Boolean,
        ...ae(),
        ...ee(B(), ["bgColor", "collapseIcon", "color", "eager", "elevation", "expandIcon", "focusable", "hideActions", "readonly", "ripple", "rounded", "tile", "static"]),
        ...Z(),
        ...V(),
        ...D(),
        variant: {
            type: String,
            default: "default",
            validator: e => te.includes(e)
        }
    }, "VExpansionPanels"),
    re = b()({
        name: "VExpansionPanels",
        props: se(),
        emits: {
            "update:modelValue": e => !0
        },
        setup(e, o) {
            let {
                slots: n
            } = o;
            const {
                next: a,
                prev: i
            } = J(e, p), {
                themeClasses: u
            } = M(e), d = v(() => e.variant && `v-expansion-panels--variant-${e.variant}`);
            return Q({
                VExpansionPanel: {
                    bgColor: t(e, "bgColor"),
                    collapseIcon: t(e, "collapseIcon"),
                    color: t(e, "color"),
                    eager: t(e, "eager"),
                    elevation: t(e, "elevation"),
                    expandIcon: t(e, "expandIcon"),
                    focusable: t(e, "focusable"),
                    hideActions: t(e, "hideActions"),
                    readonly: t(e, "readonly"),
                    ripple: t(e, "ripple"),
                    rounded: t(e, "rounded"),
                    static: t(e, "static")
                }
            }), y(() => l(e.tag, {
                class: ["v-expansion-panels", {
                    "v-expansion-panels--flat": e.flat,
                    "v-expansion-panels--tile": e.tile
                }, u.value, d.value, e.class],
                style: e.style
            }, {
                default: () => {
                    var r;
                    return [(r = n.default) == null ? void 0 : r.call(n, {
                        prev: i,
                        next: a
                    })]
                }
            })), {
                next: a,
                prev: i
            }
        }
    });
export {
    re as V, ue as a, S as b, k as c
};