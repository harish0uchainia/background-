import {
    v as f,
    k as C,
    w as E,
    b as g,
    bS as p,
    z as m,
    g as T,
    u as S
} from "./BbvgifQp.js";
import {
    u as k
} from "./Cc4FcFuq.js";
import {
    b as _,
    w as v
} from "./BBZLTf3A.js";
(function() {
    try {
        var a = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            r = new a.Error().stack;
        r && (a._sentryDebugIds = a._sentryDebugIds || {}, a._sentryDebugIds[r] = "5b916224-5292-43b9-910f-f15fccac40ff", a._sentryDebugIdIdentifier = "sentry-dbid-5b916224-5292-43b9-910f-f15fccac40ff")
    } catch {}
})();

function U() {
    const {
        isUserVip: a
    } = f(C()), r = _(!1), {
        userGeo: c
    } = f(E()), o = g("vip_user");
    return {
        isLoading: r,
        loadChatwootHelper: async () => {
            r.value = !0;
            try {
                if (window.chatwootSDK || document.querySelector('script[src="https://app.chatwoot.com/packs/js/sdk.js"]')) return;
                const n = a.value || o.value ? p.VIP : p[c.value] || p.IN;
                if (!n) {
                    console.error(`No Chatwoot settings found for geo: ${c.value}`);
                    return
                }
                await new Promise((i, t) => {
                    const e = document.createElement("script");
                    e.src = "https://app.chatwoot.com/packs/js/sdk.js", e.defer = !0, e.async = !0, document.body.appendChild(e), e.onload = () => {
                        window.chatwootSettings = {
                            position: "left",
                            locale: n.locale,
                            hideMessageBubble: !0
                        }, window.chatwootSDK.run({
                            websiteToken: n.websiteToken,
                            baseUrl: "https://app.chatwoot.com"
                        }), i()
                    }, e.onerror = () => {
                        t(new Error("Chatwoot SDK could not be loaded."))
                    }
                })
            } catch (n) {
                console.error(`Chatwoot error: ${n}`)
            } finally {
                r.value = !1
            }
        }
    }
}

function D() {
    const {
        $API: a
    } = m();
    return {
        sendDataToBackend: async ({
            email: c,
            senderId: o,
            accountId: s
        }) => {
            try {
                await a.ApiChat.sendChatDataToBackend({
                    email: c,
                    senderId: o,
                    accountId: s
                })
            } catch (n) {
                console.error("Error sending submit-chat-email:", n)
            }
        }
    }
}

function $() {
    const {
        isAuthenticated: a
    } = T();
    return {
        setUserInChatwoot: () => {
            const {
                userUUID: o,
                userFirstName: s,
                userCurrency: n
            } = f(C()), i = async () => {
                var t, e;
                a.value && o.value && window.$chatwoot && ((t = window.$chatwoot) == null || t.setUser(o.value, {
                    email: `user_${o.value}@4ra.com`,
                    identifier: o.value,
                    name: s.value || "Guest User",
                    avatar_url: "/"
                }), (e = window.$chatwoot) == null || e.setCustomAttributes({
                    currency: n.value || ""
                }))
            };
            window.addEventListener("chatwoot:ready", i)
        },
        resetChatwootUser: () => {
            window.$chatwoot && window.$chatwoot.reset()
        }
    }
}
const A = () => {
    const a = g("cw_conversation");
    return {
        reloadChatwoot: async () => {
            var o;
            const {
                loadChatwoot: c
            } = y();
            try {
                (o = window.$chatwoot) != null && o.reset && window.$chatwoot.reset(), delete window.$chatwoot, delete window.chatwootSDK, delete window.chatwootSettings, a.value = null;
                const s = document.querySelector('script[src="https://app.chatwoot.com/packs/js/sdk.js"]');
                s && s.remove();
                const n = i => {
                    var t;
                    (t = document.getElementById(i)) == null || t.remove()
                };
                n("cw-widget-holder"), n("cw-bubble-holder"), window.removeEventListener("chatwoot:on-message", () => {}), window.removeEventListener("chatwoot:ready", () => {}), await new Promise(i => setTimeout(i, 500)), await c()
            } catch (s) {
                console.error("Error reloading Chatwoot:", s)
            }
        }
    }
};

function y() {
    const {
        $config: a
    } = m(), {
        sendDataToBackend: r
    } = D(), {
        config: c
    } = S(), {
        setUserInChatwoot: o,
        resetChatwootUser: s
    } = $(), {
        reloadChatwoot: n
    } = A(), {
        loadChatwootHelper: i
    } = U(), {
        userUUID: t,
        isUserVip: e
    } = f(C()), d = g("is_chat_unauthorized_sent", {
        path: "/"
    }), l = async () => {
        c.value.IS_CHATWOOT_SET_USER_INTEGRATION && o()
    }, h = async w => {
        const {
            email: u,
            id: b
        } = w.detail.sender, I = w.detail.account_id;
        !t.value && u && (await r({
            email: u,
            senderId: b,
            accountId: I
        }), d.value = !0)
    };
    return {
        loadChatwoot: async () => {
            try {
                await i(), c.value.IS_CHATWOOT_SET_USER_INTEGRATION && (await l(), v(e, async (w, u) => {
                    w !== u && await n()
                }), v(t, async w => {
                    if (!w) {
                        s();
                        return
                    }
                    d.value && (s(), await new Promise(u => setTimeout(u, 2e3))), await l()
                }), window.addEventListener("chatwoot:on-message", h))
            } catch (w) {
                console.error("Error loading Chatwoot:", w)
            }
        },
        reloadChatwoot: n,
        updateUserInChatwoot: l,
        setUserInChatwoot: o
    }
}

function R() {
    const {
        loadChatwoot: a
    } = y(), {
        $privateLog: r
    } = m(), {
        isDesktop: c
    } = k(), o = () => window == null ? void 0 : window.$chatwoot, s = async () => {
        let t = o();
        if (!t) try {
            await a(), t = o()
        } catch (e) {
            r("Error loading $chatwoot:", String(e));
            return
        }
        t != null && t.toggle ? t.toggle("open") : t != null && t.open && t.open()
    }, n = () => new Promise((t, e) => {
        const d = setTimeout(() => {
                e(new Error("Chatwoot loading timeout"))
            }, 1e4),
            l = setInterval(() => {
                const h = o();
                h && (clearTimeout(d), clearInterval(l), t(h))
            }, 250)
    });
    return {
        openWidgetChat: s,
        loadWidgetChat: async (t = !1) => {
            try {
                await a();
                const e = await n();
                t && await s();
                const d = () => {
                    c.value && e.toggleBubbleVisibility && e.toggleBubbleVisibility("show")
                };
                return window.addEventListener("chatwoot:ready", d), () => window.removeEventListener("chatwoot:ready", d)
            } catch (e) {
                r("[Error loading chat widget]:", String(e))
            }
        }
    }
}
export {
    R as u
};