const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["./exT4JKqa.js", "./BbvgifQp.js", "./BBZLTf3A.js", "./swiper-vue.OzWMjU4A.css", "./entry.J6UAyoZA.css", "./Eh0EvCQt.js", "./NotificationDropdown.B3mw41Iv.css", "./DEf14JIh.js", "./HeaderAuthActions.DEks4V0n.css", "./CXu5n-4c.js", "./DVkCUlFY.js", "./BonusInstraction.BPCOkcGz.css", "./DChOOI6D.js", "./DkmTjkEY.js", "./DaP7mDoS.js", "./CasinoSeoText.BqyP0Aoi.css", "./C-tSONMA.js", "./DhKb1fFg.js", "./dQPzGnRW.js", "./BLXMHG5U.js", "./DYuKJgys.js", "./BqG8mLgx.js", "./Fk0ogu-X.js", "./SlotsSeoText.C4CDWUPy.css", "./CZlW6g-M.js", "./B4fA6PS_.js", "./VGrid.D0S0a0cH.css", "./AviatorSeoText.tT3XAjDV.css", "./C1reGLDx.js", "./IUR8xgfH.js", "./BOjjwF1y.js", "./ieK6h68u.js", "./0-IY7DnM.js", "./DD5lFqUU.js", "./DJLn8Y5-.js", "./CvllXjLd.js", "./CIiG4Tg6.js", "./C5OLVpw7.js", "./uakuixBb.js", "./BWFykjbH.js", "./Dxk4YADR.js", "./BZXhBWds.js", "./DY5EN8CR.js", "./Dn509E-E.js", "./D8KERa9S.js", "./BuRqQhew.js", "./CHm-x_4E.js", "./CRmddbRy.js", "./BbOXr_MO.js", "./TXVuk0CY.js", "./BHXT6HHF.js", "./IcYOZnOj.js", "./Cv0STUEp.js", "./M0EHyG2j.js", "./Dh46VNyu.js", "./CjdIMqbH.js", "./BFAkLyuy.js", "./D5jHg436.js", "./BX_8DwCz.js", "./CaQKB-7D.js", "./LmnuInVz.js", "./DOeNSoY6.js", "./2qvur7Ly.js", "./CBowTdAX.js", "./DV9JB3EK.js", "./bSJO1Ali.js", "./BR1TvFAJ.js", "./CKZ15vyB.js", "./0auYqxRJ.js", "./HB4841vv.js", "./DF9zLyti.js", "./Main-bdSeoText.CdjVdaw2.css", "./CqUEGiHy.js", "./Cl_kjHLb.js", "./Casino-bdSeoText.I3aVZoUt.css", "./C-eFFz-n.js", "./D2qWZ5eC.js", "./DqCtKBJg.js", "./sR-1d6Uq.js", "./DmeRSbOh.js", "./CGym_LSr.js", "./CZcLDuvs.js", "./CZdHkQAc.js", "./TXlEkOPv.js", "./DNwLMpuy.js", "./Cc4FcFuq.js", "./1xKHoBf3.js", "./CIAn7tHz.js", "./CasinoSliderSwiper.D-1XoxCa.css", "./lOafapvo.js", "./CyEI51nD.js", "./DBHC5eiV.js", "./sortedBanner.DksJfAqr.css", "./D5xT9ef6.js", "./D_nsTU_t.js", "./CNVksA_o.js", "./CRXlgDsv.js", "./PagesTitle.iBdyGeim.css", "./GL5mXhHm.js", "./C2rNhci2.js", "./BetbyLink.Cj4bkHFo.css", "./BMZwzS6C.js", "./BtdAVlWx.js", "./CBbqpxnU.js", "./CCvy_w1-.js", "./DDGpYvNX.js", "./CNgVgUb9.js", "./BulKdswA.js", "./CbxP4vag.js", "./BEPDeFGu.js", "./VTextField.DkEWA9Kv.css", "./D9sqA5Xl.js", "./Q3GHUzCg.js", "./B9YIqgoQ.js", "./VAvatar.CYkryKM7.css", "./iTYf75jB.js", "./VMenu.BwfwrVx9.css", "./BQ7ou4ZQ.js", "./ssrBoot.BsYIg1rJ.css", "./Ka2RWjod.js", "./VSelect.BKduvVt_.css", "./BGM-8W5I.js", "./Bm6Ktnmy.js", "./BX3KejHb.js", "./AppTimer.EjoztsoR.css", "./CbNZPVTM.js", "./WQ5Cu1Fz.js", "./7NJYkLaL.js", "./withdrawal-store.D-__JR4B.css", "./C_Bf1-bi.js", "./BGjWZMuE.js", "./sSbT21OI.js", "./Cz0MIU54.js", "./use-game-top-bar.WjIi3Oip.css", "./Dg0yrPgw.js", "./BytmlzwF.js", "./svg-slugs.zMVv3oBJ.css", "./C4K-6MHn.js", "./CVtksJDb.js", "./DcEoWEM3.js", "./VExpansionPanels.BlzZGA8i.css", "./Bhe_kv2Z.js", "./BQ66EBJG.js", "./BUXbqDP0.js", "./B9BXWkrE.js", "./B99ZEpuR.js", "./MobileButtonsInline.C_moKQaU.css", "./n2ZsJP0Z.js", "./DspbTaj6.js", "./BuDDDvke.js", "./VCard.8Js4-u2y.css", "./CL3SmZKg.js", "./VDialog.Dk_v9Av4.css", "./DialogWrapper.BCKkXFam.css", "./InfoDialog.DINbPOrM.css", "./DDfxgktf.js", "./InfoHistoryDialog.BHrjUfO2.css", "./BBTJuk9E.js", "./ApplyChangeBalance.CisZoKII.css", "./Con5w9Nv.js", "./DHxCvf5R.js", "./DCO7F8HW.js", "./AppInputWrapper.DCV2SDt0.css", "./BonusDialog.CVhMUstU.css", "./CQjX1EOx.js", "./BonusDetailsDialog.QGFEEPab.css", "./Dl6fhmgd.js", "./BonusDepositDialog.CMDXcPbF.css", "./R8VBEcXg.js", "./CancelBonusDepositDialog.RPXLJaRh.css", "./DZajOfN7.js", "./ConfirmDialog.B74h-I_c.css", "./dIXRJP0J.js", "./DownTimeDialog.wpSL4Xpz.css", "./B8XtuHhZ.js", "./D8SYA7Ha.js", "./PopupSlotDialog.BGfSPpib.css", "./Cpwiiytk.js", "./RefreshDialog.Bz2EFTKq.css", "./Bm_sYv59.js", "./ResetBalanceDialog.DscmTv_0.css", "./CU7zahs2.js", "./SlotBonusBlock.CgGc7nTQ.css", "./CKFe06ZD.js", "./SubConfirm.DUeCuGjL.css", "./Cfl1ekxD.js", "./WagerNoPossible.CPYjf3Qd.css", "./CUjF8jWh.js", "./YesNoDialog.BZDCALEJ.css", "./aKcxAXhf.js", "./PromoCodeActive.DURDQt5r.css", "./CTGpGhpy.js", "./CancelBonus.BVkx-GRk.css", "./Uvn3IYz8.js", "./D3cdnUJq.js", "./LoaderSpinner.CgeiAo1r.css", "./Bkh5hPBJ.js", "./BmQ_KTBh.js", "./WelcomeBonusBlock.BmQvWsJZ.css", "./BonusWelcomeChooseDialog.CUml7tIv.css", "./qbrMoZvN.js", "./CB2hNzxs.js", "./gfqGpLfr.js", "./checkSlotNameHasFake.DOfGiKs0.css", "./sMoUHNn4.js", "./Observer.DcLBg3y_.css", "./use-favorites-sections.ArqyqOuL.css", "./BcxiMhqF.js", "./D7fVG3Gq.js", "./VPagination.DrdZJ-hD.css", "./SearchDialog.ChYdJZHL.css", "./DS5eJvOG.js", "./quAyFRoR.js", "./jbIBlAba.js", "./D8uiyG0C.js", "./KgI_e0-N.js", "./CZeubTgC.js", "./BeLlcxC7.js", "./AppSelect.BFNqV6Cj.css", "./DPw3jDdk.js", "./BYAyGWVz.js", "./WithdrawList.C52b1Q3r.css", "./WithdrawalDialog.DohMW--H.css", "./_0nOH6tD.js", "./WithdrawSuccessDialog.x5ewg58Y.css", "./Bb8lP8E5.js", "./WithdrawAttentionDialog.p4RjJz5s.css", "./DL2n32KB.js", "./CgLBeiJ3.js", "./DD9dFLkG.js", "./VTabs.BTjDJZgH.css", "./DepositDialog.CtB9piT3.css", "./DDaE8tja.js", "./DepositRedirectDialog.CybhEUGe.css", "./D6Sl1U58.js", "./DepositCompleteAgainDialog.CBgc3IJV.css", "./C7l1kI0L.js", "./DepositFailedDialog.BvQnCC1A.css", "./HlOyknz0.js", "./BlockedByIp.CgQ-_6zy.css", "./MH9nEjN2.js", "./AppDrawer.DrM7pDRv.css"]))) => i.map(i => d[i]);
import {
    z as Ae,
    b as me,
    v as Y,
    q as At,
    w as be,
    t as ne,
    u as Ze,
    c2 as Rt,
    bJ as yo,
    bN as Do,
    h as re,
    d as Ve,
    c3 as ha,
    c4 as va,
    p as Ht,
    c5 as ga,
    a as Ke,
    c6 as ba,
    N as Bo,
    c as Oe,
    g as Te,
    k as he,
    bD as $o,
    bO as ya,
    c7 as wa,
    c8 as ka,
    c9 as Ia,
    o as xe,
    f as Ee,
    $ as Po,
    j as ye,
    bm as ce,
    U as xo,
    W as Oo,
    a3 as No,
    bX as Aa,
    a4 as Ro,
    X as Ta,
    a5 as Mo,
    Y as Ca,
    aK as Ea,
    ao as La,
    ag as Sa,
    ak as Da,
    aD as Ba,
    ad as $a,
    az as Pa,
    C as Ne,
    E as Xe,
    B as io,
    e as lo,
    I as xa,
    H as Oa,
    _ as Q,
    V as Me,
    l as Nt,
    A as co,
    n as _t,
    bz as Na,
    bF as Ra,
    bl as Pe,
    bR as Ma,
    by as Va,
    x as v,
    bA as Ha,
    s as Ua,
    ca as Fa,
    cb as Vo,
    S as yt,
    bB as za,
    F as Ga,
    G as wo,
    y as ja,
    bn as Wa,
    cc as qa
} from "./BbvgifQp.js";
import {
    _ as dt
} from "./DVkCUlFY.js";
import {
    e as Za,
    o as Ho,
    d as g,
    b as ee,
    u as e,
    B as Ce,
    l as Qt,
    D as h,
    t as Ka,
    J as Ut,
    z as oe,
    _ as b,
    V as l,
    a8 as $,
    F as ve,
    a9 as Be,
    U as F,
    an as ut,
    a7 as K,
    W as N,
    a0 as n,
    a2 as ae,
    a1 as x,
    f as Tt,
    aq as Xa,
    ai as Ya,
    aG as Qa,
    X as uo,
    $ as Ct,
    aa as nt,
    r as Uo,
    w as le,
    Y as at,
    Q as Z,
    ae as It,
    n as _o,
    C as Fo,
    a6 as Ft,
    ah as Ja,
    af as en,
    ag as tn,
    ar as on,
    y as an
} from "./BBZLTf3A.js";
import {
    a as nn,
    u as sn
} from "./BtdAVlWx.js";
import {
    u as pt
} from "./CBbqpxnU.js";
import {
    _ as po,
    M as ko,
    a as rn,
    b as ln
} from "./C2rNhci2.js";
import {
    u as mt
} from "./Eh0EvCQt.js";
import {
    _ as mo
} from "./CIAn7tHz.js";
import {
    c as De
} from "./CCvy_w1-.js";
import {
    a as cn,
    d as oo,
    c as un
} from "./DDGpYvNX.js";
import {
    _ as zt
} from "./CyEI51nD.js";
import {
    u as zo
} from "./BGM-8W5I.js";
import {
    b as _n,
    a as dn,
    c as pn,
    _ as mn
} from "./Bm6Ktnmy.js";
import {
    u as Et
} from "./D5xT9ef6.js";
import {
    u as Go
} from "./CbNZPVTM.js";
import {
    u as Ye
} from "./Cc4FcFuq.js";
import {
    u as jo
} from "./WQ5Cu1Fz.js";
import {
    u as fn,
    _ as hn
} from "./7NJYkLaL.js";
import {
    u as vn
} from "./C_Bf1-bi.js";
import {
    u as gn
} from "./sSbT21OI.js";
import {
    V as bn
} from "./iTYf75jB.js";
import {
    V as yn,
    u as Wo
} from "./Cz0MIU54.js";
import {
    u as fo
} from "./Dg0yrPgw.js";
import {
    _ as wn,
    S as kn
} from "./BytmlzwF.js";
import {
    u as ho
} from "./CRXlgDsv.js";
import {
    d as In
} from "./C4K-6MHn.js";
import {
    S as An,
    a as Tn,
    b as Cn,
    u as En
} from "./CVtksJDb.js";
import {
    V as qo,
    a as Zo,
    b as Ln,
    c as Sn
} from "./DcEoWEM3.js";
import {
    g as Ko,
    u as Xo
} from "./Bhe_kv2Z.js";
import {
    u as Dn
} from "./BMZwzS6C.js";
import {
    u as Bn
} from "./D_nsTU_t.js";
import {
    u as $n
} from "./BQ66EBJG.js";
import {
    u as Pn
} from "./BUXbqDP0.js";
import {
    u as xn
} from "./B9BXWkrE.js";
import {
    u as On
} from "./B99ZEpuR.js";
import {
    a as Nn
} from "./BGjWZMuE.js";
import {
    u as Rn
} from "./BQ7ou4ZQ.js";
(function() {
    try {
        var t = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            o = new t.Error().stack;
        o && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[o] = "0c300c47-bf0e-4d75-8fc9-b8aa83bb967a", t._sentryDebugIdIdentifier = "sentry-dbid-0c300c47-bf0e-4d75-8fc9-b8aa83bb967a")
    } catch {}
})();

function Mn() {
    return {
        useLocalStorage: En,
        useScriptTag: Cn,
        useStorage: Tn,
        StorageSerializers: An
    }
}
const vo = "i18n_lang";

function Mt(t) {
    var s;
    const {
        $i18n: o
    } = Ae();
    if ((me(vo).value || ((s = o.locale) == null ? void 0 : s.value) || o.locale) !== "pt") {
        if (t === "BD") return "bn";
        if (["BR", "MZ"].includes(t)) return "pt";
        if (["CI", "CM", "TG", "BF", "CD"].includes(t)) return "fr"
    }
}

function Yo() {
    const {
        $i18n: t
    } = Ae(), o = me(vo), {
        languages: a
    } = Y(At()), s = be(), i = ne(), c = g(() => a.value || []), u = g(() => c.value ? c.value.filter(m => t.locales.value.some(T => T.code === m.code)) : []);

    function f() {
        var m;
        return ((m = t == null ? void 0 : t.locales.value) == null ? void 0 : m.map(T => T.code)) || []
    }

    function r(m) {
        o.value = m, t.setLocale(m), s.updateLang(m)
    }

    function d(m) {
        const T = s.userGeo;
        return o.value ? o.value : T && Mt(T) ? Mt(T) : o.value || m || t.locale.value || t.locale
    }

    function _(m) {
        return f().includes(m) ? m : t.defaultLocale
    }

    function p() {
        const m = i.path.split("/")[1].length === 2 ? i.path.split("/")[1] : void 0;
        let T = d(m);
        T = _(T ? ? t.defaultLocale), r(T)
    }
    return {
        changeLocale: r,
        chooseLocale: d,
        languages: c,
        enabledLanguages: u,
        initLocaleServer: p,
        validateLocale: _
    }
}

function Vn() {
    const {
        $i18n: t
    } = Ae(), o = me(vo), {
        changeLocale: a,
        chooseLocale: s,
        validateLocale: i,
        languages: c
    } = Yo(), u = ee(!1);

    function f(_) {
        u.value = !0, a(_), u.value = !1
    }

    function r(_) {
        var E;
        const p = ((E = _.path) == null ? void 0 : E.split("/")[1].length) === 2 ? _.path.split("/")[1] : null,
            m = s(p ? ? void 0),
            T = i(m ? ? t.defaultLocale);
        f(T)
    }
    t.onBeforeLanguageSwitch = async (_, p) => u.value ? p : _;

    function d(_) {
        const {
            defaultLocale: p
        } = t, m = o.value, T = window.navigator.language, [E] = T.split("-");
        let k = p;
        if (m)
            for (const y of c.value) y.code === m && y.enabled && (k = y.code);
        else if (_ && Mt(_)) k = Mt(_) ? ? p;
        else if (E)
            for (const y of c.value) y.code === E && y.enabled && (k = y.code);
        k = i(k), f(k)
    }
    return Ho(() => {
        t.onBeforeLanguageSwitch = async () => {}
    }), {
        switchLocale: f,
        preventUsingDisabledLang: d,
        initLocaleClient: r
    }
}

function Hn() {
    let t = null,
        o = null,
        a = 0;
    const s = () => {
        t && --a <= 0 && o && (o.stop(), t = null, o = null)
    };
    return function() {
        return a++, o || (o = Za(!0), t = o.run(() => Vn())), Ho(() => s()), t
    }
}
const Qo = Hn(),
    Jt = [{
        url: "https://4ra-ext1.com",
        domain: ".4ra-ext1.com",
        is_redirect: 1,
        is_active: 1,
        is_user_group: !0,
        group: null
    }, {
        url: "https://4radop1.com",
        domain: ".4radop1.com",
        is_redirect: 1,
        is_active: 1,
        is_user_group: !0,
        group: null
    }, {
        id: 1,
        url: "https://4rabet24.com",
        domain: ".4rabet24.com",
        gtm: "GTM-T6P8T6N",
        is_redirect: !0,
        web_push: "//web.webpushs.com/js/push/44fcdbd0cd3197157bdbd9126d05692e_1.js",
        is_active: !1,
        is_current: null,
        is_user_group: !1,
        group: null
    }, {
        id: 4,
        url: "https://4rabetsite.com",
        domain: ".4rabetsite.com",
        gtm: "GTM-T6P8T6N",
        is_redirect: !0,
        web_push: "//web.webpushs.com/js/push/ae210f3853916577491d685ffb4a2a39_1.js",
        is_active: !0,
        is_current: null,
        is_user_group: !1,
        group: null
    }, {
        id: 7,
        url: "https://4rabet-x.com",
        domain: ".4rabet-x.com",
        gtm: "GTM-T6P8T6N",
        is_redirect: !1,
        web_push: "//web.webpushs.com/js/push/bf5bd80ed04f93cb2dbfcaf8b0a7dd5c_1.js",
        is_active: !0,
        is_current: null,
        is_user_group: !1,
        group: null
    }, {
        id: 10,
        url: "https://4rabet-i.com",
        domain: ".4rabet-i.com",
        gtm: "GTM-T6P8T6N",
        is_redirect: !1,
        web_push: "//web.webpushs.com/js/push/be9c1f7c8b67818ae1842299bb270aad_1.js",
        is_active: !0,
        is_current: null,
        is_user_group: !1,
        group: {
            id: 1,
            name: "20-100$"
        }
    }, {
        id: 13,
        url: "https://4rabet-g.com",
        domain: ".4rabet-g.com",
        gtm: "GTM-T6P8T6N",
        is_redirect: !1,
        web_push: "//web.webpushs.com/js/push/519d36f0c7292757152f245957eefff5_1.js",
        is_active: !0,
        is_current: null,
        is_user_group: !1,
        group: {
            id: 1,
            name: "20-100$"
        }
    }, {
        id: 16,
        url: "https://4rabet-q.com",
        domain: ".4rabet-q.com",
        gtm: "GTM-T6P8T6N",
        is_redirect: !1,
        web_push: "//web.webpushs.com/js/push/d5ab877043db33d66debcaefdc61631d_1.js",
        is_active: !0,
        is_current: null,
        is_user_group: !1,
        group: {
            id: 1,
            name: "20-100$"
        }
    }, {
        id: 19,
        url: "https://4rabet-w.com",
        domain: ".4rabet-w.com",
        gtm: "GTM-T6P8T6N",
        is_redirect: !1,
        web_push: "//web.webpushs.com/js/push/ca87ce20c0995db159cf9cc7e23ca0c2_1.js",
        is_active: !0,
        is_current: null,
        is_user_group: !1,
        group: null
    }, {
        id: 22,
        url: "https://4rabet-r.com",
        domain: ".4rabet-r.com",
        gtm: "GTM-T6P8T6N",
        is_redirect: !1,
        web_push: "//web.webpushs.com/js/push/50d6849c1ab3ba2c12e789634a24085f_1.js",
        is_active: !0,
        is_current: null,
        is_user_group: !1,
        group: null
    }, {
        id: 25,
        url: "https://4rabet-t.com",
        domain: ".4rabet-t.com",
        gtm: "GTM-T6P8T6N",
        is_redirect: !0,
        web_push: "//web.webpushs.com/js/push/621d8daeea01a134c65a8c6948e635c2_1.js",
        is_active: !0,
        is_current: null,
        is_user_group: !1,
        group: null
    }];

function Un() {
    const {
        $API: t
    } = Ae(), o = ne(), {
        config: a
    } = Ze(), {
        $privateLog: s
    } = Ae(), {
        loginToken: i,
        cluster: c,
        mirrorsBack: u
    } = Y(At()), f = Et(), r = g(() => window.location.origin), d = g(() => decodeURIComponent(i.value || "")), _ = g(() => decodeURIComponent(c.value || "")), p = g(() => {
        var w;
        return (w = a.value) != null && w.DOMAIN_FROM_BACKEND ? u.value ? ? [] : Jt
    }), m = g(() => p.value.filter(w => w.is_active && w.is_redirect)), T = g(() => p.value.filter(w => w.is_active && w.is_redirect && (w == null ? void 0 : w.group) == null)), E = g(() => p.value.find(w => w.url === r.value) || null), k = g(() => p.value.find(w => w.id === f.userMirrorId.value && w.is_active && w.is_redirect)), y = g(() => p.value.filter(w => !w.is_active || !w.is_redirect)), I = g(() => y.value.some(w => w.url === r.value)), B = g(() => {
        var w;
        return (w = a.value) != null && w.DOMAIN_FROM_BACKEND ? !!p.value.length : !!Jt.length
    }), z = g(() => {
        var C;
        let w = Jt;
        const P = [{
            url: "https://4rabet.com",
            domain: ".4rabet.com",
            gtm: "GTM-T6P8T6N",
            is_redirect: !1,
            web_push: "//web.webpushs.com/js/push/93088721901a7a5213487ebf79aa4fd7_1.js",
            is_active: !0,
            is_user_group: !1,
            group: null
        }, {
            url: "https://media4ra.com",
            domain: ".media4ra.com",
            gtm: "GTM-T6P8T6N",
            is_redirect: !1,
            is_active: !0,
            web_push: "",
            is_user_group: !1,
            group: null
        }];
        return (C = a.value) != null && C.DOMAIN_FROM_BACKEND && p.value.length && (w = p.value, w = w.concat(P)), w
    });

    function X(w, P) {
        const C = P.find(A => A.url === w);
        return C ? String(C.id) : ""
    }
    async function L(w) {
        var S, G, q;
        if (!E.value || E.value.id === f.userMirrorId.value) return;
        const C = X(w, p.value.map(M => ({
                url: M.url,
                id: String(M.id || "")
            }))) || ((S = k == null ? void 0 : k.value) == null ? void 0 : S.id) || E.value.id,
            A = me("vuexx");
        return t.ApiSettings.fetchCurrentMirror(C, {
            "Content-Type": "application/json;charset=utf-8",
            Authorization: `${(G=A.value)==null?void 0:G.token_type} ${(q=A.value)==null?void 0:q.access_token}`
        }).then(M => {
            if (!M.ok) throw new Error(`[bindMirrorToUser] Failed request, status ${M.status}`);
            return M.json()
        }).then(M => {
            console.info("[mirror binded]", M)
        }).catch(M => {
            console.info(`%c${M.message}`, "color: red; font-size: 18px"), console.info(`%c${M.stack}`, "color: red; font-size: 18px")
        })
    }
    async function H(w, P) {
        if (P < 0) return !1;
        const C = w[P].url;
        let A = C;
        A.split(".").length > 2 && (A = A.replace("app-nuxt3.", ""));
        const S = [`<link data-n-head="ssr" rel="canonical" href="${A}/`, `<link rel="canonical" href="${A}/`];
        try {
            const q = await (await fetch(C)).text();
            if (S.some(M => q.includes(M))) return w[P].url
        } catch (G) {
            console.error("checkMirror", G)
        }
        return s(w, "Current mirror is blocked! Try to find another one"), H(w, P - 1)
    }

    function U(w, P = 500) {
        var j, te;
        const C = new URL(w),
            A = new URL(window.location.href),
            S = (j = d.value) == null ? void 0 : j.split("=")[1],
            G = (te = _.value) == null ? void 0 : te.split("=")[1];
        let q = !1,
            M = !1;
        for (const [se, de] of A.searchParams.entries()) se === "login" && (q = !0), se === "cc" && (M = !0), se !== "v" && se !== "force-mirror-redirect" && C.searchParams.append(se, de);
        !q && S && C.searchParams.append("login", S), !M && G && C.searchParams.append("cc", G), C.host && !C.searchParams.get("redirect_host") && C.searchParams.append("redirect_host", C.host), yo() && C.searchParams.append("redirect_event_place", yo()), C.pathname = A.pathname, setTimeout(() => {
            L(w).then(() => {
                const se = me("redirect_host");
                se.value || (se.value = C.host), window.location.hostname.includes("localhost") ? console.info(`Redirect prevented on localhost: ${C.toString()}`) : window.location.href = C.toString()
            })
        }, P)
    }
    async function R() {
        var w, P, C, A, S, G, q;
        if (r.value.includes(Rt)) {
            console.info("Redirects are not allowed for br.4rabet.com");
            return
        }
        if ((w = o.query) != null && w.set_mr) return L(r.value);
        if (f.userMirrorId.value && !((P = o.query) != null && P.set_mr)) {
            let M = k.value;
            for (const j of m.value) j.id === f.userMirrorId.value && (j != null && j.is_current) && (j != null && j.is_active) && (j != null && j.is_redirect) && (M = j);
            if (M && M.url === r.value) return;
            if (M) {
                let j = null;
                if (await H([M], [M].length - 1).then(te => j = te), j) return U(j)
            }
        }
        if ((C = E.value) != null && C.group) {
            let M = null;
            if (await H(T.value, ((A = T.value) == null ? void 0 : A.length) - 1).then(j => M = j), M) return U(M)
        }
        if (E.value && ((S = E.value) == null ? void 0 : S.group) === null) return L(r.value);
        if ((G = m.value) != null && G.length && !m.value.some(M => M.url === r.value)) {
            let M = null;
            if (await H(m.value, ((q = m.value) == null ? void 0 : q.length) - 1).then(j => M = j), M) return U(M)
        }
    }
    return {
        bindMirrorToUser: L,
        currentMirror: E,
        allMirrors: p,
        loginToken: d,
        moveUserToProperMirror: R,
        iframeDomains: z,
        areMirrorsReadyToRender: B,
        isCurrentUrlIsProhibited: I
    }
}

function Fn(t, o = ["ru", "uk"]) {
    const a = {
        sw: "sh.js",
        "hi-bn": "bn.js"
    };
    return t.filter(s => !o.includes(s.code)).map(s => ({ ...s,
        file: a[s.code] || `${s.code}.js`
    }))
}

function go(t) {
    return Do.includes(t)
}

function zn() {
    const t = ne(),
        {
            locale: o
        } = re(),
        a = Ve(),
        s = a.host,
        i = Fn(va, ["hi-bn"]),
        c = Ko(t, o),
        u = (r, d) => {
            if (!d || d === "") return r;
            const _ = `${r}${d.startsWith("/")?"":"/"}${d}`;
            return _.endsWith("/") && _ !== `${r}/` ? _.slice(0, -1) : _
        };
    return {
        hreflangLinks: g(() => {
            const r = [{
                href: u(a.origin, c.value),
                rel: "alternate",
                hreflang: "x-default"
            }];
            if ([Rt, ha].includes(s)) {
                const _ = a.pathname.startsWith("/pt") ? a.pathname : `/pt/${c.value}`;
                r.push({
                    href: u(`https://${Rt}`, _),
                    rel: "alternate",
                    hreflang: "pt"
                })
            } else(go(s) ? i.filter(p => ["en", "bn"].includes(p.code)) : i).forEach(p => {
                const m = p.code === "en" ? c.value : `/${p.code}${c.value.startsWith("/")?"":"/"}${c.value}`;
                r.push({
                    href: u(a.origin, m),
                    rel: "alternate",
                    hreflang: p.code
                })
            });
            return r
        })
    }
}
const Gn = t => !!t && ga.includes(t),
    jn = t => t.replace(/[\[\]"<>\\]/g, "");

function Wn() {
    const t = ne(),
        o = Ke(),
        {
            fullDomain: a,
            currentHostDomain: s
        } = Ht(),
        i = g(() => {
            const u = s;
            if (Gn(u)) return `https://${u}`;
            const f = e(a),
                r = `https://${ba}`;
            return f === r ? o.app.fullDomain : f
        });
    return {
        canonicalUrl: g(() => {
            const u = t.path.startsWith("/") ? t.path : `/${t.path}`,
                f = jn(u);
            return `${i.value}${f}`
        })
    }
}
const qn = {
    "4rabet-x.com": "D7rKOTmSYftIOjJGkPGYgqqXBe51MiuUijYTxo2YA-c",
    "4rabet-i.com": "4c1vi45hTcX3robws2qRVC6ima94HcXFfad9PZnFxsA",
    "4rabet-g.com": "0l-Us6EnXpIm4ZEJ33AhnesFx2HUg8Nxmn_qIBlV710",
    "4rabet-w.com": "2tKAqPZ1KGJjPXNJ5yILljtZit68Hho8dmzwk00Q8Zc",
    "4rabet-r.com": "RXY_GcwVJgh1llb-ZcN_EBJIAhpeBrgeBVRGUKTHARU",
    "4rabet-t.com": "EiZhgyFsMCa5lZ_qxs43845JyUSQvOc5SRdSlwwaFfI",
    "4rabet-y.com": "OTWEFJQM8ijBq_2wZjHjwhisrdb_DdHIsawyfpA5c1o",
    "4rabet-e.com": "ivuZymqy2hRKIE3tbmDwG9fMwW9COc1GpgDwq1MHcjk",
    "4rabet-p.com": "jnVu_sXxTwpRAVgqhVcRmrdpaXx6jhDeR-KlmPd4bd4",
    "4rabet1.com": "4HcQo-o3UO-rgNhdPkbTpUDlGsPfj-owuSwkIMUZOQ0",
    "4rabet2.com": "io0vu_RcYXzYxnWzN5I5PR8NsFSQjkaziIEQ5KC_Wm0",
    "4rabet3.com": "ylYrNcYuMGV4DJkB5EP8yFTmiZU_1tMdZ7JYMluPstQ",
    "4rabet5.com": "PLFFKn3BfQS_nH4sqAT8zVNSGAqOhUjYxK1AuC91g1U",
    "4rabet6.com": "CIE3IKNFmbpGHq3A7cOytwk4dlYNW2FcQ3P5AZezm_Y",
    "4rabet7.com": "tBeW1ecImBLzZ5FFfP88awtqllssbqahZojRaUBak4I",
    "4rabet8.com": "uj75APevYqVH2OVmFt32Fw2wArcEH0a8Ri5oHVflNnE",
    "4rabet9.com": "AgQvv8zvxfV1Uz4LymDzAP33VP8itQPdtBJQ-J8Vqvw",
    "4rabet10.com": "hzxjjjqYNk4QVigwNtsBI2-YmOfuBLSOin0WC-t_2e4",
    "4rabet666.com": "peYOw3owTHcXgh5Mc_rOFfG_pHjFrY9nI_vFvuRicv8",
    "4rabet77.com": "LO_eIJlMm5ALArRtwq5YrAxZgI4nJJUQwK-VMZ1Yup4",
    "4rabet777.com": "a66jNcPcwkVl7_FxNf33ySf_Xj5-10Yy6tQd9sot69M",
    "4rabet365.com": "Zpre29dZHmnev-Sxwii1Ind8TKaIvVwHa82YGsH3haw",
    "4rabetvip.com": "qBTM2YTudcSUxo9T-0hlaBdrfBcWi4BIz_I4VcAu0DY",
    "foratraff.com": "BAyjK1MHqzV6w6bJUcDXzsMioz-nOXH14DpfWNmAIlU",
    "4rabet4.com": "xKXaLypZLRNk7s8jBRm-UkBrDdZvlOlCc3YW2aplZek",
    "4rabet001.com": "p2hIAwOkZH9JP9GZ0wrBhZ96yywbAJ5swQLwKVjilH4",
    "4rabet007.com": "LAgbMD4ezszbyzBFCACOngEkCB3FrLnXVe_s2yhx5zk",
    "4rabet0100.com": "sLiG7AWMIJJqX4Z-h3oqqHTuqhB-D2NSQgNKvOSf9FI",
    "4rabet013.com": "i_3-i0mQq9me7msUPeKzCtlG5n32_OCeJ9l76dQzfm8",
    "4rabet022.com": "sMQhWiDz1r4f3NCuJZZn9PUSUfgsmIUju-81UhqR9wI",
    "4rabet044.com": "jWjE-8qyKaB42-k0e7DN4adzQ2ri3SIr9oetaNhvu1E",
    "4rabet0555.com": "ONhNnKpx4pBBh2xdWOB8gQeUWw1bSbD8Q3aoLcIk3F0",
    "4rabet100.com": "aa5GZhMSsixykw4KTH6QyLyNOU6uaVKy-4ox2n18buo",
    "4rabet2play.com": "Xyrevaz40Dx-AmNa9UbAw-kyGuaVbvXSkxzju9MfUTg",
    "4rabet4premium.com": "dE73EvUWuW-aYtXw9OZEM-1P7vBJL-MHKsKTE2hO_mQ",
    "4rabet1000.com": "4O8lfrKv0QexcJ--ZvwEdi7xnZ-bU5K5wGSQUjjx9gs",
    "4rabet4prime.com": "TTvIDccd2j9YcuRXR4V7FpO0hKxmYxLEI29a1hYHpPY",
    "4rabet4top.com": "d_b-_KJXtHLuyZ5qgUhqaMSiIf7AWAkBRUcIxxXkITo",
    "4rabet55.com": "st5KZHETQF9ETSZ4AF0o2O3TsxeVnoyXgK0sV-yM8aw",
    "4rabet66.com": "dfG37Ub1KKpmP6rfxph6N4gAgSjXeiUy4eTTbUVq22M",
    "4rabet88.com": "5UMXQjfp28jVpdOo5NCMkd8IfZvTVPDDH-oYhyEI2Dc",
    "4rabet99.com": "kK8XFGUKWIiYsdwUb2okfBda9AwON2BEkaFixcnqOc4",
    "4rabetclub.com": "MygxJvl3as4PRZLQfT5MgIxE7tnyDyz9bIimDFjeRf0",
    "4rabetelite.com": "cc03WwBztFfs0Hx_XtK62XTnW3LPIPgQeC2xdjzirfU",
    "4rabetluxe.com": "wDOnbJE5WE30FSZWTWOjibcuAtviM0PRW5vQGVMmz7E",
    "4rabet22.com": "yYPmIobBCRU2hf464MB_kM1RQizv3LkPB1rr2EKaadQ",
    "4rabet32.com": "UilBzFYY8jmIcii-NdjqIEel2kImA5Fw5u88kOL4emA",
    "4rabet17.com": "roPWzk648FvDHVqx6qdfI9f9Id4JFmbaHcHdbSx_W3k",
    "4rabet11.com": "zMgfQfI-oBKK6rkN9bJ0Crv4fjuB8CV6gczj0CKbRzk",
    "4rabet14.com": "DU1dU89xSRS_R7b1t5y54oxd0HID8wr2FfEjmza2b4c",
    "4rabet4win.com": "LELKt2k3jKrK4wLA2sTtBnf3iijSvPinT2UTszK0XFE",
    "4rabet404win.com": "Dg_sj0LgwbCzQzcHlTh4rYsAn-yKLG1cXt_ll1wEzG0",
    "4rabet365win.com": "KtHxcBitAc08aEP2bTqZEz5GVdIcuWP4HaX9Lh_p79A",
    "4rabet44win.com": "YHEVAM2yPlwe-lHUtwgOPXx0yW3bFC7VstfWma4m1AM",
    "4rabet-play.com": "Tb2QrQJ1EsCdA0_CfDjmsUQien-a00kjT2SFxFye1oQ"
};

function Zn() {
    Ae();
    const t = window.location.host;
    return {
        googleMetaTag: {
            hid: "google-site-verification",
            name: "google-site-verification",
            content: qn[t] || ""
        }
    }
}

function Kn() {
    const t = Ke(),
        {
            optimoveSdkScriptObj: o,
            appWithOptimoveSdk: a
        } = xn(),
        s = Qn(),
        i = Yn(),
        c = ts();
    Bo({
        htmlAttrs: {
            lang: i
        },
        link: c,
        meta: s,
        script: (() => {
            const f = [{
                src: t.app.fingerprint,
                id: "fingerPrint",
                async: !0
            }, {
                type: "text/javascript",
                innerHTML: "window._mpevt = window._mpevt || []",
                id: "nuxt-mp-script"
            }, {
                type: "text/javascript",
                innerHTML: `(function(w,d,s,l,i){
        w[l]=w[l]||[];
        w[l].push({'gtm.start': new Date().getTime(), event:'gtm.js'});
        var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),
            dl=l!='dataLayer' ? '&l='+l : '';
        j.async=true;
        j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;
        f.parentNode.insertBefore(j,f);
      })(window,document,'script','dataLayer','GTM-T6P8T6N');`
            }, {
                src: "https://dev.visualwebsiteoptimizer.com/lib/1054809.js",
                async: !0,
                id: "vwo-script"
            }];
            return a && f.push(o), f
        })(),
        noscript: [{
            innerHTML: `<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T6P8T6N"
                    height="0" width="0" style="display:none;visibility:hidden"></iframe>`
        }]
    })
}

function Xn() {
    const {
        currentHostDomain: t
    } = Ht(), {
        $i18n: o
    } = Ae(), {
        getPathArrWithoutLocale: a
    } = Oe(), s = ne(), {
        isAuthenticated: i
    } = Te(), {
        metaTitle: c
    } = Xo(), {
        pixelStatistic: u
    } = Y(he()), {
        balance: f
    } = Go(), {
        getUUID: r
    } = $o(), {
        userGeo: d
    } = Y(be()), {
        isPWA: _
    } = Bn(), p = Ve(), m = g(() => _.value ? "pwa" : t === ya ? "website" : "mirror"), T = g(() => a(s.path)), E = g(() => T.value[0] || "main"), k = g(() => T.value[1] || ""), y = g(() => {
        if (!i.value) return "not_login";
        const P = r.value;
        return P && typeof P == "string" ? P : "not_login"
    }), I = g(() => {
        var P, C;
        return Number(((C = (P = f.value) == null ? void 0 : P.total_deposit) == null ? void 0 : C.amount) || 0)
    }), B = g(() => i.value ? I.value > 0 ? "gam" : "reg" : "sit"), z = g(() => {
        var P;
        return (P = u.value) != null && P.is_deposit_more_than_2000 ? "vip" : I.value > 0 ? "nor" : "blank"
    }), X = g(() => !i.value || y.value !== "not_login"), L = g(() => wa.includes(t ? ? "") ? "bangladesh" : (t ? ? "") === Rt ? "brazil" : "india"), H = g(() => ({
        domain: t || "not_data",
        siteType: m.value || "not_data",
        siteSection: E.value || "not_data",
        mainLang: o.defaultLocale,
        siteRegion: d.value || "not_data",
        siteCountry: L.value
    })), U = g(() => ({
        pageTitle: c.value ? c.value || document.title : "",
        pageType: E.value,
        pageCategory: k.value,
        pageUrl: p.href || "",
        pageLang: o.locale.value
    })), R = g(() => X.value ? {
        userID: y.value,
        visitorType: i.value ? "logged" : "not_logged",
        visitorRole: B.value,
        visitorLevel: z.value
    } : null), w = (P, C) => {
        if (typeof window > "u") {
            console.warn(`SEO data layer update skipped (SSR) - ${P}`);
            return
        }
        window.dataLayer = window.dataLayer || [], window.dataLayer.push({
            event: P,
            ...C
        })
    };
    return Ce(() => {
        w("siteInfo", {
            siteInfo: H.value
        }), w("pageInfo", {
            pageInfo: U.value
        }), R.value && w("userInfo", {
            userInfo: R.value
        })
    }), Qt(() => {
        w("siteInfo", {
            siteInfo: H.value
        })
    }), Qt(() => {
        w("pageInfo", {
            pageInfo: U.value
        })
    }), Qt(() => {
        R.value && w("userInfo", {
            userInfo: R.value
        })
    }), {
        getSiteInfo: H,
        getPageInfo: U,
        getUserInfo: R,
        pushSeoDataLayer: w
    }
}

function Yn() {
    const t = Ve(),
        {
            locale: o
        } = re(),
        a = g(() => o.value);
    return g(() => {
        if (go(t.host)) {
            if (a.value === "en") return "en-BD";
            if (a.value === "bn") return "bn-BD"
        }
        return a.value
    })
}

function Qn() {
    const t = ne(),
        o = Ve().host,
        a = Ye().isMobile,
        {
            locale: s
        } = re(),
        {
            googleMetaTag: i
        } = Zn();
    return g(() => {
        const c = ka.some(_ => t.path.includes(_)),
            u = Ia.some(_ => t.path.includes(_)),
            f = go(o) && (u || !["en", "bn"].includes(s.value)),
            d = [{
                key: "theme-color",
                name: "theme-color",
                content: "#172539"
            }, {
                key: "viewport",
                name: "viewport",
                content: "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no"
            }, {
                key: "robots",
                name: "robots",
                content: c || f ? "noindex, follow" : "index, follow"
            }];
        return a.value && d.push({
            key: "mobile-web-app",
            name: "mobile-web-app",
            content: "true"
        }), i && d.push({ ...i,
            key: "google-site-verification"
        }), d
    })
}
const Jn = "" + new URL("favicon-4rabet-bd-green.D99DVIOk.png",
        import.meta.url).href,
    es = "" + new URL("favicon-4rabet-bd-redcircle.DnQ74n_v.png",
        import.meta.url).href;

function ts() {
    const {
        canonicalUrl: t
    } = Wn(), {
        hreflangLinks: o
    } = zn(), a = Ve().host, s = {
        BANGLADESH_DOMAIN: Jn,
        BANGLADESH_DOMAIN_BD: es
    }, i = Object.keys(s).find(u => a.includes(u)), c = i ? s[i] : "/favicon.ico";
    return g(() => [{
        rel: "icon",
        type: "image/png",
        href: c
    }, {
        rel: "canonical",
        href: t.value || ""
    }, ...o.value])
}

function os() {
    const {
        profileForm: t
    } = Et();
    return {
        userHasFullInfoAboutHimself: g(() => {
            var s;
            const a = (s = t.value) == null ? void 0 : s.info;
            return !!(a != null && a.first_name && (a != null && a.last_name) && (a != null && a.birth) && (a != null && a.gender) && (a != null && a.country) && (a != null && a.city) && (a != null && a.phone) && (a != null && a.email))
        })
    }
}
const as = {
        offer_id: "value_1",
        partner_id: "value_2",
        landing_id: "value_3"
    },
    ns = 60 * 60 * 24 * 7;

function ss() {
    const t = ne(),
        {
            saveClickId: o,
            saveOfferId: a,
            saveLandingId: s,
            savePartnerId: i,
            saveWelcomeBonusId: c
        } = he(),
        u = {
            saveClickId: o,
            saveOfferId: a,
            savePartnerId: i,
            saveLandingId: s,
            saveWelcomeBonusId: c
        },
        f = (k, y, I) => {
            const B = me(k, {
                maxAge: ns
            });
            typeof y < "u" && B.value !== y && (B.value = y.toString(), u[I](y))
        },
        r = (k, y) => {
            const I = t.query[as[k] || k],
                B = I ? +I || I : void 0,
                z = me(k);
            if (z.value && z.value !== B) {
                u[y](z.value);
                return
            }
            if (B) {
                if (k === "welcome_bonus" && (!Number.isInteger(+B) || isNaN(+B))) return;
                f(k, B, y)
            }
        },
        d = () => {
            r("click_id", "saveClickId")
        },
        _ = () => {
            r("offer_id", "saveOfferId")
        },
        p = () => {
            r("partner_id", "savePartnerId")
        },
        m = () => {
            r("landing_id", "saveLandingId")
        },
        T = () => {
            r("welcome_bonus", "saveWelcomeBonusId")
        };
    return {
        checkAndSaveClickID: d,
        checkAndSaveOfferID: _,
        checkAndSavePartnerID: p,
        checkAndSaveLandingID: m,
        checkAndSaveWelcomeBonusID: T,
        checkAllAndSaveAllAffiliateIds: () => {
            d(), _(), p(), m(), T()
        }
    }
}

function rs() {
    const {
        $privateLog: t
    } = Ae();
    async function o(a) {
        const {
            changeBonus: s
        } = xe();
        try {
            await s(a)
        } catch (i) {
            throw t(i), i
        }
    }
    return {
        switchBonusBalance: o
    }
}

function is() {
    const t = ne(),
        {
            config: o
        } = Ze(),
        {
            userDepositAmount: a,
            userBonusSelected: s
        } = Et(),
        {
            openDialog: i
        } = Ee(),
        {
            isSuccessRegistration: c
        } = Po(),
        {
            trackButtonClick: u
        } = ye(),
        f = me("no_deposit_dialog", {
            path: "/"
        });
    return {
        runDepositScenario: () => {
            var m, T, E, k, y, I, B;
            const d = !!f.value,
                _ = +(a.value || 0) <= 0,
                p = s.value !== null;
            if (!d && _ && p && (!((m = t.query) != null && m.deposit) || !((T = t.query) != null && T.withdraw))) {
                if (f.value = "true", (E = o.value) != null && E.OFF_BONUS_DEPOSIT) return u(c ? {
                    category: "deposit_popup",
                    action: "view_paywall",
                    label: ce.AFTER_REG
                } : {
                    category: "deposit_popup",
                    action: "view_paywall",
                    label: ce.AFTER_LOGIN
                }), i("deposit");
                i("bonusDeposit")
            } else if (!d && _ && !p && (!((k = t.query) != null && k.deposit) || !((y = t.query) != null && y.withdraw)) && !(sessionStorage != null && sessionStorage.getItem("reg_or_auth_by_google")) && !((I = t.query) != null && I.welcome_after_google)) {
                if (f.value = "true", (B = o.value) != null && B.OFF_BONUS_DEPOSIT) return u(c ? {
                    category: "deposit_popup",
                    action: "view_paywall",
                    label: ce.AFTER_REG
                } : {
                    category: "deposit_popup",
                    action: "view_paywall",
                    label: ce.AFTER_LOGIN
                }), i("deposit");
                i("bonusDeposit")
            } else !d && !_ && (f.value = "true")
        }
    }
}

function Jo(t, o) {
    const {
        self: a = !1
    } = o.modifiers ? ? {}, s = o.value, i = typeof s == "object" && s.options || {
        passive: !0
    }, c = typeof s == "function" || "handleEvent" in s ? s : s.handler, u = a ? t : o.arg ? document.querySelector(o.arg) : window;
    u && (u.addEventListener("scroll", c, i), t._onScroll = Object(t._onScroll), t._onScroll[o.instance.$.uid] = {
        handler: c,
        options: i,
        target: a ? void 0 : u
    })
}

function ea(t, o) {
    var c;
    if (!((c = t._onScroll) != null && c[o.instance.$.uid])) return;
    const {
        handler: a,
        options: s,
        target: i = t
    } = t._onScroll[o.instance.$.uid];
    i.removeEventListener("scroll", a, s), delete t._onScroll[o.instance.$.uid]
}

function ls(t, o) {
    o.value !== o.oldValue && (ea(t, o), Jo(t, o))
}
const cs = {
        mounted: Jo,
        unmounted: ea,
        updated: ls
    },
    us = {
        "gam-test-no-data": {
            event: "retention",
            type: "no-data",
            action: "",
            product: "test-no-data",
            value: ""
        },
        "gam-test-no-event": {
            event: "retention",
            type: "no-event",
            action: "",
            product: "test-no-event",
            value: ""
        },
        "gam-nor-mix": {
            event: "retention",
            type: "gam_nor",
            action: "topup",
            product: "mix",
            value: "any"
        },
        "gam-nor-bet": {
            event: "retention",
            type: "gam_nor",
            action: "topup",
            product: "bet",
            value: "low"
        },
        "gam-nor-liv": {
            event: "retention",
            type: "gam_nor",
            action: "topup",
            product: "liv",
            value: "low"
        },
        "gam-nor-slo": {
            event: "retention",
            type: "gam_nor",
            action: "topup",
            product: "slo",
            value: "low"
        },
        "gam-nor-cra": {
            event: "retention",
            type: "gam_nor",
            action: "topup",
            product: "cra",
            value: "low"
        },
        "gam-vip-bet": {
            event: "retention",
            type: "gam_vip",
            action: "topup",
            product: "bet",
            value: "vip"
        },
        "gam-vip-liv": {
            event: "retention",
            type: "gam_vip",
            action: "topup",
            product: "liv",
            value: "vip"
        },
        "gam-vip-slo": {
            event: "retention",
            type: "gam_vip",
            action: "topup",
            product: "slo",
            value: "vip"
        },
        "gam-vip-cra": {
            event: "retention",
            type: "gam_vip",
            action: "topup",
            product: "cra",
            value: "vip"
        },
        "reg-bet": {
            event: "retention",
            type: "reg_bonus",
            action: "reg",
            product: "bet",
            value: "any"
        },
        "reg-cra": {
            event: "retention",
            type: "reg_bonus",
            action: "reg",
            product: "cra",
            value: "any"
        },
        "reg-cas": {
            event: "retention",
            type: "reg_bonus",
            action: "reg",
            product: "cas",
            value: "any"
        }
    };

function ta() {
    const {
        trackButtonClick: t
    } = ye();
    return o => {
        const a = us[o];
        a && t(a)
    }
}
const _s = Oo({
        scrollable: Boolean,
        ...Ca(),
        ...Mo(),
        ...Ta({
            tag: "main"
        })
    }, "VMain"),
    ds = xo()({
        name: "VMain",
        props: _s(),
        setup(t, o) {
            let {
                slots: a
            } = o;
            const {
                dimensionStyles: s
            } = No(t), {
                mainStyles: i
            } = Aa(), {
                ssrBootStyles: c
            } = Rn();
            return Ro(() => h(t.tag, {
                class: ["v-main", {
                    "v-main--scrollable": t.scrollable
                }, t.class],
                style: [i.value, c.value, s.value, t.style]
            }, {
                default: () => {
                    var u, f;
                    return [t.scrollable ? h("div", {
                        class: "v-main__scroller"
                    }, [(u = a.default) == null ? void 0 : u.call(a)]) : (f = a.default) == null ? void 0 : f.call(a)]
                }
            })), {}
        }
    }),
    ps = {
        actions: "button@2",
        article: "heading, paragraph",
        avatar: "avatar",
        button: "button",
        card: "image, heading",
        "card-avatar": "image, list-item-avatar",
        chip: "chip",
        "date-picker": "list-item, heading, divider, date-picker-options, date-picker-days, actions",
        "date-picker-options": "text, avatar@2",
        "date-picker-days": "avatar@28",
        divider: "divider",
        heading: "heading",
        image: "image",
        "list-item": "text",
        "list-item-avatar": "avatar, text",
        "list-item-two-line": "sentences",
        "list-item-avatar-two-line": "avatar, sentences",
        "list-item-three-line": "paragraph",
        "list-item-avatar-three-line": "avatar, paragraph",
        ossein: "ossein",
        paragraph: "text@3",
        sentences: "text@2",
        subtitle: "text",
        table: "table-heading, table-thead, table-tbody, table-tfoot",
        "table-heading": "chip, text",
        "table-thead": "heading@6",
        "table-tbody": "table-row-divider@6",
        "table-row-divider": "table-row, divider",
        "table-row": "text@6",
        "table-tfoot": "text@2, avatar@2",
        text: "text"
    };

function ms(t) {
    let o = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
    return h("div", {
        class: ["v-skeleton-loader__bone", `v-skeleton-loader__${t}`]
    }, [o])
}

function Io(t) {
    const [o, a] = t.split("@");
    return Array.from({
        length: a
    }).map(() => Gt(o))
}

function Gt(t) {
    let o = [];
    if (!t) return o;
    const a = ps[t];
    if (t !== a) {
        if (t.includes(",")) return Ao(t);
        if (t.includes("@")) return Io(t);
        a.includes(",") ? o = Ao(a) : a.includes("@") ? o = Io(a) : a && o.push(Gt(a))
    }
    return [ms(t, o)]
}

function Ao(t) {
    return t.replace(/\s/g, "").split(",").map(Gt)
}
const fs = Oo({
        boilerplate: Boolean,
        color: String,
        loading: Boolean,
        loadingText: {
            type: String,
            default: "$vuetify.loading"
        },
        type: {
            type: [String, Array],
            default: "ossein"
        },
        ...Mo(),
        ...Pa(),
        ...$a()
    }, "VSkeletonLoader"),
    Vt = xo()({
        name: "VSkeletonLoader",
        props: fs(),
        setup(t, o) {
            let {
                slots: a
            } = o;
            const {
                backgroundColorClasses: s,
                backgroundColorStyles: i
            } = Ea(Ka(t, "color")), {
                dimensionStyles: c
            } = No(t), {
                elevationClasses: u
            } = La(t), {
                themeClasses: f
            } = Sa(t), {
                t: r
            } = Da(), d = g(() => Gt(Ba(t.type).join(",")));
            return Ro(() => {
                var m;
                const _ = !a.default || t.loading,
                    p = t.boilerplate || !_ ? {} : {
                        ariaLive: "polite",
                        ariaLabel: r(t.loadingText),
                        role: "alert"
                    };
                return h("div", Ut({
                    class: ["v-skeleton-loader", {
                        "v-skeleton-loader--boilerplate": t.boilerplate
                    }, f.value, s.value, u.value],
                    style: [i.value, _ ? c.value : {}]
                }, p), [_ ? d.value : (m = a.default) == null ? void 0 : m.call(a)])
            }), {}
        }
    }),
    hs = {
        key: 0
    },
    vs = oe({
        __name: "ImagePreloader",
        setup(t) {
            const {
                getIconWithExt: o
            } = nn(), a = g(() => []), s = g(() => ({})), i = g(() => []), c = g(() => {
                const f = ["Popular", "New games"],
                    r = [];
                return Object.keys(s.value).forEach(d => {
                    s.value[d].forEach(_ => {
                        f.includes(_.name) && r.push(..._.slots.map(p => p.image))
                    })
                }), r
            }), u = g(() => ({
                visibility: "hidden",
                position: "absolute"
            }));
            return (f, r) => {
                var _;
                const d = dt;
                return l(), b("div", {
                    style: ut(e(u))
                }, [(_ = e(a)) != null && _.length ? (l(), b("div", hs, [(l(!0), b(ve, null, Be(e(a), (p, m) => (l(), F(d, {
                    key: m + "payment",
                    style: ut(e(u)),
                    src: p,
                    width: "1",
                    height: "1",
                    alt: `Preloaded image ${m}`
                }, null, 8, ["style", "src", "alt"]))), 128))])) : $("", !0), (l(!0), b(ve, null, Be(e(c), (p, m) => (l(), F(d, {
                    key: m + "slot",
                    style: ut(e(u)),
                    src: p,
                    width: "1",
                    height: "1",
                    alt: `Preloaded slot image ${m}`
                }, null, 8, ["style", "src", "alt"]))), 128)), (l(!0), b(ve, null, Be(e(i), (p, m) => {
                    var T;
                    return l(), F(d, {
                        key: m + "currency",
                        src: e(o)(["svgflags", (T = p == null ? void 0 : p.flag) == null ? void 0 : T.toUpperCase(), "svg"]),
                        style: ut(e(u)),
                        width: "1",
                        height: "1",
                        alt: `Preloaded currency flag ${m}`
                    }, null, 8, ["src", "style", "alt"])
                }), 128))], 4)
            }
        }
    }),
    gs = ["src"],
    bs = oe({
        __name: "LogoComponent",
        props: {
            isNewYear: {
                type: Boolean,
                default: !1
            },
            isMobile: {
                type: Boolean,
                default: !1
            }
        },
        setup(t) {
            const o = g(() => `${u.value}/logo.svg`),
                a = g(() => `${u.value}/bangladesh/rabetBd/logo.svg`),
                s = g(() => `${u.value}/bangladesh/rabet-bd/logo.svg`),
                i = Ne(),
                {
                    userGeo: c
                } = Y(be()),
                {
                    imageUrl: u
                } = pt(),
                {
                    trackButtonClick: f
                } = ye(),
                r = Ve(),
                d = g(() => r.host === io ? a : r.host === lo ? s : o),
                _ = {
                    IN: "/svgflags/HI.svg",
                    BD: "/svgflags/BN.svg",
                    BR: "/svgflags/BR.svg",
                    MM: "/svgflags/MY.svg",
                    CD: "/svgflags/CD.svg"
                },
                p = { ...Oa,
                    ...xa
                },
                m = g(() => {
                    const E = _[c.value];
                    if (E) return `${u.value}${E}`;
                    const k = p[c.value];
                    return k ? `${u.value}${k.flag}` : ""
                }),
                T = () => {
                    f({
                        category: "header",
                        action: "logo"
                    })
                };
            return (E, k) => {
                const y = dt,
                    I = Xe;
                return l(), b("div", {
                    class: K(["logo-wrapper", {
                        "logo-wrapper_mobile": E.isMobile
                    }]),
                    onClick: T
                }, [h(I, {
                    to: e(i)("/"),
                    class: "logo"
                }, {
                    default: N(() => [h(y, {
                        class: K(["logo-main", {
                            "logo-main--without-country": !e(m),
                            "logo-main--new-year": e(m) && E.isNewYear
                        }]),
                        src: e(d).value,
                        alt: "4Rabet logo official website",
                        title: "4Rabet logo official website"
                    }, null, 8, ["class", "src"]), e(m) ? (l(), b("div", {
                        key: 0,
                        class: K(["logo-country", {
                            "logo-country--new-year": E.isNewYear
                        }]),
                        "data-auto-test-el": "header-flag"
                    }, [n("img", {
                        src: E.isNewYear ? `${e(u)}/new-year/cap.png` : e(m),
                        alt: "4Rabet country logo",
                        title: "4Rabet country logo",
                        class: K({
                            "logo-country--cap": E.isNewYear
                        })
                    }, null, 10, gs)], 2)) : $("", !0)]),
                    _: 1
                }, 8, ["to"])], 2)
            }
        }
    }),
    ys = Q(bs, [
        ["__scopeId", "data-v-86d21e3a"]
    ]),
    ws = {
        class: "menu"
    },
    ks = {
        class: "menu__list"
    },
    Is = {
        style: {
            display: "contents"
        }
    },
    As = ["src"],
    Ts = ["href", "onClick"],
    Cs = ["href", "onClick"],
    Es = oe({
        __name: "MenuComponent",
        setup(t) {
            const o = ne(),
                a = Ne(),
                {
                    t: s
                } = re(),
                i = Ke(),
                {
                    config: c
                } = Ze(),
                {
                    userGeo: u
                } = Y(be()),
                {
                    trackButtonClick: f
                } = ye(),
                {
                    imageUrl: r
                } = mt(),
                d = ee(["live", "line", "cricket", "ipl", "cyberSport"]),
                _ = ee(""),
                p = g(() => {
                    var E, k;
                    let T = rn;
                    return ["BR", "MM"].includes(u.value) && (T = ln), (E = c.value) != null && E.IS_IPL && ["IN", "BD"].includes(u.value) && (T = ko), (k = c.value) != null && k.IS_ICC && ["IN", "BD"].includes(u.value) && (T = ko.map(y => y.sysname === "ipl" ? { ...y,
                        name: "ICC",
                        route: "/sports/cricket",
                        sysname: "icc",
                        icon: "icc"
                    } : y)), T.filter(y => !y.mob)
                }),
                m = T => {
                    f({
                        category: "header",
                        action: T
                    })
                };
            return Ce(() => {
                _.value = o.path
            }), (T, E) => {
                const k = Xe,
                    y = po;
                return l(), b("nav", ws, [n("ul", ks, [(l(!0), b(ve, null, Be(e(p), (I, B) => (l(), b("li", {
                    key: B,
                    class: "menu__item"
                }, [n("div", Is, [I.sysname === "ipl" ? (l(), F(k, {
                    key: 0,
                    class: K(["menu__link menu__link--ipl", {
                        "menu__link--ipl": I.sysname === "ipl"
                    }]),
                    to: e(a)(I.route)
                }, {
                    default: N(() => [n("img", {
                        class: "pr-2",
                        src: `${e(r)}/main/betby/sports/ipl.png`,
                        width: "46",
                        height: "20",
                        alt: "ipl"
                    }, null, 8, As), E[0] || (E[0] = ae(" IPL 2025 "))]),
                    _: 2
                }, 1032, ["to", "class"])) : $("", !0), e(d).indexOf(I.sysname) !== -1 && !I.external && I.sysname !== "ipl" ? (l(), F(y, {
                    key: 1,
                    "route-path": I.route,
                    class: "menu__link",
                    onClick: z => m(I.sysname)
                }, {
                    default: N(() => [ae(x(e(s)(`menu.${I.sysname}`)), 1)]),
                    _: 2
                }, 1032, ["route-path", "onClick"])) : !I.external && I.sysname !== "ipl" ? (l(), F(k, {
                    key: 2,
                    to: e(a)(I.route),
                    class: K(["menu__link", {
                        "menu__link--icc": I.sysname === "icc"
                    }]),
                    onClick: z => m(I.sysname)
                }, {
                    default: N(() => [ae(x(e(s)(`menu.${I.sysname}`)), 1)]),
                    _: 2
                }, 1032, ["to", "class", "onClick"])) : I.external && I.sysname === "blog" ? (l(), b("a", {
                    key: 3,
                    href: e(i).app.blog,
                    class: "menu__link",
                    onClick: z => m(I.sysname)
                }, x(e(s)(`menu.${I.sysname}`)), 9, Ts)) : I.external ? (l(), b("a", {
                    key: 4,
                    href: I.route,
                    class: "menu__link",
                    onClick: z => m(I.sysname)
                }, x(e(s)(`menu.${I.sysname}`)) + "44 ", 9, Cs)) : $("", !0)])]))), 128))])])
            }
        }
    }),
    Ls = Q(Es, [
        ["__scopeId", "data-v-1eb2617c"]
    ]),
    Ss = {
        class: "d-flex header-auth px-4"
    },
    Ds = oe({
        __name: "AuthComponent",
        setup(t) {
            const {
                t: o
            } = re(), {
                openDialog: a
            } = Ee(), {
                trackButtonClick: s
            } = ye();

            function i() {
                a("auth"), s({
                    category: "header",
                    action: "sign_in"
                })
            }

            function c() {
                a("registration"), s({
                    category: "header",
                    action: "registration"
                })
            }
            return (u, f) => (l(), b("div", Ss, [h(Me, {
                id: "auth_btn",
                class: "mr-2",
                "class-name": "sm",
                color: "primary",
                "data-auto-test-el": "signIn",
                "data-ignore-event-locker": "",
                onClick: i
            }, {
                default: N(() => [ae(x(e(o)("buttons.signIn")), 1)]),
                _: 1
            }), h(Me, {
                id: "reg_btn",
                "class-name": "sm",
                color: "red",
                "data-auto-test-el": "signUp",
                "data-ignore-event-locker": "",
                onClick: c
            }, {
                default: N(() => [ae(x(e(o)("buttons.register")), 1)]),
                _: 1
            })]))
        }
    }),
    Bs = Q(Ds, [
        ["__scopeId", "data-v-c49f1c79"]
    ]),
    $s = {
        class: "d-flex"
    },
    Ps = {
        class: "flag"
    },
    xs = {
        key: 0,
        class: "ml-2 white--text"
    },
    Os = {
        class: "title"
    },
    Ns = {
        class: "text"
    },
    Rs = ["id", "onClick"],
    Ms = {
        class: "flag mr-1"
    },
    Vs = {
        class: "align-center d-flex lang"
    },
    Hs = {
        key: 0
    },
    Us = {
        key: 1
    },
    Fs = oe({
        __name: "LangComponent",
        props: {
            appendIcon: {
                default: ""
            },
            position: {
                default: "header"
            },
            langs: {
                default: () => []
            },
            showInnerArrow: {
                type: Boolean,
                default: !1
            }
        },
        setup(t) {
            Qa(R => ({
                "095a201b": e(B)
            }));
            const o = Xa(),
                {
                    locale: a,
                    t: s
                } = re(),
                {
                    imageUrl: i
                } = mt(),
                c = Qo(),
                {
                    trackButtonClick: u
                } = ye(),
                {
                    isAuthenticated: f
                } = Te(),
                {
                    userGeo: r
                } = Y(be()),
                {
                    changeLangForUser: d
                } = he(),
                {
                    throttlingLangChange: _
                } = Y(he()),
                p = t,
                m = me("set_lang"),
                T = ee(!1);

            function E(R) {
                c == null || c.switchLocale(R.code), (U() === De.BRAZIL_DOMAIN || U() === De.BRAZIL_TEST_DOMAIN) && (m.value = "true"), R.code === "pt" && window.location.reload()
            }
            const k = g({
                    get() {
                        var R, w;
                        return (w = (R = p.langs) == null ? void 0 : R.find(P => P.code === a.value)) == null ? void 0 : w.id
                    },
                    set(R) {
                        var P;
                        const w = (P = p.langs) == null ? void 0 : P.find(C => C.id === R);
                        w && E(w)
                    }
                }),
                y = ee(null),
                I = g(() => `lang__content${p.position==="header"?" lang__content_header":""}`),
                B = g(() => p.position === "footer" ? "var(--black-apha-130)" : "");
            Ce(() => {
                var R, w, P;
                if (p.position === "footer" && y.value) {
                    const C = y.value.querySelector(".lang__footer .v-select__slot"),
                        A = y.value.querySelector("input"),
                        S = y.value.querySelector("i");
                    C == null || C.setAttribute("id", "footer-lang"), A == null || A.setAttribute("id", "footer-lang-text"), S == null || S.setAttribute("id", "footer-lang-icon"), C == null || C.setAttribute("data-auto-test-el", "chooseLanguage")
                } else {
                    const C = (R = y.value) == null ? void 0 : R.querySelector(".lang__header .v-select__slot"),
                        A = (w = y.value) == null ? void 0 : w.querySelector("input"),
                        S = (P = y.value) == null ? void 0 : P.querySelector("i");
                    C == null || C.setAttribute("id", "header-lang"), A == null || A.setAttribute("id", "header-lang-text"), S == null || S.setAttribute("id", "header-lang-icon"), C == null || C.setAttribute("data-auto-test-el", "chooseLanguage")
                }
            });
            async function z(R) {
                u({
                    category: "header",
                    action: "language",
                    type: a.value,
                    label: R
                }), f.value && (window._smartico_language = R, await d(R))
            }

            function X(R) {
                var A;
                const w = `${i.value}/svgflags`,
                    P = ".svg",
                    C = (((A = R.flag_code_by_geo) == null ? void 0 : A[r.value]) ? ? R.flag_code).toUpperCase();
                return `${w}/${C}${P}`
            }

            function L(R) {
                return R === "português" ? "Brasil" : R
            }

            function H(R) {
                return R === "pt" ? "br" : R
            }

            function U() {
                return typeof window < "u" ? window.location.hostname : null
            }
            return (R, w) => {
                const P = dt;
                return l(), b("div", {
                    class: K(["lang", {
                        disabled: e(_) && e(f)
                    }])
                }, [h(cn, {
                    id: "select-id-" + e(o),
                    ref_key: "languages",
                    ref: y,
                    modelValue: e(k),
                    "onUpdate:modelValue": [w[0] || (w[0] = C => Tt(k) ? k.value = C : null), w[1] || (w[1] = C => k.value = C)],
                    class: K(`lang__${R.position}`),
                    items: R.langs,
                    "menu-props": {
                        closeOnContentClick: !0,
                        scrollStrategy: "close",
                        contentClass: e(I),
                        offset: 3
                    },
                    color: "#202b37",
                    "item-text": "name",
                    "item-value": "id",
                    "hide-details": "",
                    density: "compact",
                    "min-width": "76",
                    "onUpdate:menu": w[2] || (w[2] = C => T.value = C)
                }, Ya({
                    selection: N(({
                        item: C
                    }) => [n("div", $s, [n("div", Ps, [C.raw.code ? (l(), F(P, {
                        key: 0,
                        src: X(C.raw),
                        alt: C.raw.code.toUpperCase(),
                        title: C.raw.code.toUpperCase()
                    }, null, 8, ["src", "alt", "title"])) : $("", !0)]), R.position === "footer" ? (l(), b("div", xs, [n("div", Os, x(e(s)("labels.selectLang")) + ":", 1), n("div", Ns, x(L(C.raw.name)) + "(" + x(H(C.raw.code)) + ") ", 1)])) : $("", !0)])]),
                    item: N(({
                        props: C,
                        item: A
                    }) => [n("div", Ut({
                        id: `lang__${R.position}-${A.raw.code}`,
                        class: ["flag-wrapper", {
                            "v-list-item--active": e(k) === A.raw.id
                        }]
                    }, { ...C,
                        ref: void 0,
                        title: void 0
                    }, {
                        onClick: S => z(A.raw.code)
                    }), [n("div", Ms, [A.raw.code ? (l(), F(P, {
                        key: 0,
                        src: X(A.raw),
                        alt: A.raw.code.toUpperCase(),
                        title: A.raw.code.toUpperCase()
                    }, null, 8, ["src", "alt", "title"])) : $("", !0)]), n("div", Vs, [R.position === "header" ? (l(), b("span", Hs, x(H(A.raw.code).toUpperCase()), 1)) : (l(), b("span", Us, x(L(A.raw.name)) + "(" + x(H(A.raw.code)) + ") ", 1))])], 16, Rs)]),
                    _: 2
                }, [p.showInnerArrow ? {
                    name: "append-inner",
                    fn: N(() => [h(Nt, {
                        class: K(["transition-transform duration-300", {
                            "rotate-180": e(T)
                        }]),
                        icon: "mdi-chevron-down",
                        color: "white",
                        size: "small"
                    }, null, 8, ["class"])]),
                    key: "0"
                } : void 0]), 1032, ["id", "modelValue", "class", "items", "menu-props"])], 2)
            }
        }
    }),
    oa = Q(Fs, [
        ["__scopeId", "data-v-f249947f"]
    ]),
    zs = ["innerHTML"],
    Gs = ["innerHTML"],
    js = oe({
        __name: "UserMenuBalanceItem",
        props: {
            customTag: {},
            customClassNames: {},
            currency: {},
            balance: {}
        },
        setup(t) {
            const o = ["UZS", "KES", "BDT"],
                {
                    codeToSymbol: a
                } = zo();
            return (s, i) => (l(), F(uo(s.customTag || "span"), {
                class: K(s.customClassNames)
            }, {
                default: N(() => [o.includes(s.currency) ? (l(), b("span", {
                    key: 0,
                    class: "currency",
                    "data-auto-test-el": "sumBalance",
                    innerHTML: s.currency
                }, null, 8, zs)) : (l(), b("span", {
                    key: 1,
                    class: "currency",
                    innerHTML: e(a)(s.currency)
                }, null, 8, Gs)), ae(" " + x(s.balance) + " ", 1), Ct(s.$slots, "default", {}, void 0, !0)]),
                _: 3
            }, 8, ["class"]))
        }
    }),
    aa = Q(js, [
        ["__scopeId", "data-v-02a03a54"]
    ]),
    Ws = {},
    qs = {
        xmlns: "http://www.w3.org/2000/svg",
        width: "16",
        height: "16",
        viewBox: "0 0 14 16",
        fill: "none"
    };

function Zs(t, o) {
    return l(), b("svg", qs, o[0] || (o[0] = [n("path", {
        d: "M11.571 5.33333H10.8091V3.80952C10.8091 1.67619 9.13287 0 6.99954 0C4.8662 0 3.19001 1.67619 3.19001 3.80952V5.33333H2.42811C1.59001 5.33333 0.904297 6.01905 0.904297 6.85714V14.4762C0.904297 15.3143 1.59001 16 2.42811 16H11.571C12.4091 16 13.0948 15.3143 13.0948 14.4762V6.85714C13.0948 6.01905 12.4091 5.33333 11.571 5.33333ZM6.99954 12.1905C6.16144 12.1905 5.47573 11.5048 5.47573 10.6667C5.47573 9.82857 6.16144 9.14286 6.99954 9.14286C7.83763 9.14286 8.52334 9.82857 8.52334 10.6667C8.52334 11.5048 7.83763 12.1905 6.99954 12.1905ZM9.36144 5.33333H4.63763V3.80952C4.63763 2.51429 5.7043 1.44762 6.99954 1.44762C8.29477 1.44762 9.36144 2.51429 9.36144 3.80952V5.33333Z",
        fill: "white"
    }, null, -1)]))
}
const Ks = Q(Ws, [
        ["render", Zs]
    ]),
    Xs = {},
    Ys = {
        width: "16",
        height: "16",
        viewBox: "0 0 16 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
    };

function Qs(t, o) {
    return l(), b("svg", Ys, o[0] || (o[0] = [n("path", {
        d: "M7.99998 0C3.58001 0 0 3.58001 0 7.99998C0 12.42 3.58001 16 7.99998 16C12.42 16 16 12.42 16 7.99998C16 3.57997 12.42 0 7.99998 0Z",
        fill: "#0076EE"
    }, null, -1), n("path", {
        d: "M7.99998 0C3.58001 0 0 3.58001 0 7.99998C0 12.42 3.58001 16 7.99998 16C12.42 16 16 12.42 16 7.99998C16 3.57997 12.42 0 7.99998 0Z",
        fill: "#0076EE"
    }, null, -1), n("path", {
        d: "M8.08571 4.00004C7.59479 4.00004 7.19682 4.39801 7.19682 4.88894C7.19682 5.37986 7.59479 5.77783 8.08571 5.77783C8.57664 5.77783 8.97461 5.37986 8.97461 4.88894C8.97461 4.39801 8.57664 4.00004 8.08571 4.00004Z",
        fill: "white"
    }, null, -1), n("path", {
        d: "M8.97461 12H7.19684V6.66667H8.97461V12Z",
        fill: "white"
    }, null, -1)]))
}
const Js = Q(Xs, [
        ["render", Qs]
    ]),
    er = {
        class: "balance-popup__left"
    },
    tr = ["innerHTML"],
    or = {
        class: "disabled-balance"
    },
    ar = {
        key: 1,
        class: "align-center balance-popup__right d-flex"
    },
    nr = {
        key: 0,
        href: "#",
        class: "balance-popup__link default"
    },
    sr = {
        key: 1,
        href: "#",
        class: "balance-popup__link default"
    },
    rr = ["id"],
    ir = oe({
        __name: "UserMenuBalanceSelectItem",
        props: {
            isActive: {
                type: Boolean
            },
            index: {},
            currency: {},
            title: {},
            balance: {},
            maxRealBalance: {},
            defaultBalance: {},
            isDisabled: {
                type: Boolean
            },
            selectedDisabledBonus: {
                type: Boolean
            }
        },
        emits: ["select", "select-disabled"],
        setup(t, {
            emit: o
        }) {
            const a = o,
                {
                    trackButtonClick: s
                } = ye(),
                {
                    t: i
                } = re();

            function c(r, d) {
                return d === 0 ? d : d !== 0 && d === r ? r : void 0
            }
            const u = g(() => t.title.replace(/<\/?[^>]+(>|$)/g, "")),
                f = () => {
                    s({
                        category: "dropdown_balance",
                        action: "click_on_bonus_info",
                        label: t.isDisabled ? "blocked_bonus" : "bonus",
                        value: "clicked_bonus_amount",
                        type: t.index.toString()
                    }), t.isDisabled ? a("select-disabled") : a("select")
                };
            return (r, d) => {
                const _ = aa,
                    p = Ks,
                    m = Js,
                    T = _n;
                return l(), F(oo, {
                    class: K({
                        "v-list-item--active": r.isActive
                    }),
                    rounded: 5,
                    onClick: nt(f, ["stop"])
                }, {
                    default: N(() => [n("div", er, [n("p", {
                        class: "balance-popup__title",
                        innerHTML: r.title
                    }, null, 8, tr), h(_, {
                        "custom-class-names": "balance-popup__val",
                        "custom-tag": "p",
                        currency: r.currency,
                        balance: r.balance
                    }, null, 8, ["currency", "balance"])]), r.isDisabled ? (l(), b(ve, {
                        key: 0
                    }, [h(p), n("div", or, [n("div", null, [h(m, {
                        style: {
                            width: "16px",
                            height: "16px"
                        }
                    })]), n("span", {
                        class: K(["disabled-balance_text", {
                            "disabled-balance_text--active": r.selectedDisabledBonus,
                            "disabled-balance_text--inactive": !r.selectedDisabledBonus
                        }])
                    }, x(e(i)("profile.bonuses.activation_message", {
                        bonusName: e(u),
                        sum: r.maxRealBalance,
                        currency: r.currency
                    })), 3)])], 64)) : (l(), b("div", ar, [r.isActive ? (l(), b("a", nr, x(e(i)("profile.default")), 1)) : (l(), b("a", sr, x(e(i)("labels.chooseDefault")), 1)), h(T, {
                        color: "white",
                        value: c(r.index, r.defaultBalance)
                    }, null, 8, ["value"])])), n("span", {
                        id: `header-bal-${r.index}-text`,
                        class: "overlay-content"
                    }, null, 8, rr)]),
                    _: 1
                }, 8, ["class"])
            }
        }
    }),
    lr = Q(ir, [
        ["__scopeId", "data-v-97078c07"]
    ]);

function xt(t) {
    return t === null
}

function eo(t) {
    return typeof t == "number"
}

function cr() {
    const {
        pixelStatistic: t
    } = Y(he()), o = ta();
    return {
        runPixelEvent: () => {
            const s = t.value;
            let i = !1;
            if (!s) {
                o("gam-test-no-data");
                return
            }
            const c = s.is_deposit_more_than_2000;
            s != null && s.sport_bet && (o(c ? "gam-vip-bet" : "gam-nor-bet"), i = !0), s != null && s.live_dealer_bet && (o(c ? "gam-vip-liv" : "gam-nor-liv"), i = !0), s != null && s.slot_bet && (o(c ? "gam-vip-slo" : "gam-nor-slo"), i = !0), s != null && s.crash_game_bet && (o(c ? "gam-vip-cra" : "gam-nor-cra"), i = !0), i || o("gam-test-no-event")
        }
    }
}
const ur = {
        class: "balance header-profile"
    },
    _r = {
        class: "d-flex"
    },
    dr = {
        class: "balance__icon-box desktop pl-4"
    },
    pr = {
        key: 0
    },
    mr = {
        key: 0,
        role: "button",
        class: "balance__btn-drop mobile",
        "data-trigger": "dropdown",
        "data-arr": "light",
        "data-template": "mob-balance-drop",
        "data-tippy-placement": "bottom-end"
    },
    fr = {
        id: "header-bal"
    },
    hr = {
        key: 1,
        role: "button",
        class: "balance__btn-drop mobile",
        "data-trigger": "dropdown",
        "data-arr": "light",
        "data-template": "mob-balance-drop",
        "data-tippy-placement": "bottom-end"
    },
    vr = {
        id: "header-bal"
    },
    gr = {
        class: "d-flex pr-6"
    },
    br = {
        key: 0
    },
    yr = {
        key: 0,
        class: "tippy-arrow"
    },
    wr = {
        class: "inform__left"
    },
    kr = {
        key: 0,
        class: "inform__time-countdown is-countdown"
    },
    Ir = {
        key: 0,
        class: "inform__right",
        "data-auto-test-el": "wager"
    },
    Ar = {
        class: "inform__text"
    },
    Tr = {
        class: "inform__sum"
    },
    Cr = {
        class: "popover-text text-center text-uppercase"
    },
    Er = oe({
        __name: "UserMenu",
        setup(t) {
            const {
                t: o
            } = re(), {
                imageUrl: a
            } = mt(), {
                width: s
            } = co(), i = _t(), {
                $ws: c,
                $privateLog: u
            } = Ae(), {
                hasBonusBalanceWMoney: f,
                currentBonus: r,
                currentBonusId: d,
                playerBonusBalances: _
            } = Y(xe()), {
                isTablet: p
            } = Ye(), {
                getBonusIndexById: m
            } = xe(), {
                switchBonusBalance: T
            } = rs(), {
                logoutUser: E,
                getPlayerBalance: k,
                getAsyncPixelStatistic: y,
                wsCallback: I
            } = he(), {
                pixelStatistic: B
            } = Y(he()), {
                userHasFullInfoAboutHimself: z
            } = os(), {
                runPixelEvent: X
            } = cr(), {
                balance: L
            } = Go(), {
                currencyUser: H
            } = $o(), {
                isUserLoadedLogout: U
            } = Et(), {
                userUUID: R
            } = Y(he()), {
                openDialog: w
            } = Ee(), {
                runDepositScenario: P
            } = is(), {
                fetchDepositMethods: C
            } = jo(), {
                fetchWithdrawMethodsList: A
            } = fn(), {
                depositMethods: S
            } = vn(), {
                clearAccountId: G
            } = gn(), {
                checkUserBonusSelection: q,
                checkCurrentBonus: M
            } = Na(), {
                locale: j
            } = re(), {
                trackButtonClick: te
            } = ye(), se = Ne(), {
                isAuthenticated: de
            } = Te(), ue = ee(!1), ge = Uo({
                showPopover: !1,
                chevronArr: ["mdi-chevron-down", "mdi-chevron-up"],
                newsPopup: !1,
                loaderBalance: !1
            }), st = g(() => ({
                "d-flex": !0,
                "pr-8": !p.value,
                "pr-1": p.value
            }));
            le(B, D => {
                D && X()
            });
            const Re = g(() => {
                    if (!r.value && d.value) return null;
                    const D = m(d.value);
                    return D >= 0 ? D + 2 : 1
                }),
                Le = g(() => {
                    var D;
                    return ((D = r.value) == null ? void 0 : D.wager) || null
                }),
                Se = g(() => {
                    var D;
                    return r.value && "orig_wager" in r.value && ((D = r.value) == null ? void 0 : D.orig_wager) || null
                }),
                ft = g(() => {
                    var D;
                    return r.value && "expire_at" in r.value && ((D = r.value) == null ? void 0 : D.expire_at) || null
                }),
                rt = g(() => {
                    var ie, we, Ie;
                    const D = parseInt((ie = Se.value) == null ? void 0 : ie.amount, 10) / 100 - parseInt(String((we = Le.value) == null ? void 0 : we.amount), 10) / 100,
                        J = parseInt(((Ie = Se.value) == null ? void 0 : Ie.amount) / 100, 10);
                    return Math.floor(D * 100 / J)
                }),
                jt = g(() => {
                    var D, J;
                    return ((D = _.value) == null ? void 0 : D.some(ie => ie.status === "pending")) && ((J = _.value) == null ? void 0 : J.some(ie => ie.popup_seen))
                });

            function Lt() {
                Pe(ce.HEADER), te({
                    category: "deposit_popup",
                    action: "view_paywall",
                    label: ce.HEADER
                }), w("deposit")
            }

            function St(D) {
                var J, ie, we, Ie, Je;
                return ((ie = (J = D.bonus) == null ? void 0 : J.bonus_name) == null ? void 0 : ie[j.value]) || ((Ie = (we = D.bonus) == null ? void 0 : we.bonus_name) == null ? void 0 : Ie.en) || ((Je = D.bonus) == null ? void 0 : Je.name) || ""
            }

            function it(D) {
                return D.casino && D.bets ? `${o("labels.bonus")}${o("profile.balance")}:` : D.casino || D.bets ? St(D) : ""
            }

            function ke(D, J = !1) {
                const ie = +(D || 0);
                return J ? Math.floor(ie / 100) : ie / 100
            }
            const Dt = ee(-1),
                Qe = D => Dt.value = D;
            async function lt(D) {
                if (q(D, !0)) try {
                    await T(D)
                } catch (ie) {
                    u(ie), Qe(D)
                }
            }
            le(ue, D => {
                D ? document.body.addEventListener("click", Bt) : (Qe(-1), document.body.removeEventListener("click", Bt)), D && te({
                    category: "dropdown_balance",
                    action: "open"
                })
            });

            function Bt(D) {
                const J = document.querySelector(".balance-popup"),
                    ie = D.target;
                J && !J.contains(ie) && (ue.value = !1)
            }

            function ht() {
                return M()
            }
            async function ct() {
                await E({
                    reasonLogout: Ma.self
                }), G()
            }

            function Wt() {
                i.push(se("/profile")), ue.value = !1
            }
            const qt = async () => {
                    try {
                        await k().then(() => M(!0)), Zt(), await y(), B.value && X()
                    } catch (D) {
                        console.error("Error during initialization:", D)
                    }
                },
                Zt = () => (c.sub(`personal:#${R.value}`, D => {
                    I({
                        eventName: D.data.event,
                        data: D.data.payload,
                        reason: D.data.reason
                    })
                }), !0),
                vt = ee(0),
                gt = ["mousemove", "keydown", "scroll", "click"];
            for (const D in gt) window.addEventListener(gt[D], () => {
                vt.value = Date.now()
            });

            function Kt() {
                const D = setInterval(() => {
                    var we;
                    const ie = Date.now() - vt.value;
                    if (!de.value) return S.value = [], clearInterval(D);
                    if (ie <= 9e5) {
                        const Ie = {
                            currency: H.value || "INR",
                            label: (we = R.value) == null ? void 0 : we.toString()
                        };
                        C(H.value), A(Ie)
                    } else vt.value = 0
                }, 15e5)
            }
            async function Xt() {
                var D;
                !((D = S.value) != null && D.length) && H.value && (await C(H.value), Kt()), P()
            }
            return Ce(async () => {
                ge.loaderBalance = !0, await qt(), await Xt(), ge.loaderBalance = !1
            }), (D, J) => {
                var bt, $t;
                const ie = dt,
                    we = aa,
                    Ie = lr,
                    Je = dn,
                    Yt = pn;
                return l(), b("div", ur, [!e(f) && e(L) && +((bt = e(L).total_deposit) == null ? void 0 : bt.amount) == 0 && !e(r) && +(($t = e(L).balance) == null ? void 0 : $t.amount) == 0 ? (l(), F(Me, {
                    key: 0,
                    id: "header-bal-dep-0",
                    "inner-content-id": "header-bal-dep-0-text",
                    color: "red",
                    "class-name": "sm",
                    height: "28",
                    class: "balance__btn-withdraw mobile",
                    "data-auto-test-el": "plusBalance",
                    onClick: Lt
                }, {
                    default: N(() => [ae(x(e(o)("buttons.deposit")), 1)]),
                    _: 1
                })) : $("", !0), h(bn, {
                    ref: "bonuses",
                    modelValue: e(ue),
                    "onUpdate:modelValue": J[3] || (J[3] = He => Tt(ue) ? ue.value = He : null),
                    attach: "",
                    "close-on-content-click": !1,
                    offset: "15",
                    left: ""
                }, {
                    activator: N(({
                        props: He,
                        isActive: $e
                    }) => {
                        var Ue, Fe, _e, ze, Ge, je, We, et;
                        return [n("div", Ut({
                            id: "header-bal"
                        }, He, {
                            class: "balance__inner d-flex"
                        }), [n("div", _r, [n("div", dr, [n("div", null, [h(ie, {
                            src: `${e(a)}/svg/trophy.svg`,
                            class: "balance__img",
                            width: "30",
                            height: "30",
                            alt: "image trophy icom",
                            title: "image trophy icon"
                        }, null, 8, ["src"])])]), e(L) ? e(L) && ("isNull" in D ? D.isNull : e(xt))(e(d)) ? (l(), F(we, {
                            key: 1,
                            class: "desktop",
                            currency: e(H),
                            "custom-class-names": "balance__sum",
                            balance: ke((Ue = e(L).balance) == null ? void 0 : Ue.amount).toFixed(2)
                        }, null, 8, ["currency", "balance"])) : $("", !0) : (l(), b("span", pr, [h(Ra, {
                            indeterminate: "",
                            size: "25",
                            width: 3,
                            color: "#1976d2"
                        })])), e(r) && ("isNumber" in D ? D.isNumber : e(eo))(e(d)) ? (l(), F(we, {
                            key: 2,
                            class: "desktop",
                            "custom-class-names": "balance__sum",
                            currency: (Fe = e(r).balance) == null ? void 0 : Fe.currency,
                            balance: ke((_e = e(r).balance) == null ? void 0 : _e.amount).toFixed(2)
                        }, null, 8, ["currency", "balance"])) : $("", !0), h(Nt, {
                            id: "header-bal-icon",
                            color: "white",
                            class: "desktop",
                            icon: e(ge).chevronArr[+$e],
                            "data-auto-test-el": "arrow-down"
                        }, null, 8, ["icon"]), J[5] || (J[5] = n("span", {
                            id: "header-bal-text",
                            class: "desktop overlay-content"
                        }, null, -1))]), e(f) && ("isNull" in D ? D.isNull : e(xt))(e(d)) || e(L) && ("isNull" in D ? D.isNull : e(xt))(e(d)) && (+((ze = e(L).total_deposit) == null ? void 0 : ze.amount) > 0 || +((Ge = e(L).balance) == null ? void 0 : Ge.amount) > 0) ? (l(), b("div", mr, [n("div", fr, [n("div", {
                            class: K(e(st))
                        }, [e(L) ? (l(), F(we, {
                            key: 0,
                            class: "mobile",
                            currency: e(H),
                            balance: ke((je = e(L).balance) == null ? void 0 : je.amount, !0).toFixed(0)
                        }, null, 8, ["currency", "balance"])) : $("", !0), h(Nt, {
                            id: "header-bal-icon",
                            color: "white",
                            class: "balance__icon mobile",
                            size: 20,
                            "data-auto-test-el": "arrow-down",
                            icon: e(ge).chevronArr[+$e]
                        }, null, 8, ["icon"])], 2)])])) : $("", !0), ("isNumber" in D ? D.isNumber : e(eo))(e(d)) ? (l(), b("div", hr, [n("div", vr, [n("div", gr, [e(r) ? (l(), F(we, {
                            key: 1,
                            class: "mobile",
                            "data-auto-test-el": "sumBalance",
                            currency: (We = e(r).balance) == null ? void 0 : We.currency,
                            balance: ke((et = e(r).balance) == null ? void 0 : et.amount).toFixed(2)
                        }, null, 8, ["currency", "balance"])) : (l(), b("span", br, "0")), h(Me, {
                            icon: "",
                            class: "balance__btn-chevron mobile",
                            "data-auto-test-el": "arrow-down",
                            size: 28
                        }, {
                            default: N(() => [h(Nt, {
                                id: "header-bal-text",
                                color: "white",
                                size: 20,
                                icon: e(ge).chevronArr[+$e]
                            }, null, 8, ["icon"])]),
                            _: 2
                        }, 1024)])])])) : $("", !0), n("div", {
                            onClick: J[0] || (J[0] = nt(() => {}, ["stop"]))
                        }, [n("div", {
                            id: "header-bal-dep-+",
                            "data-auto-test-el": "plusBalance",
                            class: "balance__btn-plus btn-plus mobile",
                            onClick: Lt
                        })])], 16)]
                    }),
                    default: N(({
                        isActive: He
                    }) => [He.value ? (l(), b("div", yr, [h(un, {
                        "min-width": e(s) >= 359 ? "355px" : "100%",
                        "max-width": e(s) >= 1200 ? "355px" : "100%",
                        class: "balance-popup"
                    }, {
                        default: N(() => [h(yn, {
                            modelValue: e(Re),
                            "onUpdate:modelValue": J[2] || (J[2] = $e => Tt(Re) ? Re.value = $e : null),
                            "hide-details": ""
                        }, {
                            default: N(() => {
                                var $e, Ue, Fe;
                                return [h(Ie, {
                                    id: "header-bal-1",
                                    class: K({
                                        "mb-2": ($e = e(_)) == null ? void 0 : $e.length
                                    }),
                                    "is-active": ("isNull" in D ? D.isNull : e(xt))(e(d)),
                                    title: e(o)("profile.balance") + ":",
                                    "default-balance": e(Re),
                                    currency: e(H),
                                    index: 1,
                                    balance: ke((Fe = (Ue = e(L)) == null ? void 0 : Ue.balance) == null ? void 0 : Fe.amount),
                                    "data-auto-test-el": "realMoneyBalance",
                                    onSelect: J[1] || (J[1] = _e => lt(null))
                                }, null, 8, ["class", "is-active", "title", "default-balance", "currency", "balance"]), (l(!0), b(ve, null, Be(e(_), (_e, ze) => {
                                    var Ge, je, We;
                                    return l(), b(ve, null, [_e.active ? (l(), F(Ie, {
                                        id: `header-bal-${ze+2}`,
                                        key: `header-bal-${ze+2}`,
                                        class: K(["mb-2", {
                                            pointer_events: !e(z)
                                        }]),
                                        "is-disabled": _e.is_blocked_by_real_balance,
                                        "selected-disabled-bonus": e(Dt) === _e.id,
                                        "is-active": e(d) === _e.id,
                                        title: it(_e),
                                        "default-balance": e(Re),
                                        index: ze + 2,
                                        currency: (Ge = _e.balance) == null ? void 0 : Ge.currency,
                                        balance: ke((je = _e.balance) == null ? void 0 : je.amount),
                                        "max-real-balance": ke(_e.bonus.max_real_balance),
                                        "data-auto-test-el": "bonusMoneyBalance",
                                        onSelect: et => lt(_e.id),
                                        onSelectDisabled: et => Qe(_e.id)
                                    }, null, 8, ["id", "class", "is-disabled", "selected-disabled-bonus", "is-active", "title", "default-balance", "index", "currency", "balance", "max-real-balance", "onSelect", "onSelectDisabled"])) : $("", !0), _e.id === e(d) && Number((We = e(Le)) == null ? void 0 : We.amount) !== 0 ? (l(), F(oo, {
                                        key: _e.id,
                                        class: "b-bottom-none pt-8 sub-balance"
                                    }, {
                                        default: N(() => [e(Le) && e(rt) !== 100 ? (l(), F(Je, {
                                            key: _e.id,
                                            value: e(rt)
                                        }, null, 8, ["value"])) : $("", !0), e(Le) && e(Se) && e(rt) !== 100 ? (l(), b("div", {
                                            key: _e.id,
                                            class: "d-flex inform justify-space-between sub-balance__inform w-100",
                                            style: {
                                                "align-items": "inherit"
                                            }
                                        }, [n("div", wr, [("isNumber" in D ? D.isNumber : e(eo))(e(ft)) ? (l(), b("div", kr, [e(ft) ? (l(), F(Yt, {
                                            key: 0,
                                            deadline: e(ft),
                                            "onTimer:up": ht
                                        }, null, 8, ["deadline"])) : $("", !0)])) : $("", !0)]), e(Le) && e(Se) ? (l(), b("div", Ir, [n("p", Ar, x(e(o)("profile.wager")) + ":", 1), n("p", Tr, x(((parseInt(e(Se).amount) - parseInt(e(Le).amount)) / 100).toFixed(1)) + " / " + x(parseInt(e(Se).amount) / 100) + " " + x(e(Se).currency), 1)])) : $("", !0)])) : $("", !0)]),
                                        _: 2
                                    }, 1024)) : $("", !0)], 64)
                                }), 256))]
                            }),
                            _: 1
                        }, 8, ["modelValue"]), h(oo, {
                            class: "pt-8 sub-balance"
                        }, {
                            default: N(() => [h(Me, {
                                id: "header-bal-profile",
                                color: "primary",
                                "inner-content-id": "header-bal-profile-text",
                                block: "",
                                "data-auto-test-el": "myProfile",
                                onClick: Wt
                            }, {
                                default: N(() => [ae(x(e(o)("buttons.goToAccount")), 1)]),
                                _: 1
                            }), h(Me, {
                                id: "header-bal-logout",
                                "inner-content-id": "header-bal-logout-text",
                                block: "",
                                class: "error mt-4",
                                loading: e(U),
                                "data-auto-test-el": "logout",
                                onClick: ct
                            }, {
                                default: N(() => [n("span", null, x(e(o)("labels.logOut")), 1)]),
                                _: 1
                            }, 8, ["loading"])]),
                            _: 1
                        })]),
                        _: 1
                    }, 8, ["min-width", "max-width"])])) : $("", !0)]),
                    _: 1
                }, 8, ["modelValue"]), e(jt) && e(ge).showPopover ? (l(), b("div", {
                    key: 1,
                    class: "popover-arrow",
                    onClick: J[4] || (J[4] = He => e(ge).showPopover = !1)
                }, [n("h4", Cr, x(e(o)("withdraw.balancePopup")), 1)])) : $("", !0)])
            }
        }
    }),
    na = Q(Er, [
        ["__scopeId", "data-v-3d9b0b9d"]
    ]),
    Lr = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: na
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Sr = {
        class: "mob-menu"
    },
    Dr = {
        class: "mob-menu__item",
        "data-auto-test-el": "profile"
    },
    Br = {
        class: "mob-menu__item",
        "data-auto-test-el": "deposit"
    },
    $r = {
        class: "mob-menu__item",
        "data-auto-test-el": "paymentHistory"
    },
    Pr = {
        class: "mob-menu__item",
        "data-auto-test-el": "betsHistory"
    },
    xr = oe({
        __name: "MobileMenuComponent",
        setup(t) {
            const {
                t: o
            } = re(), a = Ne(), {
                openDialog: s
            } = Ee(), {
                trackButtonClick: i
            } = ye();

            function c() {
                Pe(ce.SUBHEADER), i({
                    category: "deposit_popup",
                    action: "view_paywall",
                    label: ce.SUBHEADER
                }), s("deposit")
            }
            return (u, f) => {
                const r = Xe;
                return l(), b("div", Sr, [n("ul", null, [n("li", Dr, [h(r, {
                    class: "mob-menu__link",
                    to: e(a)("/profile"),
                    "no-prefetch": ""
                }, {
                    default: N(() => [ae(x(e(o)("profile.menu.myProfile")), 1)]),
                    _: 1
                }, 8, ["to"])]), n("li", Br, [n("a", {
                    class: "mob-menu__link",
                    onClick: c
                }, x(e(o)("mobileMenu.deposit")), 1)]), n("li", $r, [h(r, {
                    class: "mob-menu__link",
                    to: e(a)("/profile/history"),
                    "no-prefetch": ""
                }, {
                    default: N(() => [ae(x(e(o)("profile.menu.myHistory")), 1)]),
                    _: 1
                }, 8, ["to"])]), n("li", Pr, [h(r, {
                    class: "mob-menu__link",
                    to: e(a)("/sports/bets"),
                    "no-prefetch": ""
                }, {
                    default: N(() => [ae(x(e(o)("profile.menu.myBetsHistory")), 1)]),
                    _: 1
                }, 8, ["to"])])])])
            }
        }
    }),
    Or = Q(xr, [
        ["__scopeId", "data-v-bb4917df"]
    ]),
    Nr = Z(() => v(() =>
        import ("./exT4JKqa.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6]),
        import.meta.url).then(t => t.default || t)),
    Rr = Z(() => v(() => Promise.resolve().then(() => Lr), void 0,
        import.meta.url).then(t => t.default || t)),
    Mr = Z(() => v(() =>
        import ("./DEf14JIh.js"), __vite__mapDeps([7, 1, 2, 3, 4, 8]),
        import.meta.url).then(t => t.default || t)),
    Vr = Z(() => v(() =>
        import ("./CXu5n-4c.js"), __vite__mapDeps([9, 10, 1, 2, 3, 4, 5, 11]),
        import.meta.url).then(t => t.default || t)),
    Hr = {
        key: 0,
        class: "header__main"
    },
    Ur = {
        class: "header__main-left"
    },
    Fr = {
        class: "header__main-right"
    },
    zr = {
        key: 0,
        class: "header__item header__item--btn"
    },
    Gr = {
        key: 1,
        id: "noticeBell",
        class: "header__item header__item--btn header__notice notice"
    },
    jr = {
        class: "header__balance header__item"
    },
    Wr = {
        class: "header__item header__lang"
    },
    qr = {
        key: 1,
        class: "header__mob"
    },
    Zr = {
        class: "header__mob-left"
    },
    Kr = ["src"],
    Xr = ["src"],
    Yr = {
        key: 1,
        class: "notice"
    },
    Qr = {
        class: "badge-round badge-round--default notice__badge-round"
    },
    Jr = {
        class: "header__mob-center"
    },
    ei = {
        class: "app"
    },
    ti = ["href"],
    oi = ["href"],
    ai = {
        key: 0,
        class: "balance"
    },
    ni = {
        class: "balance__btn-box"
    },
    si = {
        class: "header__mob-menu"
    },
    ri = oe({
        __name: "AppHeader",
        props: {
            langs: {}
        },
        setup(t) {
            const o = ne(),
                a = Ke(),
                {
                    config: s
                } = Ze(),
                {
                    t: i
                } = re(),
                {
                    imageUrl: c
                } = pt(),
                {
                    isMobile: u,
                    isDesktop: f
                } = Ye(),
                r = s.value.NEW_YEAR_THEME,
                {
                    isAuthenticated: d
                } = Te(),
                {
                    profileForm: _
                } = Y(he()),
                {
                    openWidgetChat: p
                } = fo(),
                {
                    notificationsCount: m
                } = Y(he()),
                {
                    drawerDisplay: T
                } = Y(be()),
                {
                    updateDrawer: E
                } = be(),
                {
                    showTopBar: k
                } = Wo(),
                {
                    openDialog: y
                } = Ee(),
                {
                    showBonusPopup: I
                } = Y(xe()),
                B = g(() => {
                    var A;
                    return d.value && ((A = _.value) == null ? void 0 : A.info.uuid)
                }),
                {
                    trackButtonClick: z
                } = ye();

            function X() {
                Pe(ce.HEADER), z({
                    category: "deposit_popup",
                    action: "view_paywall",
                    label: ce.HEADER
                }), y("deposit")
            }

            function L() {
                z({
                    category: "header",
                    action: "language",
                    label: "click_icon"
                })
            }

            function H() {
                z({
                    category: "sidebar",
                    action: "open"
                }), E(!T.value)
            }
            const U = g(() => ({
                    android: Va,
                    apple: a.app.appleBtn
                })),
                R = Uo({
                    ios: !1,
                    android: !1
                });

            function w(A) {
                R[A] = !0
            }

            function P(A) {
                R[A] = !1
            }
            const C = g(() => {
                var A;
                return k.value && ((A = o.name) == null ? void 0 : A.includes("-slot-id"))
            });
            return (A, S) => {
                const G = ys,
                    q = Ls,
                    M = Nr,
                    j = Rr,
                    te = Bs,
                    se = mo,
                    de = oa,
                    ue = zt,
                    ge = na,
                    st = Or,
                    Re = Mr,
                    Le = Vr;
                return l(), b("header", {
                    class: "header",
                    style: ut({
                        backgroundImage: e(r) ? `url(${e(c)}/new-year/show-banner.png)` : "none"
                    })
                }, [e(f) ? (l(), b("div", Hr, [n("div", Ur, [h(G, {
                    "is-new-year": !!e(r)
                }, null, 8, ["is-new-year"]), h(q)]), n("div", Fr, [e(d) ? (l(), b("div", zr, [h(Me, {
                    id: "header-bal-dep-0",
                    "inner-content-id": "header-bal-dep-0-text",
                    "class-name": "sm",
                    color: "primary",
                    onClick: X
                }, {
                    default: N(() => [ae(x(e(i)("buttons.deposit")), 1)]),
                    _: 1
                })])) : $("", !0), e(d) ? (l(), b("div", Gr, [h(M)])) : $("", !0), n("div", jr, [h(se, null, {
                    default: N(() => [e(B) ? (l(), F(j, {
                        key: 0
                    })) : e(d) ? $("", !0) : (l(), F(te, {
                        key: 1
                    }))]),
                    _: 1
                }), at(n("div", Wr, [h(de, {
                    langs: A.langs,
                    onClick: L
                }, null, 8, ["langs"])], 512), [
                    [It, A.langs && !!A.langs.length]
                ])])])])) : $("", !0), e(u) ? (l(), b("div", qr, [n("div", {
                    class: K(["header__mob-top header__mob-top--fixed", {
                        "header__new-year": e(r)
                    }]),
                    style: ut({
                        backgroundImage: e(r) ? `url(${e(c)}/new-year/header_mob.svg)` : ""
                    })
                }, [n("div", Zr, [n("button", {
                    class: "burger header__burger",
                    "data-auto-test-el": "headerBurger",
                    onClick: H
                }, [e(r) ? (l(), b(ve, {
                    key: 0
                }, [n("img", {
                    class: "header__burger_ice header__burger_ice-1",
                    src: e(c) + "/new-year/humburger-2.svg",
                    alt: "country humburger-ice"
                }, null, 8, Kr), n("img", {
                    class: "header__burger_ice header__burger_ice-2",
                    src: e(c) + "/new-year/humburger-1.svg",
                    alt: "country humburger-ice"
                }, null, 8, Xr)], 64)) : $("", !0), S[5] || (S[5] = n("span", {
                    class: "burger__inner"
                }, null, -1)), e(m) ? (l(), b("div", Yr, [n("span", Qr, x(e(m)), 1)])) : $("", !0)]), n("a", {
                    id: "open-live-chat-header",
                    href: "#",
                    class: "header__message message",
                    "data-auto-test-el": "headerChat",
                    onClick: S[0] || (S[0] = nt((...Se) => e(p) && e(p)(...Se), ["prevent"]))
                }, [h(ue, {
                    class: "message__icon",
                    size: 26,
                    "symbol-id": "comments",
                    "tag-use-class-name": "message__icon-use"
                })])]), n("div", Jr, [h(G, {
                    "is-new-year": e(r),
                    "is-mobile": ""
                }, null, 8, ["is-new-year"])]), n("div", {
                    class: K(["header__mob-right", {
                        auth: e(d),
                        unauth: !e(d)
                    }])
                }, [h(se, null, {
                    default: N(() => [n("div", ei, [n("a", {
                        href: e(U).apple,
                        rel: "nofollow",
                        target: "_blank",
                        class: "app__link",
                        "data-auto-test-el": "apple"
                    }, [h(ue, {
                        class: K(["app__icon", {
                            "active-icon": e(R).ios
                        }]),
                        width: 21,
                        height: 25,
                        "symbol-id": "apple",
                        "tag-use-class-name": "app__icon-use",
                        onClick: S[1] || (S[1] = () => w("ios")),
                        onAnimationend: S[2] || (S[2] = () => P("ios"))
                    }, null, 8, ["class"])], 8, ti), n("a", {
                        href: e(U).android,
                        target: "_blank",
                        class: "app__link",
                        "data-auto-test-el": "android"
                    }, [h(ue, {
                        class: K(["app__icon", {
                            "active-icon": e(R).android
                        }]),
                        width: 22,
                        height: 25,
                        "symbol-id": "android2header",
                        "tag-use-class-name": "app__icon-use",
                        onClick: S[3] || (S[3] = () => w("android")),
                        onAnimationend: S[4] || (S[4] = () => P("android"))
                    }, null, 8, ["class"])], 8, oi)])]),
                    _: 1
                }), e(B) ? (l(), b("div", ai, [n("div", ni, [h(ge)])])) : $("", !0)], 2)], 6), at(n("div", si, [h(se, {
                    placeholder: "Loading..."
                }, {
                    default: N(() => [h(st)]),
                    _: 1
                })], 512), [
                    [It, e(d) && !e(C)]
                ]), at(h(Re, null, null, 512), [
                    [It, !e(d)]
                ])])) : $("", !0), at(h(Le, null, null, 512), [
                    [It, e(I) && e(d)]
                ])], 4)
            }
        }
    }),
    ii = Q(ri, [
        ["__scopeId", "data-v-8e575d29"]
    ]),
    li = {
        class: "cat-menu__content"
    },
    ci = {
        class: "cat-menu__text"
    },
    ui = {
        key: 0,
        class: "cat-menu__count"
    },
    _i = {
        key: 1,
        class: "cat-menu__link"
    },
    di = oe({
        __name: "CategorySidebarItem",
        props: {
            isActive: {
                type: Boolean
            },
            text: {},
            displayCounts: {
                type: Boolean
            },
            item: {}
        },
        emits: ["change"],
        setup(t) {
            const o = ne(),
                a = Ne(),
                {
                    getSubdirUrlPart: s
                } = Oe(),
                {
                    updatedImages: i
                } = ho(),
                c = g(() => `/${s(0,o.path)}`);

            function u(r) {
                return r.slug === "allGames" ? a(c.value) : a(`${c.value}/${r.slug}`)
            }

            function f(r) {
                return kn[r] || r
            }
            return (r, d) => {
                const _ = wn,
                    p = zt,
                    m = Xe;
                return l(), b("li", {
                    class: K([{
                        "is-active": r.isActive,
                        "no-hover": !r.item
                    }, "cat-menu__item cat-menu__item--line"]),
                    onClick: d[0] || (d[0] = T => r.$emit("change"))
                }, [r.item ? (l(), F(m, {
                    key: 0,
                    to: u(r.item),
                    class: "cat-menu__link",
                    "no-prefetch": ""
                }, {
                    default: N(() => [e(i).includes(r.item.slug) ? (l(), F(_, {
                        key: 0,
                        slug: r.item.slug,
                        class: "mr-3"
                    }, null, 8, ["slug"])) : (l(), F(p, {
                        key: 1,
                        class: "cat-filter__icon mr-2",
                        size: 16,
                        "tag-use-class-name": "cat-filter__icon-use",
                        "symbol-id": f(r.item.slug)
                    }, null, 8, ["symbol-id"])), n("span", li, [n("span", ci, x(r.text), 1), r.displayCounts ? (l(), b("span", ui, x(r.item.count), 1)) : $("", !0)])]),
                    _: 1
                }, 8, ["to"])) : (l(), b("div", _i))], 2)
            }
        }
    }),
    pi = Q(di, [
        ["__scopeId", "data-v-5d908fee"]
    ]),
    mi = {
        class: "l-leftbar"
    },
    fi = {
        class: "l-leftbar__position"
    },
    hi = {
        class: "l-leftbar__container"
    },
    vi = {
        class: "l-leftbar__inner"
    },
    gi = {
        class: "title-block"
    },
    bi = {
        class: "title-block__inner"
    },
    yi = {
        class: "mb-0 title-block__text"
    },
    wi = {
        class: "cat-menu"
    },
    ki = {
        class: "cat-menu__list"
    },
    Ii = oe({
        __name: "CategorySidebar",
        setup(t) {
            const o = ne(),
                {
                    t: a
                } = re(),
                {
                    sectionCategories: s,
                    getTranslationCategoryKey: i
                } = ho(),
                {
                    getSubdirUrlPart: c
                } = Oe(),
                {
                    loadedChatSupport: u
                } = Y(be()),
                f = ee(null),
                r = ee(!1),
                d = g(() => `/${c(0,o.path)}`),
                _ = g(() => !f.value),
                p = g(() => s.value.filter(k => In(d.value, k.slug)));

            function m(k) {
                return i(k)
            }

            function T() {
                var k;
                (k = o == null ? void 0 : o.params) != null && k.id ? f.value = o.params.id : f.value = null
            }

            function E() {
                f.value = null
            }
            return le(() => o.path, () => setTimeout(() => T(), 300)), Ce(() => {
                r.value = !0, T()
            }), (k, y) => {
                const I = pi;
                return l(), b("aside", mi, [n("div", fi, [n("div", hi, [n("div", vi, [n("div", gi, [n("div", bi, [n("p", yi, x(e(a)("categories.categories")), 1)])]), n("nav", wi, [n("ul", ki, [h(I, {
                    "is-active": e(_),
                    text: e(a)("categories.allGames"),
                    item: {
                        slug: "allGames"
                    },
                    onChange: E
                }, null, 8, ["is-active", "text"]), e(p).length && e(r) ? (l(!0), b(ve, {
                    key: 0
                }, Be(e(p), (B, z) => (l(), F(I, {
                    key: "categories-" + z,
                    "is-active": B.slug === e(f),
                    text: e(a)(m(B.slug)),
                    item: B,
                    "display-counts": "",
                    onChange: T
                }, null, 8, ["is-active", "text", "item"]))), 128)) : $("", !0), e(u) ? (l(), b(ve, {
                    key: 1
                }, [h(I), h(I), h(I)], 64)) : $("", !0)])])])])])])
            }
        }
    }),
    Ai = Q(Ii, [
        ["__scopeId", "data-v-6f0d7694"]
    ]),
    Ti = [{
        name: "schedule",
        query: "scheduleSport"
    }, {
        name: "horse-racing",
        query: "timeRange"
    }, {
        name: "greyhound-58",
        query: "timeRange"
    }, {
        name: "greyhound-202",
        query: "timeRange"
    }, {
        name: "harness",
        query: "timeRange"
    }, {
        name: "harness-55",
        query: "timeRange"
    }, {
        name: "harness-202",
        query: "timeRange"
    }],
    ao = {
        "/live": "/live",
        "/": "/sports",
        "/favorites": "/favorites",
        "/counter-strike-109": "/counter-strike",
        "/soccer-1": "/soccer",
        "/tennis-5": "/tennis",
        "/fifa-300": "/fifa",
        "/dota-2-111": "/dota-2",
        "/e_sport/305": "/e_sport",
        "/e_sport": "/e_sport",
        "/305": "/e_sport",
        "/basketball-2": "/basketball",
        "/ice-hockey-4": "/ice-hockey",
        "/baseball-3": "/baseball",
        "/handball-6": "/handball",
        "/floorball-7": "/floorball",
        "/football-1": "/football",
        "/golf-9": "/golf",
        "/3-egypt-chests": "/egypt-chests",
        "/boxing-10": "/boxing",
        "/rugby-12": "/rugby",
        "/aussie-rules-13": "/aussie-rules",
        "/american-football-16": "/american-football",
        "/cycling-17": "/cycling",
        "/specials-18": "/specials",
        "/snooker-19": "/snooker",
        "/table-tennis-20": "/table-tennis",
        "/cricket-21": "/cricket",
        "/volleyball-23": "/volleyball",
        "/darts-22": "/darts",
        "/waterpolo-26": "/waterpolo",
        "/futsal-29": "/futsal",
        "/badminton-31": "/badminton",
        "/squash-37": "/squash",
        "/alpine-skiing-43": "/alpine-skiing",
        "/biathlon-44": "/biathlon",
        "/ski-jumping-48": "/ski-jumping",
        "/horse-racing-55": "/horse-racing",
        "/greyhound-55": "/horse-racing",
        "/harness-55": "/horse-racing",
        "/horse-racing-58": "/greyhound-58",
        "/harness-58": "/greyhound-58",
        "/horse-racing-202": "/greyhound-202",
        "/pesapallo-61": "/pesapallo",
        "/league-of-legends-110": "/league-of-legends",
        "/starcraft-112": "/starcraft",
        "/mma-117": "/mma",
        "/overwatch-121": "/overwatch",
        "/halo-124": "/halo",
        "/rainbow-six-125": "/rainbow-six",
        "/speedway-131": "/speedway",
        "/esport-king-of-glory-134": "/esport-king-of-glory",
        "/gaelic-football-135": "/gaelic-football",
        "/gaelic-hurling-136": "/gaelic-hurling",
        "/esport-arena-of-valor-158": "/esport-arena-of-valor",
        "/motorcycle-racing-190": "/motorcycle-racing",
        "/stock-car-racing-191": "/stock-car-racing",
        "/esport-valorant-194": "/esport-valorant",
        "/mobile-legends-201": "/mobile-legends",
        "/harness-202": "/harness",
        "/rocket-league-301": "/rocket-league",
        "/nba-2k19-302": "/nba-2k19",
        "/efighting-304": "/efighting",
        "/ecricket-305": "/ecricket",
        "/ebaseball-306": "/ebaseball",
        "/fifa18-penalty-307": "/fifa18-penalty",
        "/csgo-308": "/csgo",
        "/fifa22-volta-309": "/fifa22-volta",
        "/schedule": "/schedule"
    };

function Ci() {
    return Object.fromEntries(Object.entries(ao).map(([t, o]) => [o, t]))
}

function Ei(t) {
    var o;
    return (o = Ti.find(({
        name: a
    }) => a === t)) == null ? void 0 : o.query
}
const no = t => {
        const {
            getPathArrWithoutLocale: o
        } = Oe(), a = o(t);
        if (a.length === 0) return "/";
        const [s] = a, i = Ci(), c = i[`/${a[1]}`] ? ? `/${a[1]}`, u = Ei(a[1]);
        switch (a.length) {
            case 1:
                return i[`/${s}`] ? ? `/${s}`;
            case 2:
                return s === "live" ? `/${s}${c}` : c;
            case 5:
                if (s === "sports") return "/" + a.slice(1).join("/");
                break
        }
        return u ? `${c}?${u}=${a[2]}` : `/${(s==="live"?a:a.slice(1)).join("/")}`
    },
    so = Ha("sport-store", () => {
        const {
            $API: t
        } = Ae(), o = ee(!1), a = ee(0), s = ee(!1), i = ee(null);

        function c(_) {
            const p = me("betslip", {
                maxAge: 31536e3,
                path: "/",
                default: () => !1
            });
            p.value !== _ && (p.value = _, o.value = _)
        }

        function u(_) {
            a.value = _
        }

        function f(_) {
            s.value = _
        }
        async function r(_) {
            try {
                const p = await t.ApiBonuses.createBonusBalance(_);
                return i.value = p.data.betby_jwt, p
            } catch (p) {
                console.error(p)
            }
        }

        function d(_) {
            i.value = _
        }
        return {
            showBetSlipMob: o,
            setBetSlipCookie: c,
            numberOfBetslip: a,
            setBetSlipNumber: u,
            createNewUserSession: r,
            isMountedSessions: s,
            sessionToken: i,
            setSessionToken: d,
            setIsMountedSessions: f
        }
    });

function Li() {
    const t = ne(),
        o = _t(),
        {
            locale: a
        } = re(),
        {
            isNull: s
        } = Ua(),
        {
            $bt: i
        } = Ae(),
        c = Ke(),
        {
            mobile: u
        } = co(),
        {
            openDialog: f
        } = Ee(),
        {
            isAuthenticated: r
        } = Te(),
        {
            isMobile: d,
            isDesktop: _
        } = Ye(),
        p = xe(),
        {
            currentBonusId: m
        } = Y(p),
        T = he(),
        E = so(),
        {
            showBetSlipMob: k,
            numberOfBetslip: y,
            sessionToken: I
        } = Y(so());

    function B() {
        const A = (S, G) => {
            if (window != null && window.hasOwnProperty("BTRenderer")) try {
                const q = new window.BTRenderer;
                S(q)
            } catch (q) {
                G(q)
            } else requestAnimationFrame(A.bind(null, S, G))
        };
        return new Promise((S, G) => {
            requestAnimationFrame(A.bind(null, S, G))
        })
    }
    async function z() {
        const A = no(t.path),
            S = a.value === "pt" ? "pt-br" : a.value;
        i.isHere() && (await _o(), i.get().initialize({
            token: I.value || null,
            brand_id: c.public.env.BRAND_ID,
            target: document.getElementById("betby"),
            betSlipButton: document.getElementById("betSlipButton"),
            themeName: c.public.env.BETSLIP_THEME,
            lang: S,
            hideMobileClosedBetslip: !0,
            is_rindles_available: !1,
            stickyTop: _.value ? 58 : !1,
            betSlipOffsetBottom: _.value ? 0 : 58,
            betSlipOffsetTop: _.value ? 58 : 91,
            betslipZIndex: 100,
            url: A,
            onLogin: () => {
                f("auth")
            },
            onRegister: () => {
                f("registration")
            },
            onBetslipChanged: G => {
                var M;
                let q = (G == null ? void 0 : G.betsTotal) || 0;
                X(s(m.value)), d.value && ((M = document.querySelectorAll('[data-editor-id="betslipSelection"]')) == null ? void 0 : M.length) <= 0 && E.setBetSlipCookie(!1), setTimeout(() => {
                    var j, te;
                    q || (q = +(((te = (j = document.querySelector("#bt-inner-page")) == null ? void 0 : j.shadowRoot) == null ? void 0 : te.querySelectorAll('[data-editor-id="betslipSelection"]').length) || 0)), d.value && !k.value && !r.value && (E.setBetSlipCookie(!0), q > 1 && L(), y.value === 2 && q === 1 && L()), d.value && !k.value && q === 1 && r.value && E.setBetSlipCookie(!0)
                }, 500), E.setBetSlipNumber(q)
            },
            onSessionRefresh: async () => {
                var G;
                try {
                    const q = await E.createNewUserSession(m.value);
                    return (G = q == null ? void 0 : q.data) == null ? void 0 : G.betby_jwt
                } catch (q) {
                    console.error(q)
                }
            },
            onTokenExpired: async () => {
                var G;
                try {
                    const q = await E.createNewUserSession(m.value);
                    return (G = q == null ? void 0 : q.data) == null ? void 0 : G.betby_jwt
                } catch (q) {
                    console.error(q)
                }
            },
            onRecharge: () => {
                f("deposit")
            },
            handlePageChange: G => {
                C(G)
            }
        })), E.setIsMountedSessions(!1)
    }
    async function X(A) {
        r.value && (c.public.env.NODE_ENV !== "production" && console.info(A), await H())
    }

    function L() {
        try {
            i.get().action("toggleBetSlip")
        } catch (A) {
            console.warn("Alternative method toggle betslip...", A);
            const S = document.querySelector('[data-editor-id="betslipHeader"] > div ');
            S ? S.click() : console.warn('WARN: [data-editor-id="betslipHeader"] - not found!')
        }
    }
    async function H() {
        for (let A = 0; A <= 3; A++) await new Promise(S => setTimeout(S, 1e3 * A)), await T.getPlayerBalance()
    }
    const U = ee(1e3),
        R = ee(0);

    function w() {
        var se;
        let S = 0,
            G;
        const q = () => {
                G && G.disconnect()
            },
            M = () => {
                S < 10 && (S++, q(), setTimeout(w, U.value))
            },
            j = {
                childList: !0,
                subtree: !0,
                characterData: !0
            },
            te = (se = document.querySelector("#bt-inner-page")) == null ? void 0 : se.shadowRoot;
        if (!te) {
            M();
            return
        }
        if (u.value) {
            if (!te.querySelectorAll('[data-editor-id="betslipContent"]')[0]) {
                M();
                return
            }
        } else {
            const de = te.querySelector('[data-editor-id="rightSidebar"]');
            if (!de) {
                M();
                return
            }
            G = new MutationObserver(ue => {
                ue.forEach(() => {
                    const ge = te == null ? void 0 : te.querySelectorAll('[data-editor-id="betslipSelection"]').length;
                    ge !== R.value && (R.value = ge || 0)
                })
            }), G.observe(de, j)
        }
    }

    function P(A) {
        var de;
        if (A === "/live") return A;
        const [S, G] = A.split("?").filter(ue => !!ue), q = S.split("/").filter(ue => !!ue), M = q[0] === "live" ? "/live" : "/sports", j = M === "/live" ? q.slice(1) : [...q];
        let te = G ? `/${G.split("=")[1]}` : "";
        j.length === 0 && te && (te = ao[te] ? ? te), j.length === 1 && (j[0] = ((de = ao[`/${j[0]}`]) == null ? void 0 : de.substring(1)) ? ? j[0]);
        const se = j.length ? `/${j.join("/")}` : "";
        return `${M}${se}${te}`
    }

    function C(A) {
        const G = (a.value === "en" ? "" : `/${a.value}`) + P(A);
        o.push({
            path: G
        }), setTimeout(() => {
            window.history.replaceState(null, "", G)
        })
    }
    return {
        checkExistBtRender: B,
        initBetSlip: z,
        checkIsBtLoaded: w,
        betbyPageChangeHandler: C,
        openBetSlip: L
    }
}
const Si = {
        id: "betby",
        ref: "betby"
    },
    Di = oe({
        __name: "BetbyContainer",
        setup(t) {
            const o = Ke(),
                a = ne(),
                {
                    locale: s
                } = re(),
                {
                    $bt: i
                } = Ae(),
                {
                    useScriptTag: c
                } = Mn(),
                {
                    isAuthenticated: u
                } = Te(),
                f = xe(),
                {
                    currentBonusId: r
                } = Y(f),
                d = so(),
                {
                    sessionToken: _
                } = Y(d),
                {
                    load: p
                } = c(o.public.env.BETSLIP_URL, y => {
                    y.id = "bt-script-x", y.defer = !0, y.type = "text/javascript"
                }),
                {
                    initBetSlip: m,
                    checkExistBtRender: T,
                    checkIsBtLoaded: E
                } = Li(),
                k = async () => {
                    try {
                        const y = await T();
                        i.set(y), await m(), E()
                    } catch (y) {
                        console.error("Error initializing Betby:", y)
                    }
                };
            return Ce(async () => {
                try {
                    window.hasOwnProperty("BTRenderer") || await p(), u.value ? await d.createNewUserSession(r.value) : await k(), setTimeout(() => {
                        i.update({
                            url: no(a.path),
                            lang: s.value === "pt" ? "pt-br" : s.value
                        })
                    }, 7e3)
                } catch (y) {
                    console.error(y)
                }
            }), Fo(() => {
                const y = me("betslipCount");
                y.value = null;
                const I = document.getElementById("bt-script-x");
                I && document.body.removeChild(I), i.isHere() && (i.kill(), d.setSessionToken(null))
            }), le(_, async (y, I) => {
                I !== y && (i.kill(), await k())
            }), le(() => a.path, y => {
                i.update({
                    url: no(y),
                    lang: s.value === "pt" ? "pt-br" : s.value
                })
            }), le(u, y => {
                y ? d.createNewUserSession(r.value) : d.setSessionToken(null)
            }), le(r, async (y, I) => {
                y !== I && await d.createNewUserSession(r.value)
            }), (y, I) => {
                const B = hn;
                return l(), b("div", Si, [h(B, {
                    class: "py-12"
                })], 512)
            }
        }
    }),
    Bi = Q(Di, [
        ["__scopeId", "data-v-a0e2ec74"]
    ]),
    $i = {
        class: "footer__category-title"
    },
    Pi = ["data-auto-test-el"],
    xi = ["data-auto-test-el"],
    Oi = ["onClick"],
    Ni = {
        key: 0,
        class: "new"
    },
    Ri = ["onClick"],
    Mi = ["onClick"],
    Vi = {
        key: 0,
        class: "new"
    },
    Hi = {
        key: 0,
        class: "new"
    },
    Ui = ["href"],
    Fi = {
        key: 0,
        class: "new"
    },
    zi = {
        key: 0,
        class: "new"
    },
    Gi = oe({
        __name: "CategoryComponent",
        props: {
            title: {},
            links: {},
            className: {},
            listDataAttrName: {}
        },
        setup(t) {
            const o = t,
                {
                    t: a
                } = re(),
                s = Ne(),
                i = _t(),
                {
                    openDialog: c
                } = Ee(),
                {
                    isAuthenticated: u
                } = Te(),
                {
                    setActionAfterLogin: f
                } = Po(),
                {
                    userGeo: r
                } = Y(be()),
                {
                    showSmartico: d
                } = Y(he()),
                {
                    trackButtonClick: _
                } = ye();

            function p(B) {
                B === "openMissions" ? I() : B === "openDeposit" ? k() : B === "openWithdrawal" && y()
            }

            function m(B, z, X) {
                B.preventDefault(), X === "checkAuth" && T("/" + z)
            }

            function T(B = "") {
                if (!u.value) {
                    E(), f({
                        action: "navigate",
                        target: B
                    });
                    return
                }
                i.push({
                    path: B
                })
            }

            function E() {
                c("auth")
            }

            function k() {
                if (!u.value) {
                    E(), f({
                        action: "dialog",
                        target: "deposit"
                    });
                    return
                }
                Pe(ce.FOOTER), _({
                    category: "deposit_popup",
                    action: "view_paywall",
                    label: ce.FOOTER
                }), c("deposit")
            }

            function y() {
                if (!u.value) {
                    E(), f({
                        action: "dialog",
                        target: "withdrawal"
                    });
                    return
                }
                c("withdrawal")
            }

            function I() {
                var B;
                if (!u.value) {
                    E();
                    return
                }(B = window._smartico) == null || B.dp("dp:gf")
            }
            return (B, z) => {
                const X = Xe;
                return l(), b("div", {
                    class: K(["footer__category", B.className])
                }, [n("div", $i, x(e(a)(B.title)), 1), n("ul", {
                    class: "footer__category-list",
                    "data-auto-test-el": B.listDataAttrName
                }, [(l(!0), b(ve, null, Be(o.links, L => (l(), b("li", {
                    key: L.href,
                    class: "footer__category-item",
                    "data-auto-test-el": L.dataAttrName
                }, [L.action ? (l(), b(ve, {
                    key: 0
                }, [L.href === "rewards" && e(u) && e(d) ? (l(), b("a", {
                    key: 0,
                    class: "footer__category-link",
                    onClick: nt(H => p(L.action), ["prevent"])
                }, [ae(x(e(a)(L.text)) + " ", 1), L.span ? (l(), b("span", Ni, x(e(a)(L.span)), 1)) : $("", !0)], 8, Oi)) : $("", !0), L.href === "deposit" || L.href === "withdrawal" && e(r) === "BD" ? (l(), b("a", {
                    key: 1,
                    class: "footer__category-link",
                    onClick: nt(H => p(L.action), ["prevent"])
                }, x(e(a)(L.text)), 9, Ri)) : $("", !0)], 64)) : L.handler ? (l(), b(ve, {
                    key: 1
                }, [L.handler === "checkAuth" && !e(u) ? (l(), b("a", {
                    key: 0,
                    class: "footer__category-link",
                    onClick: nt(H => m(H, L.href, L.handler), ["prevent"])
                }, [ae(x(e(a)(L.text)) + " ", 1), L.span ? (l(), b("span", Vi, x(e(a)(L.span)), 1)) : $("", !0)], 8, Mi)) : (l(), F(X, {
                    key: 1,
                    to: e(s)(`/${L.href}`),
                    class: "footer__category-link",
                    "no-prefetch": "",
                    onClick: H => m(H, L.href, L.handler)
                }, {
                    default: N(() => [ae(x(e(a)(L.text)) + " ", 1), L.span ? (l(), b("span", Hi, x(e(a)(L.span)), 1)) : $("", !0)]),
                    _: 2
                }, 1032, ["to", "onClick"]))], 64)) : L.external ? (l(), b("a", {
                    key: 2,
                    href: L.href,
                    target: "_blank",
                    rel: "noreferrer",
                    class: "footer__category-link"
                }, [ae(x(e(a)(L.text)) + " ", 1), L.span ? (l(), b("span", Fi, x(e(a)(L.span)), 1)) : $("", !0)], 8, Ui)) : (l(), F(X, {
                    key: 3,
                    to: e(s)(`/${L.href}`),
                    class: "footer__category-link",
                    "no-prefetch": ""
                }, {
                    default: N(() => [ae(x(e(a)(L.text)) + " ", 1), L.span ? (l(), b("span", zi, x(e(a)(L.span)), 1)) : $("", !0)]),
                    _: 2
                }, 1032, ["to"]))], 8, xi))), 128))], 8, Pi)], 2)
            }
        }
    }),
    ji = Q(Gi, [
        ["__scopeId", "data-v-73858279"]
    ]),
    Wi = {},
    qi = {
        xmlns: "http://www.w3.org/2000/svg",
        width: "112",
        height: "20",
        viewBox: "0 0 112 20",
        fill: "none"
    };

function Zi(t, o) {
    return l(), b("svg", qi, o[0] || (o[0] = [Ft('<path d="M39.4495 8.1328C40.5136 3.64761 37.8115 0 33.4257 0H29.4599H26.9421H24.3996L19.668 19.9987H24.7283L25.6119 16.2656H29.5682C29.7963 16.2656 30.0243 16.25 30.2523 16.2306L31.9549 19.9987H37.7602L35.1892 14.3106C37.249 12.8201 38.8623 10.6047 39.4495 8.1328ZM26.5792 12.1691L28.4889 4.09652H31.7136C34.3226 4.09652 35.0789 5.90769 34.5507 8.1328C34.0224 10.3579 32.4338 12.1691 29.7982 12.1691H26.5792Z" fill="white"></path><path d="M74.8172 11.0186C74.4732 10.4765 74.0039 10.0353 73.4167 9.69913C74.2718 9.25411 74.9825 8.66529 75.5355 7.93848C76.212 7.05039 76.5787 5.9699 76.63 4.73006C76.6927 3.21233 76.1417 2.02496 74.9958 1.20488C73.8823 0.408117 72.2575 0.00390625 70.1654 0.00390625H60.763L56.0352 20.0007H66.3364C68.9663 20.0007 71.1307 19.4624 72.7687 18.3994C74.4466 17.3131 75.3416 15.6904 75.4272 13.5799C75.469 12.583 75.2618 11.7202 74.8172 11.0186ZM62.914 11.8154H68.001C70.5682 11.8154 70.5169 13.1019 70.4998 13.5255C70.4656 14.3398 70.1445 14.9422 69.5155 15.3697C68.8599 15.8148 67.9364 16.0402 66.7696 16.0402H61.9278L62.914 11.8154ZM70.5036 7.31273C69.8955 7.74609 69.0328 7.96569 67.9402 7.96569H63.8053L64.7516 3.96051H68.972C71.486 3.96051 71.4385 5.12261 71.4233 5.50545C71.391 6.30221 71.0908 6.89492 70.5036 7.31273Z" fill="#3486E3"></path><path d="M92.6012 4.18203L93.6216 0H79.3508L74.6211 19.9987H89.2397L90.2601 15.8167H80.5518L81.4696 11.897H89.6558L90.6116 7.82575H82.452L83.3052 4.18203H92.6012Z" fill="#3486E3"></path><path d="M94.8739 0L93.8516 4.23838H99.5257L95.8145 19.9987H100.782L104.52 4.23838H110.978L111.999 0H94.8739Z" fill="#3486E3"></path><path d="M17.6229 12.1693L18.5084 8.43623H13.448L12.5625 12.1693H8.66131H7.20763L18.4324 0.0546875H12.629L0.820905 12.797L0 16.2659H2.62994H3.41284H7.69029H11.5915L10.706 19.999H15.7663L16.6518 16.2659H20.5492L21.5222 12.1693H17.6229Z" fill="white"></path><path d="M53.078 19.999H58.2334L54.6609 0.0527344H53.5075H49.5056H48.3521L35.3184 19.999H40.4737L42.9136 16.2659H52.4092L53.078 19.999ZM45.5911 12.1693L50.3664 4.86051L51.6757 12.1693H45.5911Z" fill="white"></path>', 6)]))
}
const Ki = Q(Wi, [
        ["render", Zi]
    ]),
    Xi = {},
    Yi = {
        xmlns: "http://www.w3.org/2000/svg",
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none"
    };

function Qi(t, o) {
    return l(), b("svg", Yi, o[0] || (o[0] = [n("path", {
        d: "M17.5303 10.4785V8.58697C17.5303 4.43442 14.1526 1.05664 10 1.05664C5.84745 1.05664 2.46967 4.43442 2.46967 8.58697V10.4785C1.90601 10.6157 1.412 10.9366 1.06156 11.3779C0.711111 11.817 0.5 12.3764 0.5 12.9823V13.4299C0.5 14.8527 1.65267 16.0054 3.07556 16.0054H4.60611C4.97767 16.0054 5.27744 15.7056 5.27744 15.3341V11.0781C5.27744 10.7424 5.03256 10.4638 4.70956 10.4152V8.58697C4.70956 5.66941 7.08244 3.29653 10 3.29653C12.9176 3.29653 15.2904 5.66941 15.2904 8.58697V10.4152C14.9674 10.4638 14.7226 10.7424 14.7226 11.0781V15.3341C14.7226 15.7056 15.0223 16.0054 15.3939 16.0054H15.909V17.0504C15.909 17.5719 15.4847 17.9941 14.9653 17.9941H13.4221C13.3883 17.1454 12.6875 16.4635 11.8282 16.4635C10.95 16.4635 10.2343 17.1792 10.2343 18.0595V18.4691C10.2343 18.7309 10.4476 18.9441 10.7093 18.9441H14.9653C16.0082 18.9441 16.859 18.0954 16.859 17.0504V16.0054H16.9244C18.3473 16.0054 19.5 14.8527 19.5 13.4299V12.9823C19.5 11.7684 18.6598 10.7509 17.5303 10.4785Z",
        fill: "white"
    }, null, -1)]))
}
const Ji = Q(Xi, [
        ["render", Qi]
    ]),
    el = {},
    tl = {
        xmlns: "http://www.w3.org/2000/svg",
        width: "16",
        height: "12",
        viewBox: "0 0 16 12",
        fill: "none"
    };

function ol(t, o) {
    return l(), b("svg", tl, o[0] || (o[0] = [n("path", {
        d: "M8.00008 5.37277L15.7814 0.823642C15.642 0.574512 15.441 0.367262 15.1986 0.222693C14.9561 0.078125 14.6807 0.00132441 14.4001 0H1.60008C1.31943 0.00132441 1.04406 0.078125 0.801604 0.222693C0.559148 0.367262 0.358138 0.574512 0.21875 0.823642L8.00008 5.37277Z",
        fill: "white"
    }, null, -1), n("path", {
        d: "M8.26667 6.47498C8.18559 6.52285 8.09362 6.54805 8 6.54805C7.90638 6.54805 7.81441 6.52285 7.73333 6.47498L0 1.95312V10.3641C0 10.7981 0.168571 11.2143 0.468629 11.5212C0.768687 11.8281 1.17565 12.0005 1.6 12.0005H14.4C14.8243 12.0005 15.2313 11.8281 15.5314 11.5212C15.8314 11.2143 16 10.7981 16 10.3641V1.95312L8.26667 6.47498Z",
        fill: "white"
    }, null, -1)]))
}
const al = Q(el, [
        ["render", ol]
    ]),
    nl = {},
    sl = {
        width: "16",
        height: "16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
    };

function rl(t, o) {
    return l(), b("svg", sl, o[0] || (o[0] = [n("g", {
        "clip-path": "url(#a)"
    }, [n("path", {
        d: "m6.278 10.122-.265 3.722c.38 0 .543-.162.74-.358l1.775-1.696 3.679 2.694c.675.376 1.15.178 1.332-.621l2.415-11.315c.214-.998-.36-1.388-1.018-1.143L.743 6.839c-.969.376-.954.916-.165 1.16l3.629 1.13 8.428-5.275c.397-.262.758-.117.461.146l-6.818 6.122Z",
        fill: "#fff"
    })], -1), n("defs", null, [n("clipPath", {
        id: "a"
    }, [n("path", {
        fill: "#fff",
        d: "M0 0h16v16H0z"
    })])], -1)]))
}
const il = Q(nl, [
        ["render", rl]
    ]),
    ll = {
        class: "sports"
    },
    cl = ["src", "alt"],
    ul = {
        class: "sports__name"
    },
    _l = oe({
        __name: "SportsBlock",
        setup(t) {
            const o = [{
                    id: 1,
                    name: "football",
                    seoName: "football",
                    href: "/live/soccer",
                    icon: "/main/betby/sports/football.png",
                    type: "link"
                }, {
                    id: 2,
                    name: "basketball",
                    seoName: "basketball",
                    href: "/live/basketball",
                    icon: "/main/betby/sports/basketball.png",
                    type: "link"
                }, {
                    id: 3,
                    name: "cricket",
                    seoName: "cricket",
                    href: "/live/cricket",
                    icon: "/main/betby/sports/cricket.png",
                    order: 3,
                    type: "link"
                }, {
                    id: 4,
                    name: "virtual-sports",
                    seoName: "virtual-sports",
                    href: "/sports/e_sport",
                    icon: "/main/betby/sports/virtual-sports.png",
                    order: 4,
                    type: "link"
                }, {
                    id: 5,
                    name: "tennis",
                    seoName: "tennis",
                    href: "/live/tennis",
                    icon: "/main/betby/sports/tennis.png",
                    order: 5,
                    type: "link"
                }, {
                    id: 6,
                    name: "handball",
                    seoName: "handball",
                    href: "/sports/handball",
                    icon: "/main/betby/sports/handball.png",
                    order: 6,
                    type: "link"
                }, {
                    id: 7,
                    name: "table-tennis",
                    seoName: "table-tennis",
                    href: "/live/table-tennis",
                    icon: "/main/betby/sports/table_tennis.png",
                    order: 7,
                    type: "link"
                }, {
                    id: 8,
                    name: "ice-hockey",
                    seoName: "ice-hockey",
                    href: "/live/ice-hockey",
                    icon: "/main/betby/sports/hockey.png",
                    order: 8,
                    type: "link"
                }, {
                    id: 9,
                    name: "ecricket",
                    seoName: "ecricket",
                    href: "/live/ecricket",
                    icon: "/main/betby/sports/Ecricket.png",
                    order: 9,
                    type: "link"
                }],
                {
                    imageUrl: a
                } = pt(),
                {
                    t: s
                } = re(),
                i = g(() => o);
            return (c, u) => {
                const f = po;
                return l(), b("div", ll, [(l(!0), b(ve, null, Be(e(i), r => (l(), b("div", {
                    key: r.id + "sport",
                    class: "sports__item"
                }, [h(f, {
                    class: "sports__link",
                    "route-path": r.href
                }, {
                    default: N(() => [n("img", {
                        class: "sports__img",
                        src: `${e(a)}${r.icon}`,
                        alt: `${r.name}`
                    }, null, 8, cl), n("span", ul, x(e(s)(`newMain.sportSections.${r.name}`)), 1)]),
                    _: 2
                }, 1032, ["route-path"])]))), 128))])
            }
        }
    }),
    dl = Q(_l, [
        ["__scopeId", "data-v-ad40fa64"]
    ]),
    O = {
        SPRIBE: "spribe",
        EVOLUTION: "evolution",
        EXCLUSIVE: "4rabet_exclusive",
        SMARTSOFT: "smartsoft",
        AVIATRIX: "aviatrix",
        THREEOAKS: "threeoaks",
        EZUGI: "ezugi",
        BETGAMES: "betgames",
        PGSOFT: "pgsoft",
        BETSOFT: "betsoft",
        PLAYSON: "playson",
        PPL: "pragmaticplaylive",
        WAZDAN: "wazdan",
        TURBOGAMES: "turbogames",
        PLAYNGO: "playngo",
        SPINOMENAL: "spinomenal",
        SWINTTPREMIUM: "swinttpremium"
    },
    To = {
        CD: [O.SPRIBE, O.SMARTSOFT, O.EVOLUTION, O.THREEOAKS, O.BETSOFT, O.PLAYSON, O.PLAYNGO, O.BETSOFT, O.WAZDAN],
        RW: [O.SPRIBE, O.WAZDAN, O.PPL, O.SMARTSOFT, O.AVIATRIX, O.PLAYSON, O.PPL, O.SPINOMENAL, O.SWINTTPREMIUM],
        ZM: [O.SPRIBE, O.SMARTSOFT, O.EVOLUTION, O.THREEOAKS, O.BETSOFT, O.PLAYSON, O.PPL, O.WAZDAN, O.AVIATRIX],
        CM: [O.SPRIBE, O.SMARTSOFT, O.EVOLUTION, O.THREEOAKS, O.BETSOFT, O.PLAYSON, O.PPL, O.WAZDAN, O.AVIATRIX],
        UG: [O.SPRIBE, O.SMARTSOFT, O.EVOLUTION, O.THREEOAKS, O.BETSOFT, O.PLAYSON, O.PPL, O.WAZDAN, O.AVIATRIX],
        PH: [O.SPRIBE, O.SMARTSOFT, O.AVIATRIX, O.EVOLUTION, O.THREEOAKS, O.TURBOGAMES, O.BETSOFT, O.PLAYSON, O.PLAYNGO],
        DEFAULT: [O.SPRIBE, O.EVOLUTION, O.EXCLUSIVE, O.SMARTSOFT, O.AVIATRIX, O.THREEOAKS, O.EZUGI, O.BETGAMES, O.PGSOFT]
    },
    pl = {
        key: 0,
        class: "providers"
    },
    ml = ["src", "alt"],
    fl = oe({
        __name: "ProvidersList",
        setup(t) {
            const {
                imageUrl: o
            } = pt(), a = g(() => "IN"), s = g(() => a.value ? To[a.value] ? ? To.DEFAULT : []);
            return (i, c) => e(s) ? (l(), b("div", pl, [(l(!0), b(ve, null, Be(e(s), u => (l(), b("div", {
                key: u,
                class: "providers__item"
            }, [n("img", {
                src: `${e(o)}/main/providers/banners/${u}.svg`,
                alt: u,
                class: "providers__img"
            }, null, 8, ml)]))), 128))])) : $("", !0)
        }
    }),
    hl = Q(fl, [
        ["__scopeId", "data-v-efa16282"]
    ]),
    vl = {},
    gl = {
        class: "copyright__icon",
        xmlns: "http://www.w3.org/2000/svg",
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none"
    };

function bl(t, o) {
    return l(), b("svg", gl, o[0] || (o[0] = [Ft('<g clip-path="url(#clip0_23880_35832)"><path d="M7.59222 16.0879V9.5721H6.08594V7.90234H9.67072V16.0879H7.59222Z" fill="white" fill-opacity="0.5"></path><path d="M17.4814 10.0155C17.4814 10.7278 17.0961 11.3583 16.4539 11.7087C17.3529 12.0823 17.9134 12.8647 17.9134 13.7754C17.9134 15.2467 16.6056 16.1809 14.5622 16.1809C12.5187 16.1809 11.2109 15.2584 11.2109 13.8106C11.2109 12.8764 11.8181 12.0823 12.7639 11.7087C12.075 11.3233 11.6313 10.6695 11.6313 9.9572C11.6313 8.64928 12.7757 7.82031 14.5505 7.82031C16.3487 7.82031 17.4814 8.6727 17.4814 10.0155ZM13.1726 13.6004C13.1726 14.2894 13.6631 14.6747 14.5622 14.6747C15.4613 14.6747 15.9634 14.3011 15.9634 13.6004C15.9634 12.9232 15.4613 12.5377 14.5622 12.5377C13.663 12.5377 13.1726 12.9231 13.1726 13.6004ZM13.3829 10.1323C13.3829 10.7163 13.8032 11.0431 14.5622 11.0431C15.3212 11.0431 15.7415 10.7162 15.7415 10.1323C15.7415 9.52524 15.3212 9.18655 14.5622 9.18655C13.8031 9.18655 13.3829 9.52524 13.3829 10.1323Z" fill="white" fill-opacity="0.5"></path><path d="M21.3728 8.82546C21.7183 9.84534 21.8936 10.9121 21.8936 12C21.8936 17.4553 17.4553 21.8936 12 21.8936C6.54459 21.8936 2.10624 17.4553 2.10624 12C2.10624 6.54459 6.54451 2.10646 11.9999 2.10646C13.088 2.10646 14.1547 2.28161 15.1745 2.62731V0.425612C14.1444 0.143257 13.0806 0 12 0C5.3832 0 0 5.3832 0 12C0 18.6169 5.3832 24.0001 12 24.0001C18.6167 24.0001 23.9999 18.6169 23.9999 12C23.9999 10.9194 23.8567 9.85556 23.5743 8.82546H21.3728Z" fill="white" fill-opacity="0.5"></path><path d="M20.7738 3.21891V0.917969H19.1192V3.21891H16.832V4.87334H19.1192V7.17422H20.7738V4.87334H23.0746V3.21891H20.7738Z" fill="white" fill-opacity="0.5"></path></g><defs><clipPath id="clip0_23880_35832"><rect width="24" height="24" fill="white"></rect></clipPath></defs>', 2)]))
}
const sa = Q(vl, [
        ["render", bl]
    ]),
    yl = {
        class: "copyright"
    },
    wl = {
        key: 1,
        class: "copyright__logo",
        href: "https://cert.gcb.cw/certificate?id=ZXlKcGRpSTZJakZEUzBWcWIweG9kblF3YUhRdlZWVlhNREZ0UzFFOVBTSXNJblpoYkhWbElqb2lja042YTNod2NXVmpkak5PT0ZkbFFqUlhLMDlGUVQwOUlpd2liV0ZqSWpvaU1tWXlZVFppTVRFNE5qazFNVE16WkRGbE5XUTNNalk0WTJSalpqZzJOak5tTXpnMVpHVTBZVGszTkdKak5UazBaVFEzWlRRMk5ERmpNemcxWWpFMVpTSXNJblJoWnlJNklpSjk==",
        target: "_blank"
    },
    kl = ["src"],
    Il = {
        class: "copyright__text"
    },
    Al = oe({
        __name: "CopyrightComponent",
        setup(t) {
            const {
                imageUrl: o
            } = pt(), {
                isBaseDomain: a
            } = Oe(), s = Ve(), i = new Date().getFullYear(), c = [Fa], u = g(() => c.includes(s.host) || a.value);
            return (f, r) => {
                const d = sa;
                return l(), b("div", yl, [e(a) ? $("", !0) : (l(), F(d, {
                    key: 0
                })), e(u) ? (l(), b("a", wl, [n("img", {
                    class: "copyright__gaming",
                    src: `${e(o)}/svg/gcd.svg`,
                    width: "54",
                    height: "24",
                    alt: "gaming"
                }, null, 8, kl)])) : $("", !0), n("div", Il, [ae(" Copyright © " + x(e(i)) + " 4raBet.", 1), r[0] || (r[0] = n("br", null, null, -1)), r[1] || (r[1] = ae(" All rights are reserved and protected by law "))])])
            }
        }
    }),
    Tl = Q(Al, [
        ["__scopeId", "data-v-850deb32"]
    ]),
    Cl = {},
    El = {
        class: "icon",
        xmlns: "http://www.w3.org/2000/svg",
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none"
    };

function Ll(t, o) {
    return l(), b("svg", El, o[0] || (o[0] = [Ft('<g clip-path="url(#clip0_21808_61310)" data-v-3ae23612><rect width="20" height="20" rx="6" fill="white" data-v-3ae23612></rect><path d="M10.35 23.0243C17.7921 23.0243 23.8251 16.9913 23.8251 9.54927C23.8251 2.1072 17.7921 -3.92578 10.35 -3.92578C2.90798 -3.92578 -3.125 2.1072 -3.125 9.54927C-3.125 16.9913 2.90798 23.0243 10.35 23.0243Z" fill="url(#paint0_linear_21808_61310)" data-v-3ae23612></path><path fill-rule="evenodd" clip-rule="evenodd" d="M4.60904 9.30494C7.96335 7.8937 10.2001 6.96332 11.3192 6.51384C14.5147 5.23042 15.1787 5.00746 15.6114 5.00008C15.7066 4.99847 15.9194 5.02126 16.0573 5.12929C16.2618 5.28953 16.263 5.63736 16.2403 5.86757C16.0671 7.62451 15.3178 11.8881 14.9366 13.8559C14.7753 14.6885 14.4577 14.9677 14.1503 14.995C13.4821 15.0544 12.9747 14.5686 12.3275 14.159C11.3148 13.5179 10.7427 13.1189 9.75968 12.4934C8.62366 11.7704 9.36011 11.3731 10.0075 10.7238C10.177 10.5539 13.121 7.96796 13.178 7.73337C13.1851 7.70403 13.1918 7.59465 13.1245 7.53693C13.0572 7.4792 12.9579 7.49891 12.8863 7.51462C12.7847 7.53688 11.1669 8.56948 8.03284 10.6124C7.57362 10.9169 7.15768 11.0652 6.78503 11.0575C6.37418 11.0489 5.58393 10.8332 4.99643 10.6487C4.27585 10.4226 3.70314 10.3029 3.75303 9.91883C3.77901 9.7187 4.06433 9.5141 4.60904 9.30494Z" fill="white" data-v-3ae23612></path></g><defs data-v-3ae23612><linearGradient id="paint0_linear_21808_61310" x1="10.35" y1="-3.92578" x2="10.35" y2="22.8138" gradientUnits="userSpaceOnUse" data-v-3ae23612><stop stop-color="#2AABEE" data-v-3ae23612></stop><stop offset="1" stop-color="#229ED9" data-v-3ae23612></stop></linearGradient><clipPath id="clip0_21808_61310" data-v-3ae23612><rect width="20" height="20" rx="6" fill="white" data-v-3ae23612></rect></clipPath></defs>', 2)]))
}
const Sl = Q(Cl, [
        ["render", Ll],
        ["__scopeId", "data-v-3ae23612"]
    ]),
    Dl = {},
    Bl = {
        class: "icon",
        xmlns: "http://www.w3.org/2000/svg",
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none"
    };

function $l(t, o) {
    return l(), b("svg", Bl, o[0] || (o[0] = [Ft('<g clip-path="url(#clip0_21808_61314)" data-v-e9a1a9b2><rect width="20" height="20" rx="6" fill="white" data-v-e9a1a9b2></rect><path d="M9.6875 23.125C17.1088 23.125 23.125 17.1088 23.125 9.6875C23.125 2.26617 17.1088 -3.75 9.6875 -3.75C2.26617 -3.75 -3.75 2.26617 -3.75 9.6875C-3.75 17.1088 2.26617 23.125 9.6875 23.125Z" fill="url(#paint0_linear_21808_61314)" data-v-e9a1a9b2></path><path d="M12.1958 5H8.21667C6.44167 5 5 6.44167 5 8.21667V12.1958C5 13.9708 6.44167 15.4125 8.21667 15.4125H12.1958C13.9708 15.4125 15.4125 13.9708 15.4125 12.1958V8.21667C15.4125 6.44167 13.9708 5 12.1958 5ZM14.25 12.2C14.25 13.3333 13.3292 14.2583 12.1917 14.2583H8.2125C7.07917 14.2583 6.15417 13.3375 6.15417 12.2V8.22083C6.15417 7.0875 7.075 6.1625 8.2125 6.1625H12.1917C13.325 6.1625 14.25 7.08333 14.25 8.22083V12.2Z" fill="white" data-v-e9a1a9b2></path><path d="M10.2035 7.54492C8.73685 7.54492 7.54102 8.74075 7.54102 10.2074C7.54102 11.6741 8.73685 12.8699 10.2035 12.8699C11.6702 12.8699 12.866 11.6741 12.866 10.2074C12.866 8.74075 11.6702 7.54492 10.2035 7.54492ZM10.2035 11.8241C9.31185 11.8241 8.58685 11.0991 8.58685 10.2074C8.58685 9.31575 9.31185 8.59075 10.2035 8.59075C11.0952 8.59075 11.8202 9.31575 11.8202 10.2074C11.8202 11.0991 11.0952 11.8241 10.2035 11.8241Z" fill="white" data-v-e9a1a9b2></path><path d="M13.0696 7.83778C13.3149 7.79802 13.4815 7.56693 13.4417 7.32163C13.402 7.07634 13.1709 6.90972 12.9256 6.94948C12.6803 6.98925 12.5137 7.22034 12.5534 7.46563C12.5932 7.71093 12.8243 7.87755 13.0696 7.83778Z" fill="white" data-v-e9a1a9b2></path></g><defs data-v-e9a1a9b2><linearGradient id="paint0_linear_21808_61314" x1="-0.54417" y1="19.9192" x2="18.552" y2="0.82299" gradientUnits="userSpaceOnUse" data-v-e9a1a9b2><stop stop-color="#FEE411" data-v-e9a1a9b2></stop><stop offset="0.0518459" stop-color="#FEDB16" data-v-e9a1a9b2></stop><stop offset="0.1381" stop-color="#FEC125" data-v-e9a1a9b2></stop><stop offset="0.2481" stop-color="#FE983D" data-v-e9a1a9b2></stop><stop offset="0.3762" stop-color="#FE5F5E" data-v-e9a1a9b2></stop><stop offset="0.5" stop-color="#FE2181" data-v-e9a1a9b2></stop><stop offset="1" stop-color="#9000DC" data-v-e9a1a9b2></stop></linearGradient><clipPath id="clip0_21808_61314" data-v-e9a1a9b2><rect width="20" height="20" rx="6" fill="white" data-v-e9a1a9b2></rect></clipPath></defs>', 2)]))
}
const Pl = Q(Dl, [
        ["render", $l],
        ["__scopeId", "data-v-e9a1a9b2"]
    ]),
    xl = {},
    Ol = {
        class: "legal-section"
    };

function Nl(t, o) {
    const a = sa;
    return l(), b("div", Ol, [o[0] || (o[0] = n("div", {
        class: "legal-section-line"
    }, null, -1)), h(a), o[1] || (o[1] = n("div", {
        class: "legal-section-text"
    }, [n("p", null, [n("a", {
        href: "/"
    }, "4rabet.com"), ae(" is owned and operated by New Entertainment Development N.V. (reg.number 162581) with its address at Abraham de Veerstraat 1, Curaçao. New Entertainment Development N.V. holds a valid Certificate of Operation. New Entertainment Development N.V. has an application (OGL/2024/748/0203) for a gaming license in progress with the Curaçao Gaming Authority. Until that process is concluded, based on a transitional arrangement outlined in the National Ordinance on Games of Chance (Landsverordening op de Kansspelen, P.B. 2024, no. 157), the company is permitted to continue its operations under this Certificate of Operation. The Terms and Conditions in a part, which relates to your participation in the Games, shall be governed by the Laws of Curaçao, and in a part which relates to payment collection and transactions shall be governed by the Laws of Curaçao. ")]), n("p", null, " You acknowledge that, unless stated otherwise, the Games are organized in Curaçao and your participation in these Games takes place within the aforementioned territory. Any contractual relationships between you and New Entertainment Development N.V. shall be deemed to have been entered into and performed by the parties in Curaçao, at the registered address of Abraham de Veerstraat 1, Curaçao. The parties agree that any dispute, controversy or claim arising out of or in connection with these Terms and Conditions, or the breach, termination or invalidity thereof, shall be submitted to the exclusive jurisdiction of courts of Curaçao, except for claims arising out of payment transactions which shall be submitted to the courts of Curaçao. * ")], -1)), o[2] || (o[2] = n("div", null, [n("p", null, [ae("If you have a gambling addiction, visit "), n("a", {
        href: "https://www.responsiblegambling.com",
        target: "_blank",
        rel: "noopener noreferrer"
    }, "Responsiblegambling.com")])], -1)), o[3] || (o[3] = n("div", {
        class: "legal-section-line"
    }, null, -1))])
}
const Rl = Q(xl, [
        ["render", Nl],
        ["__scopeId", "data-v-fb7f6e21"]
    ]),
    Ml = oe({
        __name: "NavBlock",
        props: {
            links: {
                default: () => []
            }
        },
        setup(t) {
            const o = t,
                {
                    t: a
                } = re(),
                {
                    customPathWithLocale: s
                } = Oe(),
                {
                    trackButtonClick: i
                } = ye(),
                c = () => {
                    i({
                        category: "footer",
                        action: "show_more"
                    })
                },
                u = d => {
                    const _ = d.split("/").pop();
                    i({
                        category: "footer",
                        action: "list_menu",
                        label: _
                    })
                },
                f = ne(),
                r = ee(!1);
            return le(() => f.fullPath, () => {
                r.value = !1
            }), (d, _) => {
                const p = Xe;
                return l(), F(qo, {
                    modelValue: e(r),
                    "onUpdate:modelValue": _[0] || (_[0] = m => Tt(r) ? r.value = m : null),
                    class: "rules-info"
                }, {
                    default: N(() => [h(Zo, null, {
                        default: N(() => [h(Ln, {
                            class: "coupon__header",
                            onClick: c
                        }, {
                            default: N(() => [Ct(d.$slots, "header", {}, void 0, !0)]),
                            _: 3
                        }), h(Sn, null, {
                            default: N(() => [(l(!0), b(ve, null, Be(o.links, m => (l(), F(p, {
                                key: m == null ? void 0 : m.text,
                                to: e(s)(`/${m==null?void 0:m.href}`),
                                "no-prefetch": "",
                                onClick: T => u(m == null ? void 0 : m.href)
                            }, {
                                default: N(() => [ae(x(e(a)(m == null ? void 0 : m.text)), 1)]),
                                _: 2
                            }, 1032, ["to", "onClick"]))), 128))]),
                            _: 1
                        })]),
                        _: 3
                    })]),
                    _: 3
                }, 8, ["modelValue"])
            }
        }
    }),
    Vl = Q(Ml, [
        ["__scopeId", "data-v-2bdd94a7"]
    ]),
    Ot = {
        TERMS: [{
            href: "terms-and-conditions",
            text: "footer.links.generalTermsAndConditions"
        }, {
            href: "bonus-terms",
            text: "footer.links.bonusTerms"
        }, {
            href: "rules-page",
            text: "footer.links.rulesForSpecific"
        }, {
            href: "privacy-policy",
            text: "footer.links.privacyPolicy"
        }, {
            href: "aml-kyc",
            text: "footer.links.amlKycPolicy"
        }],
        BETTING: [{
            href: "sports/football",
            text: "footer.links.footballBetting"
        }, {
            href: "sports/basketball",
            text: "footer.links.basketballBetting"
        }, {
            href: "sports/live",
            text: "footer.links.liveBetting"
        }, {
            href: "sports/tennis",
            text: "footer.links.tennisBetting"
        }, {
            href: "sports/table-tennis",
            text: "footer.links.tableTennisBetting"
        }, {
            href: "sports/baseball",
            text: "footer.links.baseballBetting"
        }, {
            href: "sports/cricket",
            text: "footer.links.cricketBetting"
        }, {
            href: "sports/horse-racing",
            text: "footer.links.horseRacingBetting"
        }, {
            href: "live/cricket",
            text: "footer.links.liveCricketBetting"
        }],
        CASINO: [{
            href: "casino",
            text: "footer.links.onlineCasino"
        }, {
            href: "casino/slots",
            text: "footer.links.onlineSlots"
        }, {
            href: "casino/new-games",
            text: "footer.links.newGames"
        }, {
            href: "casino/blackjack",
            text: "footer.links.onlineBlackjack"
        }, {
            href: "casino/roulette",
            text: "footer.links.onlineRoulette"
        }, {
            href: "live-dealers",
            text: "footer.links.liveCasino"
        }, {
            href: "casino/baccarat",
            text: "footer.links.onlineBaccarat"
        }],
        IPL: [{
            href: "ipl-app",
            text: "footer.links.iplApp"
        }, {
            href: "sports/cricket-ipl",
            text: "footer.links.iplCricketBetting"
        }, {
            href: "live/cricket-ipl",
            text: "footer.links.liveIplCricketBetting"
        }, {
            href: "review",
            text: "footer.links.4rabetReview"
        }, {
            href: "sports/ipl",
            text: "footer.links.iplBetting"
        }, {
            href: "live/ipl",
            text: "footer.links.liveIplBetting"
        }]
    },
    wt = {
        CASINO: [{
            href: "casino",
            text: "footerNew.casino",
            dataAttrName: "casinoBlockFooter"
        }, {
            href: "tv-games",
            text: "menu.tvGames",
            dataAttrName: "tvGamesBlockFooter"
        }, {
            href: "live-dealers",
            text: "menu.liveDealers",
            dataAttrName: "liveDealersBlockFooter"
        }, {
            href: "plinko",
            text: "menu.plinko",
            dataAttrName: "plinkoBlockFooter"
        }],
        BETTING: [{
            href: "live",
            text: "menu.live",
            dataAttrName: "liveBlockFooter"
        }, {
            href: "sports",
            text: "menu.footerLine",
            dataAttrName: "sportBlockFooter"
        }, {
            href: "sports/cricket",
            text: "menu.cricket",
            dataAttrName: "cricketBlockFooter"
        }],
        MAIN: [{
            href: "rewards",
            text: "menu.rewards",
            action: "openMissions",
            span: "menu.new",
            dataAttrName: "rewardsFooter"
        }, {
            href: "",
            text: "menu.mainTitle",
            dataAttrName: "mainBlockFooter"
        }, {
            href: "bonuses",
            text: "menu.bonuses",
            dataAttrName: "bonusesBlockFooter"
        }, {
            href: Vo,
            text: "footer.links.affiliateProgram",
            external: !0,
            dataAttrName: "affiliateProgramBlockFooter"
        }, {
            href: "gaming-policy",
            text: "footer.links.responsibleGaming",
            dataAttrName: "responsibleGamingBlockFooter"
        }],
        PERSONAL: [{
            href: "deposit",
            text: "mobileMenu.deposit",
            action: "openDeposit",
            dataAttrName: "depositFooter"
        }, {
            href: "deposit",
            text: "mobileMenu.depositInfo",
            dataAttrName: "depositInfoFooter"
        }, {
            href: "withdrawal",
            text: "buttons.withdrawal",
            action: "openWithdrawal",
            dataAttrName: "withdrawalFooter"
        }, {
            href: "profile",
            text: "mobileMenu.personalData",
            handler: "checkAuth",
            dataAttrName: "personalDataBlockFooter"
        }, {
            href: "profile/history",
            text: "mobileMenu.history",
            handler: "checkAuth",
            dataAttrName: "historyLockFooter"
        }]
    },
    Co = {
        CASINO: [{
            href: "casino",
            text: "footerNew.casino",
            dataAttrName: "casinoBlockFooter"
        }, {
            href: "live-dealers",
            text: "menu.liveDealers",
            dataAttrName: "liveDealersBlockFooter"
        }]
    },
    Eo = {
        CASINO: [{
            href: "casino",
            text: "footerNew.casino",
            dataAttrName: "casinoBlockFooter"
        }, {
            href: "live-dealers",
            text: "menu.liveDealers",
            dataAttrName: "liveDealersBlockFooter"
        }, {
            href: "casino/slot/aviator",
            text: "menu.aviator",
            dataAttrName: "aviatorBlockFooter"
        }, {
            href: "casino/slot/crazy-time-10418",
            text: "menu.crazyTime",
            dataAttrName: "crazyTimeBlockFooter"
        }],
        MAIN: [{
            href: "",
            text: "menu.mainTitle",
            dataAttrName: "mainBlockFooter"
        }, {
            href: "app",
            text: "menu.downloadApp",
            dataAttrName: "appBlockFooter"
        }, {
            href: "bonuses",
            text: "menu.bonuses",
            dataAttrName: "bonusesBlockFooter"
        }, {
            href: Vo,
            text: "footer.links.affiliateProgram",
            external: !0,
            dataAttrName: "affiliateProgramBlockFooter"
        }]
    },
    to = {
        default: {
            "/": () => v(() =>
                import ("./DChOOI6D.js"), __vite__mapDeps([12, 1, 2, 3, 4]),
                import.meta.url)
        },
        en: {
            "/": () => v(() =>
                import ("./DChOOI6D.js"), __vite__mapDeps([12, 1, 2, 3, 4]),
                import.meta.url),
            bonuses: () => v(() =>
                import ("./DkmTjkEY.js"), __vite__mapDeps([13, 1, 2, 3, 4, 5]),
                import.meta.url),
            casino: () => v(() =>
                import ("./DaP7mDoS.js"), __vite__mapDeps([14, 1, 2, 3, 4, 15]),
                import.meta.url),
            "casino/slot/baccarat": () => v(() =>
                import ("./C-tSONMA.js"), __vite__mapDeps([16, 1, 2, 3, 4]),
                import.meta.url),
            "casino/slot/bingo": () => v(() =>
                import ("./DhKb1fFg.js"), __vite__mapDeps([17, 1, 2, 3, 4]),
                import.meta.url),
            "casino/slot/crazy-time-10418": () => v(() =>
                import ("./dQPzGnRW.js"), __vite__mapDeps([18, 1, 2, 3, 4]),
                import.meta.url),
            "casino/lottery": () => v(() =>
                import ("./BLXMHG5U.js"), __vite__mapDeps([19, 1, 2, 3, 4]),
                import.meta.url),
            "casino/slot/lucky-captain-0": () => v(() =>
                import ("./DYuKJgys.js"), __vite__mapDeps([20, 1, 2, 3, 4]),
                import.meta.url),
            "casino/roulette": () => v(() =>
                import ("./BqG8mLgx.js"), __vite__mapDeps([21, 1, 2, 3, 4]),
                import.meta.url),
            "casino/slots": () => v(() =>
                import ("./Fk0ogu-X.js"), __vite__mapDeps([22, 10, 1, 2, 3, 4, 5, 23]),
                import.meta.url),
            "casino/slot/aviator": () => v(() =>
                import ("./CZlW6g-M.js"), __vite__mapDeps([24, 10, 1, 2, 3, 4, 5, 25, 26, 27]),
                import.meta.url),
            "casino/slot/chicken-road-0": () => v(() =>
                import ("./C1reGLDx.js"), __vite__mapDeps([28, 1, 2, 3, 4]),
                import.meta.url),
            live: () => v(() =>
                import ("./IUR8xgfH.js"), __vite__mapDeps([29, 1, 2, 3, 4]),
                import.meta.url),
            "live/cricket": () => v(() =>
                import ("./BOjjwF1y.js"), __vite__mapDeps([30, 1, 2, 3, 4]),
                import.meta.url),
            "live-dealers": () => v(() =>
                import ("./ieK6h68u.js"), __vite__mapDeps([31, 1, 2, 3, 4]),
                import.meta.url),
            "live-dealers/roulette": () => v(() =>
                import ("./0-IY7DnM.js"), __vite__mapDeps([32, 1, 2, 3, 4]),
                import.meta.url),
            sports: () => v(() =>
                import ("./DD5lFqUU.js"), __vite__mapDeps([33, 1, 2, 3, 4]),
                import.meta.url),
            "sports/aussie-rules": () => v(() =>
                import ("./DJLn8Y5-.js"), __vite__mapDeps([34, 1, 2, 3, 4]),
                import.meta.url),
            "sports/baseball": () => v(() =>
                import ("./CvllXjLd.js"), __vite__mapDeps([35, 1, 2, 3, 4]),
                import.meta.url),
            "sports/basketball": () => v(() =>
                import ("./CIiG4Tg6.js"), __vite__mapDeps([36, 1, 2, 3, 4]),
                import.meta.url),
            "sports/boxing": () => v(() =>
                import ("./C5OLVpw7.js"), __vite__mapDeps([37, 1, 2, 3, 4]),
                import.meta.url),
            "sports/counter-strike": () => v(() =>
                import ("./uakuixBb.js"), __vite__mapDeps([38, 1, 2, 3, 4]),
                import.meta.url),
            "sports/cricket-ipl": () => v(() =>
                import ("./BWFykjbH.js"), __vite__mapDeps([39, 1, 2, 3, 4]),
                import.meta.url),
            "sports/cricket": () => v(() =>
                import ("./Dxk4YADR.js"), __vite__mapDeps([40, 1, 2, 3, 4]),
                import.meta.url),
            "sports/dota-2": () => v(() =>
                import ("./BZXhBWds.js"), __vite__mapDeps([41, 1, 2, 3, 4]),
                import.meta.url),
            "sports/ecricket": () => v(() =>
                import ("./DY5EN8CR.js"), __vite__mapDeps([42, 1, 2, 3, 4]),
                import.meta.url),
            "sports/fifa": () => v(() =>
                import ("./Dn509E-E.js"), __vite__mapDeps([43, 1, 2, 3, 4]),
                import.meta.url),
            "sports/football": () => v(() =>
                import ("./D8KERa9S.js"), __vite__mapDeps([44, 1, 2, 3, 4]),
                import.meta.url),
            "sports/horse-racing": () => v(() =>
                import ("./BuRqQhew.js"), __vite__mapDeps([45, 1, 2, 3, 4]),
                import.meta.url),
            "sports/ice-hockey": () => v(() =>
                import ("./CHm-x_4E.js"), __vite__mapDeps([46, 1, 2, 3, 4]),
                import.meta.url),
            "sports/kabaddi-138": () => v(() =>
                import ("./CRmddbRy.js"), __vite__mapDeps([47, 1, 2, 3, 4]),
                import.meta.url),
            "sports/mma": () => v(() =>
                import ("./BbOXr_MO.js"), __vite__mapDeps([48, 1, 2, 3, 4]),
                import.meta.url),
            "sports/nba-2k-302": () => v(() =>
                import ("./TXVuk0CY.js"), __vite__mapDeps([49, 1, 2, 3, 4]),
                import.meta.url),
            "sports/soccer": () => v(() =>
                import ("./BHXT6HHF.js"), __vite__mapDeps([50, 1, 2, 3, 4]),
                import.meta.url),
            "sports/table-tennis": () => v(() =>
                import ("./IcYOZnOj.js"), __vite__mapDeps([51, 1, 2, 3, 4]),
                import.meta.url),
            "sports/tennis": () => v(() =>
                import ("./Cv0STUEp.js"), __vite__mapDeps([52, 1, 2, 3, 4]),
                import.meta.url),
            "sports/volleyball": () => v(() =>
                import ("./M0EHyG2j.js"), __vite__mapDeps([53, 1, 2, 3, 4]),
                import.meta.url)
        },
        fr: {
            "/": () => v(() =>
                import ("./Dh46VNyu.js"), __vite__mapDeps([54, 1, 2, 3, 4]),
                import.meta.url)
        },
        hi: {
            "/": () => v(() =>
                import ("./CjdIMqbH.js"), __vite__mapDeps([55, 1, 2, 3, 4]),
                import.meta.url)
        },
        pt: {
            bonuses: () => v(() =>
                import ("./BFAkLyuy.js"), __vite__mapDeps([56, 1, 2, 3, 4]),
                import.meta.url),
            casino: () => v(() =>
                import ("./D5jHg436.js"), __vite__mapDeps([57, 1, 2, 3, 4]),
                import.meta.url),
            "casino/keno": () => v(() =>
                import ("./BX_8DwCz.js"), __vite__mapDeps([58, 1, 2, 3, 4]),
                import.meta.url),
            "casino/blackjack": () => v(() =>
                import ("./CaQKB-7D.js"), __vite__mapDeps([59, 1, 2, 3, 4]),
                import.meta.url),
            live: () => v(() =>
                import ("./LmnuInVz.js"), __vite__mapDeps([60, 1, 2, 3, 4]),
                import.meta.url),
            "sports/basketball": () => v(() =>
                import ("./DOeNSoY6.js"), __vite__mapDeps([61, 1, 2, 3, 4]),
                import.meta.url),
            "sports/boxing": () => v(() =>
                import ("./2qvur7Ly.js"), __vite__mapDeps([62, 1, 2, 3, 4]),
                import.meta.url),
            "sports/counter-strike": () => v(() =>
                import ("./CBowTdAX.js"), __vite__mapDeps([63, 1, 2, 3, 4]),
                import.meta.url),
            "sports/football": () => v(() =>
                import ("./DV9JB3EK.js"), __vite__mapDeps([64, 1, 2, 3, 4]),
                import.meta.url),
            "sports/horse-racing": () => v(() =>
                import ("./bSJO1Ali.js"), __vite__mapDeps([65, 1, 2, 3, 4]),
                import.meta.url),
            "sports/mma": () => v(() =>
                import ("./BR1TvFAJ.js"), __vite__mapDeps([66, 1, 2, 3, 4]),
                import.meta.url),
            "sports/tennis": () => v(() =>
                import ("./CKZ15vyB.js"), __vite__mapDeps([67, 1, 2, 3, 4]),
                import.meta.url),
            "virtual-sports/bingo": () => v(() =>
                import ("./0auYqxRJ.js"), __vite__mapDeps([68, 1, 2, 3, 4]),
                import.meta.url)
        },
        [lo]: {
            "/": () => v(() =>
                import ("./HB4841vv.js"), __vite__mapDeps([69, 10, 1, 2, 3, 4, 5, 70, 26, 71]),
                import.meta.url),
            live: () => v(() =>
                import ("./CqUEGiHy.js"), __vite__mapDeps([72, 10, 1, 2, 3, 4, 5, 70, 26]),
                import.meta.url),
            casino: () => v(() =>
                import ("./Cl_kjHLb.js"), __vite__mapDeps([73, 10, 1, 2, 3, 4, 5, 70, 26, 74]),
                import.meta.url),
            bonuses: () => v(() =>
                import ("./C-eFFz-n.js"), __vite__mapDeps([75, 10, 1, 2, 3, 4, 5, 70, 26]),
                import.meta.url),
            "casino/slot/crazy-time-10418": () => v(() =>
                import ("./D2qWZ5eC.js"), __vite__mapDeps([76, 10, 1, 2, 3, 4, 5, 70, 26]),
                import.meta.url),
            "live/cricket": () => v(() =>
                import ("./DqCtKBJg.js"), __vite__mapDeps([77, 10, 1, 2, 3, 4, 5, 70, 26]),
                import.meta.url)
        },
        [io]: {
            "/": () => v(() =>
                import ("./sR-1d6Uq.js"), __vite__mapDeps([78, 1, 2, 3, 4]),
                import.meta.url),
            bonuses: () => v(() =>
                import ("./DmeRSbOh.js"), __vite__mapDeps([79, 1, 2, 3, 4]),
                import.meta.url),
            casino: () => v(() =>
                import ("./CGym_LSr.js"), __vite__mapDeps([80, 1, 2, 3, 4]),
                import.meta.url),
            "casino/slot/aviator": () => v(() =>
                import ("./CZcLDuvs.js"), __vite__mapDeps([81, 1, 2, 3, 4]),
                import.meta.url),
            "casino/slot/crazy-time-10418": () => v(() =>
                import ("./CZdHkQAc.js"), __vite__mapDeps([82, 1, 2, 3, 4]),
                import.meta.url),
            deposit: () => v(() =>
                import ("./TXlEkOPv.js"), __vite__mapDeps([83, 1, 2, 3, 4]),
                import.meta.url)
        }
    },
    Hl = {
        key: 0
    },
    Ul = {
        class: "coupon__header"
    },
    Fl = oe({
        __name: "SeoTextContent",
        setup(t) {
            const o = Ve(),
                {
                    host: a
                } = o,
                s = ee(!1),
                i = ee(null),
                c = ee(null),
                u = ne(),
                {
                    locale: f,
                    t: r
                } = re(),
                {
                    trackButtonClick: d
                } = ye(),
                _ = Ko(u, f),
                p = g(() => f.value),
                m = g(() => u.path === "/casino" && u.matched.length === 1),
                T = g(() => {
                    var I, B, z;
                    const k = (I = to[a]) == null ? void 0 : I[_.value || "/"];
                    if (k) return Z(k);
                    if (Do.includes(a)) return null;
                    const y = ((B = to[p.value]) == null ? void 0 : B[_.value || "/"]) || ((z = to.default) == null ? void 0 : z[_.value || "/"]);
                    return y ? Z(y) : null
                });
            le(c, async k => {
                s.value = k === 0, await _o(), i.value && (s.value ? (i.value.style.maxHeight = i.value.scrollHeight + "px", i.value.style.visibility = "visible", E()) : (i.value.style.maxHeight = "0", i.value.style.visibility = "hidden"))
            });
            const E = () => {
                d({
                    category: "seo_text",
                    action: "show_more"
                })
            };
            return Ce(async () => {
                m.value && i.value && (s.value = !s.value, i.value.style.maxHeight = "max-content", i.value.style.visibility = "visible")
            }), (k, y) => e(T) ? (l(), b("div", Hl, [h(qo, {
                modelValue: e(c),
                "onUpdate:modelValue": y[0] || (y[0] = I => Tt(c) ? c.value = I : null),
                class: "rules-info"
            }, {
                default: N(() => [h(Zo, null, {
                    title: N(() => [n("span", Ul, x(e(r)("footer.seoTitle")), 1)]),
                    default: N(() => [n("div", {
                        ref_key: "seoContent",
                        ref: i,
                        class: K(["seo-content", {
                            hidden: !e(s)
                        }])
                    }, [(l(), F(uo(e(T))))], 2)]),
                    _: 1
                })]),
                _: 1
            }, 8, ["modelValue"])])) : $("", !0)
        }
    }),
    ro = Q(Fl, [
        ["__scopeId", "data-v-ef97b4a6"]
    ]),
    zl = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: ro
    }, Symbol.toStringTag, {
        value: "Module"
    }));

function Gl() {
    const t = Ve(),
        o = t.host.includes(io),
        a = t.host.includes(lo);
    return { ...wt,
        ...o && !a && {
            CASINO: Eo.CASINO ? ? wt.CASINO,
            MAIN: Eo.MAIN ? ? wt.MAIN
        },
        ...a && {
            CASINO: Co.CASINO ? ? wt.CASINO,
            MAIN: Co.MAIN ? ? wt.MAIN
        }
    }
}
const jl = {
        key: 0,
        class: "footer test-seo-text"
    },
    Wl = {
        class: "footer__collapse"
    },
    ql = {
        class: "footer__wrapper"
    },
    Zl = {
        class: "footer__rules-info"
    },
    Kl = {
        class: "footer"
    },
    Xl = {
        key: 0,
        class: "footer__uuid"
    },
    Yl = {
        class: "footer__wrapper"
    },
    Ql = {
        class: "footer__logo"
    },
    Jl = {
        class: "footer__content"
    },
    ec = {
        class: "footer__categories"
    },
    tc = {
        class: "footer__block"
    },
    oc = {
        class: "footer__logoMobile"
    },
    ac = {
        class: "footer__lang-item"
    },
    nc = {
        class: "footer__support"
    },
    sc = {
        class: "footer__support-left"
    },
    rc = {
        class: "footer__support-icon"
    },
    ic = {
        class: "footer__support-block"
    },
    lc = {
        class: "footer__support-title"
    },
    cc = {
        class: "footer__support-text"
    },
    uc = {
        class: "footer__support-right"
    },
    _c = ["href"],
    dc = ["href"],
    pc = {
        key: 0,
        class: "footer__providers"
    },
    mc = {
        key: 1,
        class: "footer__providers"
    },
    fc = {
        class: "footer__info"
    },
    hc = {
        class: "footer__info-left"
    },
    vc = {
        class: "footer__copyright"
    },
    gc = {
        class: "footer__social"
    },
    bc = {
        class: "footer__social-icon",
        href: "https://t.me/+lJAUI6Gzw8IxMWJi",
        rel: "noreferrer",
        target: "_blank",
        "data-auto-test-el": "telegram"
    },
    yc = {
        class: "footer__social-icon",
        href: "https://www.instagram.com/4rabet.india_official/",
        rel: "noreferrer",
        target: "_blank",
        "data-auto-test-el": "instagram"
    },
    wc = {
        class: "footer__info-right"
    },
    kc = {
        class: "footer__qr"
    },
    Ic = ["src"],
    Ac = {
        class: "footer__download"
    },
    Tc = {
        class: "footer__app"
    },
    Cc = ["href"],
    Ec = ["src"],
    Lc = ["innerHTML"],
    Sc = ["href"],
    Dc = ["src"],
    Bc = ["innerHTML"],
    $c = {
        class: "footer__legal"
    },
    Pc = {
        class: "footer__collapse"
    },
    xc = {
        key: 0,
        class: "footer__rules-info",
        "data-auto-test-el": "4rabetOfficialWebSite"
    },
    Oc = {
        class: "footer__collapse-blocks"
    },
    Nc = {
        class: "footer__collapse-terms",
        "data-auto-test-el": "terms"
    },
    Rc = {
        class: "footer__collapse-betting",
        "data-auto-test-el": "betting"
    },
    Mc = {
        class: "footer__collapse-casino",
        "data-auto-test-el": "casino"
    },
    Vc = {
        class: "footer__collapse-ipl",
        "data-auto-test-el": "ipl"
    },
    Hc = {
        class: "footer__bottom"
    },
    Uc = oe({
        __name: "AppFooter",
        props: {
            langs: {}
        },
        setup(t) {
            const {
                openWidgetChat: o
            } = fo(), a = Ke(), {
                t: s
            } = re(), i = Ne(), {
                imageUrl: c
            } = pt(), {
                isBaseDomain: u
            } = Oe(), f = Gl(), {
                userGeo: r
            } = Y(be()), {
                userUUID: d,
                isUserVip: _
            } = Y(he()), p = ne(), m = g(() => p.path === "/casino"), T = ["RW", "ZM", "UG", "CM", "CD", "CI"], E = g(() => T.includes(r.value)), k = g(() => _.value && r.value === "IN" ? "mailto:vip@4rabet.com" : "mailto:support@4rabet.com"), y = g(() => _.value && r.value === "IN" ? "https://t.me/VIPSupportBetFourRaBot" : "https://t.me/Fourbetsupport_bot");

            function I() {
                o()
            }
            const B = g(() => ({
                android: De.LINK_DOWNLOAD_APP_ANDROID,
                apple: a.app.appleBtn
            }));
            return (z, X) => {
                var ue, ge;
                const L = zt,
                    H = Xe,
                    U = ji,
                    R = Ki,
                    w = oa,
                    P = mo,
                    C = Ji,
                    A = al,
                    S = il,
                    G = dl,
                    q = hl,
                    M = Tl,
                    j = Sl,
                    te = Pl,
                    se = Rl,
                    de = Vl;
                return l(), b(ve, null, [e(m) ? (l(), b("div", jl, [n("div", Wl, [n("div", ql, [n("div", Zl, [h(ro)])])])])) : $("", !0), n("footer", Kl, [e(d) && e(i)("/") === e(p).path ? (l(), b("div", Xl, x(e(d)), 1)) : $("", !0), n("div", Yl, [n("section", Ql, [h(H, {
                    to: e(i)("/"),
                    "no-prefetch": "",
                    "data-auto-test-el": "4rabetLogoFooter"
                }, {
                    default: N(() => [h(L, {
                        width: 57,
                        height: 10,
                        "symbol-id": "logoFooter"
                    })]),
                    _: 1
                }, 8, ["to"])]), n("section", Jl, [n("div", ec, [h(U, {
                    title: "footerNew.casino",
                    links: e(f).CASINO,
                    "class-name": "footer__casino",
                    "list-data-attr-name": "casinoTitleBlockFooter"
                }, null, 8, ["links"]), h(U, {
                    title: "menu.sport",
                    links: e(f).BETTING,
                    "class-name": "footer__sport",
                    "list-data-attr-name": "sportTitleBlockFooter"
                }, null, 8, ["links"]), h(U, {
                    title: "menu.mainTitle",
                    links: e(f).MAIN,
                    "class-name": "footer__main",
                    "list-data-attr-name": "mainTitleBlockFooter"
                }, null, 8, ["links"]), h(U, {
                    title: "footerNew.personal",
                    links: e(f).PERSONAL,
                    "class-name": "footer__personal",
                    "list-data-attr-name": "personalTitleBlockFooter"
                }, null, 8, ["links"])]), n("div", tc, [h(H, {
                    to: e(i)("/"),
                    "no-prefetch": ""
                }, {
                    default: N(() => [n("div", oc, [h(R)])]),
                    _: 1
                }, 8, ["to"]), n("div", ac, [at(n("div", null, [h(P, null, {
                    default: N(() => [h(w, {
                        key: "footer",
                        position: "footer",
                        langs: z.langs,
                        "show-inner-arrow": ""
                    }, null, 8, ["langs"])]),
                    _: 1
                })], 512), [
                    [It, z.langs && z.langs.length > 0]
                ])]), n("div", nc, [n("div", sc, [n("div", rc, [h(C)]), n("div", ic, [n("div", lc, x(e(s)("footerNew.support")), 1), n("div", cc, x(e(s)("footerNew.reportProblem")), 1)])]), n("div", uc, [n("a", {
                    href: e(k),
                    class: "footer__support-mail",
                    "data-auto-test-el": "sendMailToSupport"
                }, [h(A)], 8, _c), n("a", {
                    class: "footer__support-telegram",
                    href: e(y),
                    target: "_blank",
                    rel: "noopener noreferrer",
                    "data-auto-test-el": "telegramSupportBlock"
                }, [h(S)], 8, dc), n("div", {
                    class: "footer__support-chat",
                    "data-auto-test-el": "chatFooter",
                    onClick: I
                }, x(e(s)("menu.chat")), 1)])])])]), e(E) ? (l(), b("section", pc, [h(G)])) : (l(), b("section", mc, [h(q, {
                    "data-auto-test-el": "footerProviders"
                })])), n("section", fc, [n("div", hc, [n("div", vc, [h(M)]), n("div", gc, [n("a", bc, [h(j)]), n("a", yc, [h(te)])])]), n("div", wc, [n("div", kc, [n("img", {
                    src: `${e(c)}/main/providers/banners/qr.svg`,
                    alt: "qr"
                }, null, 8, Ic)]), n("div", Ac, x(e(s)("footerNew.downloadApp")), 1), n("div", Tc, [n("a", {
                    href: (ue = e(B)) == null ? void 0 : ue.apple,
                    target: "_blank",
                    class: "footer__app-btn",
                    "data-auto-test-el": "iosFooter"
                }, [n("img", {
                    class: "footer__app-icon",
                    src: `${e(c)}/main/providers/banners/ios.svg`,
                    alt: "ios"
                }, null, 8, Ec), n("div", {
                    class: "footer__app-text",
                    innerHTML: e(s)("footerNew.downloadIOS")
                }, null, 8, Lc)], 8, Cc), n("a", {
                    href: (ge = e(B)) == null ? void 0 : ge.android,
                    target: "_blank",
                    class: "footer__app-btn",
                    "data-auto-test-el": "androidFooter"
                }, [n("img", {
                    class: "footer__app-icon",
                    src: `${e(c)}/main/providers/banners/android.svg`,
                    alt: "android"
                }, null, 8, Dc), n("div", {
                    class: "footer__app-text",
                    innerHTML: e(s)("footerNew.downloadAndroid")
                }, null, 8, Bc)], 8, Sc)])])]), n("section", $c, [e(u) ? (l(), F(se, {
                    key: 0
                })) : $("", !0)]), n("section", Pc, [e(m) ? $("", !0) : (l(), b("div", xc, [h(ro)])), n("div", Oc, [n("div", Nc, [h(de, {
                    links: e(Ot).TERMS
                }, {
                    header: N(() => [ae(x(e(s)("footerNew.terms")), 1)]),
                    _: 1
                }, 8, ["links"])]), n("div", Rc, [h(de, {
                    links: e(Ot).BETTING
                }, {
                    header: N(() => [ae(x(e(s)("footerNew.betting")), 1)]),
                    _: 1
                }, 8, ["links"])]), n("div", Mc, [h(de, {
                    links: e(Ot).CASINO
                }, {
                    header: N(() => [ae(x(e(s)("footerNew.casino")), 1)]),
                    _: 1
                }, 8, ["links"])]), n("div", Vc, [h(de, {
                    links: e(Ot).IPL
                }, {
                    header: N(() => X[0] || (X[0] = [ae("IPL")])),
                    _: 1
                }, 8, ["links"])])]), n("div", Hc, [h(M)])])])])], 64)
            }
        }
    }),
    Fc = Q(Uc, [
        ["__scopeId", "data-v-97798fed"]
    ]),
    zc = {
        class: "l-rightbar"
    },
    Gc = {
        class: "l-rightbar__position"
    },
    jc = {
        class: "l-rightbar__container"
    },
    Wc = {
        class: "cat-nav"
    },
    qc = {
        class: "cat-nav__list"
    },
    Zc = {
        key: 0,
        class: "cat-nav__item",
        "data-auto-test-el": "rewardsRightBarDesktop"
    },
    Kc = ["data-src", "src"],
    Xc = {
        class: "cat-nav__name"
    },
    Yc = {
        class: "cat-nav__name"
    },
    Qc = {
        class: "cat-nav__name"
    },
    Jc = {
        class: "cat-nav__name"
    },
    eu = ["src"],
    tu = ["src"],
    ou = ["src"],
    au = ["src"],
    nu = {
        class: "cat-nav__name"
    },
    su = oe({
        __name: "CasinoSidebarRight",
        setup(t) {
            const {
                config: o
            } = Ze(), a = ne(), s = Ne(), {
                imageUrl: i
            } = mt(), {
                t: c
            } = re(), {
                openDialog: u
            } = Ee(), {
                isMobile: f
            } = Ye(), {
                isAuthenticated: r
            } = Te(), {
                showSmartico: d
            } = Y(he()), {
                userGeo: _
            } = Y(be()), {
                setRedirectSlotAuth: p
            } = Dn(), m = g(() => f.value ? yt.JETX_MOBILE : yt.JETX_DESKTOP), T = g(() => yt.AVIATOR_MOBILE), E = g(() => f.value ? yt.AVIATRIX_MOBILE : yt.AVIATRIX_DESKTOP), k = () => {
                u("auth")
            }, y = () => {
                var H;
                if (!r.value) {
                    k();
                    return
                }(H = window._smartico) == null || H.dp("dp:gf")
            }, I = g(() => _.value), B = g(() => o.value.IS_IPL && ["IN", "BD"].includes(I.value)), z = g(() => o.value.IS_ICC && ["IN", "BD"].includes(I.value));

            function X() {
                const H = "/live-dealers/slot/167";
                r.value ? window.location.href = `${s(H)}` : (p(s(H)), u("auth"))
            }

            function L(H) {
                r.value ? window.location.href = `${s(H)}` : (p(H), u("auth"))
            }
            return (H, U) => {
                const R = po,
                    w = Xe,
                    P = zt;
                return l(), b("aside", zc, [n("div", Gc, [n("div", jc, [n("nav", Wc, [n("ul", qc, [e(d) && e(_) !== "ZM" ? (l(), b("li", Zc, [n("a", {
                    class: "cat-nav__link",
                    onClick: nt(y, ["prevent"])
                }, [n("img", {
                    "data-src": `${e(i)}/main/top-sections/cup.svg`,
                    src: `${e(i)}/main/top-sections/cup.svg`,
                    alt: "levelUP",
                    title: "levelUP",
                    loading: "lazy"
                }, null, 8, Kc), n("p", Xc, x(e(c)("newMain.topSections.rewards")), 1)])])) : $("", !0), n("li", {
                    "data-auto-test-el": "cricketRightBarDesktop",
                    class: K(["cat-nav__item", {
                        "cat-nav__item--active": e(a).path.includes("/live/cricket")
                    }])
                }, [h(R, {
                    "route-path": "/live/cricket",
                    class: "cat-nav__link"
                }, {
                    default: N(() => [U[3] || (U[3] = n("svg", {
                        id: "Capa_1",
                        width: "27",
                        height: "29",
                        "enable-background": "new 0 0 512.991 512.991",
                        viewBox: "0 0 512.991 512.991",
                        xmlns: "http://www.w3.org/2000/svg",
                        class: "cat-nav__icon"
                    }, [n("g", {
                        id: "XMLID_462_"
                    }, [n("path", {
                        id: "XMLID_464_",
                        d: "m454.873 157.491 57.001-57.001-4.459-8.575c-19.885-38.24-49.275-68.27-84.992-86.843l-9.128-4.747-57.794 57.794z"
                    }), n("path", {
                        id: "XMLID_465_",
                        d: "m4.665 382.044h170.677v80.73h-170.677z",
                        transform: "matrix(.707 -.707 .707 .707 -272.327 187.363)"
                    }), n("path", {
                        id: "XMLID_466_",
                        d: "m127.917 164.813h299.99v140.534h-299.99z",
                        transform: "matrix(.707 -.707 .707 .707 -84.828 265.367)"
                    }), n("path", {
                        id: "XMLID_467_",
                        d: "m159.298 57.137-57.137-57.137-9.753 5.072c-35.717 18.573-65.107 48.603-84.992 86.843l-5.072 9.753 56.211 56.211z"
                    }), n("path", {
                        id: "XMLID_468_",
                        d: "m86.987 117.089h142.472v79.431h-142.472z",
                        transform: "matrix(.707 -.707 .707 .707 -64.535 157.807)"
                    }), n("path", {
                        id: "XMLID_469_",
                        d: "m278.052 376.738 27.766 27.199 100.745-100.745-27.767-27.198z"
                    }), n("path", {
                        id: "XMLID_471_",
                        d: "m389.62 353.351h80.73v150.432h-80.73z",
                        transform: "matrix(.707 -.707 .707 .707 -177.103 429.57)"
                    }), n("circle", {
                        id: "XMLID_444_",
                        cx: "256.337",
                        cy: "461.465",
                        r: "51.526"
                    })])], -1)), n("p", Yc, x(e(c)("rightMenu.cricket")), 1)]),
                    _: 1
                })], 2), n("li", {
                    class: K(["cat-nav__item", {
                        "cat-nav__item--active": e(a).path.includes("/live-dealers/slot/167")
                    }]),
                    "data-auto-test-el": "topLiveDealerRightBarDesktop"
                }, [e(r) ? (l(), b("a", {
                    key: 0,
                    class: "cat-nav__link",
                    onClick: X
                }, [U[4] || (U[4] = n("svg", {
                    id: "dealer",
                    width: "33",
                    height: "30",
                    viewBox: "0 0 998.441 915.244",
                    class: "cat-nav__icon"
                }, [n("path", {
                    d: "M349.456 665.638h133.125v116.484H349.456V665.638zm-166.403 0h133.121v116.484H183.053V665.638zm249.61-199.688h133.121v33.273H432.663V465.95zm83.203 199.688h133.121v116.484H515.866V665.638zm74.883-574.102c0 50.547-40.977 91.523-91.527 91.523-50.547 0-91.523-40.977-91.523-91.523 0-50.555 40.977-91.531 91.523-91.531 50.55 0 91.527 40.977 91.527 91.531z"
                }), n("path", {
                    d: "M765.475 532.513H232.971c-92.125 0-199.688 47.938-199.688 183.047v16.633c0 135.109 107.563 183.055 199.688 183.055h532.504c92.125 0 199.688-47.945 199.688-183.055V715.56c0-135.11-107.563-183.047-199.688-183.047zm-183.047 33.281h216.324c9.195 0 16.641 7.445 16.641 16.641 0 9.188-7.445 16.633-16.641 16.633H582.428c-9.191 0-16.645-7.445-16.645-16.633.001-9.196 7.454-16.641 16.645-16.641zm-382.738 0h216.328c9.195 0 16.645 7.445 16.645 16.641 0 9.188-7.449 16.633-16.645 16.633H199.69c-9.188 0-16.637-7.445-16.637-16.633 0-9.196 7.45-16.641 16.637-16.641zm619.637 309.797a231.106 231.106 0 01-53.852 6.367H232.971a231.16 231.16 0 01-53.852-6.367 16.642 16.642 0 01-12.359-11.457 16.637 16.637 0 0120.211-20.879 201.227 201.227 0 0046 5.422h532.504a201.201 201.201 0 0046-5.422 16.64 16.64 0 0120.211 20.879 16.642 16.642 0 01-12.359 11.457zm29.348-93.469c0 18.375-14.898 33.281-33.281 33.281h-632.34c-18.383 0-33.285-14.906-33.285-33.281V665.638c0-18.391 14.902-33.289 33.285-33.289h299.527v-49.914c0-9.195 7.453-16.641 16.641-16.641 9.195 0 16.645 7.445 16.645 16.641v49.914h299.527c18.383 0 33.281 14.898 33.281 33.289v116.484z"
                }), n("path", {
                    d: "M682.272 665.638h133.121v116.484H682.272V665.638zM399.378 449.302V299.544c0-9.195 7.457-16.641 16.641-16.641 9.195 0 16.645 7.445 16.645 16.641v133.125h133.121V299.544c0-9.195 7.453-16.641 16.645-16.641 9.184 0 16.637 7.445 16.637 16.641v199.68h33.281V272.911c0-31.25-25.328-56.57-56.578-56.57H422.68c-31.25 0-56.578 25.32-56.578 56.57v226.313h33.277v-49.922zM73.534 351.13c31.969 22.848 59.594 42.566 59.594 81.539 0 9.184 7.453 16.633 16.641 16.633 9.195 0 16.641-7.449 16.641-16.633 0-38.973 27.629-58.691 59.59-81.539 34.461-24.625 73.535-52.535 73.535-108.648 0-31.32-27.988-92.703-92.699-92.703a69.435 69.435 0 00-57.066 25.656 69.414 69.414 0 00-57.063-25.656c-64.715 0-92.703 61.383-92.703 92.703-.001 56.113 39.069 84.023 73.53 108.648zm858.348-94.852h-1.418a123.916 123.916 0 001.418-18.859c0-54.063-31.891-87.641-83.207-87.641-51.324 0-83.199 33.578-83.199 87.641a124.117 124.117 0 001.406 18.887l-1.406-.027c-44.313 0-66.566 44.816-66.566 69.891 0 29.02 25.816 69.883 83.203 69.883a79.15 79.15 0 0031.34-6.23 74.498 74.498 0 01-35.633 26.773c-8.059 2.156-13.273 9.953-12.195 18.234 1.086 8.281 8.137 14.473 16.488 14.473 1.449 0 2.895-.188 4.293-.566a107.645 107.645 0 0062.27-52.422 107.646 107.646 0 0062.27 52.422c8.816 2.379 17.879-2.84 20.27-11.641 2.445-8.84-2.723-17.98-11.555-20.453a74.636 74.636 0 01-35.75-26.789 79.34 79.34 0 0031.328 6.199c57.398 0 83.203-40.863 83.203-69.883-.002-25.075-22.248-69.892-66.56-69.892z"
                })], -1)), n("p", Qc, x(e(c)("rightMenu.liveDealer")), 1)])) : (l(), b("a", {
                    key: 1,
                    class: "cat-nav__link",
                    onClick: X
                }, [U[5] || (U[5] = n("svg", {
                    id: "dealer",
                    width: "33",
                    height: "30",
                    viewBox: "0 0 998.441 915.244",
                    class: "cat-nav__icon"
                }, [n("path", {
                    d: "M349.456 665.638h133.125v116.484H349.456V665.638zm-166.403 0h133.121v116.484H183.053V665.638zm249.61-199.688h133.121v33.273H432.663V465.95zm83.203 199.688h133.121v116.484H515.866V665.638zm74.883-574.102c0 50.547-40.977 91.523-91.527 91.523-50.547 0-91.523-40.977-91.523-91.523 0-50.555 40.977-91.531 91.523-91.531 50.55 0 91.527 40.977 91.527 91.531z"
                }), n("path", {
                    d: "M765.475 532.513H232.971c-92.125 0-199.688 47.938-199.688 183.047v16.633c0 135.109 107.563 183.055 199.688 183.055h532.504c92.125 0 199.688-47.945 199.688-183.055V715.56c0-135.11-107.563-183.047-199.688-183.047zm-183.047 33.281h216.324c9.195 0 16.641 7.445 16.641 16.641 0 9.188-7.445 16.633-16.641 16.633H582.428c-9.191 0-16.645-7.445-16.645-16.633.001-9.196 7.454-16.641 16.645-16.641zm-382.738 0h216.328c9.195 0 16.645 7.445 16.645 16.641 0 9.188-7.449 16.633-16.645 16.633H199.69c-9.188 0-16.637-7.445-16.637-16.633 0-9.196 7.45-16.641 16.637-16.641zm619.637 309.797a231.106 231.106 0 01-53.852 6.367H232.971a231.16 231.16 0 01-53.852-6.367 16.642 16.642 0 01-12.359-11.457 16.637 16.637 0 0120.211-20.879 201.227 201.227 0 0046 5.422h532.504a201.201 201.201 0 0046-5.422 16.64 16.64 0 0120.211 20.879 16.642 16.642 0 01-12.359 11.457zm29.348-93.469c0 18.375-14.898 33.281-33.281 33.281h-632.34c-18.383 0-33.285-14.906-33.285-33.281V665.638c0-18.391 14.902-33.289 33.285-33.289h299.527v-49.914c0-9.195 7.453-16.641 16.641-16.641 9.195 0 16.645 7.445 16.645 16.641v49.914h299.527c18.383 0 33.281 14.898 33.281 33.289v116.484z"
                }), n("path", {
                    d: "M682.272 665.638h133.121v116.484H682.272V665.638zM399.378 449.302V299.544c0-9.195 7.457-16.641 16.641-16.641 9.195 0 16.645 7.445 16.645 16.641v133.125h133.121V299.544c0-9.195 7.453-16.641 16.645-16.641 9.184 0 16.637 7.445 16.637 16.641v199.68h33.281V272.911c0-31.25-25.328-56.57-56.578-56.57H422.68c-31.25 0-56.578 25.32-56.578 56.57v226.313h33.277v-49.922zM73.534 351.13c31.969 22.848 59.594 42.566 59.594 81.539 0 9.184 7.453 16.633 16.641 16.633 9.195 0 16.641-7.449 16.641-16.633 0-38.973 27.629-58.691 59.59-81.539 34.461-24.625 73.535-52.535 73.535-108.648 0-31.32-27.988-92.703-92.699-92.703a69.435 69.435 0 00-57.066 25.656 69.414 69.414 0 00-57.063-25.656c-64.715 0-92.703 61.383-92.703 92.703-.001 56.113 39.069 84.023 73.53 108.648zm858.348-94.852h-1.418a123.916 123.916 0 001.418-18.859c0-54.063-31.891-87.641-83.207-87.641-51.324 0-83.199 33.578-83.199 87.641a124.117 124.117 0 001.406 18.887l-1.406-.027c-44.313 0-66.566 44.816-66.566 69.891 0 29.02 25.816 69.883 83.203 69.883a79.15 79.15 0 0031.34-6.23 74.498 74.498 0 01-35.633 26.773c-8.059 2.156-13.273 9.953-12.195 18.234 1.086 8.281 8.137 14.473 16.488 14.473 1.449 0 2.895-.188 4.293-.566a107.645 107.645 0 0062.27-52.422 107.646 107.646 0 0062.27 52.422c8.816 2.379 17.879-2.84 20.27-11.641 2.445-8.84-2.723-17.98-11.555-20.453a74.636 74.636 0 01-35.75-26.789 79.34 79.34 0 0031.328 6.199c57.398 0 83.203-40.863 83.203-69.883-.002-25.075-22.248-69.892-66.56-69.892z"
                })], -1)), n("p", Jc, x(e(c)("rightMenu.liveDealer")), 1)]))], 2), e(B) ? (l(), b("li", {
                    key: 1,
                    class: K(["cat-nav__item", {
                        "cat-nav__item--active": e(a).path === e(s)("/sports/cricket/india/indian-premier-league-1710528586840150016")
                    }]),
                    style: {
                        cursor: "pointer"
                    },
                    "data-auto-test-el": "ipl2025RightBarDesktop"
                }, [h(w, {
                    class: "cat-nav__link",
                    to: e(s)("/sports/cricket/india/indian-premier-league-1710528586840150016")
                }, {
                    default: N(() => [n("img", {
                        class: "entertainment-info__activity-ico",
                        src: `${e(i)}/main/betby/sports/ipl.png`,
                        width: "65",
                        height: "30",
                        alt: "ipl"
                    }, null, 8, eu), U[6] || (U[6] = n("br", null, null, -1)), U[7] || (U[7] = n("p", {
                        class: "cat-nav__name"
                    }, "IPL 2025", -1))]),
                    _: 1
                }, 8, ["to"])], 2)) : $("", !0), e(z) ? (l(), b("li", {
                    key: 2,
                    class: K(["cat-nav__item", {
                        "cat-nav__item--active": e(a).path === e(s)("/sports/cricket")
                    }]),
                    style: {
                        cursor: "pointer"
                    },
                    "data-auto-test-el": "icc2025RightBarDesktop"
                }, [h(w, {
                    class: "cat-nav__link",
                    to: e(s)("/sports/cricket")
                }, {
                    default: N(() => [n("img", {
                        class: "entertainment-info__activity-ico",
                        src: `${e(i)}/main/betby/sports/ICC.png`,
                        width: "65",
                        height: "30",
                        alt: "icc"
                    }, null, 8, tu), U[8] || (U[8] = n("br", null, null, -1)), U[9] || (U[9] = n("p", {
                        class: "cat-nav__name"
                    }, "ICC 2025", -1))]),
                    _: 1
                }, 8, ["to"])], 2)) : $("", !0), n("li", {
                    class: K(["cat-nav__item", {
                        "cat-nav__item--active": e(a).path.includes("aviator")
                    }]),
                    style: {
                        cursor: "pointer"
                    },
                    "data-auto-test-el": "AviatorRightBarDesktop"
                }, [n("div", {
                    class: "cat-nav__link",
                    onClick: U[0] || (U[0] = () => L(e(T)))
                }, [n("div", null, [h(P, {
                    height: 16,
                    width: 60,
                    "tag-use-class-name": "panel-nav__icon-use",
                    "symbol-id": "aviator-text"
                })])])], 2), n("li", {
                    class: K(["cat-nav__item", {
                        "cat-nav__item--active": e(a).path.includes("18795") || e(a).path.includes("jetx")
                    }]),
                    style: {
                        cursor: "pointer"
                    },
                    "data-auto-test-el": "jetXRightBarDesktop"
                }, [n("div", {
                    class: "cat-nav__link",
                    onClick: U[1] || (U[1] = () => L(e(m)))
                }, [n("div", null, [h(P, {
                    height: 16,
                    width: 60,
                    "tag-use-class-name": "panel-nav__icon-use",
                    "symbol-id": "jetx-text"
                })])])], 2), n("li", {
                    class: K(["cat-nav__item", {
                        "cat-nav__item--active": e(a).path.includes("26555") || e(a).path.includes("aviatrix")
                    }]),
                    style: {
                        cursor: "pointer"
                    },
                    "data-auto-test-el": "aviatriXRightBarDesktop"
                }, [n("div", {
                    class: "cat-nav__link",
                    onClick: U[2] || (U[2] = () => L(e(E)))
                }, [n("img", {
                    src: `${e(i)}/aviatrix-text.webp`,
                    alt: "aviatrix",
                    width: "60",
                    height: "16",
                    loading: "lazy"
                }, null, 8, ou)])], 2), n("li", {
                    class: K(["cat-nav__item", {
                        "cat-nav__item--active": e(a).path === "/info/tutorials"
                    }]),
                    "data-auto-test-el": "tutorialsRightBarDesktop"
                }, [h(w, {
                    to: e(s)("/info/tutorials"),
                    class: "cat-nav__link",
                    "no-prefetch": ""
                }, {
                    default: N(() => [n("img", {
                        src: `${e(i)}/guidebook-03-1.png`,
                        alt: "guidebook",
                        width: "40",
                        height: "40",
                        style: {
                            transform: "scale(1.3)"
                        },
                        loading: "lazy"
                    }, null, 8, au), n("p", nu, x(e(c)("rightMenu.tutorials")), 1)]),
                    _: 1
                }, 8, ["to"])], 2)])])])])])
            }
        }
    }),
    ru = Q(su, [
        ["__scopeId", "data-v-70252356"]
    ]);

function iu() {
    const t = ne(),
        {
            config: o
        } = Ze(),
        {
            loadWidgetChat: a
        } = fo(),
        {
            isIpCheckSuccess: s
        } = Y(be()),
        {
            platform: i,
            mobile: c
        } = co(),
        {
            isGoogleSsoSuccess: u,
            tokenDataUser: f
        } = Te(),
        {
            getUserData: r
        } = Pn(),
        d = g(() => ({
            iphone: i.value.ios,
            isBot: !1,
            slot: t.path.includes("/slot/") && c.value,
            fixed: !1
        })),
        _ = (p = !1) => {
            a(p)
        };
    return le(() => u.value, p => {
        p && r(f.value)
    }), {
        layoutClasses: d,
        loadChat: _,
        isNewYear: o.value.NEW_YEAR_THEME,
        isBlockedPage: g(() => !s.value)
    }
}

function ra() {
    const t = ne(),
        {
            userGeo: o
        } = Y(be()),
        {
            languages: a,
            enabledLanguages: s
        } = Yo(),
        i = Qo(),
        c = g(() => o.value);
    i == null || i.initLocaleClient(t);
    const u = le(() => a.value, r => {
            r && (i == null || i.preventUsingDisabledLang(), u())
        }),
        f = le(() => c.value, r => {
            r && (i == null || i.preventUsingDisabledLang(r), f())
        });
    return {
        languages: a,
        enabledLanguages: s
    }
}
const lu = ["index", "live", "live-id", "live-all", "sports", "sports-id", "sports-all", "profile", "profile-history"],
    Lo = ["profile", "profile-history", "profile-bonuses", "profile-deposit-withdraw"],
    cu = ["live", "line", "sports"],
    kt = ["casino", "casino-id", "live-dealers", "live-dealers-id", "tv-games", "tv-games-id", "virtual-sport"],
    uu = {
        casino: "titles.casino",
        "casino-id": "titles.casino",
        "live-dealers": "titles.liveCasino",
        "live-dealers-id": "titles.liveCasino",
        "tv-games": "titles.tvGames",
        "tv-games-id": "titles.tvGames",
        "virtual-sport": "menu.virtualSport",
        bonuses: "menu.bonuses",
        "profile-bonuses": "menu.activeBonuses",
        "profile-deposit-withdraw": "profile.menu.deposits",
        profile: "menu.personalAccount",
        "profile-history": "menu.personalAccount"
    };

function _u() {
    const {
        showTopBar: t
    } = Wo(), o = ne(), {
        getPathWithoutLocale: a
    } = Oe(), s = Ne(), {
        t: i
    } = re(), {
        $getRouteBaseName: c
    } = Ae(), {
        isMobile: u
    } = Ye(), f = ee(a(o.path)), r = g(() => {
        var k;
        return t.value && ((k = o.name) == null ? void 0 : k.includes("-slot-id")) && u.value
    }), d = g(() => kt.some(k => f.value.includes(k))), _ = g(() => c(o)), p = g(() => [...lu, ...kt].includes(_.value) && o.path !== s("/")), m = g(() => {
        const k = [...Lo, ...kt];
        return !!(_.value && !k.includes(_.value))
    }), T = g(() => kt.includes(_.value) ? _.value || "" : o.path.includes("live") ? "live" : "line"), E = g(() => {
        const k = o.path,
            y = _.value || "";
        if ([...Lo, ...kt].includes(y)) return i(uu[y] || "");
        const B = k.includes("live") ? "live" : "line";
        return cu.includes(B) ? i(`menu.${B}`) : null
    });
    return le(o, k => {
        f.value = a(k.path)
    }), {
        routeName: _,
        getTitle: T,
        getLocaleTitle: E,
        showMainTitle: p,
        showMainSubTitle: m,
        showFooterForSlotGameMobile: r,
        showRightAside: g(() => !u.value && f.value !== "/"),
        isVisibleSidebar: d
    }
}

function du() {
    const t = _t(),
        o = ee(!1);
    async function a() {
        const s = await window.$workbox;
        s && s.addEventListener("installed", i => {
            i.isUpdate && (o.value = !0)
        })
    }
    return Ce(() => {
        t.beforeEach((s, i, c) => {
            o.value ? window.location = s.fullPath : c(!0)
        }), a()
    }), {
        navigateWithReload: o
    }
}
const pu = "dp:gf",
    mu = t => {
        var o;
        return (o = window._smartico) == null ? void 0 : o.dp(t)
    };

function fu() {
    const t = _t(),
        o = ne();

    function a(c) {
        const {
            data: u
        } = c;
        if (!(u != null && u.isIframe)) return;
        const f = t.options.history.location,
            r = o.path;
        if (f !== r) return t.push(f);
        const [d] = o.path.split("/").filter(_ => !!_);
        t.replace({
            path: `/${d}`
        })
    }

    function s() {
        try {
            return window.self !== window.top
        } catch {
            return !0
        }
    }

    function i() {
        var c;
        (c = window.top) == null || c.postMessage({
            isIframe: !0
        }, "*")
    }
    return Ce(() => {
        window.addEventListener("message", a), s() && i()
    }), {
        onTriggerSmartico: () => mu(pu)
    }
}
const hu = Z(() => v(() =>
        import ("./DNwLMpuy.js"), __vite__mapDeps([84, 1, 2, 3, 4, 85, 86, 87, 88]),
        import.meta.url).then(t => t.default || t)),
    vu = Z(() => v(() =>
        import ("./lOafapvo.js"), __vite__mapDeps([89, 90, 1, 2, 3, 4, 87, 91, 85, 86, 92, 93, 94, 95, 96, 97]),
        import.meta.url).then(t => t.default || t)),
    gu = Z(() => v(() =>
        import ("./GL5mXhHm.js"), __vite__mapDeps([98, 2, 3, 1, 4, 99, 100, 90, 85, 86, 5, 101, 10, 102, 103, 87, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 93, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 96, 94, 95, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146]),
        import.meta.url).then(t => t.default || t)),
    bu = {
        class: "default-template__content"
    },
    yu = {
        class: "default-template__content-wrapper"
    },
    wu = oe({
        __name: "DefaultTemplate",
        props: {
            isBlockedPage: {
                type: Boolean
            }
        },
        setup(t) {
            const {
                showFooterForSlotGameMobile: o,
                showRightAside: a,
                routeName: s,
                showMainTitle: i,
                showMainSubTitle: c,
                getTitle: u,
                getLocaleTitle: f,
                isVisibleSidebar: r
            } = _u(), d = ne(), {
                isAuthenticated: _
            } = Te(), {
                enabledLanguages: p
            } = ra(), {
                isBetbyRoute: m
            } = Oe(), {
                isDesktop: T,
                isMobile: E
            } = Ye(), {
                setHead: k
            } = Xo(), y = Ja(), I = Z(() => v(() => Promise.resolve().then(() => zl), void 0,
                import.meta.url)), B = g(() => !!y.error), z = g(() => {
                var X;
                return (X = d.name) == null ? void 0 : X.includes("-slot-id")
            });
            return Ce(() => {
                Xn(), $n()
            }), k(), (X, L) => {
                const H = Ai,
                    U = hu,
                    R = vu,
                    w = Bi,
                    P = Fc,
                    C = ru,
                    A = gu;
                return l(), b("div", {
                    class: K(["default-template", {
                        "default-template_is-not-auth": !e(_),
                        "default-template_with-sidebar": e(T) && e(r) && e(a),
                        "default-template_with-sidebar-right": e(T) && !e(r) && e(a),
                        "default-template_mobile_slot": e(E) && e(z)
                    }])
                }, [e(r) ? (l(), F(H, {
                    key: 0,
                    class: "default-template__left"
                })) : $("", !0), n("div", bu, [e(i) ? (l(), F(R, {
                    key: e(s),
                    "key-slider": e(s),
                    page: e(s),
                    title: e(u),
                    "localize-title": e(f),
                    "show-sub-title": e(c),
                    "is-authenticated": e(_)
                }, {
                    slider: N(S => [h(U, en(tn(S)), null, 16)]),
                    _: 1
                }, 8, ["key-slider", "page", "title", "localize-title", "show-sub-title", "is-authenticated"])) : $("", !0), n("div", yu, [e(m) ? (l(), F(w, {
                    key: 0
                })) : $("", !0), e(B) ? Ct(X.$slots, "error", {
                    key: 1
                }, void 0, !0) : Ct(X.$slots, "default", {
                    key: 2
                }, void 0, !0)]), e(o) ? (l(), F(e(I), {
                    key: 1,
                    class: "seo-content-mobile-hidden"
                })) : (l(), F(P, {
                    key: 2,
                    langs: e(p)
                }, null, 8, ["langs"]))]), e(a) ? (l(), F(C, {
                    key: 1,
                    class: "default-template__right"
                })) : $("", !0), !X.isBlockedPage && !e(o) ? (l(), F(A, {
                    key: 2,
                    class: "mobile__btns"
                })) : $("", !0)], 2)
            }
        }
    }),
    ku = Q(wu, [
        ["__scopeId", "data-v-d1eea085"]
    ]),
    Iu = {
        key: 0
    },
    Au = {
        class: "bonus-timer"
    },
    Tu = {
        class: "info__block"
    },
    Cu = ["innerHTML"],
    Eu = ["innerHTML"],
    Lu = {
        class: "bonus-timer__img"
    },
    Su = oe({
        __name: "BonusPopUpNew",
        setup(t) {
            const {
                config: o
            } = Ze(), {
                imageUrl: a
            } = mt(), {
                lang: s,
                drawerDisplay: i
            } = Ht(), {
                isAuthenticated: c
            } = Te(), {
                userCurrency: u
            } = he(), {
                trackButtonClick: f
            } = ye(), {
                openDialog: r
            } = Ee(), {
                userGeo: d
            } = Y(be()), {
                t: _
            } = re(), p = ee(!0), m = ee(!1), T = ee(!1), {
                isWelcomeBonusesLoaded: E,
                getWelcomeBonuses: k,
                fetchWelcomeBonuses: y
            } = xe(), I = g(() => {
                var P;
                return ((P = o.value) == null ? void 0 : P.IS_ICC) && ["IN", "BD"].includes(d.value)
            }), B = g(() => I.value ? _("banner.titlePopUpICC") : _("banner.titlePlant")), z = g(() => I.value ? _("banner.subtitlePopUpICC") : _("banner.subtitlePlant")), X = g(() => I.value ? `${a.value}/main/banner-popup-icc.png?v=2` : `${a.value}/main/banner-popup-plant-small.png?v=2`), L = g(() => I.value ? `${a.value}/main/banner-popup-icc.png?v=2` : `${a.value}/main/banner-popup-plant-small.png?v=2`);
            Ce(async () => {
                p.value = !1;
                const P = localStorage.getItem("bonusInfo");
                p.value = !P || P !== "false", !k && !E && u && await y(u)
            });
            const H = () => {
                    w("deposit_now"), c.value ? (Pe(ce.WELCOME_TOOL), f({
                        category: "deposit_popup",
                        action: "view_paywall",
                        label: ce.WELCOME_TOOL
                    }), r("deposit")) : (U(), r("registration"))
                },
                U = () => {
                    localStorage.setItem("bonusInfo", "false"), p.value = !1, m.value = !0, w("close_arrow"), setTimeout(() => {
                        m.value = !1
                    }, 2e3)
                },
                R = () => {
                    localStorage.setItem("bonusInfo", "true"), T.value = !0, w("open_arrow"), setTimeout(() => {
                        T.value = !1, p.value = !0
                    }, 800)
                },
                w = P => {
                    f({
                        category: "bonus_popup",
                        action: P
                    })
                };
            return (P, C) => {
                const A = dt;
                return e(i) ? $("", !0) : (l(), b("div", Iu, [n("div", {
                    class: K(["bonus-timer__right", {
                        show: e(p)
                    }])
                }, [n("div", Au, [h(Vt, {
                    class: "mx-auto",
                    type: "image"
                }, {
                    default: N(() => [n("div", {
                        class: K(["align-center align-center bonus-timer__img d-flex justify-space-between w-100", {
                            icc: e(I)
                        }])
                    }, [h(A, {
                        src: e(X),
                        class: "big",
                        alt: "image bonus"
                    }, null, 8, ["src"]), h(A, {
                        src: `${e(a)}/main/arrow-left.svg`,
                        alt: "arrow",
                        class: "arrow",
                        onClick: U
                    }, null, 8, ["src"]), n("div", Tu, [n("div", {
                        class: "plant__title",
                        innerHTML: e(B)
                    }, null, 8, Cu), n("div", {
                        class: K(["plant__subtitle", {
                            my: e(s) === "my"
                        }]),
                        innerHTML: e(z)
                    }, null, 10, Eu), h(Me, {
                        class: K(["button", {
                            my: e(s) === "my"
                        }]),
                        "max-width": 200,
                        onClick: H
                    }, {
                        default: N(() => [ae(x(e(_)("banner.getNow")), 1)]),
                        _: 1
                    }, 8, ["class"])])], 2)]),
                    _: 1
                })])], 2), e(p) ? $("", !0) : (l(), b("div", {
                    key: 0,
                    class: K(["bonus-timer__left", {
                        "show-box": !e(p),
                        "is-show-anim": e(m),
                        "is-hide-anim": e(T)
                    }])
                }, [n("div", {
                    class: K(["bonus-timer", {
                        icc: e(I)
                    }])
                }, [h(Vt, {
                    class: "mx-auto",
                    type: "image"
                }, {
                    default: N(() => [n("div", Lu, [h(A, {
                        src: e(L),
                        alt: "image bonus",
                        class: "popup"
                    }, null, 8, ["src"]), h(A, {
                        src: `${e(a)}/main/arrow-left.svg`,
                        alt: "arrow",
                        class: "arrow",
                        onClick: R
                    }, null, 8, ["src"])])]),
                    _: 1
                })], 2)], 2))]))
            }
        }
    }),
    ia = Q(Su, [
        ["__scopeId", "data-v-cdfce566"]
    ]),
    Du = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: ia
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Bu = {
        key: 0
    },
    $u = {
        class: "bonus-timer"
    },
    Pu = {
        class: "align-center align-center bonus-timer__img d-flex justify-space-between w-100"
    },
    xu = {
        class: "info__block"
    },
    Ou = {
        class: "ipl__title"
    },
    Nu = ["innerHTML"],
    Ru = {
        class: "bonus-timer"
    },
    Mu = {
        class: "bonus-timer__img"
    },
    Vu = ["src"],
    Hu = ["src"],
    Uu = oe({
        __name: "BonusPopUpIPL",
        setup(t) {
            const {
                t: o
            } = re(), {
                imageUrl: a
            } = mt(), {
                lang: s,
                drawerDisplay: i
            } = Ht(), {
                userCurrency: c
            } = he(), {
                trackButtonClick: u
            } = ye(), {
                isAuthenticated: f
            } = Te(), {
                openDialog: r
            } = Ee(), d = ee(!0), _ = ee(!1), p = ee(!1), {
                isWelcomeBonusesLoaded: m,
                getWelcomeBonuses: T,
                fetchWelcomeBonuses: E
            } = xe();
            Ce(async () => {
                d.value = !1;
                const z = localStorage.getItem("bonusInfo");
                d.value = !z || z !== "false", !T && !m && c && await E(c)
            });
            const k = () => {
                    B("deposit_now"), f.value ? (Pe(ce.WELCOME_TOOL), u({
                        category: "deposit_popup",
                        action: "view_paywall",
                        label: ce.WELCOME_TOOL
                    }), r("deposit")) : (y(), r("registration"))
                },
                y = () => {
                    localStorage.setItem("bonusInfo", "false"), d.value = !1, _.value = !0, B("close_arrow"), setTimeout(() => _.value = !1, 2e3)
                },
                I = () => {
                    localStorage.setItem("bonusInfo", "true"), p.value = !0, B("open_arrow"), setTimeout(() => {
                        p.value = !1, d.value = !0
                    }, 800)
                },
                B = z => {
                    u({
                        category: "bonus_popup",
                        action: z
                    })
                };
            return (z, X) => {
                const L = dt,
                    H = on("lazy-container");
                return e(i) ? $("", !0) : (l(), b("div", Bu, [n("div", {
                    class: K(["bonus-timer__right", {
                        show: e(d)
                    }])
                }, [n("div", $u, [h(Vt, {
                    class: "mx-auto",
                    type: "image"
                }, {
                    default: N(() => [n("div", Pu, [h(L, {
                        src: `${e(a)}/main/banner-popup-ipl25.png?v=1`,
                        alt: "image bonus"
                    }, null, 8, ["src"]), h(L, {
                        src: `${e(a)}/main/arrow-left.svg`,
                        alt: "arrow",
                        class: "arrow",
                        onClick: y
                    }, null, 8, ["src"]), n("div", xu, [n("div", Ou, x(e(o)("banner.titlePopUpICC")), 1), n("div", {
                        class: K(["ipl__subtitle", {
                            my: e(s) === "my"
                        }]),
                        innerHTML: e(o)("banner.subtitlePopUpICC")
                    }, null, 10, Nu), h(Me, {
                        class: K(["button", {
                            my: e(s) === "my"
                        }]),
                        "max-width": 200,
                        onClick: k
                    }, {
                        default: N(() => [ae(x(e(o)("banner.takeBonus")), 1)]),
                        _: 1
                    }, 8, ["class"])])])]),
                    _: 1
                })])], 2), e(d) ? $("", !0) : (l(), b("div", {
                    key: 0,
                    class: K(["bonus-timer__left", {
                        "show-box": !e(d),
                        "is-show-anim": e(_),
                        "is-hide-anim": e(p)
                    }])
                }, [n("div", Ru, [h(Vt, {
                    class: "mx-auto",
                    type: "image"
                }, {
                    default: N(() => [at((l(), b("div", Mu, [n("img", {
                        src: `${e(a)}/main/banner-popup-ipl25.png?v=1`,
                        alt: "image bonus",
                        class: "popup"
                    }, null, 8, Vu), n("img", {
                        src: `${e(a)}/main/arrow-left.svg`,
                        alt: "arrow",
                        class: "arrow",
                        onClick: I
                    }, null, 8, Hu)])), [
                        [H, {
                            selector: "svg"
                        }]
                    ])]),
                    _: 1
                })])], 2))]))
            }
        }
    }),
    la = Q(Uu, [
        ["__scopeId", "data-v-07a6de81"]
    ]),
    Fu = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: la
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    So = {
        webManifest: {
            href: "/manifest.webmanifest"
        }
    },
    zu = oe({
        async setup() {
            if (So) {
                const t = ee({
                    link: []
                });
                Bo(t);
                const {
                    webManifest: o
                } = So;
                if (o) {
                    const {
                        href: a
                    } = o;
                    t.value.link.push({
                        rel: "manifest",
                        href: a
                    })
                }
            }
            return () => null
        }
    }),
    Gu = Z(() => v(() =>
        import ("./n2ZsJP0Z.js"), __vite__mapDeps([147, 148, 1, 2, 3, 4, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 154]),
        import.meta.url).then(t => t.default || t)),
    ju = Z(() => v(() =>
        import ("./DDfxgktf.js"), __vite__mapDeps([155, 148, 1, 2, 3, 4, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 156]),
        import.meta.url).then(t => t.default || t)),
    Wu = Z(() => v(() =>
        import ("./BBTJuk9E.js"), __vite__mapDeps([157, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 10, 102, 5, 85, 86, 103, 99, 100, 87, 104, 105, 106, 107, 110, 115, 116, 117, 118, 120, 90, 121, 93, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 96, 94, 95, 136, 137, 138, 139, 140, 141, 101, 142, 143, 144, 145, 158]),
        import.meta.url).then(t => t.default || t)),
    qu = Z(() => v(() =>
        import ("./Con5w9Nv.js"), __vite__mapDeps([159, 160, 1, 2, 3, 4, 161, 106, 107, 108, 109, 110, 162, 148, 111, 112, 113, 114, 149, 119, 150, 151, 152, 153, 102, 5, 85, 86, 70, 26, 163]),
        import.meta.url).then(t => t.default || t)),
    Zu = Z(() => v(() =>
        import ("./CQjX1EOx.js"), __vite__mapDeps([164, 148, 1, 2, 3, 4, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 165]),
        import.meta.url).then(t => t.default || t)),
    Ku = Z(() => v(() => Promise.resolve().then(() => Fu), void 0,
        import.meta.url).then(t => t.default || t)),
    Xu = Z(() => v(() => Promise.resolve().then(() => Du), void 0,
        import.meta.url).then(t => t.default || t)),
    Yu = Z(() => v(() =>
        import ("./Dl6fhmgd.js"), __vite__mapDeps([166, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 5, 167]),
        import.meta.url).then(t => t.default || t)),
    Qu = Z(() => v(() =>
        import ("./R8VBEcXg.js"), __vite__mapDeps([168, 148, 1, 2, 3, 4, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 5, 169]),
        import.meta.url).then(t => t.default || t)),
    Ju = Z(() => v(() =>
        import ("./DZajOfN7.js"), __vite__mapDeps([170, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 5, 171]),
        import.meta.url).then(t => t.default || t)),
    e_ = Z(() => v(() =>
        import ("./dIXRJP0J.js"), __vite__mapDeps([172, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 173]),
        import.meta.url).then(t => t.default || t)),
    t_ = Z(() => v(() =>
        import ("./B8XtuHhZ.js"), __vite__mapDeps([174, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 175, 176]),
        import.meta.url).then(t => t.default || t)),
    o_ = Z(() => v(() =>
        import ("./Cpwiiytk.js"), __vite__mapDeps([177, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 178]),
        import.meta.url).then(t => t.default || t)),
    a_ = Z(() => v(() =>
        import ("./Bm_sYv59.js"), __vite__mapDeps([179, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 10, 102, 5, 85, 86, 103, 99, 100, 87, 104, 105, 106, 107, 110, 115, 116, 117, 118, 120, 90, 121, 93, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 96, 94, 95, 136, 137, 138, 139, 140, 141, 101, 142, 143, 144, 145, 180]),
        import.meta.url).then(t => t.default || t)),
    n_ = Z(() => v(() =>
        import ("./CU7zahs2.js"), __vite__mapDeps([181, 148, 1, 2, 3, 4, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 5, 101, 86, 10, 102, 85, 103, 99, 100, 87, 104, 105, 106, 107, 110, 115, 116, 117, 118, 120, 90, 121, 93, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 96, 94, 95, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 182]),
        import.meta.url).then(t => t.default || t)),
    s_ = Z(() => v(() =>
        import ("./CKFe06ZD.js"), __vite__mapDeps([183, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 184]),
        import.meta.url).then(t => t.default || t)),
    r_ = Z(() => v(() =>
        import ("./Cfl1ekxD.js"), __vite__mapDeps([185, 148, 1, 2, 3, 4, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 5, 101, 86, 186]),
        import.meta.url).then(t => t.default || t)),
    i_ = Z(() => v(() =>
        import ("./CUjF8jWh.js"), __vite__mapDeps([187, 148, 1, 2, 3, 4, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 5, 188]),
        import.meta.url).then(t => t.default || t)),
    l_ = Z(() => v(() =>
        import ("./aKcxAXhf.js"), __vite__mapDeps([189, 10, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 5, 190]),
        import.meta.url).then(t => t.default || t)),
    c_ = Z(() => v(() =>
        import ("./CTGpGhpy.js"), __vite__mapDeps([191, 10, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 5, 192]),
        import.meta.url).then(t => t.default || t)),
    u_ = Z(() => v(() =>
        import ("./Uvn3IYz8.js"), __vite__mapDeps([193, 194, 2, 3, 1, 4, 195, 196, 87, 197, 95, 85, 86, 198, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 121, 93, 5, 199]),
        import.meta.url).then(t => t.default || t)),
    __ = {
        key: 0,
        class: "dialog-wrapper"
    },
    d_ = oe({
        __name: "CreateDialogs",
        props: {
            registerDialogs: {}
        },
        setup(t) {
            const o = t,
                {
                    dialogName: a,
                    dialogs: s
                } = Ee(),
                i = an({
                    info: Gu,
                    infoHistory: ju,
                    changeBalance: Wu,
                    bonus: qu,
                    bonusDetails: Zu,
                    bonusIPL: Ku,
                    bonusNew: Xu,
                    bonusDeposit: Yu,
                    cancelBonusDeposit: Qu,
                    confirm: Ju,
                    downTime: e_,
                    popupSlot: t_,
                    refresh: o_,
                    resetBalance: a_,
                    slotBonusBlock: n_,
                    subConfirm: s_,
                    wagerNoPossible: r_,
                    yesNoDialog: i_,
                    promoCodeActive: l_,
                    cancelBonus: c_,
                    bonusWelcomeChoose: u_
                });
            if (o.registerDialogs)
                for (const u in o.registerDialogs) i.value[u] = o.registerDialogs[u];
            const c = u => i.value[u];
            return (u, f) => e(a) ? (l(), b("div", __, [(l(!0), b(ve, null, Be(e(s), r => (l(), F(uo(c(r)), {
                key: "dialog-name-" + r
            }))), 128))])) : $("", !0)
        }
    }),
    p_ = Z(() => v(() =>
        import ("./qbrMoZvN.js"), __vite__mapDeps([200, 2, 3, 1, 4, 201, 135, 5, 96, 94, 95, 93, 136, 90, 161, 202, 10, 203, 101, 86, 194, 195, 204, 205, 85, 206, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 207, 208, 209, 210]),
        import.meta.url).then(t => t.default || t)),
    m_ = Z(() => v(() =>
        import ("./DS5eJvOG.js"), __vite__mapDeps([211, 212, 1, 2, 3, 4, 131, 93, 85, 86, 101]),
        import.meta.url).then(t => t.default || t)),
    f_ = Z(() => v(() =>
        import ("./jbIBlAba.js"), __vite__mapDeps([213, 212, 1, 2, 3, 4, 143, 85, 86]),
        import.meta.url).then(t => t.default || t)),
    h_ = Z(() => v(() =>
        import ("./D8uiyG0C.js"), __vite__mapDeps([214, 215, 1, 2, 3, 4, 127, 128, 10, 216, 5, 145, 25, 26, 70, 217, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 218, 219, 220, 221, 149, 150, 222]),
        import.meta.url).then(t => t.default || t)),
    v_ = Z(() => v(() =>
        import ("./_0nOH6tD.js"), __vite__mapDeps([223, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 224]),
        import.meta.url).then(t => t.default || t)),
    g_ = Z(() => v(() =>
        import ("./Bb8lP8E5.js"), __vite__mapDeps([225, 10, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 5, 127, 128, 219, 226]),
        import.meta.url).then(t => t.default || t)),
    b_ = Z(() => v(() =>
        import ("./DL2n32KB.js"), __vite__mapDeps([227, 1, 2, 3, 4, 215, 127, 128, 10, 216, 5, 145, 25, 26, 70, 217, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 218, 219, 220, 221, 130, 93, 126, 86, 125, 228, 149, 150, 229, 230, 85, 151, 152, 231]),
        import.meta.url).then(t => t.default || t)),
    y_ = Z(() => v(() =>
        import ("./DDaE8tja.js"), __vite__mapDeps([232, 1, 2, 3, 4, 220, 106, 107, 108, 109, 110, 70, 26, 151, 111, 112, 113, 114, 152, 233]),
        import.meta.url).then(t => t.default || t)),
    w_ = Z(() => v(() =>
        import ("./D6Sl1U58.js"), __vite__mapDeps([234, 10, 1, 2, 3, 4, 148, 111, 108, 112, 113, 109, 114, 149, 119, 150, 151, 152, 153, 85, 86, 5, 130, 93, 126, 235]),
        import.meta.url).then(t => t.default || t)),
    k_ = Z(() => v(() =>
        import ("./C7l1kI0L.js"), __vite__mapDeps([236, 90, 1, 2, 3, 4, 228, 93, 126, 86, 149, 119, 111, 108, 112, 113, 109, 114, 150, 151, 152, 237]),
        import.meta.url).then(t => t.default || t)),
    I_ = {
        class: "dialogs"
    },
    A_ = oe({
        __name: "CommonDialogs",
        setup(t) {
            const o = {
                search: p_,
                auth: m_,
                registration: f_,
                withdrawal: h_,
                withdrawalSuccess: v_,
                withdrawalAttentionBalance: g_,
                deposit: b_,
                depositRedirect: y_,
                depositCompleteAgain: w_,
                depositFailed: k_
            };
            return (a, s) => {
                const i = d_;
                return l(), b("div", I_, [h(i, {
                    "register-dialogs": o
                })])
            }
        }
    }),
    T_ = oe({
        __name: "CommonNotificationWrapper",
        setup(t) {
            const {
                messages: o
            } = za(), a = g(() => !!o.value);
            return (s, i) => {
                const c = mn;
                return e(a) ? (l(), F(c, Ut({
                    key: 0
                }, e(o), {
                    timeout: 6e3
                }), null, 16)) : $("", !0)
            }
        }
    }),
    C_ = Z(() => v(() =>
        import ("./HlOyknz0.js"), __vite__mapDeps([238, 134, 1, 2, 3, 4, 85, 86, 5, 239]),
        import.meta.url).then(t => t.default || t)),
    E_ = Z(() => v(() =>
        import ("./D3cdnUJq.js"), __vite__mapDeps([194, 2, 3, 1, 4, 195]),
        import.meta.url).then(t => t.default || t)),
    L_ = Z(() => v(() =>
        import ("./MH9nEjN2.js"), __vite__mapDeps([240, 1, 2, 3, 4, 5, 90, 103, 10, 99, 100, 132, 106, 107, 108, 109, 110, 115, 111, 112, 113, 114, 116, 133, 101, 86, 104, 126, 117, 118, 102, 85, 87, 105, 119, 120, 121, 93, 122, 123, 124, 125, 127, 128, 129, 130, 131, 134, 135, 96, 94, 95, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 241]),
        import.meta.url).then(t => t.default || t)),
    S_ = {
        class: "default-layout"
    },
    D_ = oe({
        __name: "default",
        setup(t) {
            var We, et, bo;
            du(), Kn();
            const o = ne(),
                a = _t(),
                {
                    layoutClasses: s,
                    isBlockedPage: i,
                    isNewYear: c,
                    loadChat: u
                } = iu(),
                f = Ke(),
                {
                    config: r
                } = Ze(),
                {
                    getSubdirUrlPart: d
                } = Oe(),
                {
                    loadSlotsForAllSections: _,
                    paramsToFetchBySection: p
                } = ho(),
                {
                    loaderGlobal: m,
                    drawerDisplay: T,
                    userGeo: E
                } = Y(be()),
                {
                    setStatistics: k,
                    updateUserStatisticsSend: y
                } = be(),
                {
                    trackButtonClick: I
                } = ye(),
                {
                    enabledLanguages: B
                } = ra(),
                {
                    isMobile: z,
                    isDesktop: X
                } = Ye(),
                {
                    userUUID: L
                } = Et(),
                {
                    fetchPaymentMethodsImages: H
                } = jo(),
                {
                    getSettings: U,
                    getAdditionalSettings: R,
                    fetchMirrorsList: w
                } = At(),
                P = ta(),
                {
                    googleSsoInit: C
                } = sn(),
                A = Ne(),
                {
                    isAuthenticated: S,
                    setTokenDataUser: G
                } = Te(),
                {
                    getDiffDates: q,
                    dayjs: M
                } = Wa(),
                {
                    displayDialog: j
                } = Ga(),
                {
                    onTriggerSmartico: te
                } = fu(),
                {
                    loginToken: se
                } = Y(At()),
                {
                    showTimer: de
                } = Y(xe()),
                {
                    fetchWelcomeBonuses: ue,
                    setTimeForBonus: ge,
                    showTimerForBonus: st,
                    fetchBonusesList: Re
                } = xe(),
                {
                    updateHashLink: Le,
                    updateCluster: Se
                } = At(),
                {
                    authByToken: ft,
                    getPlayerMe: rt,
                    getPlayerBalance: jt,
                    authByHash: Lt,
                    clearData: St
                } = he(),
                {
                    userCurrency: it,
                    profileForm: ke,
                    userRegBonusCode: Dt
                } = Y(he()),
                {
                    checkAllAndSaveAllAffiliateIds: Qe
                } = ss(),
                {
                    setPostRoute: lt
                } = wo(),
                {
                    scrollToTop: Bt
                } = On(),
                {
                    bonusesCurrencyByGeo: ht
                } = zo(),
                {
                    openDialog: ct,
                    dialogName: Wt
                } = Ee(),
                {
                    isCurrentUrlIsProhibited: qt,
                    moveUserToProperMirror: Zt,
                    allMirrors: vt
                } = Un(),
                {
                    checkBannerTrigger: gt
                } = Nn(),
                {
                    changeLoadedChatSupport: Kt
                } = be(),
                {
                    onUpdatePlayASlots: Xt
                } = wo(),
                D = ee(!1),
                J = () => {
                    D.value || (u(), Kt(!0), D.value = !0)
                };

            function ie() {
                const {
                    hash: V
                } = o;
                if (V && V.startsWith("#redirectTo=")) {
                    const W = V.replace("#redirectTo=", "");
                    switch (W) {
                        case "rewards":
                            te();
                            break;
                        case "deposit":
                            I({
                                category: "deposit_popup",
                                action: "view_paywall",
                                label: ce.LINK
                            }), Pe(ce.LINK), ct("deposit");
                            break;
                        default:
                            a.push({
                                path: `/${W}`
                            });
                            break
                    }
                    const [fe] = window.location.href.split("#redirectTo=");
                    window.history.replaceState(null, "", fe)
                }
            }
            ie();
            const we = le(() => vt.value, V => {
                    V && (S.value && Zt(), we())
                }),
                Ie = () => {
                    var V, W, fe;
                    if ((V = o.query) != null && V.slot_id) lt(A(`/casino/slot/${(W=o.query)==null?void 0:W.slot_id}`));
                    else switch ((fe = o.query) == null ? void 0 : fe.to) {
                        case "casino":
                            lt(A("/casino"));
                            break;
                        default:
                            lt(A("/profile/deposit-withdraw"));
                            break
                    }
                };

            function Je() {
                let V = null,
                    W = !0;
                const fe = E.value === "IN";
                if (fe && !S.value ? V = me("first").value : V = me("newReg").value, !V) return;
                const pe = q(V) * 1e3;
                if (fe && !S.value ? W = pe && pe > 0 : W = S.value && pe && pe > 0, W) {
                    const tt = pe + De.ADDITIONAL_BANNER_TIME > De.MAX_VALUE_FOR_TIMEOUT ? De.MAX_VALUE_FOR_TIMEOUT : pe + De.ADDITIONAL_BANNER_TIME;
                    ge(pe), st(!0), setTimeout(() => st(!1), tt)
                }
            }

            function Yt() {
                ht.value && H(ht.value)
            }

            function bt(V) {
                if (!window.dataLayer) return;
                const W = me("userId", {
                    maxAge: 60 * 60 * 24 * 7,
                    path: "/",
                    secure: !0,
                    sameSite: "none"
                });
                V === "logout" && (W.value = null)
            }
            const $t = ["/", "live", "line", "sports", "casino", "live-dealers", "tv-games", "virtual-sport"],
                He = g(() => o.path.split("/")[2] === "cricket"),
                $e = g(() => {
                    var W, fe, pe;
                    let V;
                    return E.value === "IN" && !S.value ? V = de.value : V = !["BD", "PH"].includes(E.value) && S.value && de.value && Number((pe = (fe = (W = ke == null ? void 0 : ke.value) == null ? void 0 : W.balance) == null ? void 0 : fe.total_deposit) == null ? void 0 : pe.amount) === 0, V
                }),
                Ue = g(() => {
                    var V;
                    return ((V = r.value) == null ? void 0 : V.IS_IPL) && ["IN", "BD"].includes(E.value)
                }),
                Fe = g(() => $t.includes(d(0)) && d(1) !== "slot" && !He.value && $e.value),
                _e = me("newReg", {
                    path: "/",
                    maxAge: 60 * 60
                });
            o.query.newReg && !_e.value && (_e.value = new Date);
            async function ze() {
                var qe;
                (qe = r.value) != null && qe.APP_WITH_CAPTCHA && await R();
                const V = localStorage == null ? void 0 : localStorage.getItem("postRegisterRedirect");
                V && (await a.push(V), localStorage == null || localStorage.removeItem("postRegisterRedirect"));
                const W = o.query.redirect_host,
                    fe = me("redirect_host");
                if (W && !fe.value && (fe.value = W), se.value) try {
                    await St({
                        place: "login_token"
                    });
                    const ot = await ft(),
                        Pt = new URL(window.location.href);
                    Pt.searchParams.delete("login"), history.replaceState(history.state, "", Pt.href), ot && G(ot), L.value || await rt()
                } catch {
                    console.error("me is invalid data")
                }
                if (S.value && qt.value && ![`https://${De.DEFAULT_DOMAIN_DEV}`, `https://${De.BASE_DOMAIN}`, `https://${De.MIRROR_DOMAIN}`, `https://${De.DEFAULT_DOMAIN_STAGE}`].includes(f.app.fullDomain) && f.public.env.NUXT_ENV_ENVIRONMENT === "prod") try {
                    await Lt()
                } catch {
                    console.error("authByHash is invalid data")
                }
                S.value || (C(), k());
                const pe = me("first");
                if (E.value === "IN" && !S.value) {
                    const ot = M().add(1, "h");
                    pe.value || (pe.value = ot.toString())
                }
                S.value && (await rt(), await jt(), pe.value && (pe.value = null)), Qe(), Ie(), ["/profile/bonuses", "/profile/deposit-withdraw", "/profile/history", "/profile"].includes(o.path) && !S.value && j("auth"), Ie(), _o(() => {
                    Je()
                })
            }
            async function Ge() {
                var fe, pe, tt;
                const V = ["show_reg", "show_reg_1", "show_reg_2", "show_reg_3", "show_reg_5", "show_reg_6"],
                    {
                        query: W
                    } = o;
                if (V.find(qe => W.hasOwnProperty(qe)) && !W.gsp && (Qe(), S.value || j("registration", {
                        currency: W == null ? void 0 : W.val_cur
                    })), W.auth && !W.gsp && (Qe(), S.value || j("auth")), (W.deposit || W.withdraw) && (S.value ? W.deposit ? (I({
                        category: "deposit_popup",
                        action: "view_paywall",
                        label: ce.LINK
                    }), Pe(ce.LINK), ct("deposit")) : ct("withdrawal") : j("auth")), W.bonus, W.slot_id && (S.value ? await a.push(A(`/casino/slot/${(pe=o.query)==null?void 0:pe.slot_id}`)) : j("registration", {
                        currency: (fe = o.query) == null ? void 0 : fe.val_cur
                    })), W.welcomeme) {
                    const qe = !!me("no_deposit_dialog").value;
                    if ((tt = r.value) != null && tt.OFF_BONUS_DEPOSIT) {
                        if (qe) return;
                        Pe(ce.WELCOME_TOOL), I({
                            category: "deposit_popup",
                            action: "view_paywall",
                            label: ce.WELCOME_TOOL
                        }), ct("deposit");
                        return
                    }
                    j("bonusDeposit")
                }
            }
            le(() => o.query, () => Ge()), le(() => Wt.value, (V, W) => {
                W === "deposit" && !V && setTimeout(() => {
                    gt()
                }, 0)
            }), le(() => Dt.value, V => {
                V !== null && P(V)
            }), le(() => S.value, (V, W) => {
                V !== W && Je(), V ? (Yt(), U().then(() => Bt()), ["/", "/bonuses"].includes(A(o.path)) || Re(je.value)) : Xt({
                    isDesktop: X.value,
                    isMobile: z.value
                })
            }), le(() => {
                var V, W;
                return (W = (V = ke.value) == null ? void 0 : V.info) == null ? void 0 : W.currency
            }, (V, W) => {
                V !== W && V && (y(!1), k())
            }), le(() => {
                var V, W;
                return (W = (V = ke.value) == null ? void 0 : V.meta) == null ? void 0 : W.mirror_id
            }, (V, W) => {
                V !== W && S.value && w()
            }), le(() => L.value, V => {
                {
                    if (V) {
                        bt("login");
                        return
                    }
                    bt("logout")
                }
            }, {
                immediate: !0
            }), le(T, V => {
                const W = document.documentElement;
                W.style.overflow = V ? "hidden" : "auto"
            }), o.query.cc && Se(o.query.cc), o.query.login && (!S.value || !((bo = (We = me("login")) == null ? void 0 : We.value) != null && bo.includes((et = o.query) == null ? void 0 : et.login))) && Le(o.query.login);
            const je = g(() => it != null && it.value ? it.value : ht.value);
            return Ce(async () => {
                o.query.redirect_event_place && Pe(o.query.redirect_event_place), U(), ue(je.value), _({
                    desktop: p.value.desktop,
                    mobile: p.value.mobile
                }), await ze(), await Ge(), gt()
            }), Fo(() => {
                Le(null)
            }), (V, W) => {
                const fe = C_,
                    pe = E_,
                    tt = vs,
                    qe = L_,
                    ot = ii,
                    Pt = qa,
                    ca = ku,
                    ua = ia,
                    _a = la,
                    da = mo,
                    pa = zu,
                    ma = A_,
                    fa = T_;
                return l(), F(ja, {
                    class: K(e(s)),
                    dark: ""
                }, {
                    default: N(() => [e(i) ? (l(), F(fe, {
                        key: 0
                    })) : at((l(), F(ds, {
                        key: 1,
                        class: K({
                            main_page: !0,
                            "main_page__new-year": e(c)
                        }),
                        onClickOnce: J
                    }, {
                        default: N(() => [n("div", S_, [e(m) ? (l(), F(pe, {
                            key: 0
                        })) : $("", !0), h(tt), e(z) && e(T) ? (l(), F(qe, {
                            key: 1
                        })) : $("", !0), h(ot, {
                            langs: e(B)
                        }, null, 8, ["langs"]), h(ca, {
                            "is-blocked-page": e(i)
                        }, {
                            default: N(() => [V.$slots.error ? Ct(V.$slots, "error", {
                                key: 0
                            }, void 0, !0) : (l(), F(Pt, {
                                key: 1
                            }))]),
                            _: 3
                        }, 8, ["is-blocked-page"])]), h(da, null, {
                            default: N(() => [e(Fe) && !e(Ue) ? (l(), F(ua, {
                                key: 0
                            })) : $("", !0), e(Fe) && e(Ue) ? (l(), F(_a, {
                                key: 1
                            })) : $("", !0)]),
                            _: 1
                        }), h(pa), h(ma), h(fa)]),
                        _: 3
                    }, 8, ["class"])), [
                        [cs, J]
                    ])]),
                    _: 3
                }, 8, ["class"])
            }
        }
    }),
    B_ = Q(D_, [
        ["__scopeId", "data-v-517edf3b"]
    ]),
    f1 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: B_
    }, Symbol.toStringTag, {
        value: "Module"
    }));
export {
    Vt as V, f1 as _, so as a, rs as b, iu as u
};