import {
    _ as t
} from "./BbvgifQp.js";
import {
    _ as o,
    V as r,
    $ as s
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "06438a8e-13e5-469b-9255-9c59140847a9", e._sentryDebugIdIdentifier = "sentry-dbid-06438a8e-13e5-469b-9255-9c59140847a9")
    } catch {}
})();
const a = {},
    c = {
        class: "casino-wrapper"
    };

function d(e, n) {
    return r(), o("div", c, [s(e.$slots, "default")])
}
const l = t(a, [
    ["render", d]
]);
export {
    l as _
};