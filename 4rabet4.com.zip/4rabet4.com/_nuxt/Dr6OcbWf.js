import {
    c as i
} from "./1xKHoBf3.js";
import {
    b as c,
    o as f
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "4dcc3b61-8e2b-4e45-a1a9-9ad664e27085", e._sentryDebugIdIdentifier = "sentry-dbid-4dcc3b61-8e2b-4e45-a1a9-9ad664e27085")
    } catch {}
})();

function l(e, n = [], s = !1) {
    const t = c(!1);
    if (!e) return {
        isMatch: t
    };
    const o = r => {
        n.forEach(d => d({
            value: r
        }))
    };
    t.value = e.matches, s && o(t.value);
    const a = r => {
        t.value = r.matches, o(t.value)
    };
    return e.addEventListener ? e.addEventListener("change", a) : e.addListener(a), f(() => {
        e.removeEventListener ? e.removeEventListener("change", a) : e.removeListener(a)
    }), {
        isMatch: t
    }
}
const v = (e, n = !1) => {
    const s = i("min");
    return s ? l(s, e, n) : {
        isMatch: c(!1)
    }
};
export {
    v as u
};