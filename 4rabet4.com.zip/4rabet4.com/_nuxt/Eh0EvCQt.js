import {
    u as I,
    v as c,
    w as d,
    T as l,
    a as g
} from "./BbvgifQp.js";
import {
    d as t
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "345ba371-8161-405b-80c9-f7c9271df3a6", e._sentryDebugIdIdentifier = "sentry-dbid-345ba371-8161-405b-80c9-f7c9271df3a6")
    } catch {}
})();
const r = {
    BR: "BR",
    MM: "MM",
    IN: "HI",
    BD: "HI",
    CM: "CM",
    KE: "KE",
    UG: "UG",
    CI: "CI",
    TG: "TG",
    MZ: "MZ",
    BF: "BF",
    TZ: "TZ",
    ZM: "ZM",
    BI: "BI",
    RW: "RW",
    GH: "GH",
    ZA: "ZA",
    PH: "PH",
    LK: "LK",
    NP: "NP",
    CD: "CD"
};

function D() {
    const e = g(),
        {
            config: n
        } = I(),
        o = t(() => e.app.imagesUrl),
        f = t(() => l(e.app.fullDomain)),
        i = t(() => {
            var a, u;
            const {
                userGeo: s
            } = c(d());
            return (a = n.value) != null && a.IS_IPL && ["IN", "BD"].includes(s.value) ? "IPL25" : (u = n.value) != null && u.IS_ICC && ["IN", "BD"].includes(s.value) ? "ICC" : s.value && s.value in r ? r[s.value] : "old"
        });
    return {
        imageUrl: o,
        getCorrectDomain: f,
        authBannersByGeo: i
    }
}
export {
    D as u
};