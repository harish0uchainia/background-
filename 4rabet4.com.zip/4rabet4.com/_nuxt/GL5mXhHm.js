import {
    z as h,
    _ as n,
    V as s,
    a0 as t,
    a8 as f,
    a6 as B,
    d as $,
    b as G,
    u as i,
    F as s2,
    D as l,
    W as w,
    a1 as p,
    a7 as g,
    aa as l2
} from "./BBZLTf3A.js";
import {
    _ as u,
    u as r2,
    bB as f2,
    z as _2,
    h as c2,
    C as d2,
    t as C2,
    n as v2,
    g as p2,
    f as u2,
    v as Z,
    w as m2,
    c as h2,
    j as b2,
    E as g2,
    S as B2,
    bl as w2,
    bm as x2
} from "./BbvgifQp.js";
import {
    _ as y2
} from "./C2rNhci2.js";
import {
    _ as M2
} from "./CyEI51nD.js";
import {
    u as k2
} from "./Cc4FcFuq.js";
import {
    u as I2
} from "./Eh0EvCQt.js";
import {
    a as S2
} from "./DpA9PCri.js";
import {
    u as $2
} from "./BMZwzS6C.js";
import "./1xKHoBf3.js";
import "./DVkCUlFY.js";
import "./BtdAVlWx.js";
import "./CBbqpxnU.js";
import "./CIAn7tHz.js";
import "./CCvy_w1-.js";
import "./DDGpYvNX.js";
import "./CNgVgUb9.js";
import "./BulKdswA.js";
import "./CbxP4vag.js";
import "./BEPDeFGu.js";
import "./D9sqA5Xl.js";
import "./Q3GHUzCg.js";
import "./B9YIqgoQ.js";
import "./iTYf75jB.js";
import "./BQ7ou4ZQ.js";
import "./Ka2RWjod.js";
import "./BGM-8W5I.js";
import "./D5xT9ef6.js";
import "./Bm6Ktnmy.js";
import "./BX3KejHb.js";
import "./CbNZPVTM.js";
import "./WQ5Cu1Fz.js";
import "./7NJYkLaL.js";
import "./C_Bf1-bi.js";
import "./BGjWZMuE.js";
import "./sSbT21OI.js";
import "./Cz0MIU54.js";
import "./Dg0yrPgw.js";
import "./BytmlzwF.js";
import "./CRXlgDsv.js";
import "./D_nsTU_t.js";
import "./CNVksA_o.js";
import "./C4K-6MHn.js";
import "./CVtksJDb.js";
import "./DcEoWEM3.js";
import "./Bhe_kv2Z.js";
import "./BQ66EBJG.js";
import "./BUXbqDP0.js";
import "./B9BXWkrE.js";
import "./B99ZEpuR.js";
(function() {
    try {
        var r = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            e = new r.Error().stack;
        e && (r._sentryDebugIds = r._sentryDebugIds || {}, r._sentryDebugIds[e] = "3bfc0ffc-d7a9-4857-9618-d0e5c95951ee", r._sentryDebugIdIdentifier = "sentry-dbid-3bfc0ffc-d7a9-4857-9618-d0e5c95951ee")
    } catch {}
})();
const A2 = {
        class: "icon",
        xmlns: "http://www.w3.org/2000/svg",
        width: "56",
        height: "56",
        viewBox: "0 0 56 56",
        fill: "none"
    },
    D2 = ["filter"],
    L2 = ["fill"],
    V2 = {
        key: 0
    },
    F2 = h({
        __name: "IconMain",
        props: {
            active: {
                type: Boolean
            }
        },
        setup(r) {
            return (e, a) => (s(), n("svg", A2, [t("g", {
                filter: e.active ? "url(#filter0_d_21650_46735)" : ""
            }, [t("path", {
                d: "M24.4444 20H22.6667C22.3166 20.0001 21.97 20.0693 21.6468 20.2037C21.3235 20.338 21.03 20.535 20.7831 20.7831C20.535 21.03 20.338 21.3235 20.2037 21.6468C20.0693 21.97 20.0001 22.3166 20 22.6667V24.4444C20 25.1778 20.2996 25.8444 20.7831 26.328C21.03 26.5762 21.3235 26.7731 21.6468 26.9075C21.97 27.0419 22.3166 27.111 22.6667 27.1111H24.4444C24.7945 27.111 25.1411 27.0419 25.4643 26.9075C25.7876 26.7731 26.0811 26.5762 26.328 26.328C26.5762 26.0811 26.7731 25.7876 26.9075 25.4643C27.0419 25.1411 27.111 24.7945 27.1111 24.4444V22.6667C27.111 22.3166 27.0419 21.97 26.9075 21.6468C26.7731 21.3235 26.5762 21.03 26.328 20.7831C26.0811 20.535 25.7876 20.338 25.4643 20.2037C25.1411 20.0693 24.7945 20.0001 24.4444 20ZM33.3333 20H31.5556C31.2055 20.0001 30.8589 20.0693 30.5356 20.2037C30.2124 20.338 29.9189 20.535 29.672 20.7831C29.4238 21.03 29.2269 21.3235 29.0925 21.6468C28.9581 21.97 28.889 22.3166 28.8889 22.6667V24.4444C28.8889 25.1778 29.1884 25.8444 29.672 26.328C29.9189 26.5762 30.2124 26.7731 30.5356 26.9075C30.8589 27.0419 31.2055 27.111 31.5556 27.1111H33.3333C33.6834 27.111 34.03 27.0419 34.3532 26.9075C34.6764 26.7731 34.97 26.5762 35.2169 26.328C35.4651 26.0811 35.662 25.7876 35.7964 25.4643C35.9308 25.1411 35.9999 24.7945 36 24.4444V22.6667C35.9999 22.3166 35.9308 21.97 35.7964 21.6468C35.662 21.3235 35.4651 21.03 35.2169 20.7831C34.97 20.535 34.6764 20.338 34.3532 20.2037C34.03 20.0693 33.6834 20.0001 33.3333 20ZM24.4444 28.8889H22.6667C22.3166 28.889 21.97 28.9581 21.6468 29.0925C21.3235 29.2269 21.03 29.4238 20.7831 29.672C20.535 29.9189 20.338 30.2124 20.2037 30.5356C20.0693 30.8589 20.0001 31.2055 20 31.5556V33.3333C20 34.0667 20.2996 34.7333 20.7831 35.2169C21.03 35.4651 21.3235 35.662 21.6468 35.7964C21.97 35.9308 22.3166 35.9999 22.6667 36H24.4444C24.7945 35.9999 25.1411 35.9308 25.4643 35.7964C25.7876 35.662 26.0811 35.4651 26.328 35.2169C26.5762 34.97 26.7731 34.6764 26.9075 34.3532C27.0419 34.03 27.111 33.6834 27.1111 33.3333V31.5556C27.111 31.2055 27.0419 30.8589 26.9075 30.5356C26.7731 30.2124 26.5762 29.9189 26.328 29.672C26.0811 29.4238 25.7876 29.2269 25.4643 29.0925C25.1411 28.9581 24.7945 28.889 24.4444 28.8889ZM33.3333 28.8889H31.5556C31.2055 28.889 30.8589 28.9581 30.5356 29.0925C30.2124 29.2269 29.9189 29.4238 29.672 29.672C29.4238 29.9189 29.2269 30.2124 29.0925 30.5356C28.9581 30.8589 28.889 31.2055 28.8889 31.5556V33.3333C28.8889 34.0667 29.1884 34.7333 29.672 35.2169C29.9189 35.4651 30.2124 35.662 30.5356 35.7964C30.8589 35.9308 31.2055 35.9999 31.5556 36H33.3333C33.6834 35.9999 34.03 35.9308 34.3532 35.7964C34.6764 35.662 34.97 35.4651 35.2169 35.2169C35.4651 34.97 35.662 34.6764 35.7964 34.3532C35.9308 34.03 35.9999 33.6834 36 33.3333V31.5556C35.9999 31.2055 35.9308 30.8589 35.7964 30.5356C35.662 30.2124 35.4651 29.9189 35.2169 29.672C34.97 29.4238 34.6764 29.2269 34.3532 29.0925C34.03 28.9581 33.6834 28.889 33.3333 28.8889Z",
                fill: e.active ? "#ffffff" : "#A9C6ED"
            }, null, 8, L2)], 8, D2), e.active ? (s(), n("defs", V2, a[0] || (a[0] = [B('<filter id="filter0_d_21650_46735" x="-1" y="-1" width="58" height="58" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB" data-v-7fbf99a7><feFlood flood-opacity="0" result="BackgroundImageFix" data-v-7fbf99a7></feFlood><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" data-v-7fbf99a7></feColorMatrix><feOffset data-v-7fbf99a7></feOffset><feGaussianBlur stdDeviation="10" data-v-7fbf99a7></feGaussianBlur><feComposite in2="hardAlpha" operator="out" data-v-7fbf99a7></feComposite><feColorMatrix type="matrix" values="0 0 0 0 0.504167 0 0 0 0 0.715625 0 0 0 0 1 0 0 0 1 0" data-v-7fbf99a7></feColorMatrix><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_21650_46735" data-v-7fbf99a7></feBlend><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_21650_46735" result="shape" data-v-7fbf99a7></feBlend></filter>', 1)]))) : f("", !0)]))
        }
    }),
    H2 = u(F2, [
        ["__scopeId", "data-v-7fbf99a7"]
    ]),
    O2 = {
        key: 0,
        class: "icon",
        xmlns: "http://www.w3.org/2000/svg",
        width: "52",
        height: "12",
        viewBox: "0 0 52 12",
        fill: "none"
    },
    G2 = ["filter"],
    Z2 = ["fill"],
    E2 = {
        id: "filter0_d_22239_136",
        x: "0",
        y: "0",
        width: "52",
        height: "22",
        filterUnits: "userSpaceOnUse",
        "color-interpolation-filters": "sRGB"
    },
    R2 = {
        key: 0,
        type: "matrix",
        values: "0 0 0 0 1 0 0 0 0 0 0 0 0 0 0.239216 0 0 0 1 0"
    },
    U2 = {
        key: 1,
        type: "matrix",
        values: "0 0 0 0 0.505882 0 0 0 0 0.713726 0 0 0 0 1 0 0 0 1 0"
    },
    N2 = h({
        __name: "IconLine",
        props: {
            active: {
                type: Boolean
            },
            color: {}
        },
        setup(r) {
            return (e, a) => e.active ? (s(), n("svg", O2, [t("g", {
                filter: e.active ? "url(#filter0_d_22239_136)" : ""
            }, [t("path", {
                d: "M10 12C10 10.8954 10.8954 10 12 10H40C41.1046 10 42 10.8954 42 12H10Z",
                fill: e.color || "#fff"
            }, null, 8, Z2)], 8, G2), t("defs", null, [t("filter", E2, [a[0] || (a[0] = t("feFlood", {
                "flood-opacity": "0",
                result: "BackgroundImageFix"
            }, null, -1)), a[1] || (a[1] = t("feColorMatrix", { in: "SourceAlpha",
                type: "matrix",
                values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                result: "hardAlpha"
            }, null, -1)), a[2] || (a[2] = t("feOffset", null, null, -1)), a[3] || (a[3] = t("feGaussianBlur", {
                stdDeviation: "5"
            }, null, -1)), a[4] || (a[4] = t("feComposite", {
                in2: "hardAlpha",
                operator: "out"
            }, null, -1)), e.color === "#FF003D" ? (s(), n("feColorMatrix", R2)) : (s(), n("feColorMatrix", U2)), a[5] || (a[5] = t("feBlend", {
                mode: "normal",
                in2: "BackgroundImageFix",
                result: "effect1_dropShadow_22239_136"
            }, null, -1)), a[6] || (a[6] = t("feBlend", {
                mode: "normal",
                in: "SourceGraphic",
                in2: "effect1_dropShadow_22239_136",
                result: "shape"
            }, null, -1))])])])) : f("", !0)
        }
    }),
    T2 = u(N2, [
        ["__scopeId", "data-v-c28e4e86"]
    ]),
    z2 = {
        width: "58",
        height: "54",
        viewBox: "0 0 58 54",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        class: "icon"
    },
    P2 = ["filter"],
    W2 = {
        "clip-path": "url(#clip0_28451_562)"
    },
    Y2 = ["fill"],
    j2 = ["fill"],
    q2 = ["fill"],
    Q2 = {
        key: 0
    },
    J2 = h({
        __name: "IconSports",
        props: {
            active: {
                type: Boolean
            }
        },
        setup(r) {
            return (e, a) => (s(), n("svg", z2, [t("g", {
                filter: e.active ? "url(#filter0_d_28451_562)" : ""
            }, [t("g", W2, [t("path", {
                d: "M29 29.2852C30.2621 29.2852 31.2852 28.2621 31.2852 27C31.2852 25.7379 30.2621 24.7148 29 24.7148C27.7379 24.7148 26.7148 25.7379 26.7148 27C26.7148 28.2621 27.7379 29.2852 29 29.2852Z",
                fill: e.active ? "#ffffff" : "#A9C6ED"
            }, null, 8, Y2), t("path", {
                d: "M35.5391 24.8906V29.1094C35.5391 29.156 35.5576 29.2007 35.5905 29.2337C35.6235 29.2666 35.6682 29.2852 35.7148 29.2852H38V24.7148H35.7148C35.6682 24.7148 35.6235 24.7334 35.5905 24.7663C35.5576 24.7993 35.5391 24.844 35.5391 24.8906ZM28.4727 30.298C27.6882 30.1727 26.974 29.7718 26.4585 29.1673C25.943 28.5629 25.6598 27.7944 25.6598 27C25.6598 26.2056 25.943 25.4371 26.4585 24.8327C26.974 24.2282 27.6882 23.8273 28.4727 23.702V20.1445H21.2305C20.9041 20.1445 20.5912 20.2742 20.3604 20.5049C20.1296 20.7357 20 21.0487 20 21.375V23.6602H22.2852C22.4467 23.6602 22.6067 23.692 22.756 23.7538C22.9053 23.8157 23.041 23.9063 23.1552 24.0206C23.2695 24.1348 23.3601 24.2705 23.422 24.4197C23.4838 24.569 23.5156 24.729 23.5156 24.8906V29.1094C23.5156 29.271 23.4838 29.431 23.422 29.5803C23.3601 29.7295 23.2695 29.8652 23.1552 29.9794C23.041 30.0937 22.9053 30.1843 22.756 30.2462C22.6067 30.308 22.4467 30.3398 22.2852 30.3398H20V32.625C20 32.9513 20.1296 33.2643 20.3604 33.4951C20.5912 33.7258 20.9041 33.8555 21.2305 33.8555H28.4727V30.298Z",
                fill: e.active ? "#ffffff" : "#A9C6ED"
            }, null, 8, j2), t("path", {
                d: "M35.7148 30.3398C35.3885 30.3398 35.0755 30.2102 34.8448 29.9794C34.614 29.7487 34.4844 29.4357 34.4844 29.1094V24.8906C34.4844 24.5643 34.614 24.2513 34.8448 24.0206C35.0755 23.7898 35.3885 23.6602 35.7148 23.6602H38V21.375C38 21.0487 37.8704 20.7357 37.6396 20.5049C37.4088 20.2742 37.0959 20.1445 36.7695 20.1445H29.5273V23.702C30.3118 23.8273 31.026 24.2282 31.5415 24.8327C32.057 25.4371 32.3402 26.2056 32.3402 27C32.3402 27.7944 32.057 28.5629 31.5415 29.1673C31.026 29.7718 30.3118 30.1727 29.5273 30.298V33.8555H36.7695C37.0959 33.8555 37.4088 33.7258 37.6396 33.4951C37.8704 33.2643 38 32.9513 38 32.625V30.3398H35.7148ZM22.4609 29.1094V24.8906C22.4609 24.844 22.4424 24.7993 22.4095 24.7663C22.3765 24.7334 22.3318 24.7148 22.2852 24.7148H20V29.2852H22.2852C22.3318 29.2852 22.3765 29.2666 22.4095 29.2337C22.4424 29.2007 22.4609 29.156 22.4609 29.1094Z",
                fill: e.active ? "#ffffff" : "#A9C6ED"
            }, null, 8, q2)])], 8, P2), e.active ? (s(), n("defs", Q2, a[0] || (a[0] = [B('<filter id="filter0_d_28451_562" x="0" y="-2" width="58" height="58" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB" data-v-4739f32a><feFlood flood-opacity="0" result="BackgroundImageFix" data-v-4739f32a></feFlood><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" data-v-4739f32a></feColorMatrix><feOffset data-v-4739f32a></feOffset><feGaussianBlur stdDeviation="10" data-v-4739f32a></feGaussianBlur><feComposite in2="hardAlpha" operator="out" data-v-4739f32a></feComposite><feColorMatrix type="matrix" values="0 0 0 0 0.504167 0 0 0 0 0.715625 0 0 0 0 1 0 0 0 1 0" data-v-4739f32a></feColorMatrix><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_28451_562" data-v-4739f32a></feBlend><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_28451_562" result="shape" data-v-4739f32a></feBlend></filter><clipPath id="clip0_28451_562" data-v-4739f32a><rect width="18" height="14" fill="white" transform="translate(20 20)" data-v-4739f32a></rect></clipPath>', 2)]))) : f("", !0)]))
        }
    }),
    K2 = u(J2, [
        ["__scopeId", "data-v-4739f32a"]
    ]),
    X2 = {
        class: "icon",
        xmlns: "http://www.w3.org/2000/svg",
        width: "58",
        height: "56",
        viewBox: "0 0 58 56",
        fill: "none"
    },
    t3 = ["filter"],
    o3 = ["fill"],
    e3 = {
        key: 0
    },
    a3 = h({
        __name: "IconScoreboard",
        props: {
            active: {
                type: Boolean
            }
        },
        setup(r) {
            return (e, a) => (s(), n("svg", X2, [t("g", {
                filter: e.active ? "url(#filter0_d_21650_46737)" : ""
            }, [t("path", {
                d: "M37.85 22.7048L36.3499 21.5418C36.2367 21.4542 36.0844 21.4395 35.9576 21.5054C35.8309 21.5713 35.7506 21.7054 35.7506 21.852V25.3278C34.4718 24.9285 32.6086 24.7377 31.1055 24.6478L30.9017 24.6246H30.6817C30.6817 24.6246 29.3661 24.5742 29.0001 24.5695V23.5973L30.3502 22.5506C30.4447 22.4777 30.5002 22.3622 30.5002 22.2404C30.5002 22.1187 30.4447 22.0032 30.3502 21.9303L28.85 20.7673C28.7375 20.6789 28.5845 20.6657 28.4578 20.7308C28.3303 20.7967 28.25 20.9309 28.25 21.0774V24.5695C27.884 24.575 27.2255 24.6217 26.5684 24.6246C26.464 24.6251 26.4295 24.6198 26.3451 24.6246C26.2638 24.6292 26.1446 24.6479 26.1446 24.6479C26.1446 24.6479 21.939 25.0169 20.7494 25.6225V24.3718L22.0995 23.3251C22.1947 23.2523 22.2495 23.1367 22.2495 23.015C22.2495 22.8933 22.194 22.7777 22.0995 22.7049L20.5994 21.5419C20.4861 21.4542 20.3353 21.4395 20.2071 21.5054C20.0803 21.5713 20 21.7055 20 21.852V26.504C20 26.5133 20.0007 26.5289 20.0023 26.5467L20.7478 33.4821C20.7478 34.6816 23.7053 35.1382 25.9982 35.3127V32.7068C25.9982 32.0655 26.503 31.5438 27.1233 31.5438H30.1236C30.7439 31.5438 31.2487 32.0655 31.2487 32.7068V35.315C33.5416 35.1444 36.4984 34.697 36.4969 33.5247L37.2402 26.611C37.2402 26.6079 37.2409 26.6041 37.2409 26.601C37.2424 26.5831 37.2447 26.5645 37.2462 26.5475C37.2477 26.5296 37.2484 26.5141 37.2484 26.5048C37.2484 26.1497 36.9634 25.8598 36.4983 25.6233V24.3726L37.85 23.3252C37.9445 23.2523 38 23.1368 38 23.015C38 22.8932 37.9446 22.7777 37.85 22.7048ZM20.7651 26.5071C20.8881 26.3334 21.4101 26.1125 22.2997 25.9086C22.3102 25.9295 22.3162 25.952 22.3305 25.9706L23.3618 27.3034C21.8152 27.0568 20.9226 26.7358 20.7651 26.5071ZM24.4186 27.4453C24.4089 27.429 24.4051 27.4088 24.3924 27.3925L23.118 25.7457C23.9243 25.6062 24.9212 25.486 26.107 25.4139L26.6898 27.622C25.8483 27.5841 25.0907 27.522 24.4186 27.4453ZM29.7741 27.6508C29.6848 27.6531 29.6001 27.657 29.5093 27.6585C29.222 27.6639 28.9273 27.667 28.6243 27.667C28.3205 27.667 28.025 27.664 27.7369 27.6585C27.6469 27.6569 27.5629 27.6531 27.4744 27.6508L26.8743 25.3759C27.4241 25.3534 28.0069 25.341 28.6243 25.341C29.2415 25.341 29.8243 25.3534 30.3742 25.3759L29.7741 27.6508ZM32.8299 27.4461C32.7376 27.4569 32.6491 27.4678 32.5531 27.4779C32.4511 27.4887 32.3408 27.498 32.2351 27.5073C32.1136 27.519 31.995 27.5306 31.8683 27.5415C31.7415 27.5515 31.6065 27.5601 31.4752 27.5694C31.3612 27.5771 31.2517 27.5864 31.134 27.5934C30.9809 27.6027 30.8189 27.6097 30.6592 27.6174C30.6254 27.619 30.5932 27.6205 30.5594 27.6221L31.1422 25.4131C32.3296 25.486 33.3279 25.6046 34.135 25.7403L32.8561 27.3934C32.8434 27.4096 32.8396 27.429 32.8299 27.4461ZM36.5029 26.4691L36.5007 26.4792C36.4939 26.4916 36.4797 26.5056 36.4684 26.5188C36.4557 26.5335 36.4467 26.5474 36.4287 26.5629C36.4129 26.5761 36.3904 26.5901 36.3709 26.6033C36.3469 26.6195 36.3259 26.6358 36.2959 26.6529C36.2727 26.6661 36.2419 26.68 36.2156 26.6932C36.1804 26.711 36.1474 26.7288 36.1054 26.7474C36.0746 26.7614 36.0364 26.7746 36.0019 26.7885C35.9546 26.8071 35.9096 26.8265 35.8563 26.8451C35.8181 26.8591 35.7723 26.8723 35.7303 26.8862C35.6718 26.9056 35.6156 26.925 35.5503 26.9444C35.5038 26.9583 35.4506 26.9715 35.4011 26.9855C35.3306 27.0049 35.2631 27.0243 35.1866 27.0436C35.1355 27.056 35.0778 27.0685 35.0245 27.0816C34.9405 27.1018 34.858 27.1212 34.7673 27.1405C34.7088 27.1529 34.6435 27.1646 34.5828 27.177C34.4883 27.1956 34.3967 27.215 34.2955 27.2336C34.2227 27.2468 34.1432 27.2592 34.0675 27.2723C34.0082 27.2824 33.9497 27.2925 33.8882 27.3026L34.9188 25.9713C34.936 25.9488 34.9435 25.9225 34.9555 25.8977C35.8796 26.1008 36.4114 26.318 36.5029 26.4691Z",
                fill: e.active ? "#ffffff" : "#A9C6ED"
            }, null, 8, o3)], 8, t3), e.active ? (s(), n("defs", e3, a[0] || (a[0] = [B('<filter id="filter0_d_21650_46737" x="0" y="-1" width="58" height="58" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB" data-v-992fc3cb><feFlood flood-opacity="0" result="BackgroundImageFix" data-v-992fc3cb></feFlood><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" data-v-992fc3cb></feColorMatrix><feOffset data-v-992fc3cb></feOffset><feGaussianBlur stdDeviation="10" data-v-992fc3cb></feGaussianBlur><feComposite in2="hardAlpha" operator="out" data-v-992fc3cb></feComposite><feColorMatrix type="matrix" values="0 0 0 0 0.504167 0 0 0 0 0.715625 0 0 0 0 1 0 0 0 1 0" data-v-992fc3cb></feColorMatrix><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_21650_46737" data-v-992fc3cb></feBlend><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_21650_46737" result="shape" data-v-992fc3cb></feBlend></filter>', 1)]))) : f("", !0)]))
        }
    }),
    i3 = u(a3, [
        ["__scopeId", "data-v-992fc3cb"]
    ]),
    n3 = {
        class: "icon",
        xmlns: "http://www.w3.org/2000/svg",
        width: "56",
        height: "56",
        viewBox: "0 0 56 56",
        fill: "none"
    },
    s3 = ["filter"],
    l3 = ["fill"],
    r3 = {
        key: 0
    },
    f3 = h({
        __name: "IconSlot",
        props: {
            active: {
                type: Boolean
            }
        },
        setup(r) {
            return (e, a) => (s(), n("svg", n3, [t("g", {
                filter: e.active ? "url(#filter0_d_21650_46739)" : ""
            }, [t("path", {
                d: "M34.4631 27.3249C32.8998 26.2208 31.3365 26.1419 30.1641 26.694C31.8055 25.5899 32.509 23.2239 30.7894 21.0157C27.6629 18.6498 24.2237 20.7791 24.2237 23.6971C24.2237 24.9589 24.849 26.063 25.8651 26.7728C24.6145 26.1419 22.9731 26.2208 21.488 27.4037C19.1431 30.4006 21.3317 33.7918 24.3019 33.7918C25.6306 33.7918 26.8812 33.082 27.5066 32.0568C27.4284 33.8707 26.9594 35.0536 25.9433 35.7634C25.8651 35.8423 25.8651 35.9211 25.8651 35.9211C25.8651 36 25.9433 36 26.0214 36H29.9296C30.0078 36 30.0859 35.9211 30.0859 35.9211C30.0859 35.8423 30.0859 35.7634 30.0078 35.7634C28.9917 35.0536 28.5227 33.8707 28.4445 32.0568C29.0698 33.082 30.3204 33.7918 31.6492 33.7918C34.6976 33.7129 36.8861 30.3217 34.4631 27.3249Z",
                fill: e.active ? "#ffffff" : "#A9C6ED"
            }, null, 8, l3)], 8, s3), e.active ? (s(), n("defs", r3, a[0] || (a[0] = [B('<filter id="filter0_d_21650_46739" x="-1" y="-1" width="58" height="58" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB" data-v-3c2046e0><feFlood flood-opacity="0" result="BackgroundImageFix" data-v-3c2046e0></feFlood><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" data-v-3c2046e0></feColorMatrix><feOffset data-v-3c2046e0></feOffset><feGaussianBlur stdDeviation="10" data-v-3c2046e0></feGaussianBlur><feComposite in2="hardAlpha" operator="out" data-v-3c2046e0></feComposite><feColorMatrix type="matrix" values="0 0 0 0 0.504167 0 0 0 0 0.715625 0 0 0 0 1 0 0 0 1 0" data-v-3c2046e0></feColorMatrix><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_21650_46739" data-v-3c2046e0></feBlend><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_21650_46739" result="shape" data-v-3c2046e0></feBlend></filter>', 1)]))) : f("", !0)]))
        }
    }),
    _3 = u(f3, [
        ["__scopeId", "data-v-3c2046e0"]
    ]),
    c3 = {},
    d3 = {
        class: "icon",
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
    };

function C3(r, e) {
    return s(), n("svg", d3, e[0] || (e[0] = [t("path", {
        d: "M5.57226 6.21325H18.4294C18.5796 6.21317 18.7296 6.22273 18.8786 6.24177C18.8281 5.88731 18.7064 5.54675 18.5207 5.2406C18.335 4.93447 18.0893 4.6691 17.7982 4.46051C17.5072 4.25191 17.177 4.10441 16.8275 4.02689C16.4779 3.94937 16.1163 3.94344 15.7644 4.00946L5.19057 5.81468H5.17851C4.5148 5.9416 3.92457 6.31711 3.52838 6.86454C4.12527 6.43997 4.83979 6.21232 5.57226 6.21325Z",
        fill: "white"
    }, null, -1), t("path", {
        d: "M18.4286 7.17883H5.57143C4.88967 7.1796 4.23605 7.45072 3.75398 7.93282C3.2719 8.41489 3.00075 9.06851 3 9.75026V17.4645C3.00075 18.1463 3.2719 18.7999 3.75398 19.282C4.23605 19.7641 4.88967 20.0352 5.57143 20.036H18.4286C19.1103 20.0352 19.7639 19.7641 20.246 19.282C20.7281 18.7999 20.9992 18.1463 21 17.4645V9.75026C20.9992 9.06851 20.7281 8.41489 20.246 7.93282C19.7639 7.45072 19.1103 7.1796 18.4286 7.17883ZM16.5201 14.8931C16.2658 14.8931 16.0172 14.8177 15.8058 14.6764C15.5943 14.5352 15.4296 14.3344 15.3323 14.0994C15.2349 13.8645 15.2095 13.606 15.2591 13.3566C15.3087 13.1072 15.4311 12.8781 15.6109 12.6983C15.7908 12.5184 16.0199 12.396 16.2693 12.3464C16.5186 12.2968 16.7772 12.3223 17.0121 12.4196C17.247 12.5169 17.4479 12.6817 17.5891 12.8931C17.7304 13.1045 17.8058 13.3531 17.8058 13.6074C17.8058 13.9484 17.6703 14.2754 17.4292 14.5166C17.1881 14.7577 16.8611 14.8931 16.5201 14.8931Z",
        fill: "white"
    }, null, -1), t("path", {
        d: "M3.02051 12.4606V8.46287C3.02051 7.5922 3.50265 6.13251 5.17609 5.81631C6.59641 5.54993 8.00266 5.54993 8.00266 5.54993C8.00266 5.54993 8.92676 6.19278 8.16337 6.19278C7.39998 6.19278 7.42007 7.17715 8.16337 7.17715C8.90667 7.17715 8.16337 8.12135 8.16337 8.12135L5.17006 11.5164L3.02051 12.4606Z",
        fill: "white"
    }, null, -1)]))
}
const v3 = u(c3, [
        ["render", C3],
        ["__scopeId", "data-v-dea48e27"]
    ]),
    p3 = {
        class: "icon",
        xmlns: "http://www.w3.org/2000/svg",
        width: "54",
        height: "58",
        viewBox: "0 0 54 58",
        fill: "none"
    },
    u3 = ["filter"],
    m3 = ["fill"],
    h3 = ["fill"],
    b3 = {
        key: 0
    },
    g3 = h({
        __name: "IconDice",
        props: {
            active: {
                type: Boolean
            }
        },
        setup(r) {
            return (e, a) => (s(), n("svg", p3, [t("g", {
                filter: e.active ? "url(#filter0_d_21650_46741)" : ""
            }, [t("path", {
                d: "M32.8959 32.0345C31.949 32.0818 30.5405 31.7977 30.138 30.8153C27.9838 32.354 25.8533 32.3185 23.7227 30.7325C23.1072 31.7977 22.113 32.1055 20.9057 32.0463C20.9057 31.9279 20.9057 31.8214 20.9057 31.7267C20.9057 29.7737 20.882 27.8325 20.9175 25.8795C20.9293 24.6249 21.3318 23.4768 22.2787 22.6009C22.5983 22.305 23.0125 22.1274 23.3913 21.8789C23.4623 21.8315 23.557 21.7842 23.5925 21.7013C24.0186 20.7781 24.7998 20.3046 25.7467 20.1152C28.8834 19.4997 31.9253 21.4054 32.7302 24.5065C32.8486 24.9445 32.9078 25.4179 32.9078 25.8677C32.9314 27.8562 32.9196 29.8447 32.9196 31.8332C32.9078 31.8924 32.8959 31.9516 32.8959 32.0345ZM24.9655 24.3171C24.3501 25.2641 24.3145 25.2996 23.3676 25.9742C23.2848 26.0334 23.2256 26.1399 23.2138 26.2346C23.0717 26.9211 23.1072 27.5958 23.3203 28.2587C23.9003 30.0578 25.7112 31.1467 27.6406 30.8508C29.4279 30.5786 30.8364 28.9333 30.8601 27.0987C30.8601 26.8856 30.8009 26.8383 30.5997 26.8265C29.5936 26.7673 28.6348 26.5187 27.6997 26.1281C26.67 25.7138 25.7586 25.122 24.9655 24.3171Z",
                fill: e.active ? "#ffffff" : "#A9C6ED"
            }, null, 8, m3), t("path", {
                d: "M27.0132 36.5678C27.7826 35.4788 28.5283 34.4254 29.2858 33.372C29.4279 33.1826 29.6527 33.0406 29.8658 32.934C30.0197 32.863 30.2446 32.8748 30.4103 32.9222C31.3453 33.2299 32.2923 33.5495 33.2155 33.8928C33.5943 34.0348 33.8192 34.3426 33.831 34.7568C33.8428 35.5144 33.8428 36.2719 33.831 37.0294C33.8192 37.5384 33.4286 37.929 32.9078 37.9882C32.8249 38 32.742 38 32.6474 38C28.8834 38 25.1076 38 21.3436 38C20.5387 38 20.16 37.6212 20.16 36.8045C20.16 36.1535 20.16 35.5144 20.16 34.8634C20.16 34.3544 20.4085 34.0348 20.882 33.8691C21.7342 33.5732 22.5864 33.2654 23.4387 32.9814C24.0068 32.792 24.3737 32.9222 24.717 33.3956C25.4153 34.3781 26.1137 35.3605 26.812 36.3547C26.8949 36.4021 26.9422 36.4731 27.0132 36.5678Z",
                fill: e.active ? "#ffffff" : "#A9C6ED"
            }, null, 8, h3)], 8, u3), e.active ? (s(), n("defs", b3, a[0] || (a[0] = [B('<filter id="filter0_d_21650_46741" x="-2" y="0" width="58" height="58" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB" data-v-4ef68d05><feFlood flood-opacity="0" result="BackgroundImageFix" data-v-4ef68d05></feFlood><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" data-v-4ef68d05></feColorMatrix><feOffset data-v-4ef68d05></feOffset><feGaussianBlur stdDeviation="10" data-v-4ef68d05></feGaussianBlur><feComposite in2="hardAlpha" operator="out" data-v-4ef68d05></feComposite><feColorMatrix type="matrix" values="0 0 0 0 0.504167 0 0 0 0 0.715625 0 0 0 0 1 0 0 0 1 0" data-v-4ef68d05></feColorMatrix><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_21650_46741" data-v-4ef68d05></feBlend><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_21650_46741" result="shape" data-v-4ef68d05></feBlend></filter>', 1)]))) : f("", !0)]))
        }
    }),
    B3 = u(g3, [
        ["__scopeId", "data-v-4ef68d05"]
    ]),
    w3 = {
        class: "icon",
        xmlns: "http://www.w3.org/2000/svg",
        width: "75",
        height: "57",
        viewBox: "0 0 75 57",
        fill: "none"
    },
    x3 = ["filter"],
    y3 = {
        key: 0
    },
    M3 = h({
        __name: "IconAviator",
        props: {
            active: {
                type: Boolean
            }
        },
        setup(r) {
            return (e, a) => (s(), n("svg", w3, [t("g", {
                filter: e.active ? "url(#filter0_d_21650_46761)" : ""
            }, a[0] || (a[0] = [t("path", {
                d: "M52.2563 26.6624C52.2868 26.7876 52.3785 26.8935 52.4998 26.948L53.2568 27.2547C53.3431 27.2861 53.4273 27.2338 53.4348 27.1535C53.4909 26.3133 53.5345 25.6863 53.5973 24.8278C53.6259 24.3612 53.6417 23.9003 53.5257 23.4433C53.295 22.4365 53.0514 21.4353 52.8015 20.4215C52.7773 20.309 52.776 20.1634 52.6193 20.1167C52.453 20.0665 52.3709 20.2026 52.2829 20.295C51.9996 20.5963 52.0584 21.0013 52.0022 21.3646C51.7175 23.2207 51.8696 24.8315 52.2563 26.6624Z",
                fill: "#FF003D"
            }, null, -1), t("path", {
                d: "M53.765 35.9114C54.086 33.7469 53.9346 31.5972 53.4911 29.4449C53.4819 29.4105 53.4694 29.3852 53.444 29.3656L53.3327 29.2836C53.266 29.2282 53.2672 29.1353 53.3289 29.0852C53.5493 28.9269 53.8507 28.7255 54.0032 28.6048C54.1849 28.4635 54.2094 28.3065 53.9639 28.1757C53.5016 27.9245 53.0227 27.719 52.5337 27.5411C52.2461 27.4364 52.1677 27.5323 52.1995 27.8031L52.3564 32.6819C52.3887 33.8758 52.7462 35.0117 53.0069 36.1746C53.0403 36.3216 53.0082 36.5588 53.2487 36.5841C53.4605 36.5989 53.5688 36.4206 53.6672 36.2698C53.7297 36.1577 53.7409 36.0374 53.765 35.9114Z",
                fill: "#FF003D"
            }, null, -1), t("path", {
                d: "M51.4324 27.0469C51.3526 26.2816 50.6868 25.6349 49.9015 25.5254C49.5297 25.473 49.1987 25.4873 48.8298 25.4568C47.6069 25.416 46.3652 25.3374 45.1648 25.2945L42.6805 25.1991C42.6388 25.1943 42.5938 25.1987 42.5425 25.1904C42.5234 25.1834 42.5138 25.1799 42.4946 25.1729C42.4467 25.1555 42.4246 25.1267 42.4058 25.0888C42.4 25.0452 42.4004 25.0142 42.4233 24.9811C42.4821 24.9091 42.6138 24.9052 42.7101 24.9092L42.7196 24.9126L43.9467 24.8823L43.3555 24.1798C43.1433 23.9573 42.8524 23.8618 42.5314 23.8487C41.1322 23.7853 39.6738 24.0633 38.3709 24.4808C38.0517 24.5824 38.0288 24.854 37.8879 25.062L37.5413 25.7757C35.9714 25.0177 34.4111 24.2631 32.8446 23.496C31.9225 23.0463 31.0034 22.8569 30.0314 23.2601C29.9443 23.2906 29.886 23.3316 29.8597 23.3739C29.8139 23.4402 29.8193 23.5147 29.8948 23.6355L30.3114 24.43C30.8163 25.3397 31.3213 26.2493 31.8071 27.152L33.005 29.3197L33.0113 29.3323C33.0488 29.4082 33.1022 29.5002 33.0559 29.5974L33.0526 29.6066C33.033 29.6305 33.0072 29.6419 32.9751 29.6406C32.9655 29.6371 32.9655 29.6371 32.9559 29.6336C32.8567 29.6079 32.7591 29.4583 32.7308 29.4169L31.8406 28.0144C30.4443 28.2113 29.048 28.4082 27.6375 28.4652C27.4287 28.4721 27.2461 28.4368 27.0802 28.3557C27.0068 28.3186 23.0404 26.1802 22.9483 26.1052C22.7573 25.9735 22.5368 25.8932 22.2738 25.8701C21.7157 25.8225 20.8917 25.9684 20.3669 26.0678C20.1673 26.1092 20.0331 26.2988 20.1048 26.4597C20.2016 26.6712 23.0592 30.5732 23.2302 30.7599C23.5216 31.063 24.0973 31.4799 25.0889 31.5297C29.8098 31.7445 35.5639 31.7753 40.0197 31.8832C42.2893 31.9419 44.563 31.9296 46.8167 31.7336C48.1509 31.6178 49.3405 31.5116 50.6142 31.1145C51.2752 30.9093 51.5598 30.5151 51.5559 29.8397C51.5553 28.9166 51.5355 27.9866 51.4324 27.0469ZM43.2136 29.3127C43.2103 29.3219 43.2007 29.3184 43.1974 29.3276C42.7994 29.556 42.4263 29.5965 41.9928 29.3557C38.8755 27.599 35.7515 25.8605 32.6275 24.1221C32.5542 24.085 32.4679 24.0536 32.4499 23.9537C32.5637 23.85 32.6525 23.9341 32.7546 23.9817C35.9136 25.5047 39.0692 27.037 42.2281 28.56C42.3111 28.6006 42.394 28.6411 42.4866 28.6852C42.7163 28.7999 42.9589 28.9089 43.1886 29.0236C43.3512 29.1139 43.3983 29.1933 43.2136 29.3127Z",
                fill: "#FF003D"
            }, null, -1)]), 8, x3), e.active ? (s(), n("defs", y3, a[1] || (a[1] = [B('<filter id="filter0_d_21650_46761" x="-1" y="-1" width="76" height="58" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB" data-v-790408eb><feFlood flood-opacity="0" result="BackgroundImageFix" data-v-790408eb></feFlood><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" data-v-790408eb></feColorMatrix><feOffset data-v-790408eb></feOffset><feGaussianBlur stdDeviation="10" data-v-790408eb></feGaussianBlur><feComposite in2="hardAlpha" operator="out" data-v-790408eb></feComposite><feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 0 0 0 0 0 0.239216 0 0 0 1 0" data-v-790408eb></feColorMatrix><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_21650_46761" data-v-790408eb></feBlend><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_21650_46761" result="shape" data-v-790408eb></feBlend></filter>', 1)]))) : f("", !0)]))
        }
    }),
    k3 = u(M3, [
        ["__scopeId", "data-v-790408eb"]
    ]),
    I3 = {
        class: "icon",
        width: "56",
        height: "58",
        viewBox: "0 0 56 58",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
    },
    S3 = ["filter"],
    $3 = ["fill"],
    A3 = ["fill"],
    D3 = ["fill"],
    L3 = {
        key: 0
    },
    V3 = h({
        __name: "IconBonus",
        props: {
            active: {
                type: Boolean
            }
        },
        setup(r) {
            return (e, a) => (s(), n("svg", I3, [t("g", {
                filter: e.active ? "url(#filter0_d_21661_4383)" : ""
            }, [t("path", {
                d: "M34.7813 24.1747H33.034C33.3677 23.7969 33.6002 23.3161 33.6002 22.717C33.5627 21.1791 32.3065 19.9618 30.7917 19.9962C28.9281 19.9962 28.2006 21.8508 28.0094 22.4384C28.0056 22.446 28.0056 22.4537 28.0019 22.4613C27.9831 22.4155 27.9644 22.3697 27.9456 22.3278C27.9381 22.3163 27.9344 22.301 27.9269 22.2896C27.3982 21.3394 26.6895 20.0114 25.2421 20.0114C24.4734 20.0305 23.746 20.3434 23.1985 20.8891C22.6998 21.3661 22.4111 22.0301 22.3998 22.7284C22.3998 23.0986 22.5086 23.6405 22.981 24.1785H21.2187C20.5437 24.1747 20 24.7318 20 25.4149V27.0061C20 27.6892 20.5437 28.2463 21.2187 28.2463H34.7813C35.4525 28.2463 36 27.693 36 27.0061V25.4149C36 24.7318 35.4525 24.1747 34.7813 24.1747ZM26.262 23.9915C25.992 23.9495 25.7258 23.8923 25.4633 23.8198C24.5746 23.5183 24.0272 23.1138 24.0009 22.7246C24.0009 22.7055 24.0009 22.6865 24.0009 22.6674C24.0272 22.4308 24.1359 22.2095 24.3084 22.0454C24.5371 21.8088 24.8446 21.6676 25.1708 21.6447H25.1933C25.6246 21.6447 25.9545 22.0912 26.3145 22.7513L26.6745 23.4306C26.6745 23.4344 26.6782 23.4382 26.6782 23.4382C26.802 23.7282 26.5695 24.0373 26.262 23.9915ZM31.9991 22.7475C31.9616 23.2779 30.9041 23.6939 30.5217 23.8351C30.5104 23.8389 30.4992 23.8427 30.4879 23.8465C30.2554 23.9114 30.0192 23.961 29.783 23.9953C29.4943 24.0373 29.2655 23.7587 29.3555 23.4764C29.4193 23.2703 29.483 23.0757 29.5318 22.923C29.6292 22.6216 29.978 21.6447 30.7804 21.6447C31.3991 21.6027 31.9353 22.0683 32.0028 22.6903C31.9991 22.7094 31.9991 22.7284 31.9991 22.7475Z",
                fill: e.active ? "#ffffff" : "#A9C6ED"
            }, null, 8, $3), t("path", {
                d: "M26.2398 29.4751H21.9164C21.2902 29.4751 20.7803 29.9941 20.7803 30.6313V36.8438C20.7803 37.481 21.2902 38 21.9164 38H26.2361C26.8623 38 27.3723 37.481 27.3723 36.8438V30.6313C27.376 29.9941 26.8623 29.4751 26.2398 29.4751Z",
                fill: e.active ? "#ffffff" : "#A9C6ED"
            }, null, 8, A3), t("path", {
                d: "M34.0994 29.4751H29.7797C29.1535 29.4751 28.6436 29.9941 28.6436 30.6313V36.8438C28.6436 37.481 29.1535 38 29.7797 38H34.0994C34.7256 38 35.2355 37.481 35.2355 36.8438V30.6313C35.2355 29.9941 34.7256 29.4751 34.0994 29.4751Z",
                fill: e.active ? "#ffffff" : "#A9C6ED"
            }, null, 8, D3)], 8, S3), e.active ? (s(), n("defs", L3, a[0] || (a[0] = [B('<filter id="filter0_d_21661_4383" x="-1" y="-0.00452423" width="58" height="58.0045" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB" data-v-514aaf03><feFlood flood-opacity="0" result="BackgroundImageFix" data-v-514aaf03></feFlood><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" data-v-514aaf03></feColorMatrix><feOffset data-v-514aaf03></feOffset><feGaussianBlur stdDeviation="10" data-v-514aaf03></feGaussianBlur><feComposite in2="hardAlpha" operator="out" data-v-514aaf03></feComposite><feColorMatrix type="matrix" values="0 0 0 0 0.504167 0 0 0 0 0.715625 0 0 0 0 1 0 0 0 1 0" data-v-514aaf03></feColorMatrix><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_21661_4383" data-v-514aaf03></feBlend><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_21661_4383" result="shape" data-v-514aaf03></feBlend></filter>', 1)]))) : f("", !0)]))
        }
    }),
    F3 = u(V3, [
        ["__scopeId", "data-v-514aaf03"]
    ]),
    H3 = "" + new URL("crazy-time.DORR9EQd.png",
        import.meta.url).href,
    O3 = ["src"],
    G3 = ["src"],
    Z3 = {
        class: "bottom-nav__list"
    },
    E3 = {
        key: 0,
        class: "bottom-nav__item"
    },
    R3 = {
        class: "bottom-nav__icon-box"
    },
    U3 = {
        class: "bottom-nav__icon-new"
    },
    N3 = {
        class: "bottom-nav__title"
    },
    T3 = {
        key: 2,
        class: "bottom-nav__item"
    },
    z3 = {
        class: "bottom-nav__icon-box"
    },
    P3 = {
        class: "bottom-nav__icon-new"
    },
    W3 = {
        class: "bottom-nav__title"
    },
    Y3 = {
        key: 3,
        class: "bottom-nav__item"
    },
    j3 = {
        class: "bottom-nav__icon-box"
    },
    q3 = {
        class: "bottom-nav__icon-new"
    },
    Q3 = {
        class: "bottom-nav__title"
    },
    J3 = {
        class: "bottom-nav__item"
    },
    K3 = {
        class: "bottom-nav__icon-box"
    },
    X3 = {
        class: "bottom-nav__icon-new"
    },
    t0 = {
        class: "bottom-nav__title"
    },
    o0 = {
        class: "bottom-nav__icon-box"
    },
    e0 = {
        class: "bottom-nav__icon-new"
    },
    a0 = {
        class: "bottom-nav__title bottom-nav__title--let-s"
    },
    i0 = {
        class: "bottom-nav__item"
    },
    n0 = {
        class: "bottom-nav__icon-box"
    },
    s0 = {
        class: "bottom-nav__icon-new"
    },
    l0 = {
        class: "bottom-nav__title bottom-nav__title--let-s"
    },
    r0 = {
        class: "bottom-nav__icon-box"
    },
    f0 = {
        class: "aviator-icon bottom-nav__icon-new"
    },
    _0 = {
        class: "bottom-nav__title bottom-nav__title--let-s text-red"
    },
    c0 = {
        class: "bottom-nav__figure"
    },
    d0 = {
        class: "badge-round bottom-nav__badge-round"
    },
    C0 = {
        class: "bottom-nav__title"
    },
    v0 = {
        key: 7,
        class: "bottom-nav__item"
    },
    p0 = {
        class: "bottom-nav__icon-box"
    },
    u0 = {
        class: "bottom-nav__icon-new"
    },
    m0 = {
        class: "bottom-nav__title bottom-nav__title--let-s"
    },
    h0 = h({
        __name: "MobileButtonsInline",
        setup(r) {
            var H;
            const {
                config: e
            } = r2(), {
                showNotification: a
            } = f2(), {
                $bt: A
            } = _2(), {
                t: m
            } = c2(), c = d2(), M = C2(), E = v2(), {
                imageUrl: D
            } = I2(), {
                isAuthenticated: L
            } = p2(), {
                openDialog: S
            } = u2(), {
                numberOfBetslip: R
            } = Z(S2()), {
                userGeo: x
            } = Z(m2()), {
                setRedirectSlotAuth: U
            } = $2(), {
                isBetbyRoute: N
            } = h2(), {
                trackButtonClick: T
            } = b2(), {
                isMobile: z
            } = k2(), P = (H = e.value) == null ? void 0 : H.NEW_YEAR_THEME, W = $(() => R.value), y = G(!1), k = G(!1), Y = ["RW", "ZM", "UG", "CD", "CM", "CI"], V = $(() => Y.includes(x.value)), j = $(() => z.value ? "iphone" : "");

            function _(d) {
                return M.path === c(d) && !y.value && !k.value
            }
            async function F(d) {
                const o = d === "aviator" ? B2.AVIATOR_MOBILE : "/live-dealers/slot/crazy-time-1";
                L.value ? (y.value = d === "aviator", k.value = d === "crazy-time", await E.push(c({
                    path: o
                }))) : (U(c(d)), S("auth"))
            }

            function q() {
                L.value ? (S("deposit"), w2(x2.MOBILE_MENU_FOOTER)) : S("auth")
            }

            function v(d) {
                T({
                    category: "bottom_bar",
                    action: "main",
                    label: d
                })
            }

            function Q() {
                if (A.isHere()) try {
                    A.get().action("toggleBetSlip")
                } catch {
                    const d = document.querySelector('[data-editor-id="betslipHeader"] > div ');
                    d ? d.click() : a({
                        code: 100,
                        message: 'WARN: [data-editor-id="betslipHeader"] - not found!'
                    })
                }
            }
            return (d, o) => {
                const J = H2,
                    b = T2,
                    I = g2,
                    K = K2,
                    O = y2,
                    X = i3,
                    t2 = _3,
                    o2 = v3,
                    e2 = B3,
                    a2 = k3,
                    i2 = M2,
                    n2 = F3;
                return s(), n("nav", {
                    class: g(`bottom-nav ${i(j)}`)
                }, [i(P) ? (s(), n(s2, {
                    key: 0
                }, [t("img", {
                    class: "bottom-nav-ice bottom-nav-ice__left",
                    src: i(D) + "/new-year/ice-left-toolbar.svg",
                    alt: "ice left nav"
                }, null, 8, O3), t("img", {
                    class: "bottom-nav-ice bottom-nav-ice__right",
                    src: i(D) + "/new-year/ice-right-toolbar.svg",
                    alt: "ice right nav"
                }, null, 8, G3)], 64)) : f("", !0), t("ul", Z3, [i(x) !== "BD" ? (s(), n("li", E3, [l(I, {
                    to: i(c)("/"),
                    class: g(["bottom-nav__btn", {
                        "active-link": _("/")
                    }]),
                    "no-prefetch": "",
                    onClick: o[0] || (o[0] = C => v("home"))
                }, {
                    default: w(() => [t("div", R3, [t("div", U3, [l(J, {
                        class: "bottom-nav__icon-img slot-animation svg-animation",
                        active: _("/")
                    }, null, 8, ["active"])])]), t("p", N3, p(i(m)("menu.main")), 1), o[12] || (o[12] = t("div", {
                        class: "bottom-nav__animation"
                    }, null, -1)), l(b, {
                        active: _("/")
                    }, null, 8, ["active"])]),
                    _: 1
                }, 8, ["to", "class"])])) : f("", !0), i(x) === "BD" ? (s(), n("li", {
                    key: 1,
                    class: "bottom-nav__item",
                    onClick: o[2] || (o[2] = C => v("crazyTime"))
                }, [t("div", {
                    class: g(["bottom-nav__btn", {
                        "active-link": i(k)
                    }]),
                    onClick: o[1] || (o[1] = C => F("crazy-time"))
                }, [o[13] || (o[13] = t("div", {
                    class: "bottom-nav__icon-box"
                }, [t("div", {
                    class: "bottom-nav__icon-new crazy-time"
                }, [t("img", {
                    src: H3,
                    style: {
                        width: "100%"
                    },
                    alt: "crazy-time"
                })])], -1)), o[14] || (o[14] = t("div", {
                    class: "bottom-nav__animation"
                }, null, -1)), l(b, {
                    active: i(k)
                }, null, 8, ["active"])], 2)])) : f("", !0), i(V) ? (s(), n("li", T3, [l(O, {
                    class: "bottom-nav__btn",
                    "route-path": "/sports",
                    "active-class": "active-link",
                    "active-routes": [i(c)("/sports")],
                    onClick: o[3] || (o[3] = C => v("sports"))
                }, {
                    default: w(() => [t("div", z3, [t("div", P3, [l(K, {
                        class: "bottom-nav__icon-img scoreboard-animation svg-animation",
                        active: _("/sports")
                    }, null, 8, ["active"])])]), t("p", W3, p(i(m)("profile.bonuses.sports")), 1), o[15] || (o[15] = t("div", {
                        class: "bottom-nav__animation"
                    }, null, -1)), l(b, {
                        active: _("/sports")
                    }, null, 8, ["active"])]),
                    _: 1
                }, 8, ["active-routes"])])) : f("", !0), i(x) !== "BD" ? (s(), n("li", Y3, [l(O, {
                    class: "bottom-nav__btn",
                    "route-path": "/live",
                    "active-class": "active-link",
                    "active-routes": [i(c)("/live")],
                    onClick: o[4] || (o[4] = C => v("live"))
                }, {
                    default: w(() => [t("div", j3, [t("div", q3, [l(X, {
                        class: "bottom-nav__icon-img scoreboard-animation svg-animation",
                        active: _("/live")
                    }, null, 8, ["active"])])]), t("p", Q3, p(i(m)("titles.live")), 1), o[16] || (o[16] = t("div", {
                        class: "bottom-nav__animation"
                    }, null, -1)), l(b, {
                        active: _("/live")
                    }, null, 8, ["active"])]),
                    _: 1
                }, 8, ["active-routes"])])) : f("", !0), t("li", J3, [l(I, {
                    to: i(c)("/casino"),
                    class: g(["bottom-nav__btn", {
                        "active-link": i(M).path.startsWith(i(c)("/casino"))
                    }]),
                    "no-prefetch": "",
                    onClick: o[5] || (o[5] = C => v("casino"))
                }, {
                    default: w(() => [t("div", K3, [t("div", X3, [l(t2, {
                        class: "bottom-nav__icon-img slot-animation svg-animation",
                        active: _("/casino")
                    }, null, 8, ["active"])])]), t("p", t0, p(i(m)("menu.casino")), 1), o[17] || (o[17] = t("div", {
                        class: "bottom-nav__animation"
                    }, null, -1)), l(b, {
                        active: _("/casino")
                    }, null, 8, ["active"])]),
                    _: 1
                }, 8, ["to", "class"])]), i(x) === "BD" ? (s(), n("li", {
                    key: 4,
                    class: "bottom-nav__item",
                    onClick: o[6] || (o[6] = C => v("deposit"))
                }, [t("div", {
                    class: "bottom-nav__btn",
                    onClick: q
                }, [t("div", o0, [t("div", e0, [l(o2)])]), t("p", a0, p(i(m)("mobileMenu.deposit")), 1)])])) : f("", !0), t("li", i0, [l(I, {
                    to: i(c)("/live-dealers"),
                    class: g(["bottom-nav__btn", {
                        "active-link": i(M).path.startsWith(i(c)("/live-dealers"))
                    }]),
                    "no-prefetch": "",
                    onClick: o[7] || (o[7] = C => v("liveDealers"))
                }, {
                    default: w(() => [t("div", n0, [t("div", s0, [l(e2, {
                        class: "bottom-nav__icon-img dice-animation svg-animation",
                        active: _("/live-dealers")
                    }, null, 8, ["active"])])]), t("p", l0, p(i(m)("menu.liveCasino")), 1), o[18] || (o[18] = t("div", {
                        class: "bottom-nav__animation"
                    }, null, -1)), l(b, {
                        active: _("/live-dealers")
                    }, null, 8, ["active"])]),
                    _: 1
                }, 8, ["to", "class"])]), i(V) ? f("", !0) : (s(), n("li", {
                    key: 5,
                    class: "bottom-nav__item",
                    onClick: o[9] || (o[9] = C => v("aviator"))
                }, [t("div", {
                    class: g(["bottom-nav__btn", {
                        "active-link": i(y)
                    }]),
                    onClick: o[8] || (o[8] = C => F("aviator"))
                }, [t("div", r0, [t("div", f0, [l(a2, {
                    active: i(y),
                    class: "aviator-animation bottom-nav__icon-img svg-animation"
                }, null, 8, ["active"])])]), t("p", _0, p(i(m)("menu.aviator")), 1), o[19] || (o[19] = t("div", {
                    class: "bottom-nav__animation"
                }, null, -1)), l(b, {
                    active: i(y),
                    color: "#FF003D"
                }, null, 8, ["active"])], 2)])), i(N) ? (s(), n("li", {
                    key: 6,
                    class: "bottom-nav__item",
                    onClick: o[10] || (o[10] = C => v("betSlip"))
                }, [t("a", {
                    id: "betSlipButton",
                    href: "#",
                    class: "bottom-nav__btn bottom-nav__btn--padding js-openBets",
                    onClick: l2(Q, ["prevent"])
                }, [t("span", c0, [l(i2, {
                    class: "bottom-nav__figure-icon",
                    size: 16,
                    height: 19,
                    "symbol-id": "list2"
                }), t("span", d0, p(i(W)), 1)]), t("p", C0, p(i(m)("titles.cupon")), 1), o[20] || (o[20] = t("div", {
                    class: "bottom-nav__animation"
                }, null, -1))])])) : (s(), n("li", v0, [l(I, {
                    to: i(c)("/bonuses"),
                    class: g(["bottom-nav__btn", {
                        "active-link": i(M).path.startsWith(i(c)("/bonuses"))
                    }]),
                    "no-prefetch": "",
                    onClick: o[11] || (o[11] = C => v("bonuses"))
                }, {
                    default: w(() => [t("div", p0, [t("div", u0, [l(n2, {
                        class: "bonus-animation bottom-nav__icon-img",
                        active: _("/bonuses")
                    }, null, 8, ["active"])])]), t("p", m0, p(i(m)("menu.bonuses")), 1), o[21] || (o[21] = t("div", {
                        class: "bottom-nav__animation"
                    }, null, -1)), l(b, {
                        active: _("/bonuses")
                    }, null, 8, ["active"])]),
                    _: 1
                }, 8, ["to", "class"])]))])], 2)
            }
        }
    }),
    v5 = u(h0, [
        ["__scopeId", "data-v-42e6c57b"]
    ]);
export {
    v5 as
    default
};