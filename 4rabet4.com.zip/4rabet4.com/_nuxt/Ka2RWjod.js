import {
    U as u,
    Y as c
} from "./BbvgifQp.js";
import {
    E as i,
    A as l,
    az as f
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "8ea5ce4b-c2d7-4880-950d-6490e3fcc695", e._sentryDebugIdIdentifier = "sentry-dbid-8ea5ce4b-c2d7-4880-950d-6490e3fcc695")
    } catch {}
})();

function m(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "div",
        r = arguments.length > 2 ? arguments[2] : void 0;
    return u()({
        name: r ? ? i(f(e.replace(/__/g, "-"))),
        props: {
            tag: {
                type: String,
                default: t
            },
            ...c()
        },
        setup(n, s) {
            let {
                slots: a
            } = s;
            return () => {
                var d;
                return l(n.tag, {
                    class: [e, n.class],
                    style: n.style
                }, (d = a.default) == null ? void 0 : d.call(a))
            }
        }
    })
}
export {
    m as c
};