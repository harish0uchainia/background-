import {
    W as s
} from "./BbvgifQp.js";
import {
    y as f,
    d as r,
    w as u
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            a = new e.Error().stack;
        a && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[a] = "697e00b2-0511-4bfa-8f39-2cab156e8cbf", e._sentryDebugIdIdentifier = "sentry-dbid-697e00b2-0511-4bfa-8f39-2cab156e8cbf")
    } catch {}
})();
const b = s({
    eager: Boolean
}, "lazy");

function c(e, a) {
    const o = f(!1),
        t = r(() => o.value || e.eager || a.value);
    u(a, () => o.value = !0);

    function n() {
        e.eager || (o.value = !1)
    }
    return {
        isBooted: o,
        hasContent: t,
        onAfterLeave: n
    }
}
export {
    b as m, c as u
};