const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["./Bkh5hPBJ.js", "./CIAn7tHz.js", "./BBZLTf3A.js", "./swiper-vue.OzWMjU4A.css", "./BbvgifQp.js", "./entry.J6UAyoZA.css", "./BmQ_KTBh.js", "./CNVksA_o.js", "./Cc4FcFuq.js", "./1xKHoBf3.js", "./WelcomeBonusBlock.BmQvWsJZ.css", "./BsQwbIkT.js", "./BonusBlock.irLMJb0p.css", "./CD3x7And.js", "./CMnmInvQ.js", "./BM8cjqjo.js", "./DHxCvf5R.js", "./DCO7F8HW.js", "./CNgVgUb9.js", "./BulKdswA.js", "./CbxP4vag.js", "./BEPDeFGu.js", "./VTextField.DkEWA9Kv.css", "./AppInputWrapper.DCV2SDt0.css", "./CyEI51nD.js", "./AppInputPwd.CrKvjOB5.css", "./Nc2j0qUX.js", "./DDGpYvNX.js", "./D9sqA5Xl.js", "./Q3GHUzCg.js", "./B9YIqgoQ.js", "./VAvatar.CYkryKM7.css", "./iTYf75jB.js", "./VMenu.BwfwrVx9.css", "./BQ7ou4ZQ.js", "./ssrBoot.BsYIg1rJ.css", "./Ka2RWjod.js", "./VSelect.BKduvVt_.css", "./VCheckbox.7-tHc5Uf.css", "./DF9zLyti.js", "./VGrid.D0S0a0cH.css", "./BtdAVlWx.js", "./Eh0EvCQt.js", "./BeLlcxC7.js", "./AppSelect.BFNqV6Cj.css", "./RegistrationFormView.BkUWLAY9.css", "./BUXbqDP0.js", "./RegistrationBanner.CxuH8qKk.css"]))) => i.map(i => d[i]);
import {
    j as re,
    f as ve,
    h as z,
    l as Le,
    _ as V,
    n as he,
    k as Ce,
    z as Te,
    g as ee,
    p as Ie,
    A as Se,
    C as te,
    v as U,
    o as oe,
    w as pe,
    D as xe,
    E as ce,
    a as Me,
    q as we,
    c as Oe,
    F as Re,
    u as me,
    G as Ue,
    x as _e,
    S as C,
    H as He,
    I as Pe
} from "./BbvgifQp.js";
import {
    z as D,
    _ as b,
    V as u,
    u as e,
    a0 as f,
    D as x,
    W as B,
    a2 as F,
    k as Be,
    w as le,
    B as ie,
    a7 as $,
    a1 as L,
    b as J,
    l as je,
    U as N,
    d as y,
    a8 as M,
    F as H,
    a9 as j,
    ah as Je,
    $ as K,
    ai as Ne,
    J as Ge,
    Y as Xe,
    ae as ze,
    n as de,
    aj as Fe,
    ak as Ke,
    al as qe,
    am as We,
    Q as fe
} from "./BBZLTf3A.js";
import {
    _ as Ye
} from "./Bz8Ax51J.js";
import {
    _ as Ze
} from "./DBHC5eiV.js";
import {
    u as ne
} from "./Eh0EvCQt.js";
import {
    u as De,
    i as Qe,
    c as et
} from "./C7j6Eg3V.js";
import {
    u as ue
} from "./D5xT9ef6.js";
import {
    u as tt
} from "./CBbqpxnU.js";
import {
    A as it,
    _ as nt
} from "./C2rNhci2.js";
import {
    g as Z
} from "./DCO7F8HW.js";
import {
    c as Ae
} from "./CCvy_w1-.js";
import {
    _ as st
} from "./CIAn7tHz.js";
import {
    u as Q
} from "./Cc4FcFuq.js";
import {
    _ as at,
    c as ot
} from "./gfqGpLfr.js";
import {
    _ as lt
} from "./DVkCUlFY.js";
import {
    u as rt
} from "./D_nsTU_t.js";
import {
    _ as ct
} from "./CyEI51nD.js";
import {
    u as ut
} from "./BGM-8W5I.js";
import "./DNwLMpuy.js";
import "./1xKHoBf3.js";
import "./CNVksA_o.js";
(function() {
    try {
        var i = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            t = new i.Error().stack;
        t && (i._sentryDebugIds = i._sentryDebugIds || {}, i._sentryDebugIds[t] = "e030bf56-0245-4ca8-9540-53ebdf08a22d", i._sentryDebugIdIdentifier = "sentry-dbid-e030bf56-0245-4ca8-9540-53ebdf08a22d")
    } catch {}
})();

function mt() {
    const {
        trackButtonClick: i
    } = re();

    function t({
        label: s,
        action: r,
        list: n
    }) {
        const l = {
                live: {
                    act: "live_casino"
                },
                crash: {
                    act: "crash"
                },
                casino: {
                    act: "casino"
                },
                sports: {
                    act: r
                }
            },
            {
                act: a
            } = l[r] || {
                act: r
            },
            o = n.findIndex(m => m.name === s) + 1;
        i({
            category: "main",
            action: a,
            label: s,
            value: String(o)
        })
    }
    return {
        handleClick: t
    }
}
const dt = {
        class: "elastic-search__label",
        for: "search-main-field-click"
    },
    pt = ["placeholder"],
    _t = D({
        __name: "ElasticSearch",
        setup(i) {
            const {
                openDialog: t
            } = ve(), {
                t: s
            } = z();
            return (r, n) => (u(), b("div", {
                class: "elastic-search",
                onClick: n[0] || (n[0] = l => e(t)("search"))
            }, [f("label", dt, [x(Le, {
                class: "search__btn",
                color: "#60748d",
                size: "16"
            }, {
                default: B(() => n[1] || (n[1] = [F("mdi-magnify")])),
                _: 1
            })]), f("input", {
                id: "search-main-field-click",
                placeholder: e(s)("placeholders.search"),
                class: "elastic-search__input",
                type: "search",
                readonly: ""
            }, null, 8, pt)]))
        }
    }),
    ft = V(_t, [
        ["__scopeId", "data-v-0932cb15"]
    ]),
    gt = {
        id: "story-card",
        class: "story-card top-sections__item"
    },
    kt = {
        class: "top-sections__img-wrapper"
    },
    yt = ["data-src", "src", "alt", "title"],
    bt = {
        class: "top-sections__name"
    },
    vt = D({
        __name: "InAppStoryStack",
        props: {
            config: {
                required: !1,
                type: Object,
                default: null
            },
            sectionItem: {
                required: !0,
                type: Object
            }
        },
        setup(i) {
            const {
                t
            } = z(), s = i, r = he(), {
                imageUrl: n
            } = ne(), {
                config: l
            } = Be(s), {
                renderStackedStoryCard: a,
                unreadTrendsCount: o,
                isInAppStoriesReady: m
            } = De(), {
                profileForm: _
            } = Ce(), {
                $privateLog: c
            } = Te();
            let k;
            const d = p => {
                k = Qe(r, p), a(k)
            };
            return le(l, p => {
                p && d(p)
            }), ie(() => {
                var p, v;
                c("[InAppStories] --> InAppStories Mounted"), (p = l.value) != null && p.apiKey && m && ((v = _ == null ? void 0 : _.info) != null && v.uuid) && d(l.value)
            }), (p, v) => {
                var h, T, w, A, E;
                return u(), b("div", gt, [f("div", {
                    class: $(["trends-wrapper", [`trends-${e(o)}`]])
                }, null, 2), f("div", kt, [f("img", {
                    "data-src": `${e(n)}/main/top-sections/${(h=i.sectionItem)==null?void 0:h.iconName}.png`,
                    src: `${e(n)}/main/top-sections/${(T=i.sectionItem)==null?void 0:T.iconName}.png`,
                    alt: `top-sections ${(w=i.sectionItem)==null?void 0:w.name}`,
                    title: `top-sections ${(A=i.sectionItem)==null?void 0:A.name}`,
                    class: "top-sections__img"
                }, null, 8, yt)]), f("span", bt, L(e(t)(`newMain.topSections.${(E=i.sectionItem)==null?void 0:E.name}`)), 1)])
            }
        }
    }),
    ht = V(vt, [
        ["__scopeId", "data-v-1acad3cc"]
    ]),
    Ct = D({
        __name: "InAppStory",
        props: {
            sectionItem: {}
        },
        setup(i) {
            const {
                userUUID: t
            } = ue(), {
                isInAppStoriesReady: s
            } = De(), r = J(null);
            return je(() => {
                s && t.value && (r.value = et(t.value))
            }), (n, l) => {
                const a = ht;
                return u(), N(a, {
                    config: e(r),
                    "section-item": n.sectionItem
                }, null, 8, ["config", "section-item"])
            }
        }
    }),
    ye = {
        "bonuses-page": {
            Bonuses: "bonuses",
            Active: "activeBonuses",
            History: "historyBonuses",
            All: "all",
            Casino: "casino",
            Sports: "sports"
        },
        "main-page-top-sections": {
            JetX: "jetxSections",
            sports: "sportsSections",
            "live-casino": "LiveCasionSections",
            evolution: "evolutionSections",
            casino: "casinoSections",
            aviator: "aviatorSections",
            vip: "vipClubSections",
            cricket: "cricketSections"
        },
        "main-page-sections-titles": {
            live: "liveCasinoTitle",
            sport: "sportsTitle",
            crash: "сrashGamesTitle",
            slots: "slotsTitle",
            casino: "casinoTitle",
            exclusives: "4rabetExclusivesTitle"
        },
        "main-page-sections-more": {
            live: "moreLiveDealers",
            sport: "moreLiveEvents",
            crash: "moreCrashGames",
            slots: "seeAllSlots",
            casino: "moreCasinoGames",
            exclusives: "seeAll4rabetExclusives"
        },
        "main-page-sections-sliders": {
            live: "sliderLiveDealers",
            crash: "sliderCrashGames",
            sport: "sliderSports",
            slots: "sliderSlots",
            casino: "sliderCasinoGames",
            exclusives: "slider4rabetExclusives"
        },
        "main-page-sections-sports": {
            cricket: "sportsCricekt",
            football: "sportsFootball",
            sport: "sports",
            ecricket: "sportsECricket",
            basketball: "sportsBasketball",
            tennis: "sportsTennis",
            fifa: "sportsFifa",
            "table-tennis": "sportsTableTennis",
            volleyball: "sportsVolleyball",
            "ice-hockey": "sportsIceHockey",
            baseball: "sportsBaseBall",
            mma: "sportsMMA",
            handball: "sportsHandball"
        },
        "casino-page": {
            popular: "popular",
            exclusives: "exclusive",
            "new-games": "newGames",
            slots: "slots",
            baccarat: "baccarat",
            roulette: "roulette",
            blackjack: "blackjack",
            other: "other",
            table: "table",
            crash: "crash",
            local: "local",
            fast: "fast",
            vip: "vip",
            virtual_sports: "virtualSports",
            "video-poker-new": "videoPokerNew",
            board: "board"
        },
        "three-pages-titles": {
            popular: "titlePopular",
            exclusives: "titleExclusives",
            "new-games": "titleNewGames",
            slots: "titleSlots",
            baccarat: "titleBaccarat",
            roulette: "titleRoulette",
            blackjack: "titleBlackjack",
            table: "titleTable",
            crash: "titleCrash",
            other: "titleOther",
            vip: "titleVip",
            virtual_sports: "titleVirtualSports",
            "video-poker-new": "titleVideoPokerNew",
            board: "titleBoard"
        }
    };

function Tt(i, t = null) {
    var r;
    const s = t ? (r = ye[t]) == null ? void 0 : r[i] : ye[i];
    return typeof s == "string" ? s : ""
}
const It = ["href", "data-auto-test-el"],
    St = {
        class: "top-sections__img-wrapper"
    },
    xt = ["src", "alt", "title"],
    wt = {
        class: "name-inner top-sections__name"
    },
    Bt = ["id"],
    Nt = D({
        __name: "TopSectionItem",
        props: {
            item: {}
        },
        setup(i) {
            const {
                imageUrl: t
            } = tt(), {
                isAuthenticated: s
            } = ee(), {
                fullDomain: r
            } = Ie(), n = he(), {
                openDialog: l
            } = ve(), {
                mobile: a
            } = Se(), {
                trackButtonClick: o
            } = re(), {
                t: m
            } = z(), _ = te(), c = y(() => i.item.customClass || ""), k = y(() => i.item.name === "aviator" ? a.value ? _(i.item.mobileHref || "") : _(i.item.desktopHref || "") : _(i.item.href) || ""), d = () => (i.item.type === "game" || i.item.type === "lobby") && !s.value, p = () => i.item.name === "deposit", v = () => i.item.name === "vip", h = () => i.item.name === "rewards", T = () => {
                var I;
                return ((I = i.item.href) == null ? void 0 : I.startsWith("/")) || !1
            }, w = I => {
                window.location.href = `${r.value}${I}`
            }, A = () => {
                var I;
                (I = window._smartico) == null || I.dp("dp:gf")
            }, E = (I, P) => {
                I.preventDefault(), d() ? l("auth") : p() ? q() : v() ? w(i.item.href) : h() ? A() : T() ? n.push(k.value) : window.location.href = k.value, o({
                    category: "main",
                    action: "top",
                    label: P
                })
            }, q = () => {
                l(s.value ? "deposit" : "auth")
            };
            return (I, P) => (u(), b("a", {
                href: e(k),
                class: $(["top-sections__item", e(c)]),
                "data-auto-test-el": ("generateTestAttribute" in I ? I.generateTestAttribute : e(Tt))(I.item.name, "main-page-top-sections"),
                onClick: P[0] || (P[0] = W => E(W, I.item.name))
            }, [f("div", St, [f("img", {
                src: `${e(t)}/main/top-sections/${I.item.iconName}.png`,
                alt: `top-sections ${I.item.name}`,
                title: `top-sections ${I.item.name}`,
                class: "top-sections__img"
            }, null, 8, xt)]), f("span", wt, L(e(m)(`newMain.topSections.${I.item.name}`)), 1), f("div", {
                id: `top-section__${I.item.name}`,
                class: "top-sections__item-inner"
            }, null, 8, Bt)], 10, It))
        }
    }),
    Dt = V(Nt, [
        ["__scopeId", "data-v-f6364ff1"]
    ]),
    At = {
        key: 0,
        class: "top-sections__wrapper"
    },
    $t = D({
        __name: "TopSectionList",
        props: {
            modifiedItems: {
                default: () => []
            }
        },
        setup(i) {
            const {
                isInAppStoriesReady: t
            } = U(oe()), s = y(() => Array.isArray(i.modifiedItems) ? i.modifiedItems : []), r = y(() => s.value.find(l => (l == null ? void 0 : l.name) === "trends")), n = y(() => s.value.filter(l => (l == null ? void 0 : l.name) !== "trends"));
            return (l, a) => {
                const o = Ct,
                    m = Dt;
                return e(s).length ? (u(), b("div", At, [e(r) && e(t) ? (u(), N(o, {
                    key: `${e(r).id}-trends`,
                    "section-item": e(r)
                }, null, 8, ["section-item"])) : M("", !0), (u(!0), b(H, null, j(e(n), _ => (u(), N(m, {
                    key: _.id,
                    item: _
                }, null, 8, ["item"]))), 128))])) : M("", !0)
            }
        }
    }),
    Vt = {
        class: "top-sections"
    },
    Et = D({
        __name: "index",
        props: {
            topData: {}
        },
        setup(i) {
            const {
                isAuthenticated: t
            } = ee(), {
                userUUID: s
            } = ue(), {
                isInAppStoriesReady: r
            } = U(oe()), {
                showSmartico: n
            } = U(Ce()), {
                userGeo: l
            } = U(pe());

            function a(c, k) {
                const d = it.includes(k),
                    p = ["RW", "ZM"].includes(k);
                return c.filter(v => "forAfrica" in v ? d ? v.name === "pragmatic" ? p ? v.rwORzm === !0 : !v.rwORzm : v.forAfrica : !v.forAfrica : !0)
            }
            const o = y(() => a(i.topData.list, l.value)),
                m = (c, k, d, p) => {
                    if (!c.length) return c;
                    const v = c.findIndex(T => T.id === k),
                        h = c.findIndex(T => T.id === d);
                    return v === -1 || h === -1 ? c : [...c.slice(0, h), p, ...c.slice(h).filter((T, w) => w + h !== v)]
                },
                _ = y(() => {
                    let c = [...o.value];
                    if (n.value) {
                        const k = !!xe[l.value];
                        c = m(c, k ? 9 : 4, k ? 1 : 2, {
                            id: 2,
                            iconName: "cup",
                            name: "rewards",
                            href: ""
                        })
                    }
                    return r.value && t.value && l.value === "IN" && s.value && (c = m(c, 1, 1, {
                        id: 1,
                        iconName: "trends",
                        name: "trends",
                        href: ""
                    })), c
                });
            return (c, k) => {
                const d = $t;
                return u(), b("div", Vt, [(u(), N(d, {
                    key: e(n),
                    "modified-items": e(_),
                    "show-smartico": e(n)
                }, null, 8, ["modified-items", "show-smartico"]))])
            }
        }
    }),
    Lt = {
        class: "entertainment-info__title-block"
    },
    Mt = ["src"],
    Ot = ["data-auto-test-el"],
    Rt = D({
        __name: "TitleComponent",
        props: {
            config: {},
            sectionLink: {}
        },
        setup(i) {
            const {
                imageUrl: t
            } = ne(), {
                t: s
            } = z(), r = te(), {
                trackButtonClick: n
            } = re(), l = o => {
                n({
                    category: "gamehall",
                    action: "header_click",
                    label: o
                })
            }, a = (o, m) => {
                n({
                    category: "main",
                    action: o,
                    label: m
                })
            };
            return (o, m) => {
                var c;
                const _ = ce;
                return u(), b("div", Lt, [x(_, {
                    to: e(r)(o.config.titleLink),
                    tag: "div",
                    class: "entertainment-info__title-link-wrapper",
                    onClick: l
                }, {
                    default: B(() => [f("img", {
                        src: `${e(t)}/main/slots/block/small/${o.config.titleIcoId}.png`,
                        alt: "block"
                    }, null, 8, Mt), f("h2", {
                        class: "entertainment-info__title-text",
                        "data-auto-test-el": ("generateDataAutoTestElName" in o ? o.generateDataAutoTestElName : e(Z))(o.config.name, "main-page-sections-titles")
                    }, [f("span", null, L(e(s)(`newMain.gameSection.${o.config.name}.title`)), 1)], 8, Ot)]),
                    _: 1
                }, 8, ["to"]), o.config.link && ((c = o.config.linkText) == null ? void 0 : c.length) > 0 ? (u(), N(_, {
                    key: 0,
                    id: `main__${o.config.name}-more-btn`,
                    to: e(r)(o.sectionLink),
                    class: "entertainment-info__second-link",
                    "data-auto-test-el": ("generateDataAutoTestElName" in o ? o.generateDataAutoTestElName : e(Z))(o.config.name, "main-page-sections-more"),
                    onClick: m[0] || (m[0] = k => a(`more_${o.config.name}`, o.config.name))
                }, {
                    default: B(() => [F(L(e(s)(`newMain.gameSection.${o.config.name}.linkText`)) + " > ", 1)]),
                    _: 1
                }, 8, ["id", "to", "data-auto-test-el"])) : M("", !0)])
            }
        }
    }),
    Ut = V(Rt, [
        ["__scopeId", "data-v-1ae0e451"]
    ]),
    Ht = {
        class: "statistics-block"
    },
    Pt = {
        class: "statistics-block__main-content"
    },
    jt = {
        class: "statistics-block__nums-info statistics-block__nums-info--bold statistics-block__nums-info--skeleton"
    },
    Jt = {
        class: "statistics-block__nums-info"
    },
    Gt = {
        class: "statistics-block__mark-text"
    },
    Xt = D({
        __name: "StatisticsComponent",
        props: {
            markColor: {
                default: "green"
            }
        },
        setup(i) {
            const t = i,
                s = Je(),
                r = J(!1);
            return ie(() => {
                var a;
                const n = (a = s.data) == null ? void 0 : a.call(s),
                    l = (n == null ? void 0 : n.map(o => o.children).join("")) || "";
                l && (r.value = l.length > 13)
            }), (n, l) => (u(), b("div", Ht, [f("div", Pt, [f("p", jt, [K(n.$slots, "data", {}, void 0, !0)]), f("p", Jt, [K(n.$slots, "description", {}, void 0, !0)])]), e(s).markText && e(s).data ? (u(), b("mark", {
                key: 0,
                class: $(["statistics-block__mark", `statistics-block__mark--${t.markColor}`, {
                    "statistics-block__mark--moved": e(r)
                }])
            }, [f("span", Gt, [K(n.$slots, "markText", {}, void 0, !0)])], 2)) : M("", !0)]))
        }
    }),
    zt = V(Xt, [
        ["__scopeId", "data-v-e4c89751"]
    ]),
    Ft = {
        class: "info-block__inner-block"
    },
    Kt = {
        class: "info-block__top-section"
    },
    qt = {
        class: "info-block__headline"
    },
    Wt = {
        class: "info-block__headline info-block__headline--bold"
    },
    Yt = ["src"],
    Zt = {
        class: "info-block__bottom-block"
    },
    Qt = ["src"],
    ei = D({
        __name: "InfoComponent",
        props: {
            blockColor: {
                default: "green"
            },
            infoType: {
                default: ""
            },
            blockLink: {
                default: ""
            },
            config: {}
        },
        setup(i) {
            const t = i,
                {
                    t: s
                } = z(),
                {
                    app: r
                } = Me(),
                {
                    randomNumbers: n
                } = U(we()),
                {
                    appDefaultCurrency: l
                } = Ie(),
                a = y(() => {
                    var _, c, k, d, p;
                    return (k = (c = (_ = t.config) == null ? void 0 : _.infoBlock) == null ? void 0 : c.statisticsBlocks) != null && k.length ? (p = (d = t.config) == null ? void 0 : d.infoBlock) == null ? void 0 : p.statisticsBlocks : []
                }),
                o = y(() => {
                    var _, c, k, d;
                    return (c = (_ = t.config) == null ? void 0 : _.infoBlock) != null && c.images ? (d = (k = t.config) == null ? void 0 : k.infoBlock) == null ? void 0 : d.images : {
                        main: "",
                        minor: ""
                    }
                });

            function m(_, c = !1) {
                const d = n.value,
                    p = new Intl.NumberFormat().format((d == null ? void 0 : d[_]) || "0"),
                    v = Ae.MAIN_CURRENCY.includes(l.value) ? l.value : "INR";
                return c ? `${p} ${v}` : p
            }
            return (_, c) => {
                const k = zt,
                    d = ce;
                return u(), N(d, Ge({
                    to: _.blockLink,
                    class: ["info-block", `info-block--${_.blockColor}`]
                }, _.$attrs, {
                    tag: "div"
                }), {
                    default: B(() => [f("div", Ft, [f("div", Kt, [f("p", qt, [f("span", null, L(e(s)(`newMain.gameSection.${_.config.name}.minorTitle`)), 1)]), f("p", Wt, [f("span", null, L(e(s)(`newMain.gameSection.${_.config.name}.minorSubTitle`)), 1)])]), f("div", {
                        class: $([
                            [`info-block__img-block--main-${_.infoType}`], "info-block__img-block"
                        ])
                    }, [f("img", {
                        class: "entertainment-info__img",
                        src: `${e(r).imagesUrl}${e(o).main}`,
                        alt: "image slot icon",
                        title: "image slot icon"
                    }, null, 8, Yt)], 2), f("div", Zt, [(u(!0), b(H, null, j(e(a), p => {
                        var v;
                        return u(), N(k, {
                            key: p.key || p.defaultValue,
                            "mark-color": (v = p.badge) == null ? void 0 : v.color,
                            class: "entertainment-info__statistics-block"
                        }, Ne({
                            description: B(() => [F(L(e(s)(`newMain.gameSection.${_.config.name}.${p.description}`)), 1)]),
                            _: 2
                        }, [e(n) ? {
                            name: "data",
                            fn: B(() => [F(L(p.key ? m(p.key, p.isCurrency) : p.defaultValue), 1)]),
                            key: "0"
                        } : void 0, p.badge ? {
                            name: "markText",
                            fn: B(() => [F(L(e(s)(`newMain.gameSection.${_.config.name}.${p.badge.text}`)), 1)]),
                            key: "1"
                        } : void 0]), 1032, ["mark-color"])
                    }), 128))]), f("div", {
                        class: $([
                            [`info-block__img-block--minor-${_.infoType}`], "info-block__img-block"
                        ])
                    }, [f("img", {
                        class: "entertainment-info__img entertainment-info__img--minor",
                        src: `${e(r).imagesUrl}${e(o).minor}`,
                        alt: "image slot icon",
                        title: "image slot icon"
                    }, null, 8, Qt)], 2)])]),
                    _: 1
                }, 16, ["to", "class"])
            }
        }
    }),
    ti = V(ei, [
        ["__scopeId", "data-v-83226f10"]
    ]),
    ii = {
        class: "activity-block__inner"
    },
    ni = {
        class: "activity-block__content"
    },
    si = D({
        __name: "ActivityBlock",
        props: {
            name: {
                default: ""
            },
            goto: {}
        },
        setup(i) {
            const t = i;
            return (s, r) => {
                const n = nt;
                return u(), N(n, {
                    class: "activity-block",
                    "route-path": t.goto
                }, {
                    default: B(() => [f("div", ii, [f("div", ni, [K(s.$slots, "icon"), f("h3", null, [K(s.$slots, "name")])])])]),
                    _: 3
                }, 8, ["route-path"])
            }
        }
    }),
    ai = ["id", "data-auto-test-el"],
    oi = ["src", "alt"],
    li = {
        class: "entertainment-info__activity-name"
    },
    ri = D({
        __name: "ActivityCard",
        props: {
            activity: {},
            handleClickTrack: {
                type: Function
            }
        },
        setup(i) {
            const t = i,
                {
                    isMobile: s
                } = Q(),
                {
                    t: r
                } = z(),
                {
                    imageUrl: n
                } = ne();

            function l() {
                return s.value && t.activity.hrefMobile || t.activity.href
            }
            return (a, o) => {
                const m = si;
                return u(), b("li", {
                    id: `sport__${a.activity.seoName}`,
                    class: $(["entertainment-info__list-item", {
                        "entertainment-info__list-item": !e(s),
                        "entertainment-info__slider-item": e(s)
                    }]),
                    "data-auto-test-el": ("generateDataAutoTestElName" in a ? a.generateDataAutoTestElName : e(Z))(a.activity.name, "main-page-sections-sports"),
                    onClick: o[0] || (o[0] = _ => a.handleClickTrack(a.activity.name, "sports"))
                }, [x(m, {
                    goto: l(),
                    name: a.activity.name,
                    class: $({
                        "entertainment-info__activity-block": !0,
                        icc: a.activity.name === "ICC",
                        ipl: a.activity.name === "IPL"
                    })
                }, {
                    icon: B(() => [f("div", {
                        class: $(["entertainment-info__activity-ico-wrapper", {
                            icc: a.activity.name === "ICC",
                            ipl: a.activity.name === "IPL"
                        }])
                    }, [f("img", {
                        class: "entertainment-info__activity-ico",
                        src: e(n) + a.activity.icon,
                        alt: a.activity.name
                    }, null, 8, oi)], 2)]),
                    name: B(() => [f("div", li, L(e(r)(`newMain.sportSections.${a.activity.name}`)), 1)]),
                    _: 1
                }, 8, ["goto", "name", "class"])], 10, ai)
            }
        }
    }),
    ci = V(ri, [
        ["__scopeId", "data-v-64509d00"]
    ]),
    ui = {},
    mi = {
        class: "entertainment-info__list-slot-skeleton"
    };

function di(i, t) {
    return u(), b("div", mi)
}
const pi = V(ui, [
        ["render", di],
        ["__scopeId", "data-v-cec0f1c0"]
    ]),
    _i = {
        class: "slot-item"
    },
    fi = {
        class: "slot-item__name"
    },
    be = "/no-img.png",
    gi = D({
        __name: "SlotItemMain",
        props: {
            slotItem: {},
            categoryLink: {},
            completeHref: {},
            useAspectRatio: {
                type: Boolean
            }
        },
        setup(i) {
            const t = i,
                {
                    imageUrl: s
                } = ne(),
                r = te(),
                {
                    slotItem: n,
                    categoryLink: l
                } = Be(t),
                {
                    changeUploadHost: a
                } = Oe(),
                o = J(!1),
                m = y(() => {
                    var d;
                    return o.value ? be : n.value.imageCustom ? s.value + n.value.image : a((d = n == null ? void 0 : n.value) == null ? void 0 : d.image)
                }),
                _ = y(() => n.value.name),
                c = y(() => {
                    let d = "";
                    return t.completeHref ? d = t.completeHref : (d = new URL(l.value, window.location.origin).pathname, d = `${d}/slot/${n.value.link_name||n.value.friendly_url||n.value.id}`), r(d)
                });

            function k() {
                o.value = !0
            }
            return (d, p) => {
                const v = at,
                    h = lt,
                    T = ce;
                return u(), b("div", _i, [x(T, {
                    class: "slot-item__link-wrapper",
                    to: e(c)
                }, {
                    default: B(() => {
                        var w;
                        return [f("div", {
                            class: $(["slot-item__img-block", {
                                "slot-item__img-block--aspect-ratio": d.useAspectRatio
                            }])
                        }, [x(v, {
                            "slot-item": e(n)
                        }, null, 8, ["slot-item"]), x(h, {
                            alt: e(n).name,
                            class: "slot-item__img",
                            placeholder: be,
                            preset: e(n).image && ((w = e(n).image) != null && w.includes(".svg")) ? "" : "slotImg",
                            src: e(m),
                            title: e(n).name,
                            loading: "lazy",
                            onError: k
                        }, null, 8, ["alt", "preset", "src", "title"])], 2), f("div", fi, [K(d.$slots, "default", {
                            slotName: e(_)
                        }, void 0, !0)])]
                    }),
                    _: 3
                }, 8, ["to"])])
            }
        }
    }),
    ki = V(gi, [
        ["__scopeId", "data-v-c4670273"]
    ]),
    yi = {
        class: "entertainment-info__slot-item-name"
    },
    bi = D({
        __name: "SlotCard",
        props: {
            slotItem: {},
            config: {},
            handleClickTrack: {
                type: Function
            }
        },
        setup(i) {
            const t = i,
                {
                    displayDialog: s
                } = Re(),
                {
                    isMobile: r
                } = Q(),
                {
                    isUserFake: n
                } = ue(),
                {
                    isAuthenticated: l
                } = ee(),
                a = y(() => ot(t.slotItem.name, n.value));

            function o() {
                _(), t.handleClickTrack(t.slotItem.name, t.config.name)
            }

            function m() {
                return r && t.slotItem.hrefMobile || t.slotItem.href
            }

            function _() {
                l.value || s("registration")
            }
            return (c, k) => {
                const d = ki;
                return Xe((u(), b("li", {
                    class: $({
                        "entertainment-info__slider-item": e(r),
                        "entertainment-info__list-slot-wrapper": !e(r)
                    }),
                    onClick: o
                }, [x(d, {
                    "complete-href": m(),
                    "category-link": c.config.link,
                    "slot-item": c.slotItem,
                    "use-aspect-ratio": e(r),
                    class: $({
                        "entertainment-info__slot-item": !0,
                        "entertainment-info__slot-item--no-click": !e(l)
                    })
                }, Ne({
                    _: 2
                }, [e(r) ? {
                    name: "default",
                    fn: B(({
                        slotName: p
                    }) => [f("span", yi, L(p), 1)]),
                    key: "0"
                } : void 0]), 1032, ["complete-href", "category-link", "slot-item", "use-aspect-ratio", "class"])], 2)), [
                    [ze, e(a)]
                ])
            }
        }
    }),
    vi = V(bi, [
        ["__scopeId", "data-v-82e48265"]
    ]),
    hi = {
        class: "entertainment-info"
    },
    Ci = {
        class: "entertainment-info__content-block"
    },
    Ti = ["data-auto-test-el"],
    Ii = ["data-auto-test-el"],
    Si = "crash",
    xi = 12,
    wi = D({
        __name: "EntertainmentIndex",
        props: {
            config: {}
        },
        setup(i) {
            const t = i,
                s = te(),
                {
                    config: r
                } = me(),
                {
                    userGeo: n
                } = U(pe()),
                {
                    getSlotsMainPage: l
                } = U(Ue()),
                {
                    isMobile: a
                } = Q(),
                {
                    handleClick: o
                } = mt(),
                {
                    isMobileUa: m
                } = rt(),
                {
                    getCustomRequest: _
                } = we(),
                c = J([]),
                k = y(() => t.config.name),
                d = y(() => k.value === Si),
                p = y(() => n.value),
                v = y(() => t.config.isBlockCategory ? t.config.linkCategory : t.config.link),
                h = y(() => {
                    var g, S;
                    return (S = (g = t.config) == null ? void 0 : g.infoBlock) != null && S.style ? t.config.infoBlock.style : {
                        color: ""
                    }
                }),
                T = y(() => {
                    var S, O, R, G;
                    if (!((O = (S = t.config) == null ? void 0 : S.list) != null && O.length)) return [];
                    const g = JSON.parse(JSON.stringify(t.config.list));
                    return t.config.name === "sport" && p.value === Ae.DEFAULT_GEO && ((R = r.value) != null && R.IS_IPL) ? (g.pop(), g.unshift({
                        id: 0,
                        name: "IPL",
                        seoName: "IPL",
                        href: "/sports/cricket/india/indian-premier-league-1710528586840150016",
                        icon: "/main/betby/sports/ipl.png",
                        order: 0,
                        type: "link"
                    }), g) : t.config.name === "sport" && ["IN", "BD"].includes(p.value) && ((G = r.value) != null && G.IS_ICC) ? (g.pop(), g.unshift({
                        id: 0,
                        name: "ICC",
                        seoName: "ICC",
                        href: "/sports/cricket",
                        icon: "/main/betby/sports/ICC.png",
                        order: 0,
                        type: "link"
                    }), g) : t.config.list
                }),
                w = y(() => {
                    var g;
                    return ((g = T.value) == null ? void 0 : g.length) && !d.value
                }),
                A = y(() => {
                    var g, S;
                    return !((g = T.value) != null && g.length) || ((S = T.value) == null ? void 0 : S.length) && d.value
                }),
                E = y(() => t.config.isDataDynamic),
                q = y(() => {
                    var R;
                    if (!((R = t.config) != null && R.apiUrl)) return "";
                    const [g, S] = t.config.apiUrl.split("?"), O = new URLSearchParams(S);
                    return a.value || m.value ? O.set("mobile", "true") : O.set("desktop", "true"), p.value && O.set("country", p.value), `${g}?${O.toString()}`
                }),
                I = y(() => {
                    var O, R, G, ae;
                    if (!((O = t.config) != null && O.isDataExternal) || !t.config.section || !t.config.externalCategorySlug) return [];
                    const g = l.value,
                        S = ((R = t.config) == null ? void 0 : R.section) + ((G = t.config) == null ? void 0 : G.externalCategorySlug);
                    return ((ae = g == null ? void 0 : g[S]) == null ? void 0 : ae.slots.slice(0, xi)) || []
                });
            async function P() {
                try {
                    return (await _(q.value)).data
                } catch {
                    throw new Error("[EntertainmentInfoSection.fetchSlots] Error while fetching slots")
                }
            }

            function W(g, S) {
                o({
                    label: g,
                    action: S,
                    list: T.value
                })
            }

            function se(g, S) {
                o({
                    label: g,
                    action: S,
                    list: c.value
                })
            }
            return ie(async () => {
                var g;
                if (E.value) {
                    await de();
                    try {
                        c.value = await P()
                    } catch (S) {
                        console.error(S)
                    }
                } else(g = t.config) != null && g.isDataExternal ? (await de(), c.value = I.value) : c.value = T.value
            }), le(() => I.value, g => {
                var S;
                (S = t.config) != null && S.isDataExternal && (c.value = g)
            }), (g, S) => {
                var ge, ke;
                const O = Ut,
                    R = ti,
                    G = st,
                    ae = ci,
                    $e = pi,
                    Ve = vi;
                return u(), b("section", hi, [x(O, {
                    config: t.config,
                    "section-link": e(v)
                }, null, 8, ["config", "section-link"]), f("div", Ci, [x(G, null, {
                    default: B(() => [!e(a) || !e(m) ? (u(), N(R, {
                        key: 0,
                        "block-color": e(h).color,
                        config: t.config,
                        "info-type": t.config.name,
                        "block-link": e(s)(e(v)),
                        class: "entertainment-info__info-block"
                    }, null, 8, ["block-color", "config", "info-type", "block-link"])) : M("", !0)]),
                    _: 1
                }), e(w) ? (u(), b("ul", {
                    key: 0,
                    class: $({
                        "entertainment-info__list": !e(a) || !e(m),
                        "entertainment-info__slider entertainment-info__slider--sport-mob": e(a) || e(m)
                    }),
                    "data-auto-test-el": ("generateDataAutoTestElName" in g ? g.generateDataAutoTestElName : e(Z))(t.config.name, "main-page-sections-sliders")
                }, [(u(!0), b(H, null, j(e(T), X => (u(), N(ae, {
                    key: X.id,
                    activity: X,
                    "is-mobile": e(a) || e(m),
                    "handle-click-track": W
                }, null, 8, ["activity", "is-mobile"]))), 128))], 10, Ti)) : M("", !0), e(A) ? (u(), b("ul", {
                    key: 1,
                    class: $({
                        "entertainment-info__list": !e(a) || !e(m),
                        "entertainment-info__slider entertainment-info__slider--slot-mob": e(a) || e(m)
                    }),
                    "data-auto-test-el": ("generateDataAutoTestElName" in g ? g.generateDataAutoTestElName : e(Z))(t.config.name, "main-page-sections-sliders")
                }, [((ge = e(c)) == null ? void 0 : ge.length) === 0 ? (u(), b(H, {
                    key: 0
                }, j(12, X => x($e, {
                    key: "skeleton-" + (e(a) || e(m) ? "mobile-" : "") + X
                })), 64)) : M("", !0), ((ke = e(c)) == null ? void 0 : ke.length) > 0 ? (u(!0), b(H, {
                    key: 1
                }, j(e(c), (X, Ee) => (u(), N(Ve, {
                    key: X.id,
                    "slot-item": X,
                    config: t.config,
                    "handle-click-track": se,
                    "data-auto-test-el": `${t.config.name}${Ee+1}`
                }, null, 8, ["slot-item", "config", "data-auto-test-el"]))), 128)) : M("", !0)], 10, Ii)) : M("", !0)])])
            }
        }
    }),
    Bi = V(wi, [
        ["__scopeId", "data-v-e28d11db"]
    ]),
    Ni = fe(() => _e(() =>
        import ("./Bkh5hPBJ.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]),
        import.meta.url).then(i => i.default || i)),
    Di = fe(() => _e(() =>
        import ("./BsQwbIkT.js"), __vite__mapDeps([11, 1, 2, 3, 4, 5, 6, 7, 12]),
        import.meta.url).then(i => i.default || i)),
    Ai = {
        class: "allBonuses"
    },
    $i = {
        key: 0,
        class: "allBonuses__right-gradient"
    },
    Vi = {
        key: 1,
        class: "d-flex justify-space-between"
    },
    Ei = {
        key: 2,
        class: "allBonuses__swiper"
    },
    Li = {
        key: 3,
        class: "allBonuses__slider-arrows"
    },
    Mi = {
        id: "slider-back-bonus",
        class: "slider-btn-bonus"
    },
    Oi = {
        id: "slider-next-bonus",
        class: "ml-2 slider-btn-bonus"
    },
    Ri = D({
        __name: "ListComponent",
        setup(i) {
            const {
                mdAndUp: t
            } = Se(), {
                isMobile: s
            } = Q(), {
                isAuthenticated: r
            } = ee(), {
                userUUID: n
            } = ue(), {
                bonusesCurrencyByGeo: l
            } = ut(), {
                fetchBonusesList: a
            } = oe(), {
                isDesktop: o
            } = Q(), {
                sortedBonuses: m
            } = U(oe()), _ = y(() => ({
                delay: 1e4,
                disableOnInteraction: s.value
            })), c = y(() => o.value && m.value.length && m.value.length >= 3), k = y(() => s.value ? 2 : 3), d = J(0);
            return le(n, (p, v) => {
                p !== v && a(l.value)
            }), le(() => m.value, (p, v) => {
                p !== v && d.value++
            }, {
                deep: !0
            }), ie(() => {
                (!n.value && !r.value && !m.value.length || !m.value.length && n.value) && a(l.value)
            }), (p, v) => {
                const h = Ni,
                    T = Di,
                    w = ct;
                return u(), b("div", Ai, [e(c) ? (u(), b("div", $i)) : M("", !0), e(m).length ? (u(), b("div", Ei, [x(e(Fe), {
                    ref: "swiper",
                    loop: !1,
                    autoplay: e(_),
                    "update-on-window-resize": !0,
                    "free-mode": !0,
                    mousewheel: !1,
                    "hidden-class": !0,
                    "slides-per-view": "auto",
                    "space-between": 8,
                    navigation: {
                        enabled: !0,
                        disabledClass: "not-active",
                        nextEl: "#slider-next-bonus",
                        prevEl: "#slider-back-bonus"
                    },
                    modules: [e(Ke), e(qe)],
                    "data-auto-test-el": "sliderBonuses"
                }, {
                    default: B(() => [(u(!0), b(H, null, j(e(m), (A, E) => (u(), N(e(We), {
                        key: E,
                        class: "swiper-slide"
                    }, {
                        default: B(() => [f("div", {
                            class: $(`bonusBlock${E}`)
                        }, [A.is_welcome ? (u(), N(h, {
                            key: `welcome-${e(d)}`,
                            bonus: A
                        }, null, 8, ["bonus"])) : (u(), N(T, {
                            key: `blocks-${e(d)}`,
                            bonus: A
                        }, null, 8, ["bonus"]))], 2)]),
                        _: 2
                    }, 1024))), 128))]),
                    _: 1
                }, 8, ["autoplay", "modules"])])) : (u(), b("div", Vi, [(u(!0), b(H, null, j(e(k) || 2, A => (u(), b("div", {
                    key: A,
                    class: "allBonuses__skeleton"
                }))), 128))])), e(t) ? (u(), b("div", Li, [f("div", Mi, [x(w, {
                    size: 33,
                    "symbol-id": "slidePrev"
                })]), f("div", Oi, [x(w, {
                    size: 33,
                    "symbol-id": "slideNext"
                })])])) : M("", !0)])
            }
        }
    }),
    Ui = V(Ri, [
        ["__scopeId", "data-v-dc0217fe"]
    ]),
    Hi = {
        class: "bonuses-section"
    },
    Pi = {
        class: "bonuses-section__title-block"
    },
    ji = ["src"],
    Ji = {
        class: "bonuses-section__title-block__text",
        "data-auto-test-el": "bonusesTitle"
    },
    Gi = D({
        __name: "BonusesIndex",
        setup(i) {
            const {
                t
            } = z(), s = te(), {
                imageUrl: r
            } = ne(), {
                trackButtonClick: n
            } = re();

            function l(a) {
                n({
                    category: "main",
                    action: a,
                    label: "bonuses"
                })
            }
            return (a, o) => {
                const m = ce,
                    _ = Ui;
                return u(), b("div", Hi, [f("div", Pi, [x(m, {
                    to: e(s)("bonuses"),
                    tag: "div",
                    class: "bonuses-section__title-block__link-wrapper"
                }, {
                    default: B(() => [f("img", {
                        src: `${e(r)}/main/slots/block/small/gift-box.png`,
                        alt: "block"
                    }, null, 8, ji), f("h2", Ji, [f("span", null, L(e(t)("newMain.bonusSection.title")), 1)])]),
                    _: 1
                }, 8, ["to"]), x(m, {
                    to: e(s)("bonuses"),
                    class: "bonuses-section__second-link",
                    "data-auto-test-el": "moreBonuses",
                    onClick: o[0] || (o[0] = c => l("more_bonuses"))
                }, {
                    default: B(() => [F(L(e(t)("newMain.bonusSection.showMore")) + " > ", 1)]),
                    _: 1
                }, 8, ["to"])]), x(_)])
            }
        }
    }),
    Xi = V(Gi, [
        ["__scopeId", "data-v-81640f85"]
    ]),
    zi = {
        banner: {
            subTitle1: "700%",
            bgType: "blue",
            mainBgPhoto: "/main/main-top-banner-item-flagv2.png",
            mainPhoto: "/main/main-top-banner-item-person.png"
        },
        top: {
            title: "शीर्ष सैक्‍शंस",
            list: [{
                id: 1,
                iconName: "JetX",
                name: "JetX",
                href: C.JETX_MOBILE,
                desktopHref: C.JETX_DESKTOP,
                mobileHref: C.JETX_MOBILE,
                type: "game"
            }, {
                id: 2,
                iconName: "sports",
                name: "sports",
                href: "/live",
                isLinkToBT: !0
            }, {
                id: 3,
                iconName: "live-casino",
                name: "live-casino",
                href: "/live-dealers"
            }, {
                id: 4,
                iconName: "evolution",
                name: "evolution",
                href: "/live-dealers/evolution",
                desktopHref: "/live-dealers/evolution",
                mobileHref: "/live-dealers/evolution",
                type: "lobby"
            }, {
                id: 5,
                iconName: "chicken-road",
                name: "chicken-road",
                href: C.CHICKEN_ROAD,
                type: "game"
            }, {
                id: 6,
                iconName: "aviator",
                name: "aviator",
                href: C.AVIATOR_MOBILE,
                desktopHref: C.AVIATOR_DESKTOP,
                mobileHref: C.AVIATOR_MOBILE,
                type: "game"
            }, {
                id: 7,
                iconName: "vip",
                name: "vip",
                href: "/new-promo/land-loyalty-vip"
            }, {
                id: 8,
                iconName: "cricket",
                name: "cricket",
                href: "/live/cricket",
                isLinkToBT: !0
            }]
        },
        sections: [{
            name: "live",
            order: 1,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "popular",
            section: "live-casino",
            seoTitle: "liveTitle",
            title: "लाइव कैसिनो",
            titleIcoId: "live-casino",
            link: "/live-dealers",
            titleLink: "/live-dealers",
            linkText: "More games",
            icon: "",
            infoBlock: {
                style: {
                    color: "blue"
                },
                images: {
                    main: "/main/slot2.png",
                    minor: "/main/cubes.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "green"
                    },
                    id: 1,
                    key: "live_dealers_total_round_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    key: "live_dealers_active_tables",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "",
                    defaultValue: "BET ON TEEN PATTI",
                    description: "title3",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "live_dealers_highest_win_of_day",
                    defaultValue: "",
                    description: "title4",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=25&pagination[limit]=12&pagination[page]=1&weighted=25&favorite=0",
            list: []
        }, {
            name: "sport",
            order: 2,
            isSport: !0,
            isDataDynamic: !1,
            seoTitle: "sportTitle",
            title: "स्‍पोर्ट्सबुक‍",
            titleIcoId: "sports",
            link: "/live",
            titleLink: "/live",
            linkText: "अधिक इवेंट्स",
            infoBlock: {
                style: {
                    color: "green"
                },
                images: {
                    main: "/main/sport.png",
                    minor: "/main/cricket-ball.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "red"
                    },
                    key: "online_now_highest_win_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !0
                }, {
                    badge: {
                        text: "bage2",
                        color: "green"
                    },
                    key: "online_now_highest_win_of_month",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: {
                        text: "bage3",
                        color: "green"
                    },
                    key: "online_now_highest_win_of_all_time",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "",
            list: [{
                id: 1,
                name: "cricket",
                seoName: "cricket",
                href: "/live/cricket",
                icon: "/main/betby/sports/cricket.png",
                order: 1,
                type: "link"
            }, {
                id: 2,
                name: "football",
                seoName: "football",
                href: "/live/soccer",
                icon: "/main/betby/sports/football.png",
                order: 2,
                type: "link"
            }, {
                id: 3,
                name: "ecricket",
                seoName: "ecricket",
                href: "/live/ecricket",
                icon: "/main/betby/sports/Ecricket.png",
                order: 3,
                type: "link"
            }, {
                id: 4,
                name: "basketball",
                seoName: "basketball",
                href: "/live/basketball",
                icon: "/main/betby/sports/basketball.png",
                order: 4,
                type: "link"
            }, {
                id: 5,
                name: "tennis",
                seoName: "tennis",
                href: "/live/tennis",
                icon: "/main/betby/sports/tennis.png",
                order: 5,
                type: "link"
            }, {
                id: 6,
                name: "fifa",
                seoName: "fifa",
                href: "/live/fifa",
                icon: "/main/betby/sports/fifa.png",
                order: 6,
                type: "link"
            }, {
                id: 7,
                name: "table-tennis",
                seoName: "table-tennis",
                href: "/live/table-tennis",
                icon: "/main/betby/sports/table_tennis.png",
                order: 7,
                type: "link"
            }, {
                id: 8,
                name: "volleyball",
                seoName: "volleyball",
                href: "/live/volleyball",
                icon: "/main/betby/sports/volleyball.png",
                order: 8,
                type: "link"
            }, {
                id: 9,
                name: "ice-hockey",
                seoName: "ice-hockey",
                href: "/live/ice-hockey",
                icon: "/main/betby/sports/hockey.png",
                order: 9,
                type: "link"
            }, {
                id: 10,
                name: "baseball",
                seoName: "baseball",
                href: "/live/baseball",
                icon: "/main/betby/sports/baseball.png",
                order: 11,
                type: "link"
            }, {
                id: 11,
                name: "mma",
                seoName: "mma",
                href: "/sports/mma",
                icon: "/main/betby/sports/mma.png",
                order: 11,
                type: "link"
            }, {
                id: 12,
                name: "handball",
                seoName: "handball",
                href: "/sports/handball",
                icon: "/main/betby/sports/handball.png",
                order: 12,
                type: "link"
            }]
        }, {
            name: "crash",
            order: 3,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "crash",
            section: "casino",
            seoTitle: "crashTitle",
            title: "क्रैश गेम्‍स",
            titleIcoId: "aviator",
            link: "/casino",
            linkCategory: "/casino/crash",
            isBlockCategory: !0,
            titleLink: "/casino/crash",
            linkText: "More Crash games",
            infoBlock: {
                style: {
                    color: "red"
                },
                images: {
                    main: "/main/red-plane.png",
                    minor: "/main/x100.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "green"
                    },
                    key: "tv_games_total_round_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "",
                    defaultValue: "AVIATOR",
                    description: "title2",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "tv_games_highest_win_of_day",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "tv_games_highest_jackpot_of_all_time",
                    defaultValue: "",
                    description: "title4",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=13&pagination[limit]=12&pagination[page]=1&weighted=13&favorite=0",
            list: []
        }, {
            name: "slots",
            order: 4,
            isSport: !1,
            isDataDynamic: !0,
            seoTitle: "slotsTitle",
            title: "क्रैश गेम्‍स",
            titleIcoId: "slots",
            link: "/casino",
            linkCategory: "/casino/slots",
            isBlockCategory: !0,
            titleLink: "/casino/slots",
            linkText: "See all",
            infoBlock: {
                style: {
                    color: "pink"
                },
                images: {
                    main: "/main/slots.png",
                    minor: "/main/777-slots.png"
                },
                statisticsBlocks: [{
                    badge: null,
                    key: "best_slots_highest_win",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "best_slots_jackpot",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "best_slots_weekly_spins",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !1
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=8&pagination[limit]=12&pagination[page]=1&weighted=8&favorite=0",
            list: []
        }, {
            name: "casino",
            order: 5,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "popular",
            section: "casino",
            seoTitle: "casinoTitle",
            title: "कैसिनो",
            titleIcoId: "casino",
            link: "/casino",
            titleLink: "/casino",
            linkText: "अधिक गेम्‍स",
            infoBlock: {
                style: {
                    color: "yellow"
                },
                images: {
                    main: "/main/men.png",
                    minor: "/main/casino-coins.png"
                },
                statisticsBlocks: [{
                    key: "slots_max_spins_of_week",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "slots_highest_win_of_all_time",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "slots_highest_jackpot_of_all_time",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "",
            list: []
        }, {
            name: "exclusives",
            order: 5,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            isBlockCategory: !0,
            externalCategorySlug: "exclusives",
            section: "casino",
            seoTitle: "casinoTitle",
            title: "कैसिनो",
            titleIcoId: "4rabet_exclusives",
            link: "/casino",
            linkCategory: "/casino/exclusives",
            titleLink: "/casino/exclusives",
            linkText: "अधिक गेम्‍स",
            infoBlock: {
                style: {
                    color: "blue2"
                },
                images: {
                    main: "/main/wheek-exclusives.png",
                    minor: "/main/logo-exclusives.png"
                },
                statisticsBlocks: [{
                    badge: null,
                    defaultValue: "Diver",
                    description: "title2",
                    isCurrency: !1,
                    key: ""
                }, {
                    badge: null,
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1,
                    key: "casino_exclusive_weekly_spins"
                }, {
                    badge: null,
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0,
                    key: "casino_exclusive_highest_win"
                }],
                link: ""
            },
            apiUrl: "",
            list: []
        }],
        bonusSection: {
            title: "बोनस",
            linkText: "अधिक बोनस"
        }
    },
    Fi = {
        banner: {
            subTitle1: "700%",
            bgType: "green",
            mainBgPhoto: "/main/main-top-banner-item-flagv3.png",
            mainPhoto: "/main/main-top-banner-item-person-pt.png"
        },
        top: {
            title: "Seção principal",
            list: [{
                id: 1,
                iconName: "JetX",
                name: "JetX",
                href: C.JETX_MOBILE,
                desktopHref: C.JETX_DESKTOP,
                mobileHref: C.JETX_MOBILE,
                type: "game"
            }, {
                id: 2,
                iconName: "sports",
                name: "sportsv2",
                href: "/live",
                isLinkToBT: !0
            }, {
                id: 3,
                iconName: "live-casino",
                name: "live-casino",
                href: "/live-dealers"
            }, {
                id: 4,
                iconName: "evolution",
                name: "evolution",
                href: "/live-dealers/evolution",
                desktopHref: "/live-dealers/evolution",
                mobileHref: "/live-dealers/evolution",
                type: "lobby",
                forAfrica: !1
            }, {
                id: 4,
                iconName: "pragmatic",
                name: "pragmatic",
                href: "/live-dealers/slot/speed-auto-roulette-26071",
                desktopHref: "/live-dealers/slot/speed-auto-roulette-26071",
                mobileHref: "/live-dealers/slot/speed-auto-roulette-26071",
                type: "game",
                forAfrica: !0
            }, {
                id: 5,
                iconName: "casino",
                name: "casino",
                href: "/casino"
            }, {
                id: 6,
                iconName: "aviator",
                name: "aviator",
                href: C.AVIATOR_MOBILE,
                desktopHref: C.AVIATOR_DESKTOP,
                mobileHref: C.AVIATOR_MOBILE,
                type: "game"
            }, {
                id: 7,
                iconName: "vip",
                name: "vip",
                href: "/new-promo/land-loyalty-vip"
            }, {
                id: 8,
                iconName: "sports",
                name: "football",
                href: "/sports/football",
                isLinkToBT: !0
            }]
        },
        sections: [{
            name: "live",
            order: 1,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "popular",
            section: "live-casino",
            seoTitle: "liveTitle",
            title: "Cassino Ao Vivo",
            titleIcoId: "live-casino",
            link: "/live-dealers",
            titleLink: "/live-dealers",
            linkText: "Mais jogos",
            icon: "",
            infoBlock: {
                style: {
                    color: "orange"
                },
                images: {
                    main: "/main/live-casino2.png",
                    minor: "/main/cubes.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "green"
                    },
                    key: "live_dealers_total_round_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    key: "live_dealers_active_tables",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "",
                    defaultValue: "Auto-Roulette",
                    description: "title3",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "live_dealers_highest_win_of_day",
                    defaultValue: "",
                    description: "title4",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=25&pagination[limit]=12&pagination[page]=1&weighted=25&favorite=0",
            list: []
        }, {
            name: "sport",
            order: 2,
            isSport: !0,
            isDataDynamic: !1,
            seoTitle: "sportTitle",
            title: "APOSTAS",
            titleIcoId: "sports",
            link: "/live",
            titleLink: "/live",
            linkText: "Mais eventos",
            infoBlock: {
                style: {
                    color: "green-pt"
                },
                images: {
                    main: "/main/sport2.png",
                    minor: "/main/football-ball.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "red"
                    },
                    key: "online_now_highest_win_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !0
                }, {
                    badge: {
                        text: "bage2",
                        color: "green"
                    },
                    key: "online_now_highest_win_of_month",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: {
                        text: "bage3",
                        color: "green"
                    },
                    key: "online_now_highest_win_of_all_time",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "",
            list: [{
                id: 1,
                name: "football",
                seoName: "football",
                href: "/live/soccer",
                icon: "/main/betby/sports/football.png",
                order: 1,
                type: "link"
            }, {
                id: 2,
                name: "basketball",
                seoName: "basketball",
                href: "/live/basketball",
                icon: "/main/betby/sports/basketball.png",
                order: 2,
                type: "link"
            }, {
                id: 3,
                name: "tennis",
                seoName: "tennis",
                href: "/live/tennis",
                icon: "/main/betby/sports/tennis.png",
                order: 3,
                type: "link"
            }, {
                id: 4,
                name: "ecricket",
                seoName: "ecricket",
                href: "/live/ecricket",
                icon: "/main/betby/sports/Ecricket.png",
                order: 4,
                type: "link"
            }, {
                id: 5,
                name: "volleyball",
                seoName: "volleyball",
                href: "/live/volleyball",
                icon: "/main/betby/sports/volleyball.png",
                order: 5,
                type: "link"
            }, {
                id: 6,
                name: "handball",
                seoName: "handball",
                href: "/sports/handball",
                icon: "/main/betby/sports/handball.png",
                order: 6,
                type: "link"
            }, {
                id: 7,
                name: "table-tennis",
                seoName: "table-tennis",
                href: "/live/table-tennis",
                icon: "/main/betby/sports/table_tennis.png",
                order: 7,
                type: "link"
            }, {
                id: 8,
                name: "ice-hockey",
                seoName: "ice-hockey",
                href: "/live/ice-hockey",
                icon: "/main/betby/sports/hockey.png",
                order: 8,
                type: "link"
            }, {
                id: 9,
                name: "cricket",
                seoName: "cricket",
                href: "/live/cricket",
                icon: "/main/betby/sports/cricket.png",
                order: 9,
                type: "link"
            }, {
                id: 10,
                name: "fifa",
                seoName: "fifa",
                href: "/live/fifa",
                icon: "/main/betby/sports/fifa.png",
                order: 10,
                type: "link"
            }, {
                id: 11,
                name: "baseball",
                seoName: "baseball",
                href: "/live/baseball",
                icon: "/main/betby/sports/baseball.png",
                order: 11,
                type: "link"
            }, {
                id: 12,
                name: "mma",
                seoName: "mma",
                href: "/sports/mma",
                icon: "/main/betby/sports/mma.png",
                order: 12,
                type: "link"
            }]
        }, {
            name: "crash",
            order: 3,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "crash",
            section: "casino",
            seoTitle: "crashTitle",
            title: "Jogos crash",
            titleIcoId: "aviator",
            link: "/casino",
            linkCategory: "/casino/crash",
            isBlockCategory: !0,
            titleLink: "/casino/crash",
            linkText: "Mais jogos de crash",
            infoBlock: {
                style: {
                    color: "red"
                },
                images: {
                    main: "/main/red-plane.png",
                    minor: "/main/x100.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "green"
                    },
                    key: "tv_games_total_round_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "",
                    defaultValue: "Aviator",
                    description: "title2",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "tv_games_highest_win_of_day",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "tv_games_highest_jackpot_of_all_time",
                    defaultValue: "",
                    description: "title4",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=13&pagination[limit]=12&pagination[page]=1&weighted=13&favorite=0",
            list: []
        }, {
            name: "slots",
            order: 4,
            isSport: !1,
            isDataDynamic: !0,
            seoTitle: "slotsTitle",
            title: "क्रैश गेम्‍स",
            titleIcoId: "slots",
            link: "/casino",
            linkCategory: "/casino/slots",
            isBlockCategory: !0,
            titleLink: "/casino/slots",
            linkText: "See all",
            infoBlock: {
                style: {
                    color: "pink"
                },
                images: {
                    main: "/main/slots.png",
                    minor: "/main/777-slots.png"
                },
                statisticsBlocks: [{
                    badge: null,
                    key: "best_slots_highest_win",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "best_slots_jackpot",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "best_slots_weekly_spins",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !1
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=8&pagination[limit]=12&pagination[page]=1&weighted=8&favorite=0",
            list: []
        }, {
            name: "casino",
            order: 5,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "popular",
            section: "casino",
            seoTitle: "casinoTitle",
            title: "Cassino",
            titleIcoId: "casino",
            link: "/casino",
            titleLink: "/casino",
            linkText: "Mais jogos",
            infoBlock: {
                style: {
                    color: "yellow"
                },
                images: {
                    main: "/main/men.png",
                    minor: "/main/casino-coins.png"
                },
                statisticsBlocks: [{
                    key: "slots_max_spins_of_week",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "slots_highest_win_of_all_time",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "slots_highest_jackpot_of_all_time",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "",
            list: []
        }, {
            name: "exclusives",
            order: 5,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            isBlockCategory: !0,
            externalCategorySlug: "exclusives",
            section: "casino",
            seoTitle: "casinoTitle",
            title: "कैसिनो",
            titleIcoId: "4rabet_exclusives",
            link: "/casino",
            linkCategory: "/casino/exclusives",
            titleLink: "/casino/exclusives",
            linkText: "अधिक गेम्‍स",
            infoBlock: {
                style: {
                    color: "blue2"
                },
                images: {
                    main: "/main/wheek-exclusives.png",
                    minor: "/main/logo-exclusives.png"
                },
                statisticsBlocks: [{
                    badge: null,
                    defaultValue: "Diver",
                    description: "title2",
                    isCurrency: !1,
                    key: ""
                }, {
                    badge: null,
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1,
                    key: "casino_exclusive_weekly_spins"
                }, {
                    badge: null,
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0,
                    key: "casino_exclusive_highest_win"
                }],
                link: ""
            },
            apiUrl: "",
            list: []
        }],
        bonusSection: {
            title: "Bônus",
            linkText: "Mais bônus"
        }
    },
    Ki = {
        banner: {
            subTitle1: "700%",
            bgType: "blue",
            mainBgPhoto: "/main/main-top-banner-item-flagv2.png",
            mainPhoto: "/main/main-top-banner-item-person.png"
        },
        top: {
            title: "সেরা বিভাগ",
            list: [{
                id: 1,
                iconName: "evolution",
                name: "evolution",
                href: "/live-dealers/evolution",
                desktopHref: "/live-dealers/evolution",
                mobileHref: "/live-dealers/evolution",
                type: "lobby"
            }, {
                id: 2,
                iconName: "aviator",
                name: "aviator",
                href: C.AVIATOR_MOBILE,
                desktopHref: C.AVIATOR_DESKTOP,
                mobileHref: C.AVIATOR_MOBILE,
                type: "game"
            }, {
                id: 3,
                iconName: "live-casino",
                name: "live-casino",
                href: "/live-dealers"
            }, {
                id: 4,
                iconName: "casino",
                name: "casino",
                href: "/casino"
            }, {
                id: 5,
                iconName: "sports",
                name: "sports",
                href: "/live",
                isLinkToBT: !0
            }, {
                id: 6,
                iconName: "cricket",
                name: "cricket",
                href: "/live/cricket",
                isLinkToBT: !0
            }, {
                id: 7,
                iconName: "vip",
                name: "vip",
                href: "/new-promo/land-loyalty-vip"
            }, {
                id: 8,
                iconName: "pragmatic",
                name: "pragmatic",
                href: "/live-dealers/slot/lucky-6-roulette-1",
                desktopHref: "/live-dealers/slot/lucky-6-roulette-1",
                mobileHref: "/live-dealers/slot/lucky-6-roulette-1",
                type: "game"
            }]
        },
        sections: [{
            name: "live",
            order: 1,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "popular",
            section: "live-casino",
            seoTitle: "liveTitle",
            title: "লাইভ ক্যাসিনো",
            titleIcoId: "live-casino",
            link: "/live-dealers",
            titleLink: "/live-dealers",
            linkText: "আরো গেমস",
            icon: "",
            infoBlock: {
                style: {
                    color: "blue"
                },
                images: {
                    main: "/main/slot2.png",
                    minor: "/main/cubes.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "green"
                    },
                    key: "live_dealers_total_round_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    key: "live_dealers_active_tables",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "",
                    defaultValue: "Auto-Roulette",
                    description: "title3",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "live_dealers_highest_win_of_day",
                    defaultValue: "",
                    description: "title4",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=25&pagination[limit]=12&pagination[page]=1&weighted=25&favorite=0",
            list: []
        }, {
            name: "slots",
            order: 2,
            isSport: !1,
            isDataDynamic: !0,
            seoTitle: "slotsTitle",
            title: "क्रैश गेम्‍स",
            titleIcoId: "slots",
            link: "/casino",
            linkCategory: "/casino/slots",
            isBlockCategory: !0,
            titleLink: "/casino/slots",
            linkText: "See all",
            infoBlock: {
                style: {
                    color: "pink"
                },
                images: {
                    main: "/main/slots.png",
                    minor: "/main/777-slots.png"
                },
                statisticsBlocks: [{
                    badge: null,
                    key: "best_slots_highest_win",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "best_slots_jackpot",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "best_slots_weekly_spins",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !1
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=8&pagination[limit]=12&pagination[page]=1&weighted=8&favorite=0",
            list: []
        }, {
            name: "sport",
            order: 3,
            isSport: !0,
            isDataDynamic: !1,
            seoTitle: "sportTitle",
            title: "স্পোর্টস",
            titleIcoId: "sports",
            link: "/live",
            titleLink: "/live",
            linkText: "আরো ইভেন্ট",
            infoBlock: {
                style: {
                    color: "green"
                },
                images: {
                    main: "/main/sport.png",
                    minor: "/main/cricket-ball.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "red"
                    },
                    key: "online_now_highest_win_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !0
                }, {
                    badge: {
                        text: "bage2",
                        color: "green"
                    },
                    key: "online_now_highest_win_of_month",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: {
                        text: "bage3",
                        color: "green"
                    },
                    key: "online_now_highest_win_of_all_time",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "",
            list: [{
                id: 1,
                name: "cricket",
                seoName: "cricket",
                href: "/live/cricket",
                icon: "/main/betby/sports/cricket.png",
                order: 1,
                type: "link"
            }, {
                id: 2,
                name: "football",
                seoName: "football",
                href: "/live/soccer",
                icon: "/main/betby/sports/football.png",
                order: 2,
                type: "link"
            }, {
                id: 3,
                name: "ecricket",
                seoName: "ecricket",
                href: "/live/ecricket",
                icon: "/main/betby/sports/Ecricket.png",
                order: 3,
                type: "link"
            }, {
                id: 4,
                name: "basketball",
                seoName: "basketball",
                href: "/live/basketball",
                icon: "/main/betby/sports/basketball.png",
                order: 4,
                type: "link"
            }, {
                id: 5,
                name: "tennis",
                seoName: "tennis",
                href: "/live/tennis",
                icon: "/main/betby/sports/tennis.png",
                order: 5,
                type: "link"
            }, {
                id: 6,
                name: "fifa",
                seoName: "fifa",
                href: "/live/fifa",
                icon: "/main/betby/sports/fifa.png",
                order: 6,
                type: "link"
            }, {
                id: 7,
                name: "table-tennis",
                seoName: "table-tennis",
                href: "/live/table-tennis",
                icon: "/main/betby/sports/table_tennis.png",
                order: 7,
                type: "link"
            }, {
                id: 8,
                name: "volleyball",
                seoName: "volleyball",
                href: "/live/volleyball",
                icon: "/main/betby/sports/volleyball.png",
                order: 8,
                type: "link"
            }, {
                id: 9,
                name: "ice-hockey",
                seoName: "ice-hockey",
                href: "/live/ice-hockey",
                icon: "/main/betby/sports/hockey.png",
                order: 9,
                type: "link"
            }, {
                id: 10,
                name: "baseball",
                seoName: "baseball",
                href: "/live/baseball",
                icon: "/main/betby/sports/baseball.png",
                order: 11,
                type: "link"
            }, {
                id: 11,
                name: "mma",
                seoName: "mma",
                href: "/sports/mma",
                icon: "/main/betby/sports/mma.png",
                order: 11,
                type: "link"
            }, {
                id: 12,
                name: "handball",
                seoName: "handball",
                href: "/sports/handball",
                icon: "/main/betby/sports/handball.png",
                order: 12,
                type: "link"
            }]
        }, {
            name: "crash",
            order: 4,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "crash",
            section: "casino",
            seoTitle: "crashTitle",
            title: "ক্র্যাশ গেমস",
            titleIcoId: "aviator",
            link: "/casino",
            linkCategory: "/casino/crash",
            isBlockCategory: !0,
            titleLink: "/casino/crash",
            linkText: "আরো ক্র্যাশ গেমস",
            infoBlock: {
                style: {
                    color: "red"
                },
                images: {
                    main: "/main/red-plane.png",
                    minor: "/main/x100.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "green"
                    },
                    key: "tv_games_total_round_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "",
                    defaultValue: "AVIATOR",
                    description: "title2",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "tv_games_highest_win_of_day",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "tv_games_highest_jackpot_of_all_time",
                    defaultValue: "",
                    description: "title4",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=13&pagination[limit]=12&pagination[page]=1&weighted=13&favorite=0",
            list: []
        }, {
            name: "casino",
            order: 5,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "popular",
            section: "casino",
            seoTitle: "casinoTitle",
            title: "ক্যাসিনো",
            titleIcoId: "casino",
            link: "/casino",
            titleLink: "/casino",
            linkText: "আরো গেমস",
            infoBlock: {
                style: {
                    color: "yellow"
                },
                images: {
                    main: "/main/men.png",
                    minor: "/main/casino-coins.png"
                },
                statisticsBlocks: [{
                    key: "slots_max_spins_of_week",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "slots_highest_win_of_all_time",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "slots_highest_jackpot_of_all_time",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "",
            list: []
        }, {
            name: "exclusives",
            order: 5,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            isBlockCategory: !0,
            externalCategorySlug: "exclusives",
            section: "casino",
            seoTitle: "casinoTitle",
            title: "कैसिनो",
            titleIcoId: "4rabet_exclusives",
            link: "/casino",
            linkCategory: "/casino/exclusives",
            titleLink: "/casino/exclusives",
            linkText: "अधिक गेम्‍स",
            infoBlock: {
                style: {
                    color: "blue2"
                },
                images: {
                    main: "/main/wheek-exclusives.png",
                    minor: "/main/logo-exclusives.png"
                },
                statisticsBlocks: [{
                    badge: null,
                    defaultValue: "Diver",
                    description: "title2",
                    isCurrency: !1,
                    key: ""
                }, {
                    badge: null,
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1,
                    key: "casino_exclusive_weekly_spins"
                }, {
                    badge: null,
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0,
                    key: "casino_exclusive_highest_win"
                }],
                link: ""
            },
            apiUrl: "",
            list: []
        }],
        bonusSection: {
            title: "বোনাস",
            linkText: "আরো বোনাস"
        }
    },
    qi = {
        banner: {
            subTitle1: "700%",
            bgType: "green",
            mainBgPhoto: "/main/main-top-banner-item-flagv3.png",
            mainPhoto: "/main/main-top-banner-item-person-pt.png"
        },
        top: {
            title: "Seção principal",
            list: [{
                id: 1,
                iconName: "JetX",
                name: "JetX",
                href: C.JETX_MOBILE,
                desktopHref: C.JETX_DESKTOP,
                mobileHref: C.JETX_MOBILE,
                type: "game"
            }, {
                id: 2,
                iconName: "sporttsv3",
                name: "sportsv2",
                href: "/live",
                isLinkToBT: !0
            }, {
                id: 3,
                iconName: "live-casino",
                name: "live-casino",
                href: "/live-dealers"
            }, {
                id: 4,
                iconName: "evolution",
                name: "evolution",
                href: "/live-dealers/evolution",
                desktopHref: "/live-dealers/evolution",
                mobileHref: "/live-dealers/evolution",
                type: "lobby"
            }, {
                id: 5,
                iconName: "casino",
                name: "casino",
                href: "/casino"
            }, {
                id: 6,
                iconName: "aviator",
                name: "aviator",
                href: C.AVIATOR_MOBILE,
                desktopHref: C.AVIATOR_DESKTOP,
                mobileHref: C.AVIATOR_MOBILE,
                type: "game"
            }, {
                id: 7,
                iconName: "vip",
                name: "vip",
                href: "/new-promo/land-loyalty-vip"
            }, {
                id: 8,
                iconName: "sports",
                name: "sports",
                href: "/sports",
                isLinkToBT: !0
            }]
        },
        sections: [{
            name: "live",
            order: 1,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "popular",
            section: "live-casino",
            seoTitle: "liveTitle",
            title: "Cassino Ao Vivo",
            titleIcoId: "live-casino",
            link: "/live-dealers",
            titleLink: "/live-dealers",
            linkText: "Mais jogos",
            icon: "",
            infoBlock: {
                style: {
                    color: "orange"
                },
                images: {
                    main: "/main/live-casino2.png",
                    minor: "/main/cubes.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "green"
                    },
                    key: "live_dealers_total_round_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    key: "live_dealers_active_tables",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "",
                    defaultValue: "Auto-Roulette",
                    description: "title3",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "live_dealers_highest_win_of_day",
                    defaultValue: "",
                    description: "title4",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=25&pagination[limit]=12&pagination[page]=1&weighted=25&favorite=0",
            list: []
        }, {
            name: "sport",
            order: 2,
            isSport: !0,
            isDataDynamic: !1,
            seoTitle: "sportTitle",
            title: "APOSTAS",
            titleIcoId: "sports",
            link: "/live",
            titleLink: "/live",
            linkText: "Mais eventos",
            infoBlock: {
                style: {
                    color: "green-pt"
                },
                images: {
                    main: "/main/sport2.png",
                    minor: "/main/football-ball.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "red"
                    },
                    key: "online_now_highest_win_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !0
                }, {
                    badge: {
                        text: "bage2",
                        color: "green"
                    },
                    key: "online_now_highest_win_of_month",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: {
                        text: "bage3",
                        color: "green"
                    },
                    key: "online_now_highest_win_of_all_time",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "",
            list: [{
                id: 1,
                name: "football",
                seoName: "football",
                href: "/live/soccer",
                icon: "/main/betby/sports/football.png",
                order: 1,
                type: "link"
            }, {
                id: 2,
                name: "basketball",
                seoName: "basketball",
                href: "/live/basketball",
                icon: "/main/betby/sports/basketball.png",
                order: 2,
                type: "link"
            }, {
                id: 3,
                name: "tennis",
                seoName: "tennis",
                href: "/live/tennis",
                icon: "/main/betby/sports/tennis.png",
                order: 3,
                type: "link"
            }, {
                id: 4,
                name: "fifa",
                seoName: "fifa",
                href: "/live/fifa",
                icon: "/main/betby/sports/fifa.png",
                order: 10,
                type: "link"
            }, {
                id: 5,
                name: "volleyball",
                seoName: "volleyball",
                href: "/live/volleyball",
                icon: "/main/betby/sports/volleyball.png",
                order: 5,
                type: "link"
            }, {
                id: 6,
                name: "ice-hockey",
                seoName: "ice-hockey",
                href: "/live/ice-hockey",
                icon: "/main/betby/sports/hockey.png",
                order: 8,
                type: "link"
            }, {
                id: 7,
                name: "table-tennis",
                seoName: "table-tennis",
                href: "/live/table-tennis",
                icon: "/main/betby/sports/table_tennis.png",
                order: 7,
                type: "link"
            }, {
                id: 8,
                name: "ecricket",
                seoName: "ecricket",
                href: "/live/ecricket",
                icon: "/main/betby/sports/Ecricket.png",
                order: 4,
                type: "link"
            }, {
                id: 9,
                name: "cricket",
                seoName: "cricket",
                href: "/live/cricket",
                icon: "/main/betby/sports/cricket.png",
                order: 9,
                type: "link"
            }, {
                id: 10,
                name: "handball",
                seoName: "handball",
                href: "/sports/handball",
                icon: "/main/betby/sports/handball.png",
                order: 6,
                type: "link"
            }, {
                id: 11,
                name: "baseball",
                seoName: "baseball",
                href: "/live/baseball",
                icon: "/main/betby/sports/baseball.png",
                order: 11,
                type: "link"
            }, {
                id: 12,
                name: "mma",
                seoName: "mma",
                href: "/sports/mma",
                icon: "/main/betby/sports/mma.png",
                order: 12,
                type: "link"
            }]
        }, {
            name: "crash",
            order: 3,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "crash",
            section: "casino",
            seoTitle: "crashTitle",
            title: "Jogos crash",
            titleIcoId: "aviator",
            link: "/casino",
            linkCategory: "/casino/crash",
            isBlockCategory: !0,
            titleLink: "/casino/crash",
            linkText: "crash",
            infoBlock: {
                style: {
                    color: "red"
                },
                images: {
                    main: "/main/red-plane.png",
                    minor: "/main/x100.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "green"
                    },
                    key: "tv_games_total_round_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "",
                    defaultValue: "Aviator",
                    description: "title2",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "tv_games_highest_win_of_day",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "tv_games_highest_jackpot_of_all_time",
                    defaultValue: "",
                    description: "title4",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=13&pagination[limit]=12&pagination[page]=1&weighted=13&favorite=0",
            list: []
        }, {
            name: "slots",
            order: 4,
            isSport: !1,
            isDataDynamic: !0,
            seoTitle: "slotsTitle",
            title: "क्रैश गेम्‍स",
            titleIcoId: "slots",
            link: "/casino",
            linkCategory: "/casino/slots",
            isBlockCategory: !0,
            titleLink: "/casino/slots",
            linkText: "See all",
            infoBlock: {
                style: {
                    color: "pink"
                },
                images: {
                    main: "/main/slots.png",
                    minor: "/main/777-slots.png"
                },
                statisticsBlocks: [{
                    badge: null,
                    key: "best_slots_highest_win",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "best_slots_jackpot",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "best_slots_weekly_spins",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !1
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=8&pagination[limit]=12&pagination[page]=1&weighted=8&favorite=0",
            list: []
        }, {
            name: "casino",
            order: 5,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "popular",
            section: "casino",
            seoTitle: "casinoTitle",
            title: "Cassino",
            titleIcoId: "casino",
            link: "/casino",
            titleLink: "/casino",
            linkText: "Mais jogos",
            infoBlock: {
                style: {
                    color: "yellow"
                },
                images: {
                    main: "/main/men.png",
                    minor: "/main/casino-coins.png"
                },
                statisticsBlocks: [{
                    key: "slots_max_spins_of_week",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "slots_highest_win_of_all_time",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "slots_highest_jackpot_of_all_time",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "",
            list: []
        }, {
            name: "exclusives",
            order: 5,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            isBlockCategory: !0,
            externalCategorySlug: "exclusives",
            section: "casino",
            seoTitle: "casinoTitle",
            title: "कैसिनो",
            titleIcoId: "4rabet_exclusives",
            link: "/casino",
            linkCategory: "/casino/exclusives",
            titleLink: "/casino/exclusives",
            linkText: "अधिक गेम्‍स",
            infoBlock: {
                style: {
                    color: "blue2"
                },
                images: {
                    main: "/main/wheek-exclusives.png",
                    minor: "/main/logo-exclusives.png"
                },
                statisticsBlocks: [{
                    badge: null,
                    defaultValue: "Diver",
                    description: "title2",
                    isCurrency: !1,
                    key: ""
                }, {
                    badge: null,
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1,
                    key: "casino_exclusive_weekly_spins"
                }, {
                    badge: null,
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0,
                    key: "casino_exclusive_highest_win"
                }],
                link: ""
            },
            apiUrl: "",
            list: []
        }],
        bonusSection: {
            title: "Bonuses",
            linkText: "More bonuses"
        }
    },
    Wi = {
        banner: {
            subTitle1: "700%",
            bgType: "blue",
            mainBgPhoto: "/main/main-top-banner-item-flagv2.png",
            mainPhoto: "/main/main-top-banner-item-person.png"
        },
        top: {
            title: "शीर्ष सैक्‍शंस",
            list: [{
                id: 1,
                iconName: "sports",
                name: "sports",
                href: "/live",
                isLinkToBT: !0
            }, {
                id: 2,
                iconName: "sports",
                name: "football",
                href: "/sports/football",
                isLinkToBT: !0
            }, {
                id: 3,
                iconName: "casino",
                name: "casino",
                href: "/casino"
            }, {
                id: 4,
                iconName: "live-casino",
                name: "live-casino",
                href: "/live-dealers"
            }, {
                id: 5,
                iconName: "aviator",
                name: "aviator",
                href: C.AVIATOR_MOBILE,
                desktopHref: C.AVIATOR_DESKTOP,
                mobileHref: C.AVIATOR_MOBILE,
                type: "game"
            }, {
                id: 6,
                iconName: "vip",
                name: "vip",
                href: "/new-promo/land-loyalty-vip"
            }, {
                id: 7,
                iconName: "pragmatic",
                name: "pragmatic",
                href: "/live-dealers/slot/speed-auto-roulette-26071",
                desktopHref: "/live-dealers/slot/speed-auto-roulette-26071",
                mobileHref: "/live-dealers/slot/speed-auto-roulette-26071",
                type: "game",
                forAfrica: !0
            }, {
                id: 8,
                iconName: "pragmatic",
                name: "pragmatic",
                href: "/live-dealers/slot/lucky-6-roulette-1",
                desktopHref: "/live-dealers/slot/lucky-6-roulette-1",
                mobileHref: "/live-dealers/slot/lucky-6-roulette-1",
                type: "game",
                forAfrica: !0,
                rwORzm: !0
            }, {
                id: 9,
                iconName: "evolution",
                name: "evolution",
                href: "/live-dealers/evolution",
                desktopHref: "/live-dealers/evolution",
                mobileHref: "/live-dealers/evolution",
                type: "lobby",
                forAfrica: !1
            }, {
                id: 10,
                iconName: "JetX",
                name: "JetX",
                href: C.JETX_MOBILE,
                desktopHref: C.JETX_DESKTOP,
                mobileHref: C.JETX_MOBILE,
                type: "game"
            }]
        },
        sections: [{
            name: "sport",
            order: 2,
            isSport: !0,
            isDataDynamic: !1,
            seoTitle: "sportTitle",
            title: "स्‍पोर्ट्सबुक‍",
            titleIcoId: "sports",
            link: "/live",
            titleLink: "/live",
            linkText: "अधिक इवेंट्स",
            infoBlock: {
                style: {
                    color: "green-pt"
                },
                images: {
                    main: "/main/sport2.png",
                    minor: "/main/football-ball.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "red"
                    },
                    key: "online_now_highest_win_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !0
                }, {
                    badge: {
                        text: "bage2",
                        color: "green"
                    },
                    key: "online_now_highest_win_of_month",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: {
                        text: "bage3",
                        color: "green"
                    },
                    key: "online_now_highest_win_of_all_time",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "",
            list: [{
                id: 1,
                name: "cricket",
                seoName: "cricket",
                href: "/live/cricket",
                icon: "/main/betby/sports/cricket.png",
                order: 1,
                type: "link"
            }, {
                id: 2,
                name: "football",
                seoName: "football",
                href: "/live/soccer",
                icon: "/main/betby/sports/football.png",
                order: 2,
                type: "link"
            }, {
                id: 3,
                name: "ecricket",
                seoName: "ecricket",
                href: "/live/ecricket",
                icon: "/main/betby/sports/Ecricket.png",
                order: 3,
                type: "link"
            }, {
                id: 4,
                name: "basketball",
                seoName: "basketball",
                href: "/live/basketball",
                icon: "/main/betby/sports/basketball.png",
                order: 4,
                type: "link"
            }, {
                id: 5,
                name: "tennis",
                seoName: "tennis",
                href: "/live/tennis",
                icon: "/main/betby/sports/tennis.png",
                order: 5,
                type: "link"
            }, {
                id: 6,
                name: "fifa",
                seoName: "fifa",
                href: "/live/fifa",
                icon: "/main/betby/sports/fifa.png",
                order: 6,
                type: "link"
            }, {
                id: 7,
                name: "table-tennis",
                seoName: "table-tennis",
                href: "/live/table-tennis",
                icon: "/main/betby/sports/table_tennis.png",
                order: 7,
                type: "link"
            }, {
                id: 8,
                name: "volleyball",
                seoName: "volleyball",
                href: "/live/volleyball",
                icon: "/main/betby/sports/volleyball.png",
                order: 8,
                type: "link"
            }, {
                id: 9,
                name: "ice-hockey",
                seoName: "ice-hockey",
                href: "/live/ice-hockey",
                icon: "/main/betby/sports/hockey.png",
                order: 9,
                type: "link"
            }, {
                id: 10,
                name: "baseball",
                seoName: "baseball",
                href: "/live/baseball",
                icon: "/main/betby/sports/baseball.png",
                order: 11,
                type: "link"
            }, {
                id: 11,
                name: "mma",
                seoName: "mma",
                href: "/sports/mma",
                icon: "/main/betby/sports/mma.png",
                order: 11,
                type: "link"
            }, {
                id: 12,
                name: "handball",
                seoName: "handball",
                href: "/sports/handball",
                icon: "/main/betby/sports/handball.png",
                order: 12,
                type: "link"
            }, {
                id: 13,
                name: "virtual-sports",
                seoName: "virtual-sports",
                href: "/sports/e_sport",
                icon: "/main/betby/sports/virtual-sports.png",
                order: 13,
                type: "link"
            }]
        }, {
            name: "live",
            order: 1,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "popular",
            section: "live-casino",
            seoTitle: "liveTitle",
            title: "लाइव कैसिनो",
            titleIcoId: "live-casino",
            link: "/live-dealers",
            titleLink: "/live-dealers",
            linkText: "More games",
            icon: "",
            infoBlock: {
                style: {
                    color: "orange"
                },
                images: {
                    main: "/main/live-casino2.png",
                    minor: "/main/cubes.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "green"
                    },
                    key: "live_dealers_total_round_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    key: "live_dealers_active_tables",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "",
                    defaultValue: "Auto-Roulette",
                    description: "title3",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "live_dealers_highest_win_of_day",
                    defaultValue: "",
                    description: "title4",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=25&pagination[limit]=12&pagination[page]=1&weighted=25&favorite=0",
            list: []
        }, {
            name: "crash",
            order: 3,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "crash",
            section: "casino",
            seoTitle: "crashTitle",
            title: "क्रैश गेम्‍स",
            titleIcoId: "aviator",
            link: "/casino",
            linkCategory: "/casino/crash",
            isBlockCategory: !0,
            titleLink: "/casino/crash",
            linkText: "More Crash games",
            infoBlock: {
                style: {
                    color: "red"
                },
                images: {
                    main: "/main/red-plane.png",
                    minor: "/main/x100.png"
                },
                statisticsBlocks: [{
                    badge: {
                        text: "bage1",
                        color: "green"
                    },
                    key: "tv_games_total_round_of_day",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "",
                    defaultValue: "AVIATOR",
                    description: "title2",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "tv_games_highest_win_of_day",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "tv_games_highest_jackpot_of_all_time",
                    defaultValue: "",
                    description: "title4",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=13&pagination[limit]=12&pagination[page]=1&weighted=13&favorite=0",
            list: []
        }, {
            name: "slots",
            order: 4,
            isSport: !1,
            isDataDynamic: !0,
            seoTitle: "slotsTitle",
            title: "क्रैश गेम्‍स",
            titleIcoId: "slots",
            link: "/casino",
            linkCategory: "/casino/slots",
            isBlockCategory: !0,
            titleLink: "/casino/slots",
            linkText: "See all",
            infoBlock: {
                style: {
                    color: "pink"
                },
                images: {
                    main: "/main/slots.png",
                    minor: "/main/777-slots.png"
                },
                statisticsBlocks: [{
                    badge: null,
                    key: "best_slots_highest_win",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "best_slots_jackpot",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "best_slots_weekly_spins",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !1
                }],
                link: ""
            },
            apiUrl: "/slots/enabled?category=8&pagination[limit]=12&pagination[page]=1&weighted=8&favorite=0",
            list: []
        }, {
            name: "casino",
            order: 5,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            externalCategorySlug: "popular",
            section: "casino",
            seoTitle: "casinoTitle",
            title: "कैसिनो",
            titleIcoId: "casino",
            link: "/casino",
            titleLink: "/casino",
            linkText: "अधिक गेम्‍स",
            infoBlock: {
                style: {
                    color: "yellow"
                },
                images: {
                    main: "/main/men.png",
                    minor: "/main/casino-coins.png"
                },
                statisticsBlocks: [{
                    key: "slots_max_spins_of_week",
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1
                }, {
                    badge: null,
                    key: "slots_highest_win_of_all_time",
                    defaultValue: "",
                    description: "title2",
                    isCurrency: !0
                }, {
                    badge: null,
                    key: "slots_highest_jackpot_of_all_time",
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0
                }],
                link: ""
            },
            apiUrl: "",
            list: []
        }, {
            name: "exclusives",
            order: 5,
            isSport: !1,
            isDataDynamic: !1,
            isDataExternal: !0,
            isBlockCategory: !0,
            externalCategorySlug: "exclusives",
            section: "casino",
            seoTitle: "casinoTitle",
            title: "कैसिनो",
            titleIcoId: "4rabet_exclusives",
            link: "/casino",
            linkCategory: "/casino/exclusives",
            titleLink: "/casino/exclusives",
            linkText: "अधिक गेम्‍स",
            infoBlock: {
                style: {
                    color: "blue2"
                },
                images: {
                    main: "/main/wheek-exclusives.png",
                    minor: "/main/logo-exclusives.png"
                },
                statisticsBlocks: [{
                    badge: null,
                    defaultValue: "Diver",
                    description: "title2",
                    isCurrency: !1,
                    key: ""
                }, {
                    badge: null,
                    defaultValue: "",
                    description: "title1",
                    isCurrency: !1,
                    key: "casino_exclusive_weekly_spins"
                }, {
                    badge: null,
                    defaultValue: "",
                    description: "title3",
                    isCurrency: !0,
                    key: "casino_exclusive_highest_win"
                }],
                link: ""
            },
            apiUrl: "",
            list: []
        }],
        bonusSection: {
            title: "बोनस",
            linkText: "अधिक बोनस"
        }
    },
    Y = {
        IN: zi,
        BR: Fi,
        BD: Ki,
        MM: qi,
        CA: Wi
    };

function Yi() {
    const i = J(null),
        t = J(null);
    return {
        regBannerResponseData: i,
        executeAbTest: async () => {
            const {
                $API: r
            } = Te(), n = {
                scope: "banner-registration-form"
            };
            try {
                const l = await r.ApiSettings.customGetRequestV3("post", "/ab-test", n);
                if (l && l.data) i.value = l.data;
                else throw new Error("Incorrect response from API")
            } catch (l) {
                const a = l;
                t.value = a, i.value = null, console.error(`Error: ${a.message}`, "color: red; font-size: 18px"), console.error(`Stack Trace: ${a.stack}`, "color: red; font-size: 18px")
            }
        }
    }
}
const Zi = fe(() => _e(() =>
        import ("./CD3x7And.js"), __vite__mapDeps([13, 14, 2, 3, 4, 5, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 8, 9, 43, 44, 45, 46, 47]),
        import.meta.url).then(i => i.default || i)),
    Qi = {
        class: "main-page"
    },
    en = {
        key: 0,
        class: "main-page__container"
    },
    tn = D({
        __name: "index",
        setup(i) {
            const {
                config: t
            } = me(), {
                userGeo: s
            } = U(pe()), {
                isAuthenticated: r
            } = ee(), {
                regBannerResponseData: n,
                executeAbTest: l
            } = Yi(), {
                config: a
            } = me(), o = y(() => xe[s.value] ? Y.CA : Y[s.value] ? Y[s.value] : He[s.value] || Pe[s.value] ? Y.BR : Y.IN), m = J(!1), _ = y(() => {
                var h, T;
                if (((h = a.value) != null && h.IS_ICC || (T = a.value) != null && T.IS_IPL) && ["IN", "BD"].includes(s.value)) {
                    const w = [2, 1, 3, 4, 5];
                    return [...o.value.sections].sort((A, E) => w.indexOf(A.order) - w.indexOf(E.order))
                }
                return o.value.sections
            }), c = y(() => s.value === "IN"), k = y(() => {
                var h;
                return !r.value && c.value && ((h = n == null ? void 0 : n.value) == null ? void 0 : h.group) === 1
            }), d = y(() => {
                var h;
                return r.value || s.value && ((h = n.value) == null ? void 0 : h.group) !== void 0
            }), p = y(() => {
                var h;
                return (h = t.value) != null && h.SHOW_REGISTRATION_BANNER ? d.value && k.value : !1
            }), v = y(() => ({
                "blur-block": !d.value
            }));
            return ie(async () => {
                r.value || await l(), await de(() => {
                    m.value = !0
                })
            }), (h, T) => {
                const w = ft,
                    A = Zi,
                    E = Ye,
                    q = Ze,
                    I = Et,
                    P = Bi,
                    W = Xi;
                return u(), b("div", Qi, [e(o) ? (u(), b("div", en, [f("div", null, [x(w, {
                    class: "main-page__search"
                }), e(m) ? (u(), b(H, {
                    key: 0
                }, [e(p) ? (u(), b("div", {
                    key: 0,
                    class: $([e(v), "main-page__banner"])
                }, [x(A)], 2)) : (u(), N(E, {
                    key: 1
                }))], 64)) : e(m) ? M("", !0) : (u(), N(q, {
                    key: 1
                }))]), x(I, {
                    "top-data": e(o).top
                }, null, 8, ["top-data"]), (u(!0), b(H, null, j(e(_), se => (u(), N(P, {
                    key: se.name,
                    config: se
                }, null, 8, ["config"]))), 128)), x(W)])) : M("", !0)])
            }
        }
    }),
    In = V(tn, [
        ["__scopeId", "data-v-4792a74a"]
    ]);
export {
    In as
    default
};