import {
    bA as Z,
    z as tt,
    u as et,
    bB as at,
    bC as i
} from "./BbvgifQp.js";
import {
    T as st
} from "./1xKHoBf3.js";
import {
    b as o,
    d as w
} from "./BBZLTf3A.js";
(function() {
    try {
        var n = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            c = new n.Error().stack;
        c && (n._sentryDebugIds = n._sentryDebugIds || {}, n._sentryDebugIds[c] = "9749c955-bb9b-4a50-aa53-4d94bdd729c8", n._sentryDebugIdIdentifier = "sentry-dbid-9749c955-bb9b-4a50-aa53-4d94bdd729c8")
    } catch {}
})();
const rt = Z("payments-store", () => {
    const {
        $API: n,
        $i18n: c
    } = tt(), {
        config: m
    } = et(), {
        showNotification: x
    } = at(), D = o(null), E = o(!1), u = o(null), v = o(null), g = o([]), f = o(null), d = o(null), p = o(null), l = o([]), P = o(null), M = o(null), A = o(null), b = o(null), y = o(null), S = o(null), _ = o(null), T = o(null), C = o(0), I = o(0);

    function W(e) {
        T.value = e
    }

    function L(e) {
        b.value = e
    }

    function O(e) {
        P.value = e
    }

    function F(e) {
        y.value = e
    }

    function k(e) {
        S.value = e
    }

    function N(e) {
        p.value = e
    }

    function q(e) {
        C.value = e
    }

    function H(e) {
        e === null && W(null), v.value = e
    }

    function R(e) {
        I.value = e
    }
    async function B(e) {
        try {
            return (await n.ApiPayments.identifierPayment(e)).data
        } catch (t) {
            throw i(t), t
        }
    }
    async function $(e) {
        var t;
        try {
            let a;
            const s = window.innerWidth <= st ? "mobile" : "desktop",
                r = {
                    currency: e,
                    platform: s
                };
            return (t = m.value) != null && t.NEW_API_LIST ? a = await n.ApiPayments.fetchDepositMethods(r) : a = await n.ApiPayments.fetchDepositMethodsOld(r), g.value = a.data, a.data
        } catch (a) {
            throw i(a), a
        }
    }
    async function z(e) {
        try {
            const t = await n.ApiPayments.fetchWithdrawMethodsList(e);
            return f.value = t.data, t.data
        } catch (t) {
            throw f.value = null, i(t), t
        }
    }
    async function Q(e = 0) {
        try {
            return (await n.ApiPayments.fetchCalcCommission({
                amount: e
            })).data
        } catch (t) {
            throw i(t), t
        }
    }
    async function U(e) {
        try {
            const t = await n.ApiPayments.fetchWithdrawMethodFields(e);
            return d.value = t.data, t.data
        } catch (t) {
            throw d.value = null, i(t), t
        }
    }
    async function j(e) {
        var t;
        try {
            const a = ["fail", "invalid", "limit", "notConfirmedAccount"],
                s = await n.ApiPayments.createOrderToWithdraw(e),
                {
                    status: r
                } = s.data;
            if (a.includes(r)) {
                let {
                    message: h
                } = s.data;
                throw r === "limit" && (h = ((t = s == null ? void 0 : s.data) == null ? void 0 : t.limit_count) === "1" ? c.t("dialogs.withdrawOnceDay.text") : c.t("withdraw.withdrawLimits", {
                    limit: s.data.limit_count
                })), new Error(h)
            }
            return u.value = "success", s.data
        } catch (a) {
            throw u.value = "fail", x({
                code: 400,
                message: a == null ? void 0 : a.toString()
            }), i(a), a
        } finally {
            E.value = !1
        }
    }
    async function G(e) {
        try {
            const t = await n.ApiPayments.fetchDataForCrypto(e);
            return p.value = t.data, t.data
        } catch (t) {
            throw i(t), t
        }
    }
    async function J(e) {
        if (l.value.length) return l.value;
        try {
            const t = await n.ApiPayments.fetchPaymentMethodsImages(e);
            return l.value = t.data, t.data
        } catch (t) {
            throw i(t), t
        }
    }
    async function K(e) {
        try {
            const a = (await n.ApiPayments.fetchDepositStatus(e)).data,
                s = a.transaction_info;
            return a && a.status === "success" && (O(s.status === "processing" ? "in_queue" : s.status), M.value = s.title, A.value = s.text), a.data
        } catch (t) {
            throw i(t), t
        }
    }
    async function V(e) {
        try {
            const a = (await n.ApiPayments.fetchWithdrawOrderStatus(e)).data,
                s = a.transaction_info;
            return a && a.status === "success" && (u.value = s.status === "processing" ? "in_queue" : s.status), a.data
        } catch (t) {
            throw i(t), t
        }
    }
    async function X(e) {
        try {
            const t = await n.ApiPayments.fetchDepositMessengers({
                token: e
            });
            return _.value = t.data, t.data
        } catch (t) {
            throw i(t), t
        }
    }
    async function Y(e, t) {
        try {
            const a = {
                "pagination[limit]": t || 10,
                "pagination[page]": e,
                desc: "created_at"
            };
            return (await n.ApiPayments.fetchDepositHistory(a)).data
        } catch (a) {
            throw i(a), a
        }
    }
    return {
        withdrawMethods: f,
        depositMethods: g,
        withdrawOrderCreatingStatus: u,
        depositProcessStatus: P,
        setDepositProcessStatus: O,
        depositTransactionData: y,
        setDepositTransactionData: F,
        depositResultText: A,
        depositResultTitle: M,
        currentDepositProcessComponent: T,
        displayDepositProcessComponent: W,
        setQRcodeData: k,
        setSelectDepositMethod: H,
        paymentMethodsImages: l,
        depositCryptoData: p,
        setDepositCryptoData: N,
        selectedDepositMethod: v,
        qrCodeData: S,
        messengersData: _,
        sumToDeposit: C,
        setSumToDeposit: q,
        withdrawMethodFields: w(() => {
            var e;
            return (e = d.value) == null ? void 0 : e.fields
        }),
        withdrawMethodTexts: w(() => {
            var e;
            return (e = d.value) == null ? void 0 : e.texts
        }),
        paykassmaMethods: w(() => {
            var e, t, a, s, r;
            return (r = (s = (a = (t = (e = y.value) == null ? void 0 : e.show_fields) == null ? void 0 : t.upi_method_type) == null ? void 0 : a.params) == null ? void 0 : s.options) == null ? void 0 : r.map(h => h.value)
        }),
        setDepositOrWithdrawDialog: e => D.value = e,
        depositOrWithdrawDialog: D,
        identifierPayment: B,
        fetchDepositMethods: $,
        fetchWithdrawMethodsList: z,
        fetchCalcCommission: Q,
        fetchWithdrawMethodFields: U,
        createOrderToWithdraw: j,
        fetchDataForCrypto: G,
        fetchPaymentMethodsImages: J,
        fetchDepositStatus: K,
        fetchWithdrawOrderStatus: V,
        paykassmaMethodImage: b,
        savePaykassmaMethodImage: L,
        fetchDepositMessengers: X,
        fetchDepositHistory: Y,
        setDepositProcessStep: R,
        depositProcessStep: I
    }
});
export {
    rt as u
};