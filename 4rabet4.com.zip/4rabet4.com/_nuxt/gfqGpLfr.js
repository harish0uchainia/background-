import {
    p as N,
    u as D,
    b as L,
    m as O
} from "./DVkCUlFY.js";
import {
    R as P,
    bq as $,
    z as V,
    u as C,
    v as R,
    o as U,
    _ as H
} from "./BbvgifQp.js";
import {
    z,
    Z as M,
    d as c,
    b as T,
    B as j,
    _ as f,
    V as m,
    a8 as F,
    F as q,
    a9 as G,
    J,
    u as y,
    k as Z,
    D as K
} from "./BBZLTf3A.js";
import {
    u as Q
} from "./Eh0EvCQt.js";
(function() {
    try {
        var t = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            a = new t.Error().stack;
        a && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[a] = "bf4bacda-fde8-414f-91a3-c429531bb1d1", t._sentryDebugIdIdentifier = "sentry-dbid-bf4bacda-fde8-414f-91a3-c429531bb1d1")
    } catch {}
})();
const W = ["type", "sizes", "srcset"],
    X = ["src", "sizes", "srcset"],
    Y = z({
        __name: "NuxtPicture",
        props: N,
        emits: ["load", "error"],
        setup(t, {
            emit: a
        }) {
            const s = t,
                o = M(),
                i = a,
                v = !1,
                u = P(),
                {
                    attrs: x,
                    options: p,
                    modifiers: d
                } = D(s),
                r = c(() => $(s.src)),
                _ = c(() => ["png", "webp", "gif", "svg"].includes(r.value)),
                g = c(() => s.legacyFormat ? s.legacyFormat : _.value ? "png" : "jpeg"),
                I = c(() => {
                    var h, n;
                    const e = ((h = s.format) == null ? void 0 : h.split(",")) || (r.value === "svg" ? ["svg"] : (n = u.options.format) != null && n.length ? [...u.options.format] : ["webp"]);
                    return e[0] === "svg" ? [{
                        src: s.src
                    }] : (e.includes(g.value) && e.splice(e.indexOf(g.value), 1), e.push(g.value), e.map(k => {
                        const {
                            srcset: B,
                            sizes: E,
                            src: S
                        } = u.getSizes(s.src, { ...p.value,
                            sizes: s.sizes || u.options.screens,
                            densities: s.densities,
                            modifiers: { ...d.value,
                                format: k
                            }
                        });
                        return {
                            src: S,
                            type: `image/${k}`,
                            sizes: E,
                            srcset: B
                        }
                    }))
                }),
                b = c(() => I.value[I.value.length - 1]),
                A = { ...s.imgAttrs,
                    "data-nuxt-pic": ""
                };
            for (const e in o) e in L && !(e in A) && (A[e] = o[e]);
            const l = T(),
                w = V().isHydrating;
            return j(() => {
                l.value && (l.value.complete && w && (l.value.getAttribute("data-error") ? i("error", new Event("error")) : i("load", new Event("load"))), l.value.onload = e => {
                    i("load", e)
                }, l.value.onerror = e => {
                    i("error", e)
                }, O("nuxt-picture"))
            }), (e, h) => (m(), f("picture", null, [(m(!0), f(q, null, G(I.value.slice(0, -1), n => (m(), f("source", {
                key: n.src,
                type: n.type,
                sizes: n.sizes,
                srcset: n.srcset
            }, null, 8, W))), 128)), b.value ? (m(), f("img", J({
                key: 0,
                ref_key: "imgEl",
                ref: l
            }, { ...y(x),
                ...y(v) ? {
                    onerror: "this.setAttribute('data-error', 1)"
                } : {},
                ...A
            }, {
                src: b.value.src,
                sizes: b.value.sizes,
                srcset: b.value.srcset
            }), null, 16, X)) : F("", !0)]))
        }
    }),
    ee = {
        key: 0,
        class: "bonus-available"
    },
    se = z({
        __name: "SlotItemBonusAvailable",
        props: {
            slotItem: {}
        },
        setup(t) {
            const a = t,
                {
                    config: s
                } = C(),
                {
                    slotItem: o
                } = Z(a),
                {
                    imageUrl: i
                } = Q(),
                {
                    globalBonusId: v,
                    bonusOnlyForSelectedCasinoSlots: u
                } = R(U()),
                x = c(() => {
                    var p, d, r, _;
                    return v.value ? u.value ? (d = (p = o.value) == null ? void 0 : p.allowed_bonus_ids) == null ? void 0 : d.includes(v.value) : s.value.OLD_FLAG_BONUS_AVAILABLE ? (r = o.value) == null ? void 0 : r.is_bonus_available : (_ = o.value) == null ? void 0 : _.is_general_bonus_available : !1
                });
            return (p, d) => {
                const r = Y;
                return y(x) ? (m(), f("div", ee, [K(r, {
                    src: `${y(i)}/bonuses/gift.png?v=2`,
                    alt: "bonus_available"
                }, null, 8, ["src"])])) : F("", !0)
            }
        }
    }),
    ie = H(se, [
        ["__scopeId", "data-v-bd443061"]
    ]),
    ue = (t = "", a) => {
        const s = t.trimEnd().lastIndexOf("| only fake") !== -1;
        return a ? !0 : !s
    };
export {
    ie as _, ue as c
};