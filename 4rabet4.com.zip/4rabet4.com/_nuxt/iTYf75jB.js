import {
    W as D,
    ad as p,
    aA as ee,
    Y as $,
    af as le,
    ab as K,
    U as B,
    a7 as L,
    a8 as F,
    ai as te,
    a4 as M,
    aj as ae,
    a9 as ne,
    l as oe,
    an as ue,
    aD as x,
    aH as ie,
    aK as re,
    aT as se,
    a2 as ce,
    b1 as _,
    aa as de,
    aL as T,
    b2 as fe,
    aQ as H,
    au as ve,
    b3 as me
} from "./BbvgifQp.js";
import {
    d as c,
    t as g,
    D as V,
    I as q,
    o as ye,
    y as R,
    b as W,
    J as h,
    Y as be,
    ar as ge,
    F as Ce,
    i as Y,
    n as z,
    p as Ve,
    q as ke,
    w as Se
} from "./BBZLTf3A.js";
import {
    d as we
} from "./CNgVgUb9.js";
import {
    b as N,
    c as j,
    m as Ie,
    a as Ae
} from "./D9sqA5Xl.js";
import {
    f as Ee
} from "./CbxP4vag.js";
import {
    u as he
} from "./B9YIqgoQ.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            s = new e.Error().stack;
        s && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[s] = "bb74b56f-c7f8-4c7d-a637-26856d3ce205", e._sentryDebugIdIdentifier = "sentry-dbid-bb74b56f-c7f8-4c7d-a637-26856d3ce205")
    } catch {}
})();
const J = Symbol.for("vuetify:selection-control-group"),
    Q = D({
        color: String,
        disabled: {
            type: Boolean,
            default: null
        },
        defaultsTarget: String,
        error: Boolean,
        id: String,
        inline: Boolean,
        falseIcon: K,
        trueIcon: K,
        ripple: {
            type: [Boolean, Object],
            default: !0
        },
        multiple: {
            type: Boolean,
            default: null
        },
        name: String,
        readonly: {
            type: Boolean,
            default: null
        },
        modelValue: null,
        type: String,
        valueComparator: {
            type: Function,
            default: le
        },
        ...$(),
        ...ee(),
        ...p()
    }, "SelectionControlGroup"),
    De = D({ ...Q({
            defaultsTarget: "VSelectionControl"
        })
    }, "VSelectionControlGroup"),
    Ge = B()({
        name: "VSelectionControlGroup",
        props: De(),
        emits: {
            "update:modelValue": e => !0
        },
        setup(e, s) {
            let {
                slots: d
            } = s;
            const t = L(e, "modelValue"),
                i = F(),
                y = c(() => e.id || `v-selection-control-group-${i}`),
                v = c(() => e.name || y.value),
                o = new Set;
            return q(J, {
                modelValue: t,
                forceUpdate: () => {
                    o.forEach(a => a())
                },
                onForceUpdate: a => {
                    o.add(a), ye(() => {
                        o.delete(a)
                    })
                }
            }), te({
                [e.defaultsTarget]: {
                    color: g(e, "color"),
                    disabled: g(e, "disabled"),
                    density: g(e, "density"),
                    error: g(e, "error"),
                    inline: g(e, "inline"),
                    modelValue: t,
                    multiple: c(() => !!e.multiple || e.multiple == null && Array.isArray(t.value)),
                    name: v,
                    falseIcon: g(e, "falseIcon"),
                    trueIcon: g(e, "trueIcon"),
                    readonly: g(e, "readonly"),
                    ripple: g(e, "ripple"),
                    type: g(e, "type"),
                    valueComparator: g(e, "valueComparator")
                }
            }), M(() => {
                var a;
                return V("div", {
                    class: ["v-selection-control-group", {
                        "v-selection-control-group--inline": e.inline
                    }, e.class],
                    style: e.style,
                    role: e.type === "radio" ? "radiogroup" : void 0
                }, [(a = d.default) == null ? void 0 : a.call(d)])
            }), {}
        }
    }),
    Pe = D({
        label: String,
        baseColor: String,
        trueValue: null,
        falseValue: null,
        value: null,
        ...$(),
        ...Q()
    }, "VSelectionControl");

function xe(e) {
    const s = Y(J, void 0),
        {
            densityClasses: d
        } = ue(e),
        t = L(e, "modelValue"),
        i = c(() => e.trueValue !== void 0 ? e.trueValue : e.value !== void 0 ? e.value : !0),
        y = c(() => e.falseValue !== void 0 ? e.falseValue : !1),
        v = c(() => !!e.multiple || e.multiple == null && Array.isArray(t.value)),
        o = c({
            get() {
                const S = s ? s.modelValue.value : t.value;
                return v.value ? x(S).some(m => e.valueComparator(m, i.value)) : e.valueComparator(S, i.value)
            },
            set(S) {
                if (e.readonly) return;
                const m = S ? i.value : y.value;
                let w = m;
                v.value && (w = S ? [...x(t.value), m] : x(t.value).filter(l => !e.valueComparator(l, i.value))), s ? s.modelValue.value = w : t.value = w
            }
        }),
        {
            textColorClasses: a,
            textColorStyles: u
        } = ie(c(() => {
            if (!(e.error || e.disabled)) return o.value ? e.color : e.baseColor
        })),
        {
            backgroundColorClasses: k,
            backgroundColorStyles: I
        } = re(c(() => o.value && !e.error && !e.disabled ? e.color : e.baseColor)),
        E = c(() => o.value ? e.trueIcon : e.falseIcon);
    return {
        group: s,
        densityClasses: d,
        trueValue: i,
        falseValue: y,
        model: o,
        textColorClasses: a,
        textColorStyles: u,
        backgroundColorClasses: k,
        backgroundColorStyles: I,
        icon: E
    }
}
const Oe = B()({
        name: "VSelectionControl",
        directives: {
            Ripple: ae
        },
        inheritAttrs: !1,
        props: Pe(),
        emits: {
            "update:modelValue": e => !0
        },
        setup(e, s) {
            let {
                attrs: d,
                slots: t
            } = s;
            const {
                group: i,
                densityClasses: y,
                icon: v,
                model: o,
                textColorClasses: a,
                textColorStyles: u,
                backgroundColorClasses: k,
                backgroundColorStyles: I,
                trueValue: E
            } = xe(e), S = F(), m = R(!1), w = R(!1), l = W(), n = c(() => e.id || `input-${S}`), r = c(() => !e.disabled && !e.readonly);
            i == null || i.onForceUpdate(() => {
                l.value && (l.value.checked = o.value)
            });

            function f(C) {
                r.value && (m.value = !0, se(C.target, ":focus-visible") !== !1 && (w.value = !0))
            }

            function b() {
                m.value = !1, w.value = !1
            }

            function A(C) {
                C.stopPropagation()
            }

            function P(C) {
                if (!r.value) {
                    l.value && (l.value.checked = o.value);
                    return
                }
                e.readonly && i && z(() => i.forceUpdate()), o.value = C.target.checked
            }
            return M(() => {
                var G, O;
                const C = t.label ? t.label({
                        label: e.label,
                        props: {
                            for: n.value
                        }
                    }) : e.label,
                    [X, Z] = ne(d),
                    U = V("input", h({
                        ref: l,
                        checked: o.value,
                        disabled: !!e.disabled,
                        id: n.value,
                        onBlur: b,
                        onFocus: f,
                        onInput: P,
                        "aria-disabled": !!e.disabled,
                        "aria-label": e.label,
                        type: e.type,
                        value: E.value,
                        name: e.name,
                        "aria-checked": e.type === "checkbox" ? o.value : void 0
                    }, Z), null);
                return V("div", h({
                    class: ["v-selection-control", {
                        "v-selection-control--dirty": o.value,
                        "v-selection-control--disabled": e.disabled,
                        "v-selection-control--error": e.error,
                        "v-selection-control--focused": m.value,
                        "v-selection-control--focus-visible": w.value,
                        "v-selection-control--inline": e.inline
                    }, y.value, e.class]
                }, X, {
                    style: e.style
                }), [V("div", {
                    class: ["v-selection-control__wrapper", a.value],
                    style: u.value
                }, [(G = t.default) == null ? void 0 : G.call(t, {
                    backgroundColorClasses: k,
                    backgroundColorStyles: I
                }), be(V("div", {
                    class: ["v-selection-control__input"]
                }, [((O = t.input) == null ? void 0 : O.call(t, {
                    model: o,
                    textColorClasses: a,
                    textColorStyles: u,
                    backgroundColorClasses: k,
                    backgroundColorStyles: I,
                    inputNode: U,
                    icon: v.value,
                    props: {
                        onFocus: f,
                        onBlur: b,
                        id: n.value
                    }
                })) ? ? V(Ce, null, [v.value && V(oe, {
                    key: "icon",
                    icon: v.value
                }, null), U])]), [
                    [ge("ripple"), e.ripple && [!e.disabled && !e.readonly, null, ["center", "circle"]]]
                ])]), C && V(we, {
                    for: n.value,
                    onClick: A
                }, {
                    default: () => [C]
                })])
            }), {
                isFocused: m,
                input: l
            }
        }
    }),
    Te = D({
        id: String,
        submenu: Boolean,
        ...de(Ie({
            closeDelay: 250,
            closeOnContentClick: !0,
            locationStrategy: "connected",
            location: void 0,
            openDelay: 300,
            scrim: !1,
            scrollStrategy: "reposition",
            transition: {
                component: Ae
            }
        }), ["absolute"])
    }, "VMenu"),
    Ke = B()({
        name: "VMenu",
        props: Te(),
        emits: {
            "update:modelValue": e => !0
        },
        setup(e, s) {
            let {
                slots: d
            } = s;
            const t = L(e, "modelValue"),
                {
                    scopeId: i
                } = he(),
                {
                    isRtl: y
                } = ce(),
                v = F(),
                o = c(() => e.id || `v-menu-${v}`),
                a = W(),
                u = Y(N, null),
                k = R(new Set);
            q(N, {
                register() {
                    k.value.add(v)
                },
                unregister() {
                    k.value.delete(v)
                },
                closeParents(l) {
                    setTimeout(() => {
                        var n;
                        !k.value.size && !e.persistent && (l == null || (n = a.value) != null && n.contentEl && !me(l, a.value.contentEl)) && (t.value = !1, u == null || u.closeParents())
                    }, 40)
                }
            }), Ve(() => {
                u == null || u.unregister(), document.removeEventListener("focusin", I)
            }), ke(() => t.value = !1);
            async function I(l) {
                var f, b, A;
                const n = l.relatedTarget,
                    r = l.target;
                await z(), t.value && n !== r && ((f = a.value) != null && f.contentEl) && ((b = a.value) != null && b.globalTop) && ![document, a.value.contentEl].includes(r) && !a.value.contentEl.contains(r) && ((A = _(a.value.contentEl)[0]) == null || A.focus())
            }
            Se(t, l => {
                l ? (u == null || u.register(), H && document.addEventListener("focusin", I, {
                    once: !0
                })) : (u == null || u.unregister(), H && document.removeEventListener("focusin", I))
            }, {
                immediate: !0
            });

            function E(l) {
                u == null || u.closeParents(l)
            }

            function S(l) {
                var n, r, f, b, A;
                if (!e.disabled)
                    if (l.key === "Tab" || l.key === "Enter" && !e.closeOnContentClick) {
                        if (l.key === "Enter" && (l.target instanceof HTMLTextAreaElement || l.target instanceof HTMLInputElement && l.target.closest("form"))) return;
                        l.key === "Enter" && l.preventDefault(), fe(_((n = a.value) == null ? void 0 : n.contentEl, !1), l.shiftKey ? "prev" : "next", C => C.tabIndex >= 0) || (t.value = !1, (f = (r = a.value) == null ? void 0 : r.activatorEl) == null || f.focus())
                    } else e.submenu && l.key === (y.value ? "ArrowRight" : "ArrowLeft") && (t.value = !1, (A = (b = a.value) == null ? void 0 : b.activatorEl) == null || A.focus())
            }

            function m(l) {
                var r;
                if (e.disabled) return;
                const n = (r = a.value) == null ? void 0 : r.contentEl;
                n && t.value ? l.key === "ArrowDown" ? (l.preventDefault(), l.stopImmediatePropagation(), T(n, "next")) : l.key === "ArrowUp" ? (l.preventDefault(), l.stopImmediatePropagation(), T(n, "prev")) : e.submenu && (l.key === (y.value ? "ArrowRight" : "ArrowLeft") ? t.value = !1 : l.key === (y.value ? "ArrowLeft" : "ArrowRight") && (l.preventDefault(), T(n, "first"))) : (e.submenu ? l.key === (y.value ? "ArrowLeft" : "ArrowRight") : ["ArrowDown", "ArrowUp"].includes(l.key)) && (t.value = !0, l.preventDefault(), setTimeout(() => setTimeout(() => m(l))))
            }
            const w = c(() => h({
                "aria-haspopup": "menu",
                "aria-expanded": String(t.value),
                "aria-controls": o.value,
                onKeydown: m
            }, e.activatorProps));
            return M(() => {
                const l = j.filterProps(e);
                return V(j, h({
                    ref: a,
                    id: o.value,
                    class: ["v-menu", e.class],
                    style: e.style
                }, l, {
                    modelValue: t.value,
                    "onUpdate:modelValue": n => t.value = n,
                    absolute: !0,
                    activatorProps: w.value,
                    location: e.location ? ? (e.submenu ? "end" : "bottom"),
                    "onClick:outside": E,
                    onKeydown: S
                }, i), {
                    activator: d.activator,
                    default: function() {
                        for (var n = arguments.length, r = new Array(n), f = 0; f < n; f++) r[f] = arguments[f];
                        return V(ve, {
                            root: "VMenu"
                        }, {
                            default: () => {
                                var b;
                                return [(b = d.default) == null ? void 0 : b.call(d, ...r)]
                            }
                        })
                    }
                })
            }), Ee({
                id: o,
                ΨopenChildren: k
            }, a)
        }
    });
export {
    Ke as V, Oe as a, Q as b, Ge as c, Pe as m
};