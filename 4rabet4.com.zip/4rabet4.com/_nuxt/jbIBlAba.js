import {
    _ as a
} from "./quAyFRoR.js";
import {
    bB as r
} from "./BbvgifQp.js";
import {
    u as c
} from "./BUXbqDP0.js";
import {
    z as f,
    _ as d,
    V as u,
    D as _,
    u as p
} from "./BBZLTf3A.js";
import "./Cc4FcFuq.js";
import "./1xKHoBf3.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "0edf9944-1cd8-4873-8753-f7848afb7fa0", e._sentryDebugIdIdentifier = "sentry-dbid-0edf9944-1cd8-4873-8753-f7848afb7fa0")
    } catch {}
})();
const l = {
        class: "registration-dialog"
    },
    h = f({
        __name: "RegistrationDialog",
        setup(e) {
            const {
                showNotification: t
            } = r(), {
                getUserData: o
            } = c(), s = n => {
                t(n)
            };
            return (n, m) => {
                const i = a;
                return u(), d("div", l, [_(i, {
                    "modal-type": "register",
                    "onGet:notification": s,
                    "onGet:responseSuccess": p(o)
                }, null, 8, ["onGet:responseSuccess"])])
            }
        }
    });
export {
    h as
    default
};