const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["./Cq3N6wD0.js", "./BrNfvlGm.js", "./BbvgifQp.js", "./BBZLTf3A.js", "./swiper-vue.OzWMjU4A.css", "./entry.J6UAyoZA.css", "./BuDDDvke.js", "./Ka2RWjod.js", "./D9sqA5Xl.js", "./CbxP4vag.js", "./Q3GHUzCg.js", "./B9YIqgoQ.js", "./BEPDeFGu.js", "./VAvatar.CYkryKM7.css", "./VCard.8Js4-u2y.css", "./CL3SmZKg.js", "./VDialog.Dk_v9Av4.css", "./AppDialog.DACLH303.css", "./CMnmInvQ.js", "./BM8cjqjo.js", "./DHxCvf5R.js", "./DCO7F8HW.js", "./CNgVgUb9.js", "./BulKdswA.js", "./VTextField.DkEWA9Kv.css", "./AppInputWrapper.DCV2SDt0.css", "./CyEI51nD.js", "./AppInputPwd.CrKvjOB5.css", "./Nc2j0qUX.js", "./DDGpYvNX.js", "./iTYf75jB.js", "./VMenu.BwfwrVx9.css", "./BQ7ou4ZQ.js", "./ssrBoot.BsYIg1rJ.css", "./VSelect.BKduvVt_.css", "./VCheckbox.7-tHc5Uf.css", "./DF9zLyti.js", "./VGrid.D0S0a0cH.css", "./BtdAVlWx.js", "./Eh0EvCQt.js", "./Cc4FcFuq.js", "./1xKHoBf3.js", "./BeLlcxC7.js", "./AppSelect.BFNqV6Cj.css", "./RegistrationFormView.BkUWLAY9.css", "./D3cdnUJq.js", "./LoaderSpinner.CgeiAo1r.css", "./DWq0O7ht.js", "./BcxiMhqF.js", "./CNVksA_o.js", "./BQ66EBJG.js", "./CbNZPVTM.js", "./BYAyGWVz.js", "./B99ngSfl.js", "./VTooltip.DtANW6X5.css", "./BkMYWUSc.js", "./RegistrationAdditionDialog.CaPzKN1x.css", "./CBbqpxnU.js", "./Dr6OcbWf.js", "./B4fA6PS_.js", "./RegistrationDialog.zYSOs41W.css", "./BVNRR7vF.js", "./AuthDialog.RgejYO95.css", "./C44sN4r2.js", "./ResetPwdDialog.Dbyx-ggv.css", "./B9IS5qGS.js", "./RegistrationDialogExistsEmail.FNOT27hk.css"]))) => i.map(i => d[i]);
import {
    v as V,
    $ as R,
    x as l
} from "./BbvgifQp.js";
import {
    z as N,
    ah as _,
    I as z,
    b as G,
    d as U,
    w as f,
    p as W,
    U as u,
    V as m,
    W as s,
    $ as a,
    a8 as Y,
    u as i,
    Q as p,
    ai as H,
    af as T,
    ag as h
} from "./BBZLTf3A.js";
(function() {
    try {
        var r = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            y = new r.Error().stack;
        y && (r._sentryDebugIds = r._sentryDebugIds || {}, r._sentryDebugIds[y] = "bbf8708e-ba63-4bc4-a85b-fddfa390217f", r._sentryDebugIdIdentifier = "sentry-dbid-bbf8708e-ba63-4bc4-a85b-fddfa390217f")
    } catch {}
})();
const K = Symbol("landingRegistrationFormType"),
    q = N({
        __name: "LoginRegisterModal",
        props: {
            modalType: {},
            landingRegistrationFormType: {},
            typeRegistration: {},
            hideBanner: {
                type: Boolean
            },
            widthDialog: {}
        },
        emits: ["get:notification", "get:response-success", "get:response-error", "get:validation-error", "get:validation-success"],
        setup(r, {
            emit: y
        }) {
            const D = p(() => l(() =>
                    import ("./Cq3N6wD0.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60]),
                    import.meta.url)),
                E = p(() => l(() =>
                    import ("./BVNRR7vF.js"), __vite__mapDeps([61, 2, 3, 4, 5, 18, 19, 20, 21, 22, 23, 9, 12, 24, 25, 26, 27, 28, 29, 8, 10, 11, 13, 30, 31, 32, 33, 7, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 1, 6, 14, 15, 16, 17, 58, 50, 51, 52, 62]),
                    import.meta.url)),
                S = p(() => l(() =>
                    import ("./C44sN4r2.js"), __vite__mapDeps([63, 3, 4, 18, 2, 5, 19, 20, 21, 22, 23, 9, 12, 24, 25, 26, 27, 28, 29, 8, 10, 11, 13, 30, 31, 32, 33, 7, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 1, 6, 14, 15, 16, 17, 52, 64]),
                    import.meta.url)),
                A = p(() => l(() =>
                    import ("./B9IS5qGS.js"), __vite__mapDeps([65, 3, 4, 2, 5, 18, 19, 20, 21, 22, 23, 9, 12, 24, 25, 26, 27, 28, 29, 8, 10, 11, 13, 30, 31, 32, 33, 7, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 1, 6, 14, 15, 16, 17, 66]),
                    import.meta.url)),
                I = p(() => l(() =>
                    import ("./CMnmInvQ.js").then(e => e.C), __vite__mapDeps([18, 3, 4, 2, 5, 19, 20, 21, 22, 23, 9, 12, 24, 25, 26, 27, 28, 29, 8, 10, 11, 13, 30, 31, 32, 33, 7, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44]),
                    import.meta.url)),
                d = y,
                M = _(),
                {
                    dialogData: $,
                    notification: P,
                    isGoogleSsoSuccess: C,
                    tokenDataUser: F,
                    googleSsoErrors: B
                } = V(R()),
                {
                    changeDialogData: c,
                    displayNotification: L,
                    onUpdateGoogleSsoSuccess: O,
                    setCfCaptchaOption: v
                } = R(),
                b = r;
            z(K, !!b.landingRegistrationFormType);
            const k = G(null),
                g = U(() => {
                    var e;
                    return (e = $.value) != null && e.name ? k.value || b.modalType : null
                }),
                n = (e, o, t = !0) => {
                    k.value = e, v({
                        key: "displayCaptcha",
                        value: !1
                    }), t && e && c({
                        name: e,
                        data: o
                    })
                },
                w = () => {
                    c({
                        name: b.modalType
                    })
                };
            return M.activator || w(), f(() => $.value, e => {
                (!e || e != null && e.name) && n(e == null ? void 0 : e.name, e == null ? void 0 : e.data, !1)
            }), f(() => C.value, e => {
                e && (d("get:response-success", F.value), c(null))
            }), f(() => B.value, e => {
                e && d("get:response-error", B.value)
            }), f(() => P.value, e => {
                e && d("get:notification", e), setTimeout(() => {
                    L(null)
                }, 1e3)
            }), W(() => {
                O(!1), v({
                    key: "displayCaptcha",
                    value: !1
                })
            }), (e, o) => (m(), u(i(I), {
                class: "login-register"
            }, {
                default: s(() => [a(e.$slots, "activator", {
                    handleClick: w
                }), i(g) === "register" ? (m(), u(i(D), {
                    key: 0,
                    listeners: d,
                    "hide-banner": e.hideBanner,
                    "width-dialog": e.widthDialog,
                    "freeze-type-registration": e.typeRegistration,
                    "onDisplay:authModal": o[0] || (o[0] = t => n("login"))
                }, H({
                    _: 2
                }, [e.$slots.customHeader ? {
                    name: "customHeader",
                    fn: s(() => [a(e.$slots, "customHeader")]),
                    key: "0"
                } : void 0, e.$slots.customBodyHeader ? {
                    name: "customBodyHeader",
                    fn: s(() => [a(e.$slots, "customBodyHeader")]),
                    key: "1"
                } : void 0, e.$slots.customActionsHeader ? {
                    name: "customActionsHeader",
                    fn: s(() => [a(e.$slots, "customActionsHeader")]),
                    key: "2"
                } : void 0, e.$slots.customButtonSubmit ? {
                    name: "customButtonSubmit",
                    fn: s(t => [a(e.$slots, "customButtonSubmit", T(h(t)))]),
                    key: "3"
                } : void 0, e.$slots.customBodyFooter ? {
                    name: "customBodyFooter",
                    fn: s(() => [a(e.$slots, "customBodyFooter")]),
                    key: "4"
                } : void 0]), 1032, ["hide-banner", "width-dialog", "freeze-type-registration"])) : i(g) === "login" ? (m(), u(i(E), {
                    key: 1,
                    listeners: d,
                    "hide-banner": e.hideBanner,
                    "width-dialog": e.widthDialog,
                    "onDisplay:registerModal": o[1] || (o[1] = t => n("register")),
                    "onDisplay:resetPwdModal": o[2] || (o[2] = t => n("reset-pwd", t))
                }, H({
                    _: 2
                }, [e.$slots.customHeader ? {
                    name: "customHeader",
                    fn: s(() => [a(e.$slots, "customHeader")]),
                    key: "0"
                } : void 0, e.$slots.customBodyHeader ? {
                    name: "customBodyHeader",
                    fn: s(() => [a(e.$slots, "customBodyHeader")]),
                    key: "1"
                } : void 0, e.$slots.customActionsHeader ? {
                    name: "customActionsHeader",
                    fn: s(() => [a(e.$slots, "customActionsHeader")]),
                    key: "2"
                } : void 0, e.$slots.customButtonSubmit ? {
                    name: "customButtonSubmit",
                    fn: s(t => [a(e.$slots, "customButtonSubmit", T(h(t)))]),
                    key: "3"
                } : void 0, e.$slots.customBodyFooter ? {
                    name: "customBodyFooter",
                    fn: s(() => [a(e.$slots, "customBodyFooter")]),
                    key: "4"
                } : void 0]), 1032, ["hide-banner", "width-dialog"])) : i(g) === "reset-pwd" ? (m(), u(i(S), {
                    key: 2,
                    listeners: d,
                    "onDisplay:authModal": o[3] || (o[3] = t => n("login"))
                })) : i(g) === "register-exist" ? (m(), u(i(A), {
                    key: 3,
                    "onDisplay:authModal": o[4] || (o[4] = t => n("login")),
                    "onDisplay:registerModal": o[5] || (o[5] = t => n("register")),
                    "onDisplay:resetPwdModal": o[6] || (o[6] = t => n("reset-pwd", t))
                })) : Y("", !0)]),
                _: 3
            }))
        }
    });
export {
    K as L, q as _
};