import {
    b as n
} from "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "340b761a-fb6d-4c9a-87b6-587090b1d936", e._sentryDebugIdIdentifier = "sentry-dbid-340b761a-fb6d-4c9a-87b6-587090b1d936")
    } catch {}
})();

function u() {
    const e = n("");
    return e.value = localStorage.getItem("accountId") || "", {
        setAccountId: c => {
            localStorage.setItem("accountId", c), e.value = c
        },
        getAccountId: () => e.value,
        clearAccountId: () => {
            localStorage.removeItem("accountId"), e.value = ""
        }
    }
}
export {
    u
};