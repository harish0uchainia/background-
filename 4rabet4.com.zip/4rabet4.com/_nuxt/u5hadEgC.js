import {
    u as R,
    a as b,
    i as T,
    b as I
} from "./BbvgifQp.js";
import "./BBZLTf3A.js";
(function() {
    try {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
            u = new e.Error().stack;
        u && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[u] = "d1c1d50f-63d2-47c0-ae2f-778f50249e76", e._sentryDebugIdIdentifier = "sentry-dbid-d1c1d50f-63d2-47c0-ae2f-778f50249e76")
    } catch {}
})();
const o = b(),
    {
        config: y
    } = R(),
    D = [429],
    O = 20;
var E, S;
o.public.env.SENTRY_DSN && ((E = y.value) != null && E.IS_SENTRY_ON) && T({
    dsn: o.public.env.SENTRY_DSN,
    debug: o.public.env.NUXT_ENV_ENVIRONMENT === "dev" && ((S = y.value) == null ? void 0 : S.IS_SENTRY_DEBUG_ON),
    environment: o.public.env.NUXT_ENV_ENVIRONMENT,
    tracesSampleRate: o.public.env.NUXT_ENV_ENVIRONMENT === "prod" ? .01 : .1,
    beforeSend(e, u) {
        var c, d, f, N, p, _;
        const i = u.originalException,
            g = s => s !== null && typeof s == "object" && "response" in s,
            v = s => s !== null && typeof s == "object" && "status" in s;
        if (g(i) && v(i.response) && D.includes(i.response.status)) return null;
        const n = (d = (c = e.exception) == null ? void 0 : c.values) == null ? void 0 : d[0],
            r = (N = (f = n == null ? void 0 : n.stacktrace) == null ? void 0 : f.frames) == null ? void 0 : N[0],
            l = ((p = e.fingerprint) == null ? void 0 : p.join("|")) ? ? `${(n==null?void 0:n.type)??""}:${(n==null?void 0:n.value)??""}:${(r==null?void 0:r.filename)??""}:${(r==null?void 0:r.lineno)??""}:${((_=e.request)==null?void 0:_.url)??""}:${e.transaction??""}`,
            t = I("sent_sentry_errors", {
                maxAge: 3600,
                path: "/",
                sameSite: "strict"
            });
        Array.isArray(t.value) || (t.value = []);
        const a = Array.isArray(t.value) ? t.value : JSON.parse(t.value);
        return a.includes(l) ? null : (a.length >= O && a.shift(), t.value = [...a, l], e)
    }
});